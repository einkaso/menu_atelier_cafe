import { createHmac, timingSafeEqual } from "node:crypto";
import type { CashSnapshot } from "./cash-day";

type FrozenCashSnapshot = {
  employeeId: string;
  dayId: number;
  checkpointId: number | null;
  snapshot: CashSnapshot;
  registerEvent: { id: string; state: string; amount: string; createdAt: string } | null;
  expires: number;
};

function signature(payload: string) {
  const secret = process.env.WAITER_SESSION_SECRET ?? process.env.ADMIN_SESSION_SECRET;
  if (!secret) throw new Error("Cash snapshot signing secret is not configured");
  return createHmac("sha256", secret).update(`cash-snapshot:${payload}`).digest();
}

export function signCashSnapshot(value: Omit<FrozenCashSnapshot, "expires">, now = Date.now()) {
  const payload = Buffer.from(JSON.stringify({ ...value, expires: now + 4 * 60 * 60 * 1000 })).toString("base64url");
  return `${payload}.${signature(payload).toString("base64url")}`;
}

export function readCashSnapshot(token: unknown, employeeId: string, dayId: number, now = Date.now()): FrozenCashSnapshot | null {
  if (typeof token !== "string" || token.length > 100_000) return null;
  try {
    const [payload, encodedSignature, extra] = token.split(".");
    if (!payload || !encodedSignature || extra) return null;
    const received = Buffer.from(encodedSignature, "base64url");
    const expected = signature(payload);
    if (received.length !== expected.length || !timingSafeEqual(received, expected)) return null;
    const value = JSON.parse(Buffer.from(payload, "base64url").toString()) as FrozenCashSnapshot;
    return value.employeeId === employeeId && value.dayId === dayId && value.expires > now ? value : null;
  } catch {
    return null;
  }
}
