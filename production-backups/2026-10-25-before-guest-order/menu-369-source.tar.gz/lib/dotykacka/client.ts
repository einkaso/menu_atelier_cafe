import "server-only";
import {stockStatusTarget} from "./status-url";
import { mergePaymentReportRevenue } from "../cash-day";
import type { DotykackaCategory, DotykackaConfig, DotykackaDeliveryNote, DotykackaEmployee, DotykackaMoneyLog, DotykackaNamedEntity, DotykackaOrder, DotykackaOrderItem, DotykackaPosActionResponse, DotykackaProduct, DotykackaProductCustomization, DotykackaSalesReport, DotykackaStockProduct, DotykackaStockTakingResponse, DotykackaStockTakingStatus, DotykackaSupplier, DotykackaTable, DotykackaWebhook } from "./types";

type Page<T> = T[] | { data?: T[]; items?: T[]; page?: number; pages?: number; totalPages?: number };

export class DotykackaClient {
  private accessToken?: string;
  constructor(private readonly config: DotykackaConfig) {}

  private async token() {
    if (this.accessToken) return this.accessToken;
    const response = await fetch(`${this.config.apiUrl}/signin/token`, {
      method: "POST",
      headers: { Authorization: `User ${this.config.refreshToken}`, "Content-Type": "application/json" },
      body: JSON.stringify({ _cloudId: this.config.cloudId }),
      cache: "no-store",
      signal: AbortSignal.timeout(this.config.timeoutMs),
    });
    if (!response.ok) throw new Error(`Dotykačka authorization failed (${response.status})`);
    const body = await response.json() as { accessToken?: string };
    if (!body.accessToken) throw new Error("Dotykačka did not return an access token");
    this.accessToken = body.accessToken;
    return body.accessToken;
  }

  private async request<T>(path: string, init?: { method?: string; body?: unknown; timeoutMs?: number; headers?: Record<string, string> }): Promise<T> {
    const accessToken = await this.token();
    const response = await fetch(`${this.config.apiUrl}${path}`, {
      method: init?.method ?? "GET",
      headers: { Authorization: `Bearer ${accessToken}`, Accept: "application/json", ...(init?.body === undefined ? {} : { "Content-Type": "application/json" }), ...(init?.headers ?? {}) },
      body: init?.body === undefined ? undefined : JSON.stringify(init.body),
      cache: "no-store",
      signal: AbortSignal.timeout(init?.timeoutMs ?? this.config.timeoutMs),
    });
    if (!response.ok) {
      const details = (await response.text()).replace(/\s+/g, " ").trim().slice(0, 600);
      throw new Error(`Dotykačka request failed (${response.status})${details ? `: ${details}` : ""}`);
    }
    return response.json() as Promise<T>;
  }

  private async all<T>(path: string, requireComplete = false, stopAfter?: (items: T[]) => boolean): Promise<T[]> {
    const limit = 100;
    const result: T[] = [];
    for (let page = 1; page <= 100; page += 1) {
      const separator = path.includes("?") ? "&" : "?";
      const body = await this.request<Page<T>>(`${path}${separator}page=${page}&limit=${limit}`);
      if (requireComplete && !Array.isArray(body) && !Array.isArray(body.data) && !Array.isArray(body.items)) throw new Error("Dotykačka zwróciła niepełną odpowiedź raportu.");
      const items = Array.isArray(body) ? body : body.data ?? body.items ?? [];
      result.push(...items);
      if (stopAfter?.(items)) return result;
      const totalPages = Array.isArray(body) ? undefined : body.totalPages ?? body.pages;
      if (!items.length || items.length < limit || (totalPages && page >= totalPages)) return result;
    }
    if (requireComplete) throw new Error("Zbyt wiele rachunków. Wybierz krótszy okres raportu.");
    return result;
  }

  categories() {
    return this.all<DotykackaCategory>(`/clouds/${this.config.cloudId}/categories`);
  }

  products() {
    return this.all<DotykackaProduct>(`/clouds/${this.config.cloudId}/products`);
  }

  async updateProductPromo(productId: string, featured: boolean) {
    if (!/^\d+$/.test(productId) || !Number.isSafeInteger(Number(productId))) throw new Error("Nieprawidłowy identyfikator produktu Dotykački.");
    const path = `/clouds/${this.config.cloudId}/products/${productId}`;
    const headers = { Authorization: `Bearer ${await this.token()}`, Accept: "application/json" };
    const read = () => fetch(`${this.config.apiUrl}${path}`, { headers, cache: "no-store", signal: AbortSignal.timeout(this.config.timeoutMs) });
    const response = await read();
    if (!response.ok) throw new Error(`Nie udało się pobrać produktu z Dotykački (${response.status}).`);
    const current = await response.json() as DotykackaProduct;
    if (current.deleted) throw new Error("Nie można polecać produktu usuniętego w Dotykačce.");
    const isPromo = (tag: string) => tag.trim().toLocaleLowerCase("pl") === "promo";
    const tags = current.tags ?? [];
    if (tags.some(isPromo) === featured) return { product: current, changed: false };
    const etag = response.headers.get("etag");
    if (!etag) throw new Error("Dotykačka nie zwróciła wersji produktu. Polecenie nie zostało zmienione.");
    const nextTags = [...tags.filter(tag => !isPromo(tag)), ...(featured ? ["PROMO"] : [])];
    const updated = await fetch(`${this.config.apiUrl}${path}`, {
      method: "PATCH", headers: { ...headers, "Content-Type": "application/json", "If-Match": etag },
      body: JSON.stringify({ id: Number(productId), tags: nextTags }), cache: "no-store", signal: AbortSignal.timeout(this.config.timeoutMs),
    });
    if (!updated.ok) throw new Error(updated.status === 409 || updated.status === 412
      ? "Produkt zmienił się w Dotykačce. Odśwież i spróbuj ponownie."
      : `Nie udało się zapisać tagu PROMO w Dotykačce (${updated.status}).`);
    const verified = await read();
    if (!verified.ok) throw new Error("Nie udało się potwierdzić tagu PROMO. Spróbuj ponownie.");
    const product = await verified.json() as DotykackaProduct;
    if ((product.tags ?? []).some(isPromo) !== featured) throw new Error("Dotykačka nie potwierdziła zmiany tagu PROMO.");
    return { product, changed: true };
  }

  async updateProductDisplay(productId: string, display: boolean) {
    if (!/^\d+$/.test(productId) || !Number.isSafeInteger(Number(productId))) throw new Error("Nieprawidłowy identyfikator produktu Dotykački.");
    const accessToken = await this.token();
    const path = `/clouds/${this.config.cloudId}/products/${productId}`;
    const headers = { Authorization: `Bearer ${accessToken}`, Accept: "application/json" };
    const currentResponse = await fetch(`${this.config.apiUrl}${path}`, {
      headers,
      cache: "no-store",
      signal: AbortSignal.timeout(this.config.timeoutMs),
    });
    if (!currentResponse.ok) {
      const details = (await currentResponse.text()).replace(/\s+/g, " ").trim().slice(0, 600);
      throw new Error(`Nie udało się pobrać produktu z Dotykački (${currentResponse.status})${details ? `: ${details}` : ""}`);
    }
    const current = await currentResponse.json() as DotykackaProduct;
    if (current.deleted) throw new Error("Produkt jest usunięty w Dotykačce i nie można zmienić jego widoczności.");
    if (current.display === display) return { product: current, changed: false };
    const etag = currentResponse.headers.get("etag");
    if (!etag) throw new Error("Dotykačka nie zwróciła wersji produktu. Widoczność nie została zmieniona.");

    const updateResponse = await fetch(`${this.config.apiUrl}${path}`, {
      method: "PATCH",
      headers: { ...headers, "Content-Type": "application/json", "If-Match": etag },
      body: JSON.stringify({ id: Number(productId), display }),
      cache: "no-store",
      signal: AbortSignal.timeout(this.config.timeoutMs),
    });
    if (!updateResponse.ok) {
      const details = (await updateResponse.text()).replace(/\s+/g, " ").trim().slice(0, 600);
      if (updateResponse.status === 409 || updateResponse.status === 412) throw new Error("Produkt zmienił się w Dotykačce. Odśwież menu i spróbuj ponownie.");
      throw new Error(`Nie udało się zmienić widoczności w Dotykačce (${updateResponse.status})${details ? `: ${details}` : ""}`);
    }

    const verifiedResponse = await fetch(`${this.config.apiUrl}${path}`, {
      headers,
      cache: "no-store",
      signal: AbortSignal.timeout(this.config.timeoutMs),
    });
    if (!verifiedResponse.ok) throw new Error("Zmiana została wysłana, ale nie udało się potwierdzić stanu produktu w Dotykačce.");
    const product = await verifiedResponse.json() as DotykackaProduct;
    if (product.display !== display) throw new Error("Dotykačka nie potwierdziła zmiany widoczności produktu.");
    return { product, changed: true };
  }

  taxes() {
    return this.all<{ id: number; name: string; value: number; deleted: boolean; flags: number }>(`/clouds/${this.config.cloudId}/taxes`);
  }

  async productForUpdate(id: string) {
    if (!/^\d+$/.test(id)) throw new Error("Invalid product ID");
    const response = await fetch(`${this.config.apiUrl}/clouds/${this.config.cloudId}/products/${id}`, {
      headers: { Authorization: `Bearer ${await this.token()}`, Accept: "application/json", "Allow-Version": "BC2" },
      cache: "no-store",
      signal: AbortSignal.timeout(this.config.timeoutMs),
    });
    if (!response.ok) throw new Error("Product read failed");
    return { product: await response.json() as DotykackaProduct, etag: response.headers.get("etag") };
  }

  createTicketProduct(product: Record<string, unknown>) {
    return this.request<DotykackaProduct[]>(`/clouds/${this.config.cloudId}/products`, { method: "POST", body: [product], headers: { "Allow-Version": "BC2" } });
  }

  async updateTicketProduct(id: string, etag: string, product: Record<string, unknown>) {
    if (!/^\d+$/.test(id) || !etag) throw new Error("Product version is required");
    const response = await fetch(`${this.config.apiUrl}/clouds/${this.config.cloudId}/products/${id}`, {
      method: "PATCH",
      headers: { Authorization: `Bearer ${await this.token()}`, "Content-Type": "application/json", "If-Match": etag, "Allow-Version": "BC2" },
      body: JSON.stringify(product),
      cache: "no-store",
      signal: AbortSignal.timeout(this.config.timeoutMs),
    });
    if (!response.ok) throw new Error("Product update failed");
    return response.json() as Promise<DotykackaProduct>;
  }

  productCustomizations() {
    return this.all<DotykackaProductCustomization>(`/clouds/${this.config.cloudId}/product-customizations`);
  }

  suppliers() {
    return this.all<DotykackaSupplier>(`/clouds/${this.config.cloudId}/suppliers`);
  }

  deliveryNotes() {
    return this.all<DotykackaDeliveryNote>(`/clouds/${this.config.cloudId}/delivery-notes`);
  }

  async deliveryNoteDocument(url: string) {
    const parsed = new URL(url);
    if (parsed.protocol !== "https:") throw new Error("Dotykačka returned an unsafe delivery note URL");
    const response = await fetch(parsed, { cache: "no-store", signal: AbortSignal.timeout(this.config.timeoutMs) });
    if (!response.ok) throw new Error(`Delivery note download failed (${response.status})`);
    const declaredSize = Number(response.headers.get("content-length") ?? 0);
    if (declaredSize > 2_000_000) throw new Error("Delivery note document is too large");
    const text = await response.text();
    if (text.length > 2_000_000) throw new Error("Delivery note document is too large");
    return text;
  }

  warehouses() {
    return this.all<DotykackaNamedEntity>(`/clouds/${this.config.cloudId}/warehouses`);
  }

  branches() {
    return this.all<DotykackaNamedEntity>(`/clouds/${this.config.cloudId}/branches`);
  }

  employees() {
    return this.all<DotykackaEmployee>(`/clouds/${this.config.cloudId}/employees`);
  }

  async assignEmployeeBarcode(employeeId: string, proposedBarcode: string) {
    if (!/^\d+$/.test(employeeId) || !Number.isSafeInteger(Number(employeeId))) throw new Error("Invalid Dotykačka employee id");
    if (!/^[A-Z0-9-]{8,180}$/.test(proposedBarcode)) throw new Error("Invalid employee barcode");
    const accessToken = await this.token();
    const path = `/clouds/${this.config.cloudId}/employees/${employeeId}`;
    const headers = { Authorization: `Bearer ${accessToken}`, Accept: "application/json" };
    const currentResponse = await fetch(`${this.config.apiUrl}${path}`, {
      headers,
      cache: "no-store",
      signal: AbortSignal.timeout(this.config.timeoutMs),
    });
    if (!currentResponse.ok) {
      const details = (await currentResponse.text()).replace(/\s+/g, " ").trim().slice(0, 600);
      throw new Error(`Nie udało się pobrać pracownika z Dotykački (${currentResponse.status})${details ? `: ${details}` : ""}`);
    }
    const current = await currentResponse.json() as DotykackaEmployee;
    const existingBarcode = String(current.barcode ?? current.barCode ?? current.ean ?? "").trim();
    if (existingBarcode) return { employee: current, barcode: existingBarcode, created: false };
    const etag = currentResponse.headers.get("etag");
    if (!etag) throw new Error("Dotykačka nie zwróciła wersji rekordu pracownika. Kod nie został zmieniony.");

    const updateResponse = await fetch(`${this.config.apiUrl}${path}`, {
      method: "PATCH",
      headers: { ...headers, "Content-Type": "application/json", "If-Match": etag },
      body: JSON.stringify({ id: Number(employeeId), barcode: proposedBarcode }),
      cache: "no-store",
      signal: AbortSignal.timeout(this.config.timeoutMs),
    });
    if (!updateResponse.ok) {
      const details = (await updateResponse.text()).replace(/\s+/g, " ").trim().slice(0, 600);
      if (updateResponse.status === 409 || updateResponse.status === 412) throw new Error("Dane pracownika zmieniły się w Dotykačce. Odśwież listę i spróbuj ponownie.");
      throw new Error(`Nie udało się zapisać kodu w Dotykačce (${updateResponse.status})${details ? `: ${details}` : ""}`);
    }

    const verifiedResponse = await fetch(`${this.config.apiUrl}${path}`, {
      headers,
      cache: "no-store",
      signal: AbortSignal.timeout(this.config.timeoutMs),
    });
    if (!verifiedResponse.ok) throw new Error("Kod został wysłany, ale nie udało się potwierdzić zapisu w Dotykačce.");
    const employee = await verifiedResponse.json() as DotykackaEmployee;
    const barcode = String(employee.barcode ?? employee.barCode ?? employee.ean ?? "").trim();
    if (barcode !== proposedBarcode) throw new Error("Dotykačka nie potwierdziła zapisu wygenerowanego kodu pracownika.");
    return { employee, barcode, created: true };
  }

  tables() {
    return this.all<DotykackaTable>(`/clouds/${this.config.cloudId}/tables`);
  }

  recentClosedOrders(since: Date) {
    const filters = [`status|eq|closed`, `completed|gteq|${since.toISOString()}`];
    if (this.config.branchId) filters.push(`_branchId|eq|${this.config.branchId}`);
    const query = new URLSearchParams({ filter: filters.join(";"), sort: "-completed" });
    return this.all<DotykackaOrder>(`/clouds/${this.config.cloudId}/orders?${query}`);
  }

  closedOrdersRange(from: Date, to: Date) {
    if (!this.config.branchId) throw new Error("Wybierz oddział Dotykački przed generowaniem raportu.");
    const filter = [`status|eq|closed`, `completed|gteq|${from.toISOString()}`, `completed|lt|${to.toISOString()}`, `_branchId|eq|${this.config.branchId}`].join(";");
    const query = new URLSearchParams({ filter, sort: "completed" });
    return this.all<DotykackaOrder>(`/clouds/${this.config.cloudId}/orders?${query}`, true);
  }

  async closedOrderDetail(orderId: string) {
    if (!/^\d+$/.test(orderId)) throw new Error("Invalid Dotykačka order id");
    const itemQuery = new URLSearchParams({ filter: `_orderId|eq|${orderId}`, sort: "created" });
    const paymentQuery = new URLSearchParams({ filter: `_orderId|eq|${orderId}`, sort: "created" });
    const [order, items, payments] = await Promise.all([
      this.request<DotykackaOrder>(`/clouds/${this.config.cloudId}/orders/${orderId}`),
      this.all<DotykackaOrderItem>(`/clouds/${this.config.cloudId}/order-items?${itemQuery}`),
      this.all<DotykackaMoneyLog>(`/clouds/${this.config.cloudId}/money-logs?${paymentQuery}`),
    ]);
    return { order, items, payments };
  }

  registerEvents(since?: Date) {
    if (!this.config.branchId) throw new Error("Dotykačka branch is not configured");
    const filter = [
      `_branchId|eq|${this.config.branchId}`,
      "transactionType|in|REGISTER_OPEN,REGISTER_CLOSE,REGISTER_OPEN_SECONDARY,REGISTER_CLOSE_SECONDARY",
    ].join(";");
    const query = new URLSearchParams({ filter, sort: "-created" });
    return this.all<DotykackaMoneyLog>(`/clouds/${this.config.cloudId}/money-logs?${query}`, true, (items) => !since || items.some((event) => new Date(event.created ?? "").getTime() < since.getTime()));
  }

  salesReport(dateFrom: Date, dateTo: Date) {
    if (!this.config.branchId) return Promise.resolve(null);
    const query = new URLSearchParams({
      vatPayer: "true",
      dateFrom: dateFrom.toISOString(),
      dateTo: dateTo.toISOString(),
      lang: "pl",
    });
    return this.request<DotykackaSalesReport>(`/clouds/${this.config.cloudId}/branches/${this.config.branchId}/sales-report?${query}`);
  }

  async salesReportRange(dateFrom: Date, dateTo: Date) {
    if (!this.config.branchId) return null;
    const windows: Array<[Date, Date]> = [];
    let cursor = dateFrom.getTime();
    const finalTime = dateTo.getTime();
    while (cursor < finalTime) {
      const nextCursor = Math.min(cursor + 24 * 60 * 60 * 1000, finalTime);
      windows.push([new Date(cursor), new Date(nextCursor - 1)]);
      cursor = nextCursor;
    }

    const reports: DotykackaSalesReport[] = [];
    for (let index = 0; index < windows.length; index += 5) {
      const results = await Promise.all(windows.slice(index, index + 5).map(([from, to]) => this.salesReport(from, to)));
      reports.push(...results.filter((report): report is DotykackaSalesReport => Boolean(report)));
    }

    const productSales = new Map<number, NonNullable<DotykackaSalesReport["productSales"]>[number]>();
    for (const report of reports) {
      for (const product of report.productSales ?? []) {
        const previous = productSales.get(product.id);
        productSales.set(product.id, {
          ...product,
          name: product.name || previous?.name || "",
          categoryId: product.categoryId ?? previous?.categoryId ?? null,
          count: Number(previous?.count ?? 0) + Number(product.count ?? 0),
        });
      }
    }
    return {
      revenue: mergePaymentReportRevenue(reports),
      productSales: Array.from(productSales.values()),
    } satisfies DotykackaSalesReport;
  }

  stockProducts() {
    if (!this.config.warehouseId) return Promise.resolve([] as DotykackaStockProduct[]);
    return this.all<DotykackaStockProduct>(`/clouds/${this.config.cloudId}/warehouses/${this.config.warehouseId}/products`);
  }

  posAction(input: Record<string, unknown>) {
    if (!this.config.branchId) throw new Error("Dotykačka branch is not configured");
    return this.request<DotykackaPosActionResponse>(
      `/clouds/${this.config.cloudId}/branches/${this.config.branchId}/pos-actions`,
      { method: "POST", body: input, timeoutMs: Math.max(this.config.timeoutMs, 25_000) },
    );
  }

  stockTakingDates(productIds: number[]) {
    if (!this.config.warehouseId) throw new Error("Dotykačka warehouse is not configured");
    return this.request<Array<{ _productId: number; lastStockTakingDate?: string | number | null }>>(
      `/clouds/${this.config.cloudId}/warehouses/${this.config.warehouseId}/stock-taking-dates`,
      { method: "POST", body: { _productIds: productIds } },
    );
  }

  createStockTaking(input: { note?: string; stockTakingDate: string; items: Array<{ _productId: number; quantity: number }> }) {
    if (!this.config.warehouseId) throw new Error("Dotykačka warehouse is not configured");
    return this.request<DotykackaStockTakingResponse>(
      `/clouds/${this.config.cloudId}/warehouses/${this.config.warehouseId}/stock-takings`,
      { method: "POST", body: input },
    );
  }

  async stockTakingStatus(statusWebhookUrl: string, transactionId?:string) {
    const {url,authenticated}=stockStatusTarget(statusWebhookUrl,this.config.apiUrl,String(this.config.cloudId),transactionId);
    const response = await fetch(url, {
      headers: { ...(authenticated?{Authorization:`Bearer ${await this.token()}`} : {}), Accept: "application/json" },
      redirect:"error",
      cache: "no-store",
      signal: AbortSignal.timeout(this.config.timeoutMs),
    });
    if (!response.ok) throw new Error(`Dotykačka stock-taking status failed (${response.status})`);
    const data=await response.json() as DotykackaStockTakingStatus & {reason?:string;message?:string};
    if(!["PROCESSING","FINISHED","FAILED"].includes(data.status))throw Error("Nieznany status inwentaryzacji Dotykački.");
    return {...data,error:data.error??(data.status==="FAILED"?[data.reason,data.message].filter(Boolean).join(": "):undefined)};
  }

  webhooks() {
    return this.all<DotykackaWebhook>(`/clouds/${this.config.cloudId}/webhooks`);
  }

  registerStockWebhook(url: string) {
    return this.request<DotykackaWebhook>(`/clouds/${this.config.cloudId}/webhooks`, {
      method: "POST",
      body: {
        _warehouseId: this.config.warehouseId ? Number(this.config.warehouseId) : null,
        method: "POST",
        url,
        payloadEntity: "STOCKLOG",
        payloadVersion: "V1",
      },
    });
  }

  deleteWebhook(webhookId: number) {
    return this.request<unknown>(`/clouds/${this.config.cloudId}/webhooks/${webhookId}`, { method: "DELETE" });
  }
}
