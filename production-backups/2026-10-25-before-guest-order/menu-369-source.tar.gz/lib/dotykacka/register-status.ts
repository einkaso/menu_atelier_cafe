import "server-only";
import { DotykackaClient } from "./client";
import { getDotykackaConfig } from "./config";
import type { DotykackaMoneyLog } from "./types";

export type DotykackaRegisterEvent = {
  id: string;
  state: "OPEN" | "CLOSED";
  amount: string;
  currency: string | null;
  createdAt: string;
  employeeId: string | null;
};

function eventDate(value: string | number | null | undefined) {
  if (value == null || value === "") return null;
  const numeric = typeof value === "number" ? value : /^\d+$/.test(value) ? Number(value) : null;
  const date = numeric == null
    ? new Date(value)
    : new Date(numeric < 10_000_000_000 ? numeric * 1000 : numeric);
  return Number.isNaN(date.getTime()) ? null : date;
}

export function selectRegisterEvent(events: DotykackaMoneyLog[], closingAfter?: Date): DotykackaRegisterEvent | null {
  const latest = closingAfter
    ? events.filter((event) => String(event.transactionType) === "REGISTER_CLOSE" && (eventDate(event.created)?.getTime() ?? 0) >= closingAfter.getTime())
      .sort((left, right) => eventDate(left.created)!.getTime() - eventDate(right.created)!.getTime())[0]
    : events[0];
  if (!latest) return null;
  const transactionType = String(latest.transactionType ?? "");
  const state = transactionType.includes("OPEN") ? "OPEN" : transactionType.includes("CLOSE") ? "CLOSED" : null;
  const createdAt = eventDate(latest.created);
  const amount = Number(latest.amountDefaultCurrency ?? latest.amount);
  if (!state || !createdAt || !Number.isFinite(amount)) return null;
  return {
    id: String(latest.id),
    state,
    amount: amount.toFixed(2),
    currency: latest.currency ?? null,
    createdAt: createdAt.toISOString(),
    employeeId: latest._employeeId == null ? null : String(latest._employeeId),
  };
}

export async function fetchDotykackaRegisterStatus(closingAfter?: Date): Promise<DotykackaRegisterEvent | null> {
  const config = await getDotykackaConfig();
  if (!config.branchId) throw new Error("W konfiguracji Dotykački nie wybrano oddziału.");
  return selectRegisterEvent(await new DotykackaClient(config).registerEvents(closingAfter), closingAfter);
}

export async function safeDotykackaRegisterStatus(closingAfter?: Date) {
  try {
    return { event: await fetchDotykackaRegisterStatus(closingAfter), error: null };
  } catch (error) {
    return {
      event: null,
      error: error instanceof Error ? error.message : "Nie udało się odczytać stanu kasy Dotykačka.",
    };
  }
}
