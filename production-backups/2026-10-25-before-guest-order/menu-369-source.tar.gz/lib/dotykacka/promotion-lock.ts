import "server-only";
import postgres from "postgres";

// Separate pool: waiting saves must not exhaust the connections needed by the
// import holding this lock. PostgreSQL also coordinates separate app processes.
let lockClient: ReturnType<typeof postgres> | undefined;
export async function withPromotionLock<T>(work: () => Promise<T>): Promise<T> {
  if (!process.env.DATABASE_URL) throw new Error("DATABASE_URL is not configured");
  lockClient ??= postgres(process.env.DATABASE_URL, { max: 1, prepare: false });
  let result!: T;
  await lockClient.begin(async tx => {
    await tx`select pg_advisory_xact_lock(834721, 239)`;
    result = await work();
  });
  return result;
}
