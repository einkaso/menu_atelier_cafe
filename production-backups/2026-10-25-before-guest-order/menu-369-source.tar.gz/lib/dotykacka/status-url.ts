// This callback host is returned by the authenticated Dotykačka stock-taking API.
// Its status resources are public and must never receive the API bearer token.
const STOCK_STATUS_HOST='zmpj7fqf19.execute-api.eu-west-1.amazonaws.com';
export function stockStatusTarget(raw:string,apiUrl:string,cloudId:string,transactionId?:string){
 const url=new URL(raw);const base=new URL(apiUrl);
 if(url.protocol!=='https:'||url.username||url.password||url.hash)throw Error('Dotykačka returned an unsafe stock-taking status URL');
 if(url.origin===base.origin)return {url,authenticated:true};
 const match=/^\/prod\/v1\/stock-taking-status-(\d+)-(\d+)\.json$/.exec(url.pathname);
 if(url.hostname!==STOCK_STATUS_HOST||url.port||url.search||!match||match[1]!==cloudId||(transactionId&&match[2]!==transactionId))throw Error('Dotykačka returned an unsafe stock-taking status URL');
 return {url,authenticated:false};
}
