export const giftPalettes={cobalt:'Kobalt',magenta:'Magenta',vermilion:'Pomarańcz'};
export const giftMotifs={rings:'Kręgi Atelier',fala:'Fale',listek:'Listki',spirala:'Spirale'};
export type GiftDesign={palette:keyof typeof giftPalettes;motif:keyof typeof giftMotifs;rich:boolean};
export const defaultGiftDesign:GiftDesign={palette:'cobalt',motif:'rings',rich:false};
export function validGiftProposal(value:unknown):value is GiftDesign & {dedication:string}{
 if(!value||typeof value!=='object')return false;
 const v=value as Record<string,unknown>;
 return typeof v.palette==='string'&&Object.hasOwn(giftPalettes,v.palette)&&typeof v.motif==='string'&&Object.hasOwn(giftMotifs,v.motif)&&typeof v.rich==='boolean'&&typeof v.dedication==='string'&&v.dedication.trim().length>0&&v.dedication.length<=700;
}
