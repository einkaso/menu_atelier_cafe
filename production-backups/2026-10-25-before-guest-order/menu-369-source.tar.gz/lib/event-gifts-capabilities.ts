export type GiftCapabilities = {apiVersion:string;mode:'contract-test'|'sandbox'|'production';salesEnabled:boolean;testTicket?:{available:boolean;unitGrossCents:number;currency:string};artworkGeneration?:{available:boolean};openVoucher:{unitGrossCents:number;currency:string;validityMonths:number;anyAvailableEvent:boolean;surcharge:boolean}};
export function parseGiftCapabilities(value:unknown):GiftCapabilities|null {
 if(!value||typeof value!=='object')return null;
 const v=value as Record<string,unknown>,o=v.openVoucher as Record<string,unknown>|undefined;
 if(typeof v.apiVersion!=='string'||v.apiVersion.length>80||!['contract-test','sandbox','production'].includes(String(v.mode))||typeof v.salesEnabled!=='boolean'||!o||typeof o!=='object'||!Number.isSafeInteger(o.unitGrossCents)||!Number.isSafeInteger(o.validityMonths)||typeof o.currency!=='string'||typeof o.anyAvailableEvent!=='boolean'||typeof o.surcharge!=='boolean')return null;
 const test=v.testTicket as Record<string,unknown>|undefined;
 return {apiVersion:v.apiVersion,mode:v.mode as GiftCapabilities['mode'],salesEnabled:v.salesEnabled,testTicket:{available:test?.available===true&&test.unitGrossCents===1000&&test.currency==='PLN',unitGrossCents:1000,currency:'PLN'},artworkGeneration:{available:['0.2.0-test','0.3.0-test'].includes(v.apiVersion)&&(v.artworkGeneration as Record<string,unknown>|undefined)?.available===true&&(v.artworkGeneration as Record<string,unknown>)?.brandPreset==='atelier-menu-v1'},openVoucher:{unitGrossCents:Number(o.unitGrossCents),currency:o.currency,validityMonths:Number(o.validityMonths),anyAvailableEvent:o.anyAvailableEvent,surcharge:o.surcharge}};
}
export function giftContractMatches(c:GiftCapabilities){return ['0.1.0-test','0.2.0-test','0.3.0-test'].includes(c.apiVersion)&&c.openVoucher.unitGrossCents===19500&&c.openVoucher.currency==='PLN'&&c.openVoucher.validityMonths===6&&c.openVoucher.anyAvailableEvent&&!c.openVoucher.surcharge;}
export type GiftIntegrationStatus={connected:boolean;compatible:boolean;menuSalesEnabled:false;checkedAt:string;capabilities:GiftCapabilities|null;message:string};
export function giftIntegrationStatus(value:unknown,checkedAt=new Date().toISOString()):GiftIntegrationStatus{
 const c=parseGiftCapabilities(value);const compatible=c!==null&&giftContractMatches(c);
 return {connected:c!==null,compatible,menuSalesEnabled:false,checkedAt,capabilities:c,message:!c?'Nieprawidłowa odpowiedź Events. Sprzedaż pozostaje wyłączona.':!compatible?'Wersja kontraktu lub zasady vouchera różnią się od uzgodnionych. Sprzedaż pozostaje wyłączona.':c.mode==='contract-test'?'Połączenie potwierdzone. Dostępny jest kontrakt testowy, bez aktywnej sprzedaży.':'Połączenie potwierdzone. Menu pozostaje w podglądzie do zakończenia testów całego zakupu.'};
}
