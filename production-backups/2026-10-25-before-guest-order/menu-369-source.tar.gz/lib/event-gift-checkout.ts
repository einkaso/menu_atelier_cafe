import {validId} from './event-gift-artwork-core';

export const TEST_GIFT_CENTS=1000;
export function testTicketAvailable(value:unknown){
 const capabilities=value as {testTicket?:{available?:unknown;unitGrossCents?:unknown;currency?:unknown}}|null;
 return capabilities?.testTicket?.available===true&&capabilities.testTicket.unitGrossCents===TEST_GIFT_CENTS&&capabilities.testTicket.currency==='PLN';
}
export function checkoutInput(value:unknown){
 if(!value||typeof value!=='object')throw Error('Nieprawidłowe dane zamówienia.');
 const input=value as Record<string,unknown>;
 if(input.kind!=='test_ticket'||input.quantity!==1||!validId(input.orderId)||typeof input.receipt!=='string'||input.receipt.length>4096)throw Error('Wybierz jeden bilet testowy za 10 zł.');
 function field(name:string,max:number,required=false){const value=input[name];if(typeof value!=='string'||value.length>max||(required&&!value.trim()))throw Error('Uzupełnij dane prezentu i kupującego.');return value.trim();}
 const email=field('email',254,true);
 if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))throw Error('Podaj poprawny e-mail kupującego.');
 if(typeof input.culinaryInvitation!=='boolean')throw Error('Nieprawidłowy wybór poczęstunku.');
 return {orderId:input.orderId,receipt:input.receipt,kind:'test_ticket',quantity:1,recipient:field('recipient',100,true),donorSignature:field('donorSignature',100,true),dedication:field('dedication',700),occasion:field('occasion',120)||null,serviceRequest:field('serviceRequest',1500)||null,culinaryInvitation:input.culinaryInvitation,purchaser:{name:field('purchaserName',160,true),email}};
}
export function safeGiftOrderUrl(value:unknown,origin:string,orderId:string,document:''|'pdf'|'qr'=''){
 if(typeof value!=='string'||value.length>2048||!validId(orderId))throw Error('Nieprawidłowy adres zamówienia.');
 const url=new URL(value);
 if(url.origin!==origin||url.username||url.password||url.hash||url.pathname!==`/api/integrations/menu/gifts/v1/orders/${orderId}${document?'/'+document:''}`||!url.searchParams.get('token')||url.searchParams.get('token')!.length<32)throw Error('Nieprawidłowy adres zamówienia.');
 return url.href;
}
export function safeGiftCheckoutUrl(value:unknown){
 if(typeof value!=='string'||value.length>2048)throw Error('Nieprawidłowy adres płatności.');
 const url=new URL(value);
 if(url.protocol!=='https:'||!['martabanaszek.pl','www.martabanaszek.pl'].includes(url.hostname)||url.port||url.username||url.password||url.hash||!/\/order-pay\/\d+\/?$/.test(url.pathname)||!url.searchParams.get('key'))throw Error('Nieprawidłowy adres płatności.');
 return url.href;
}
