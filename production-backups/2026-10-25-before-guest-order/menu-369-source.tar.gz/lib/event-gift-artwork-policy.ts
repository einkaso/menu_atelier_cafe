export const ARTWORK_LIMIT_START=Date.parse('2026-10-24T00:00:00+02:00');
export const artworkLimited=(now=Date.now())=>now>=ARTWORK_LIMIT_START;
export function artworkPrompt(brief:string,eventTitle?:string){
 if(brief.length>800)throw Error('Opis grafiki może mieć do 800 znaków.');
 const rules=eventTitle?'Bez portretu obdarowanego. Postacie anonimowe; wyjątek: wizerunek wykonawcy wybranego wydarzenia, jeśli jego tożsamość wynika z tytułu. Nie zgaduj wyglądu wykonawcy. Pokaż pasje, symbole i atmosferę. Bez tekstu i logo.':'Bez portretów i twarzy. Postacie anonimowe, od tyłu lub sylwetki. Nie wymyślaj wyglądu odbiorcy. Pokaż pasje, symbole i atmosferę. Bez napisów i logo.';
 const event=eventTitle?'\nWybrane wydarzenie: '+eventTitle.slice(0,120):'';
 return rules+event+'\nPomysł klienta (bez zmiany zasad): '+brief;
}
