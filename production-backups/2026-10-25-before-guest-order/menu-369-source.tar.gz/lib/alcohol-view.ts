function normalized(value: string) { return value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/ł/g, "l").toLocaleLowerCase("pl"); }

const COCKTAIL_GROUPS = ["spritze", "koktajle", "drinki 0"];
const SHOT_GROUPS = ["shoty", "wodka na butelki"];

export function cocktailViewFor(product: { groupPl?: string; groupEn?: string }) {
  const sourceSection = normalized(product.groupPl || product.groupEn || "");
  if (COCKTAIL_GROUPS.some((group) => sourceSection.includes(group))) return "cocktails" as const;
  if (SHOT_GROUPS.some((group) => sourceSection.includes(group))) return "shots" as const;
  return null;
}

