export type ArtWhiskySection = "smooth" | "vanilla" | "smoky" | "cognac";

export type ArtWhiskyProductLike = {
  id?: number;
  pl: string;
  en?: string;
  country?: string;
  countryEn?: string;
  descPl?: string;
  descEn?: string;
  tastingNotes?: string;
  tastingNotesEn?: string;
  attributes?: Record<string, string>;
  attributesEn?: Record<string, string>;
};

export type ArtWhiskyFilters = {
  characters: ArtWhiskySection[];
  origins: string[];
  ages: number[];
};

export const EMPTY_ART_WHISKY_FILTERS: ArtWhiskyFilters = { characters: [], origins: [], ages: [] };

export const ART_WHISKY_SECTIONS: Record<ArtWhiskySection, { pl: string; en: string; introPl: string; introEn: string }> = {
  smooth: { pl: "Łagodne i miodowe", en: "Smooth and honeyed", introPl: "Miód, wanilia, dojrzałe owoce. Dobre na początek.", introEn: "Honey, vanilla and ripe fruit. A gentle place to start." },
  vanilla: { pl: "Waniliowo-karmelowe", en: "Vanilla and caramel", introPl: "Bourbon i beczka: wanilia, karmel, dąb.", introEn: "Bourbon and barrel: vanilla, caramel and oak." },
  smoky: { pl: "Dymne i torfowe", en: "Smoky and peated", introPl: "Dym, torf i morska sól. Dla zdecydowanych.", introEn: "Smoke, peat and sea salt. For decisive palates." },
  cognac: { pl: "Koniaki i brandy", en: "Cognac and brandy", introPl: "Winne destylaty: suszone owoce, dąb, orzech.", introEn: "Wine distillates: dried fruit, oak and nuts." },
};

type WhiskyPresentation = {
  namePl: string;
  nameEn: string;
  section: ArtWhiskySection;
  origin: string;
  originEn: string;
  type: string;
  typeEn: string;
  ageYears?: number;
  classLabel?: string;
  notesPl: string;
  notesEn: string;
};

const WHISKY_BY_ID: Record<number, WhiskyPresentation> = {
  36746: { namePl: "Chivas Regal 12 Years", nameEn: "Chivas Regal 12 Years", section: "vanilla", origin: "Szkocja", originEn: "Scotland", type: "Blended", typeEn: "Blended", ageYears: 12, classLabel: "12 lat", notesPl: "Wanilia, miód, jabłko, karmel i dąb.", notesEn: "Vanilla, honey, apple, caramel and oak." },
  36749: { namePl: "Glenrothes", nameEn: "Glenrothes", section: "smooth", origin: "Szkocja", originEn: "Scotland", type: "Single malt", typeEn: "Single malt", notesPl: "Dojrzałe owoce, wanilia, przyprawy i dąb.", notesEn: "Ripe fruit, vanilla, spice and oak." },
  36751: { namePl: "Hennessy V.S", nameEn: "Hennessy V.S", section: "cognac", origin: "Francja", originEn: "France", type: "Koniak", typeEn: "Cognac", classLabel: "V.S", notesPl: "Migdały, winogrona, wanilia, czerwone owoce i dąb.", notesEn: "Almond, grape, vanilla, red fruit and oak." },
  36759: { namePl: "Metaxa 12 Stars", nameEn: "Metaxa 12 Stars", section: "cognac", origin: "Grecja", originEn: "Greece", type: "Brandy", typeEn: "Brandy", ageYears: 12, classLabel: "12 Stars", notesPl: "Suszone owoce, miód, przyprawy i dębowa beczka.", notesEn: "Dried fruit, honey, spice and oak barrel." },
  36753: { namePl: "Jameson", nameEn: "Jameson", section: "smooth", origin: "Irlandia", originEn: "Ireland", type: "Blended", typeEn: "Blended", notesPl: "Miód, wanilia, delikatne przyprawy i łagodny finisz.", notesEn: "Honey, vanilla, gentle spice and a smooth finish." },
  36761: { namePl: "Springbank 10 Years", nameEn: "Springbank 10 Years", section: "smoky", origin: "Szkocja", originEn: "Scotland", type: "Single malt", typeEn: "Single malt", ageYears: 10, classLabel: "10 lat", notesPl: "Dym, torf, morska sól, cytrusy i słód.", notesEn: "Smoke, peat, sea salt, citrus and malt." },
  36750: { namePl: "Grant’s", nameEn: "Grant’s", section: "smooth", origin: "Szkocja", originEn: "Scotland", type: "Blended", typeEn: "Blended", notesPl: "Miód, wanilia, dojrzałe owoce i łagodny dąb.", notesEn: "Honey, vanilla, ripe fruit and gentle oak." },
  36748: { namePl: "Glen Turner", nameEn: "Glen Turner", section: "vanilla", origin: "Szkocja", originEn: "Scotland", type: "Single malt", typeEn: "Single malt", notesPl: "Wanilia, karmel, słód i delikatne drewno.", notesEn: "Vanilla, caramel, malt and gentle wood." },
  36760: { namePl: "Singleton 15 Years", nameEn: "Singleton 15 Years", section: "vanilla", origin: "Szkocja", originEn: "Scotland", type: "Single malt", typeEn: "Single malt", ageYears: 15, classLabel: "15 lat", notesPl: "Wanilia, karmel, suszone owoce i dąb.", notesEn: "Vanilla, caramel, dried fruit and oak." },
  36763: { namePl: "Teeling Small Batch", nameEn: "Teeling Small Batch", section: "vanilla", origin: "Irlandia", originEn: "Ireland", type: "Blended", typeEn: "Blended", notesPl: "Wanilia, karmel, owoce i przyprawy z beczki po rumie.", notesEn: "Vanilla, caramel, fruit and rum-cask spice." },
  36744: { namePl: "Ballantine’s 12 Years", nameEn: "Ballantine’s 12 Years", section: "smooth", origin: "Szkocja", originEn: "Scotland", type: "Blended", typeEn: "Blended", ageYears: 12, classLabel: "12 lat", notesPl: "Miód, wanilia, dojrzałe owoce i kremowy finisz.", notesEn: "Honey, vanilla, ripe fruit and a creamy finish." },
  36762: { namePl: "Teacher’s", nameEn: "Teacher’s", section: "smoky", origin: "Szkocja", originEn: "Scotland", type: "Blended", typeEn: "Blended", notesPl: "Dym, torf, słód i wytrawne przyprawy.", notesEn: "Smoke, peat, malt and dry spice." },
  36745: { namePl: "Ballantine’s John Lennon", nameEn: "Ballantine’s John Lennon", section: "smooth", origin: "Szkocja", originEn: "Scotland", type: "Blended", typeEn: "Blended", notesPl: "Miód, wanilia, miękkie owoce i delikatny dąb.", notesEn: "Honey, vanilla, soft fruit and gentle oak." },
  36754: { namePl: "Jim Beam Bourbon", nameEn: "Jim Beam Bourbon", section: "vanilla", origin: "USA", originEn: "USA", type: "Bourbon", typeEn: "Bourbon", notesPl: "Wanilia, karmel, kukurydza i lekko opalany dąb.", notesEn: "Vanilla, caramel, corn and lightly charred oak." },
  36766: { namePl: "Pliska XO", nameEn: "Pliska XO", section: "cognac", origin: "Bułgaria", originEn: "Bulgaria", type: "Brandy", typeEn: "Brandy", ageYears: 10, classLabel: "XO", notesPl: "Suszone owoce, wanilia, karmel, orzech i dąb.", notesEn: "Dried fruit, vanilla, caramel, nuts and oak." },
  36758: { namePl: "Maxime Frères", nameEn: "Maxime Frères", section: "cognac", origin: "Francja", originEn: "France", type: "Koniak", typeEn: "Cognac", ageYears: 17, classLabel: "17 lat", notesPl: "Suszone owoce, orzech, wanilia i dojrzały dąb.", notesEn: "Dried fruit, nuts, vanilla and mature oak." },
  36757: { namePl: "Martell V.S", nameEn: "Martell V.S", section: "cognac", origin: "Francja", originEn: "France", type: "Koniak", typeEn: "Cognac", classLabel: "V.S", notesPl: "Świeże owoce, wanilia, delikatne przyprawy i dąb.", notesEn: "Fresh fruit, vanilla, gentle spice and oak." },
};

function normalized(value: string) {
  return value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/ł/g, "l").toLocaleLowerCase("pl");
}

function fallbackPresentation(product: ArtWhiskyProductLike): WhiskyPresentation {
  const values = normalized(`${product.attributes?.spiritType ?? ""} ${product.attributes?.tasteProfile ?? ""} ${product.pl}`);
  const section: ArtWhiskySection = /koniak|cognac|brandy/.test(values) ? "cognac" : /dym|torf|smok|peat/.test(values) ? "smoky" : /wanil|karmel|vanilla|caramel|bourbon/.test(values) ? "vanilla" : "smooth";
  const rawOrigin = product.attributes?.origin || product.country || "";
  const origin = rawOrigin.replace(/\s*·\s*Cognac\s*$/i, "").trim();
  const rawAge = product.attributes?.ageStatement || "";
  const ageYears = Number(rawAge.match(/\d+/)?.[0]) || undefined;
  const rawName = product.pl.replace(/\s+\d+(?:[,.]\d+)?\s*(?:%|vol)\b/gi, "").replace(/\s+whisk(?:y|ey)\b/gi, "").replace(/\s+/g, " ").trim();
  const type = section === "cognac" ? (/brandy/i.test(values) ? "Brandy" : "Koniak") : product.attributes?.spiritStyle || "Whisky";
  return {
    namePl: rawName,
    nameEn: product.en || rawName,
    section,
    origin,
    originEn: product.attributesEn?.origin?.replace(/\s*·\s*Cognac\s*$/i, "").trim() || product.countryEn || origin,
    type,
    typeEn: section === "cognac" && type === "Koniak" ? "Cognac" : product.attributesEn?.spiritStyle || type,
    ageYears,
    classLabel: rawAge || undefined,
    notesPl: product.tastingNotes || product.descPl || "Charakter trunku zapytaj naszą obsługę.",
    notesEn: product.tastingNotesEn || product.descEn || product.tastingNotes || product.descPl || "Ask our team about this spirit's character.",
  };
}

export function artWhiskyPresentation(product: ArtWhiskyProductLike) {
  return (product.id ? WHISKY_BY_ID[product.id] : undefined) || fallbackPresentation(product);
}

export function artWhiskySectionTitle(section: ArtWhiskySection, lang: "pl" | "en") {
  return ART_WHISKY_SECTIONS[section][lang];
}

export function artWhiskySectionIntro(section: ArtWhiskySection, lang: "pl" | "en") {
  return lang === "pl" ? ART_WHISKY_SECTIONS[section].introPl : ART_WHISKY_SECTIONS[section].introEn;
}

export function matchesArtWhiskyProduct(product: ArtWhiskyProductLike, filters: ArtWhiskyFilters) {
  const presentation = artWhiskyPresentation(product);
  const characterMatches = !filters.characters.length || filters.characters.includes(presentation.section);
  const originMatches = !filters.origins.length || filters.origins.includes(presentation.origin);
  const ageMatches = !filters.ages.length || filters.ages.some(age => Boolean(presentation.ageYears && presentation.ageYears >= age));
  return characterMatches && originMatches && ageMatches;
}

export const ART_WHISKY_ORIGINS = ["Szkocja", "Irlandia", "USA", "Francja", "Grecja", "Bułgaria"];
export const ART_WHISKY_AGES = [10, 12, 15];

