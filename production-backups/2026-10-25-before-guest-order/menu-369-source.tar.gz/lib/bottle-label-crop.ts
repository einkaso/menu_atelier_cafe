type Bounds = { width:number;height:number;x:number;y:number;w:number;h:number };
// Home-page experiment: label detail in a 4:3 frame, with the bottle edges visible.
export function bottleLabelCrop(b: Bounds | undefined, image: string) {
 if (!b) return undefined;
 const bala = image.includes("405-c0c3bd732909e1d0");
 const width = bala ? .50 : .55;
 const center = bala ? .63 : .75;
 const scale = width * 4/3 / b.w;
 return {width:`${b.width/b.w*width*100}%`,height:"auto",aspectRatio:`${b.width} / ${b.height}`,left:"50%",top:`${(0.5-(b.y+b.h*center)*scale)*100}%`,transform:`translateX(-${(b.x+b.w/2)/b.width*100}%)`};
}
