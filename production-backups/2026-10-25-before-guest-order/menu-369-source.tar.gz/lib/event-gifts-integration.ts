import 'server-only';
import {giftIntegrationStatus,type GiftIntegrationStatus} from './event-gifts-capabilities';
export async function readGiftIntegrationStatus():Promise<GiftIntegrationStatus>{
 const checkedAt=new Date().toISOString();
 try{
 const secret=process.env.MENU_EVENT_OS_SECRET?.trim();if(!secret||secret.length<32)throw Error('configuration');
 const origin=new URL(process.env.EVENT_OS_APP_URL?.trim()||'https://events.mbstudio.online');
 if(origin.protocol!=='https:'||origin.username||origin.password||origin.search||origin.hash||origin.pathname!=='/')throw Error('origin');
 const r=await fetch(origin.origin+'/api/integrations/menu/gifts/v1/capabilities',{headers:{Authorization:`Bearer ${secret}`,Accept:'application/json'},cache:'no-store',redirect:'error',signal:AbortSignal.timeout(5000)});
 if(!r.ok)throw Error('upstream');
 return giftIntegrationStatus(await r.json(),checkedAt);
 }catch{return {connected:false,compatible:false,menuSalesEnabled:false,checkedAt,capabilities:null,message:'Nie udało się potwierdzić połączenia z Events. Kreator działa wyłącznie jako podgląd.'};}
}
