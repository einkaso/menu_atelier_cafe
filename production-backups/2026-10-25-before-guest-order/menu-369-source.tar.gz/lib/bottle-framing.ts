import { bottleLabelCrop } from "./bottle-label-crop";
// Visible bottle bounds, keyed by immutable image filename. Original photos are
// untouched. All bottles use the same height and baseline as Hendrick’s.
const bounds: Record<string, {width:number;height:number;x:number;y:number;w:number;h:number}> = {
  "901123-ac322778b28ea062.webp": {
    "width": 564,
    "height": 1600,
    "x": 133,
    "y": 164,
    "w": 296,
    "h": 1348
  },
  "901101-fc51177ac11429af.png": {
    "width": 1254,
    "height": 1254,
    "x": 424,
    "y": 17,
    "w": 402,
    "h": 1222
  },
  "901080-3da39d045d80b165.webp": {
    "width": 994,
    "height": 1600,
    "x": 221,
    "y": 105,
    "w": 551,
    "h": 1407
  },
  "901105-0de88dddb8d6bb9a.png": {
    "width": 1254,
    "height": 1254,
    "x": 467,
    "y": 11,
    "w": 320,
    "h": 1228
  },
  "901055-f6fb2f9f0fb18d4c.webp": {
    "width": 581,
    "height": 1600,
    "x": 131,
    "y": 104,
    "w": 319,
    "h": 1406
  },
  "901120-df0c4391173af655.webp": {
    "width": 853,
    "height": 1600,
    "x": 196,
    "y": 105,
    "w": 462,
    "h": 1407
  },
  "901077-d96f9819a1b515fc.webp": {
    "width": 1156,
    "height": 1600,
    "x": 262,
    "y": 105,
    "w": 636,
    "h": 1409
  },
  "901050-825cd9e5b08c8397.webp": {
    "width": 365,
    "height": 1200,
    "x": 7,
    "y": 3,
    "w": 353,
    "h": 1196
  },
  "901087-330d7a46384bf430.webp": {
    "width": 875,
    "height": 1600,
    "x": 197,
    "y": 105,
    "w": 479,
    "h": 1407
  },
  "901083-2e1c7936b405c74a.webp": {
    "width": 984,
    "height": 1600,
    "x": 220,
    "y": 105,
    "w": 545,
    "h": 1407
  },
  "901068-c480085e00edfe01.webp": {
    "width": 589,
    "height": 1600,
    "x": 132,
    "y": 105,
    "w": 324,
    "h": 1405
  },
  "901072-246d0ac53c3b9b6a.webp": {
    "width": 885,
    "height": 1600,
    "x": 199,
    "y": 105,
    "w": 485,
    "h": 1406
  },
  "901099-ccdd5a9d30ea30da.webp": {
    "width": 863,
    "height": 1600,
    "x": 197,
    "y": 105,
    "w": 470,
    "h": 1405
  },
  "901088-9a1764fa9b5fed12.webp": {
    "width": 1020,
    "height": 1200,
    "x": 363,
    "y": 29,
    "w": 300,
    "h": 1146
  },
  "901058-1cb7c6f842453f6f.webp": {
    "width": 924,
    "height": 1600,
    "x": 209,
    "y": 104,
    "w": 506,
    "h": 1406
  },
  "901060-92008956afe921a6.webp": {
    "width": 776,
    "height": 1600,
    "x": 176,
    "y": 104,
    "w": 422,
    "h": 1408
  },
  "901110-be84a1c650d84ba7.webp": {
    "width": 765,
    "height": 1600,
    "x": 90,
    "y": 108,
    "w": 586,
    "h": 1401
  },
  "901111-b63c99d6703f51f7.webp": {
    "width": 1109,
    "height": 1600,
    "x": 130,
    "y": 106,
    "w": 850,
    "h": 1410
  },
  "901075-26ba2d5372332166.webp": {
    "width": 583,
    "height": 1600,
    "x": 133,
    "y": 105,
    "w": 319,
    "h": 1405
  },
  "901107-b544f862bebe82c0.webp": {
    "width": 637,
    "height": 1600,
    "x": 143,
    "y": 105,
    "w": 351,
    "h": 1401
  },
  "68-bfbe2f1a7e22ac50.webp": {
    "width": 1012,
    "height": 1600,
    "x": 248,
    "y": 104,
    "w": 515,
    "h": 1398
  },
  "901108-c893c9fbe85418ce.webp": {
    "width": 900,
    "height": 1600,
    "x": 281,
    "y": 87,
    "w": 345,
    "h": 1446
  },
  "901071-16291eff615052f7.webp": {
    "width": 877,
    "height": 1600,
    "x": 196,
    "y": 105,
    "w": 485,
    "h": 1402
  },
  "901063-6d019edcaa3740e9.webp": {
    "width": 820,
    "height": 1600,
    "x": 185,
    "y": 105,
    "w": 448,
    "h": 1406
  },
  "901112-9a32ecf51bf4e716.webp": {
    "width": 672,
    "height": 1600,
    "x": 158,
    "y": 104,
    "w": 361,
    "h": 1408
  },
  "901109-0051df51d74c04f1.webp": {
    "width": 556,
    "height": 1600,
    "x": 125,
    "y": 105,
    "w": 305,
    "h": 1405
  },
  "3998564-44d7383fbd89442c.webp": {
    "width": 132,
    "height": 500,
    "x": 7,
    "y": 1,
    "w": 117,
    "h": 499
  },
  "901122-ac322778b28ea062.webp": {
    "width": 564,
    "height": 1600,
    "x": 133,
    "y": 164,
    "w": 296,
    "h": 1348
  },
  "901121-557a7b3ba59f4946.webp": {
    "width": 564,
    "height": 1600,
    "x": 127,
    "y": 104,
    "w": 309,
    "h": 1406
  },
  "901118-df0c4391173af655.webp": {
    "width": 853,
    "height": 1600,
    "x": 196,
    "y": 105,
    "w": 462,
    "h": 1407
  },
  "901119-df0c4391173af655.webp": {
    "width": 853,
    "height": 1600,
    "x": 196,
    "y": 105,
    "w": 462,
    "h": 1407
  }
};
export function bottleImageStyle(image: string) {
 const b = bounds[image.split("/").pop()?.split("?")[0] ?? ""];
 if (!b) return undefined;
 const scale = 0.8125 / b.h;
 return {
  width: `${b.width * scale * 150}%`, height: `${b.height * scale * 100}%`,
  left: `${50 - (b.x + b.w / 2) * scale * 150}%`, top: `${10 - b.y * scale * 100}%`,
 };
}

export function bottleLabelStyle(image?: string) { return image ? bottleLabelCrop(bounds[image.split("/").pop()?.split("?")[0] ?? ""],image) : undefined; }
