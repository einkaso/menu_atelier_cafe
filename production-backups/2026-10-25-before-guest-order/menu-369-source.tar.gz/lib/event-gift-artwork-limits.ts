import {createHmac} from 'node:crypto';
import {sql} from 'drizzle-orm';
import {getDb} from '../db';
import {artworkLimited} from './event-gift-artwork-policy';
export class ArtworkLimitError extends Error {}
const hash=(secret:string,value:string)=>createHmac('sha256',secret).update('gift-limit:'+value).digest('hex');
export async function artworkAllowance(owner:string,secret:string,now=Date.now()){
 if(!artworkLimited(now))return true;
 const rows=await getDb().execute(sql`select 1 from gift_artwork_attempts where owner_hash=${hash(secret,owner)} and not is_test limit 1`);
 return rows.length===0;
}
export async function reserveArtwork(owner:string,network:string,key:string,body:string,secret:string,now=Date.now()){
 const ownerHash=hash(secret,owner),networkHash=hash(secret,network),bodyHash=hash(secret,body),limited=artworkLimited(now);
 return getDb().transaction(async tx=>{
  await tx.execute(sql`select pg_advisory_xact_lock(hashtextextended(${networkHash},0))`);
  await tx.execute(sql`select pg_advisory_xact_lock(hashtextextended(${ownerHash},0))`);
  const previous=await tx.execute(sql`select * from gift_artwork_attempts where request_key=${key}::uuid or (owner_hash=${ownerHash} and not is_test and ${limited}) order by created_at limit 1`);
  if(previous.length){const row=previous[0];if(row.owner_hash!==ownerHash||row.body_hash!==bodyHash)throw new ArtworkLimitError('Dla tego prezentu przygotowaliśmy już ilustrację. Zachowaj ją albo wybierz standardowy voucher.');if(!row.job_id&&Date.now()-new Date(String(row.created_at)).getTime()>86400000)throw new ArtworkLimitError('Poprzednie zgłoszenie wymaga sprawdzenia przez obsługę. Możesz wybrać standardowy voucher.');return {key:String(row.request_key),jobId:row.job_id?String(row.job_id):null};}
  if(limited){const rows=await tx.execute(sql`select count(*)::int as count from gift_artwork_attempts where network_hash=${networkHash} and not is_test and created_at>now()-interval '24 hours'`);if(Number(rows[0].count)>=5)throw new ArtworkLimitError('Limit bezpłatnych ilustracji został osiągnięty. Możesz nadal przygotować standardowy voucher.');}
  await tx.execute(sql`insert into gift_artwork_attempts(request_key,owner_hash,network_hash,body_hash,is_test) values(${key}::uuid,${ownerHash},${networkHash},${bodyHash},${!limited})`);
  return {key,jobId:null};
 });
}
export async function acceptArtwork(key:string,id:string){await getDb().execute(sql`update gift_artwork_attempts set job_id=${id}::uuid where request_key=${key}::uuid`);}

export async function recoverArtwork(owner:string,secret:string){
 if(!artworkLimited())return null;
 const rows=await getDb().execute(sql`select job_id from gift_artwork_attempts where owner_hash=${hash(secret,owner)} and not is_test and job_id is not null order by created_at desc limit 1`);
 return rows.length?String(rows[0].job_id):null;
}
