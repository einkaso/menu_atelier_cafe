export function adminHttpsRedirect(requestUrl:string,headers:Headers){
 const url=new URL(requestUrl);
 const host=(headers.get('host')||url.host).split(':')[0].toLowerCase();
 if(host!=='menu.martabanaszek.pl')return null;
 let scheme=headers.get('x-forwarded-proto')?.split(',')[0]?.trim();
 try{const visitor=JSON.parse(headers.get('cf-visitor')||'null');if(visitor?.scheme==='http'||visitor?.scheme==='https')scheme=visitor.scheme;}catch{}
 if((scheme||url.protocol.replace(':',''))!=='http')return null;
 const destination=new URL('https://menu.martabanaszek.pl');
 destination.pathname=url.pathname;destination.search=url.search;
 return destination.href;
}
