export async function readGiftCheckoutResponse(response:Response){
 const value=await response.json().catch(()=>null);
 if(!response.ok){
 const message=value&&typeof value.error==='string'&&value.error.length<=500?value.error:'Nie udało się połączyć z płatnością. Twoje dane pozostają w kreatorze. Spróbuj ponownie za chwilę.';
 throw Error(message);
 }
 if(!value||typeof value.checkoutUrl!=='string')throw Error('Nie udało się odczytać adresu płatności. Spróbuj ponownie z tymi samymi danymi.');
 let url:URL;
 try{url=new URL(value.checkoutUrl);}catch{throw Error('Otrzymaliśmy nieprawidłowy adres płatności. Spróbuj ponownie za chwilę.');}
 if(url.protocol!=='https:'||!['martabanaszek.pl','www.martabanaszek.pl'].includes(url.hostname)||url.username||url.password||url.port||url.hash||!/\/order-pay\/\d+\/?$/.test(url.pathname)||!url.searchParams.get('key'))throw Error('Otrzymaliśmy nieprawidłowy adres płatności. Spróbuj ponownie za chwilę.');
 return url.href;
}
