import sharp from 'sharp';
import {readFile} from 'node:fs/promises';
import path from 'node:path';

// Apply the original brand asset after generation, so the model cannot alter it.
export async function brandGiftArtwork(data:Buffer):Promise<Buffer>{
 const image=sharp(data,{limitInputPixels:16777216});
 const {width,height}=await image.metadata();
 if(!width||!height||width<128||height<128)throw Error('Invalid artwork dimensions');
 const unit=Math.min(width,height),margin=Math.round(unit*.024),padding=Math.round(unit*.012);
 const logo=await sharp(await readFile(path.join(process.cwd(),'public/menu-art/logo-mb-atelier-cafe-czarne.svg'))).resize({width:Math.round(unit*.19)}).png().toBuffer();
 const size=await sharp(logo).metadata(),badgeWidth=size.width!+padding*2,badgeHeight=size.height!+padding*2;
 const panel=Buffer.from(`<svg xmlns="http://www.w3.org/2000/svg" width="${badgeWidth}" height="${badgeHeight}"><rect width="100%" height="100%" rx="${padding}" fill="white" fill-opacity="0.94"/></svg>`);
 const badge=await sharp(panel).composite([{input:logo,left:padding,top:padding}]).png().toBuffer();
 return image.composite([{input:badge,left:width-badgeWidth-margin,top:height-badgeHeight-margin}]).png().toBuffer();
}
