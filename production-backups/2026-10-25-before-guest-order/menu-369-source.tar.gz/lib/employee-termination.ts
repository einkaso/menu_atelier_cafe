export function parseTerminationDate(value: unknown): string | null | undefined {
  if (value === undefined) return undefined;
  if (value === null || value === "") return null;
  if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value)) throw new Error("Podaj prawidłową datę zwolnienia.");
  const date = new Date(value + "T12:00:00Z");
  if (Number.isNaN(date.getTime()) || date.toISOString().slice(0, 10) !== value || value < "1900-01-01") throw new Error("Podaj prawidłową datę zwolnienia.");
  return value;
}
