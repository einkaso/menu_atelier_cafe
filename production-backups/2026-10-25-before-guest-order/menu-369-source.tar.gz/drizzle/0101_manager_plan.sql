CREATE TABLE IF NOT EXISTS manager_plan_days (
 work_date date PRIMARY KEY,
 kind text CHECK (kind IN ('WORK','LEAVE','SICK')),
 intervals jsonb NOT NULL DEFAULT '[]',
 note text NOT NULL DEFAULT '',
 revision integer NOT NULL DEFAULT 1 CHECK (revision > 0),
 updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS manager_plan_audit (
 id bigserial PRIMARY KEY,
 work_date date NOT NULL,
 actor text NOT NULL,
 before_entry jsonb,
 after_entry jsonb NOT NULL,
 changed_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS manager_plan_audit_date ON manager_plan_audit(work_date,id DESC);
