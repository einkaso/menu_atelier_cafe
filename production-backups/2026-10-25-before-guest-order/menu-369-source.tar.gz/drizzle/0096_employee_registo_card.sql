ALTER TABLE waiter_employees ADD COLUMN IF NOT EXISTS registo_qr_hash text;
CREATE UNIQUE INDEX IF NOT EXISTS waiter_employees_registo_qr_hash_uq ON waiter_employees(registo_qr_hash);
