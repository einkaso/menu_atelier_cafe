BEGIN;
ALTER TABLE staff_instructions ADD COLUMN IF NOT EXISTS content_version integer NOT NULL DEFAULT 1;
ALTER TABLE staff_instruction_receipts ADD COLUMN IF NOT EXISTS content_version integer;
CREATE TABLE IF NOT EXISTS staff_instruction_versions (
 id serial PRIMARY KEY, instruction_id integer NOT NULL REFERENCES staff_instructions(id) ON DELETE CASCADE,
 content_version integer NOT NULL, revision integer NOT NULL, title text NOT NULL, content text NOT NULL,
 attachments jsonb NOT NULL DEFAULT '[]', updated_by text NOT NULL, created_at timestamptz NOT NULL DEFAULT now(),
 CONSTRAINT staff_instruction_versions_uq UNIQUE (instruction_id, content_version)
);
INSERT INTO staff_instruction_versions(instruction_id, content_version, revision, title, content, attachments, updated_by, created_at)
 SELECT id,content_version,revision,title,content,attachments,updated_by,updated_at FROM staff_instructions ON CONFLICT DO NOTHING;
-- Only the current revision can be reconstructed; never invent historical text.
UPDATE staff_instruction_receipts r SET content_version=i.content_version FROM staff_instructions i
 WHERE r.instruction_id=i.id AND r.instruction_revision=i.revision AND r.acknowledged_at IS NOT NULL AND r.content_version IS NULL;
CREATE OR REPLACE FUNCTION staff_instruction_bump_version() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF (NEW.title,NEW.content,NEW.attachments,NEW.revision) IS DISTINCT FROM (OLD.title,OLD.content,OLD.attachments,OLD.revision) THEN
  NEW.content_version := OLD.content_version + 1;
 ELSE NEW.content_version := OLD.content_version; END IF;
 RETURN NEW;
END $$;
CREATE OR REPLACE FUNCTION staff_instruction_snapshot() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 INSERT INTO staff_instruction_versions(instruction_id,content_version,revision,title,content,attachments,updated_by)
 VALUES(NEW.id,NEW.content_version,NEW.revision,NEW.title,NEW.content,NEW.attachments,NEW.updated_by) ON CONFLICT DO NOTHING;
 RETURN NEW;
END $$;
DROP TRIGGER IF EXISTS staff_instruction_bump_version ON staff_instructions;
CREATE TRIGGER staff_instruction_bump_version BEFORE UPDATE ON staff_instructions FOR EACH ROW EXECUTE FUNCTION staff_instruction_bump_version();
DROP TRIGGER IF EXISTS staff_instruction_snapshot ON staff_instructions;
CREATE TRIGGER staff_instruction_snapshot AFTER INSERT OR UPDATE ON staff_instructions FOR EACH ROW EXECUTE FUNCTION staff_instruction_snapshot();
COMMIT;
