CREATE TABLE IF NOT EXISTS inventory_product_policies (
 product_id text PRIMARY KEY REFERENCES inventory_catalog_products(dotykacka_id),
 interval_days integer NOT NULL CHECK(interval_days IN (1,5,6,7,14,30)),
 minimum_quantity numeric(14,3) NOT NULL DEFAULT 0 CHECK(minimum_quantity>=0),
 lead_days integer NOT NULL DEFAULT 1 CHECK(lead_days BETWEEN 0 AND 60),
 updated_by text NOT NULL, updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS inventory_losses (
 id serial PRIMARY KEY, request_id uuid NOT NULL UNIQUE,
 product_id text NOT NULL REFERENCES inventory_catalog_products(dotykacka_id),
 quantity numeric(14,3) NOT NULL CHECK(quantity>0),
 remaining_quantity numeric(14,3) NOT NULL CHECK(remaining_quantity>=0),
 reason text NOT NULL CHECK(reason IN ('ZEPSUCIE','PRZETERMINOWANIE','ZNISZCZENIE','ZAGUBIENIE','INNE')),
 note text NOT NULL, actor_id text NOT NULL, actor_name text NOT NULL,
 created_at timestamptz NOT NULL DEFAULT now(),
 status text NOT NULL DEFAULT 'REPORTED' CHECK(status IN ('REPORTED','REVIEWED','VOID')),
 reviewed_by text, reviewed_at timestamptz, review_note text
);
CREATE TABLE IF NOT EXISTS inventory_reminder_resolutions (
 origin text PRIMARY KEY, resolved_by text NOT NULL, resolved_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE inventory_stages ADD COLUMN IF NOT EXISTS quality_required boolean NOT NULL DEFAULT false;
ALTER TABLE inventory_stage_items ADD COLUMN IF NOT EXISTS quality jsonb;
