CREATE TABLE "recovered_photo_assignments" (
 "sha256" text PRIMARY KEY NOT NULL,
 "product_id" integer NOT NULL REFERENCES "menu_products"("id"),
 "image_path" text NOT NULL,
 "assigned_by" text NOT NULL,
 "assigned_at" timestamp with time zone DEFAULT now() NOT NULL
);
