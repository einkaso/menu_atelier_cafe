ALTER TABLE "kitchen_dish_components" ADD COLUMN "pending_recipe_id" integer REFERENCES "kitchen_recipes"("id") ON DELETE RESTRICT;
--> statement-breakpoint
ALTER TABLE "kitchen_dish_components" ADD CONSTRAINT "kitchen_dish_component_pending_check" CHECK ("pending_recipe_id" IS NULL OR ("mode" = 'RECIPE' AND "recipe_version_id" IS NULL));
--> statement-breakpoint
CREATE INDEX "kitchen_dish_components_pending_recipe_idx" ON "kitchen_dish_components" ("pending_recipe_id");
