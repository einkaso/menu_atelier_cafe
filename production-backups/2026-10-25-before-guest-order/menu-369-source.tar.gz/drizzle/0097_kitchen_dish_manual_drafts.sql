CREATE TABLE IF NOT EXISTS kitchen_dish_manual_drafts (
 product_id integer PRIMARY KEY REFERENCES menu_products(id) ON DELETE CASCADE,
 instructions text,
 revision integer NOT NULL DEFAULT 0,
 updated_by text NOT NULL,
 updated_at timestamptz NOT NULL DEFAULT now()
);
