ALTER TABLE "waiter_employees" ADD COLUMN IF NOT EXISTS "can_view_reports" boolean DEFAULT false NOT NULL;
--> statement-breakpoint
CREATE TABLE "work_report_payouts" (
 "id" serial PRIMARY KEY NOT NULL,
 "employee_dotykacka_id" text NOT NULL,
 "employee_name" text NOT NULL,
 "date_from" date NOT NULL,
 "date_to" date NOT NULL,
 "amount" numeric(12,2) NOT NULL,
 "allocation_ids" jsonb NOT NULL,
 "adjustment_ids" jsonb NOT NULL,
 "paid_by" text NOT NULL,
 "paid_at" timestamp with time zone DEFAULT now() NOT NULL
);
