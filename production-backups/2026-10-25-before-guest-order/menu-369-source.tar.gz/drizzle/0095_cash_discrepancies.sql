ALTER TABLE waiter_settlements ADD COLUMN handed_by_dotykacka_id text;
ALTER TABLE waiter_settlements ADD COLUMN handed_by_name text;
CREATE TABLE waiter_cash_discrepancies (
 id serial PRIMARY KEY,
 cash_day_id integer NOT NULL REFERENCES waiter_cash_days(id) ON DELETE RESTRICT,
 settlement_id integer REFERENCES waiter_settlements(id) ON DELETE RESTRICT,
 kind text NOT NULL CONSTRAINT cash_discrepancy_kind_check CHECK (kind IN ('OPEN','HANDOVER','CLOSE')),
 business_date date NOT NULL,
 expected_cash numeric(12,2) NOT NULL,
 counted_cash numeric(12,2) NOT NULL CONSTRAINT cash_discrepancy_counted_check CHECK (counted_cash >= 0),
 difference numeric(12,2) NOT NULL CONSTRAINT cash_discrepancy_difference_check CHECK (difference <> 0 AND difference = counted_cash - expected_cash),
 handed_by_dotykacka_id text,
 handed_by_name text,
 counted_by_dotykacka_id text NOT NULL,
 counted_by_name text NOT NULL,
 employee_note text NOT NULL,
 status text NOT NULL DEFAULT 'OPEN' CONSTRAINT cash_discrepancy_status_check CHECK (status IN ('OPEN','RESOLVED')),
 resolution text,
 resolved_by text,
 resolved_at timestamptz,
 created_at timestamptz NOT NULL DEFAULT now(),
 CONSTRAINT cash_discrepancy_source_check CHECK ((kind='OPEN' AND settlement_id IS NULL) OR (kind<>'OPEN' AND settlement_id IS NOT NULL)),
 CONSTRAINT cash_discrepancy_resolution_check CHECK ((status='OPEN' AND resolved_at IS NULL AND resolved_by IS NULL AND resolution IS NULL) OR (status='RESOLVED' AND resolved_at IS NOT NULL AND resolved_by IS NOT NULL AND resolution IS NOT NULL AND length(trim(resolution))>0))
);
CREATE UNIQUE INDEX waiter_cash_discrepancies_opening_uq ON waiter_cash_discrepancies(cash_day_id) WHERE kind='OPEN';
CREATE UNIQUE INDEX waiter_cash_discrepancies_settlement_uq ON waiter_cash_discrepancies(settlement_id) WHERE settlement_id IS NOT NULL;
CREATE INDEX waiter_cash_discrepancies_status_idx ON waiter_cash_discrepancies(status,created_at);
