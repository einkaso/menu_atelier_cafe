ALTER TABLE "waiter_employees" ADD COLUMN IF NOT EXISTS "can_control_xr18" boolean DEFAULT false NOT NULL;
--> statement-breakpoint
ALTER TABLE "waiter_employees" ADD COLUMN IF NOT EXISTS "xr18_pin_hash" text;
--> statement-breakpoint
CREATE TABLE "xr18_control_events" (
	"id" serial PRIMARY KEY NOT NULL,
	"actor_dotykacka_id" text NOT NULL,
	"actor_name" text NOT NULL,
	"target_id" text NOT NULL,
	"property" text NOT NULL,
	"previous_value" jsonb,
	"requested_value" jsonb NOT NULL,
	"observed_value" jsonb,
	"status" text NOT NULL,
	"error" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE INDEX "xr18_control_events_target_created_idx" ON "xr18_control_events" USING btree ("target_id","created_at");
--> statement-breakpoint
CREATE INDEX "xr18_control_events_actor_created_idx" ON "xr18_control_events" USING btree ("actor_dotykacka_id","created_at");
