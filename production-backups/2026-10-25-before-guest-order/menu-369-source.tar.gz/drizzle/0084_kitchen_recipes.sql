CREATE TABLE "kitchen_recipes" (
  "id" serial PRIMARY KEY,
  "archived" boolean NOT NULL DEFAULT false,
  "created_by" text NOT NULL,
  "created_at" timestamptz NOT NULL DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "kitchen_recipe_versions" (
  "id" serial PRIMARY KEY,
  "recipe_id" integer NOT NULL REFERENCES "kitchen_recipes"("id") ON DELETE RESTRICT,
  "version" integer NOT NULL,
  "status" text NOT NULL DEFAULT 'DRAFT' CHECK ("status" IN ('DRAFT', 'PUBLISHED')),
  "content" jsonb NOT NULL,
  "media" jsonb NOT NULL DEFAULT '[]'::jsonb,
  "edit_revision" integer NOT NULL DEFAULT 1,
  "updated_by" text NOT NULL,
  "updated_at" timestamptz NOT NULL DEFAULT now(),
  "published_at" timestamptz,
  CONSTRAINT "kitchen_recipe_versions_number_uq" UNIQUE ("recipe_id", "version")
);
--> statement-breakpoint
CREATE UNIQUE INDEX "kitchen_recipe_one_draft_uq" ON "kitchen_recipe_versions" ("recipe_id") WHERE "status" = 'DRAFT';
--> statement-breakpoint
CREATE TABLE "kitchen_dish_cards" (
  "product_id" integer PRIMARY KEY REFERENCES "menu_products"("id") ON DELETE CASCADE,
  "revision" integer NOT NULL DEFAULT 1,
  "updated_by" text NOT NULL,
  "updated_at" timestamptz NOT NULL DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "kitchen_dish_components" (
  "id" serial PRIMARY KEY,
  "product_id" integer NOT NULL REFERENCES "kitchen_dish_cards"("product_id") ON DELETE CASCADE,
  "name" text NOT NULL,
  "mode" text NOT NULL,
  "recipe_version_id" integer REFERENCES "kitchen_recipe_versions"("id") ON DELETE RESTRICT,
  "quantity" text NOT NULL,
  "unit" text NOT NULL,
  "notes" text NOT NULL DEFAULT '',
  "sort_order" integer NOT NULL,
  CONSTRAINT "kitchen_dish_component_mode_check" CHECK ("mode" IN ('RECIPE', 'PURCHASED') AND ("mode" <> 'PURCHASED' OR "recipe_version_id" IS NULL))
);
--> statement-breakpoint
CREATE INDEX "kitchen_dish_components_product_idx" ON "kitchen_dish_components" ("product_id");
--> statement-breakpoint
CREATE INDEX "kitchen_dish_components_version_idx" ON "kitchen_dish_components" ("recipe_version_id");
