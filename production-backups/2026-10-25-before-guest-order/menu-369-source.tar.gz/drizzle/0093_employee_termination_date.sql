ALTER TABLE waiter_employees ADD COLUMN IF NOT EXISTS termination_date date;
