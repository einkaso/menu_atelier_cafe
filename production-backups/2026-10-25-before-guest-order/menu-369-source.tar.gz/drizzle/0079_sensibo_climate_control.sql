ALTER TABLE "waiter_employees" ADD COLUMN IF NOT EXISTS "can_control_climate" boolean DEFAULT false NOT NULL;
--> statement-breakpoint
CREATE TABLE "climate_control_events" (
	"id" serial PRIMARY KEY NOT NULL,
	"actor_dotykacka_id" text NOT NULL,
	"actor_name" text NOT NULL,
	"room_key" text NOT NULL,
	"room_name" text NOT NULL,
	"device_id" text NOT NULL,
	"property" text NOT NULL,
	"requested_value" jsonb NOT NULL,
	"status" text NOT NULL,
	"error" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE INDEX "climate_control_events_room_created_idx" ON "climate_control_events" USING btree ("room_key","created_at");
--> statement-breakpoint
CREATE INDEX "climate_control_events_actor_created_idx" ON "climate_control_events" USING btree ("actor_dotykacka_id","created_at");
