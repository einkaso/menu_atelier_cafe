ALTER TABLE "waiter_employees" ADD COLUMN IF NOT EXISTS "can_control_heating" boolean DEFAULT false NOT NULL;
--> statement-breakpoint
CREATE TABLE "netatmo_connections" (
	"id" text PRIMARY KEY DEFAULT 'primary' NOT NULL,
	"access_token_encrypted" text NOT NULL,
	"refresh_token_encrypted" text NOT NULL,
	"expires_at" timestamp with time zone NOT NULL,
	"scopes" jsonb DEFAULT '[]'::jsonb NOT NULL,
	"connected_by" text NOT NULL,
	"connected_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "heating_control_events" (
	"id" serial PRIMARY KEY NOT NULL,
	"actor_dotykacka_id" text NOT NULL,
	"actor_name" text NOT NULL,
	"home_id" text NOT NULL,
	"home_name" text NOT NULL,
	"room_id" text,
	"room_name" text,
	"action" text NOT NULL,
	"requested_value" jsonb NOT NULL,
	"status" text NOT NULL,
	"error" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE INDEX "heating_control_events_home_created_idx" ON "heating_control_events" USING btree ("home_id","created_at");
--> statement-breakpoint
CREATE INDEX "heating_control_events_room_created_idx" ON "heating_control_events" USING btree ("room_id","created_at");
--> statement-breakpoint
CREATE INDEX "heating_control_events_actor_created_idx" ON "heating_control_events" USING btree ("actor_dotykacka_id","created_at");
