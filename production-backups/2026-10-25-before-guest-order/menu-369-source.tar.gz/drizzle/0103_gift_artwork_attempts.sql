CREATE TABLE IF NOT EXISTS gift_artwork_attempts (
 request_key uuid PRIMARY KEY,
 owner_hash text NOT NULL,
 network_hash text NOT NULL,
 body_hash text NOT NULL,
 job_id uuid,
 is_test boolean NOT NULL,
 created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS gift_artwork_attempts_owner_idx ON gift_artwork_attempts(owner_hash,created_at);
CREATE INDEX IF NOT EXISTS gift_artwork_attempts_network_idx ON gift_artwork_attempts(network_hash,created_at);
