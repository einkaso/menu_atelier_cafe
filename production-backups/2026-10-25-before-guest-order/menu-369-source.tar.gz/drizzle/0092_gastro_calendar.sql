CREATE TABLE gastro_occurrences (
 event_id text NOT NULL, year integer NOT NULL CHECK(year BETWEEN 2025 AND 2199),
 decision text NOT NULL DEFAULT 'UNDECIDED' CHECK(decision IN ('UNDECIDED','CELEBRATE','SKIP','LATER')),
 snooze_until text, date_override text, date_note text NOT NULL DEFAULT '', note text NOT NULL DEFAULT '',
 plan jsonb NOT NULL DEFAULT '{}'::jsonb, plan_approved_at timestamptz, plan_approved_by text,
 version integer NOT NULL DEFAULT 0, updated_by text NOT NULL, updated_at timestamptz NOT NULL DEFAULT now(),
 PRIMARY KEY(event_id,year)
);
CREATE TABLE gastro_tasks (
 id serial PRIMARY KEY, event_id text NOT NULL, year integer NOT NULL,
 title text NOT NULL, due_date text NOT NULL, owner text NOT NULL,
 status text NOT NULL DEFAULT 'TODO' CHECK(status IN ('TODO','DONE')),
 completion_note text NOT NULL DEFAULT '',completed_at timestamptz,completed_by text,
 FOREIGN KEY(event_id,year) REFERENCES gastro_occurrences(event_id,year) ON DELETE CASCADE
);
CREATE INDEX gastro_tasks_occurrence_idx ON gastro_tasks(event_id,year);
CREATE TABLE gastro_audit (
 id serial PRIMARY KEY,event_id text NOT NULL,year integer NOT NULL,actor text NOT NULL,
 action text NOT NULL,details jsonb NOT NULL,created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE gastro_notices (
 key text PRIMARY KEY,event_id text NOT NULL,year integer NOT NULL,title text NOT NULL,message text NOT NULL,
 due text NOT NULL,level text NOT NULL,kind text NOT NULL,active boolean NOT NULL DEFAULT true,
 first_seen_at timestamptz NOT NULL DEFAULT now(),last_checked_at timestamptz NOT NULL DEFAULT now(),resolved_at timestamptz
);
CREATE TABLE gastro_monitor_runs (
 id serial PRIMARY KEY,checked_at timestamptz NOT NULL DEFAULT now(),open_count integer NOT NULL
);
