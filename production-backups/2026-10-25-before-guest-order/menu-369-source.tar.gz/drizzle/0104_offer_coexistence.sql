ALTER TABLE menu_offer_settings ADD COLUMN IF NOT EXISTS special_replaces_seasonal boolean NOT NULL DEFAULT true;
