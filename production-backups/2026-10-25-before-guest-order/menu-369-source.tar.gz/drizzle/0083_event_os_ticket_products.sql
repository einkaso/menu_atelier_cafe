CREATE TABLE "event_os_ticket_products" (
 "price_id" text PRIMARY KEY NOT NULL,
 "event_id" text NOT NULL,
 "source_version" integer NOT NULL,
 "source_digest" text NOT NULL,
 "product_id" text,
 "pending" boolean DEFAULT false NOT NULL,
 "updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
