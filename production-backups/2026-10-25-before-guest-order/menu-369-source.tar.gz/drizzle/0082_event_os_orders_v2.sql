ALTER TABLE event_os_events ADD COLUMN finished_at timestamptz;
--> statement-breakpoint
ALTER TABLE event_os_orders ADD COLUMN source_version integer;
--> statement-breakpoint
ALTER TABLE event_os_orders ADD COLUMN source_digest text;
--> statement-breakpoint
ALTER TABLE event_os_orders ADD COLUMN menu_version integer NOT NULL DEFAULT 0;
--> statement-breakpoint
CREATE TABLE event_os_order_actions (
  request_id text PRIMARY KEY, order_id text NOT NULL REFERENCES event_os_orders(external_id),
  actor text NOT NULL, action text NOT NULL, payload_digest text NOT NULL, result jsonb NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
