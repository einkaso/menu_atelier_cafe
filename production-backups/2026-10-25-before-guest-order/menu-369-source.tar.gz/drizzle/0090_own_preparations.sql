CREATE TABLE inventory_own_products (
 id serial PRIMARY KEY,
 name text NOT NULL CHECK(length(trim(name)) BETWEEN 1 AND 160),
 unit text NOT NULL CHECK(unit IN ('kg','l','szt.','porcja')),
 interval_days integer NOT NULL CHECK(interval_days IN (1,5,6,7,14,30)),
 minimum_quantity numeric(14,3) NOT NULL DEFAULT 0 CHECK(minimum_quantity >= 0),
 archived boolean NOT NULL DEFAULT false,
 created_by text NOT NULL, created_at timestamptz NOT NULL DEFAULT now(),
 updated_by text NOT NULL, updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX inventory_own_products_name ON inventory_own_products(lower(trim(name))) WHERE NOT archived;
ALTER TABLE inventory_stage_items ADD COLUMN inventory_source text NOT NULL DEFAULT 'DOTYKACKA' CHECK(inventory_source IN ('DOTYKACKA','OWN'));
ALTER TABLE inventory_stage_items ADD COLUMN own_product_id integer REFERENCES inventory_own_products(id);
ALTER TABLE inventory_stage_items ADD CONSTRAINT inventory_item_source_check CHECK((inventory_source='OWN' AND own_product_id IS NOT NULL AND product_dotykacka_id='own:'||own_product_id::text) OR (inventory_source='DOTYKACKA' AND own_product_id IS NULL));
CREATE TABLE inventory_own_product_events (
 id serial PRIMARY KEY, product_id integer NOT NULL REFERENCES inventory_own_products(id),
 actor_id text NOT NULL, details jsonb NOT NULL, created_at timestamptz NOT NULL DEFAULT now()
);
