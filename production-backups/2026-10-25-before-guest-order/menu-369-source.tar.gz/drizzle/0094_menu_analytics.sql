CREATE TABLE IF NOT EXISTS menu_analytics_events (
  id text PRIMARY KEY, session_id text NOT NULL, view_id text,
  kind text NOT NULL CHECK (kind IN ('category_view','product_open','product_time','allergen_open')),
  category text NOT NULL, category_name text NOT NULL, product_id integer, product_name text,
  duration_ms integer NOT NULL DEFAULT 0 CHECK (duration_ms BETWEEN 0 AND 30000),
  device text NOT NULL CHECK (device IN ('tablet','phone','desktop')),
  occurred_at timestamptz NOT NULL, received_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS menu_analytics_occurred_idx ON menu_analytics_events(occurred_at);
CREATE INDEX IF NOT EXISTS menu_analytics_view_idx ON menu_analytics_events(view_id);
