ALTER TABLE "menu_offer_settings" ADD COLUMN "welcome_layout" text DEFAULT 'portrait' NOT NULL;
--> statement-breakpoint
ALTER TABLE "menu_offer_settings" ADD CONSTRAINT "menu_offer_settings_welcome_layout_check" CHECK ("welcome_layout" IN ('portrait', 'tiles'));
