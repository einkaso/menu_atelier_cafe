ALTER TABLE menu_offer_settings ADD COLUMN IF NOT EXISTS special_starts_at timestamptz;
ALTER TABLE menu_offer_settings ADD COLUMN IF NOT EXISTS special_ends_at timestamptz;
