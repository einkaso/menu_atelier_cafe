CREATE TABLE IF NOT EXISTS kitchen_queue_state (
 id integer PRIMARY KEY CHECK (id=1),
 state jsonb NOT NULL DEFAULT '{"orders":{},"batches":[]}'::jsonb,
 excluded_table_ids jsonb NOT NULL DEFAULT '[]'::jsonb,
 last_success_at timestamptz
);
INSERT INTO kitchen_queue_state(id,excluded_table_ids) VALUES (1,'["4329247220398845","1373248863832221","3918622577100907","2256315614726316"]'::jsonb) ON CONFLICT (id) DO NOTHING;
