CREATE TABLE inventory_keg_settings (
 product_id text PRIMARY KEY,
 capacity_liters integer CHECK(capacity_liters IN (20,30,50)),
 updated_by text NOT NULL, updated_at timestamptz NOT NULL DEFAULT now()
);
INSERT INTO inventory_keg_settings(product_id,capacity_liters,updated_by) VALUES
 ('1528749922760391',20,'initial-configuration'),('2113036097020351',30,'user-confirmed');
CREATE TABLE inventory_keg_counts (
 id serial PRIMARY KEY, request_id uuid NOT NULL UNIQUE,
 product_id text NOT NULL REFERENCES inventory_keg_settings(product_id),
 capacity_liters integer NOT NULL CHECK(capacity_liters IN (20,30,50)),
 full_spare_kegs integer NOT NULL CHECK(full_spare_kegs BETWEEN 0 AND 1000),
 connected_full boolean NOT NULL,
 liters numeric(14,3) NOT NULL CHECK(liters>=0),
 stage_id integer NOT NULL UNIQUE REFERENCES inventory_stages(id),
 actor_id text NOT NULL, actor_name text NOT NULL,
 note text NOT NULL, counted_at timestamptz NOT NULL DEFAULT now()
);
UPDATE inventory_catalog_products SET inventory_tracked=false WHERE dotykacka_id IN
 ('2113034865920067','2113033250521259','2303182221952635','2303181343900559','1528749922760391','2113036097020351');
ALTER TABLE inventory_exports ADD COLUMN batch_results jsonb NOT NULL DEFAULT '[]'::jsonb;
