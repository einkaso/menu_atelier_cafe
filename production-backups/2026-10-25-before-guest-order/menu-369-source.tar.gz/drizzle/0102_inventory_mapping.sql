CREATE TABLE inventory_count_groups (
 id serial PRIMARY KEY, name text NOT NULL, unit text NOT NULL, interval_days integer NOT NULL CHECK(interval_days BETWEEN 1 AND 366), enabled boolean NOT NULL DEFAULT true,
 revision integer NOT NULL DEFAULT 1, updated_by text NOT NULL, updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE inventory_product_mapping (
 product_id text PRIMARY KEY REFERENCES inventory_catalog_products(dotykacka_id), group_id integer REFERENCES inventory_count_groups(id),
 factor numeric(14,3) NOT NULL DEFAULT 1 CHECK(factor>0), ignored boolean NOT NULL DEFAULT false, reason text NOT NULL DEFAULT '',
 updated_by text NOT NULL, updated_at timestamptz NOT NULL DEFAULT now(), CHECK ((ignored AND group_id IS NULL) OR (NOT ignored AND group_id IS NOT NULL))
);
CREATE TABLE inventory_mapping_audit (id bigserial PRIMARY KEY, actor text NOT NULL, details jsonb NOT NULL, created_at timestamptz NOT NULL DEFAULT now());
CREATE TABLE inventory_group_counts (
 item_id integer PRIMARY KEY REFERENCES inventory_stage_items(id) ON DELETE CASCADE, group_id integer NOT NULL REFERENCES inventory_count_groups(id),
 members jsonb NOT NULL, resolved_at timestamptz, resolved_by text
);
CREATE TABLE inventory_morning_audience (
 stage_id integer NOT NULL REFERENCES inventory_stages(id) ON DELETE CASCADE, employee_id text NOT NULL, PRIMARY KEY(stage_id,employee_id)
);
CREATE INDEX inventory_group_counts_group_idx ON inventory_group_counts(group_id);
ALTER TABLE inventory_stage_items DROP CONSTRAINT inventory_stage_items_inventory_source_check;
ALTER TABLE inventory_stage_items DROP CONSTRAINT inventory_item_source_check;
ALTER TABLE inventory_stage_items ADD CONSTRAINT inventory_stage_items_inventory_source_check CHECK(inventory_source IN ('DOTYKACKA','OWN','GROUP'));
ALTER TABLE inventory_stage_items ADD CONSTRAINT inventory_item_source_check CHECK(
 (inventory_source='OWN' AND own_product_id IS NOT NULL AND product_dotykacka_id='own:'||own_product_id::text) OR
 (inventory_source='DOTYKACKA' AND own_product_id IS NULL) OR
 (inventory_source='GROUP' AND own_product_id IS NULL AND product_dotykacka_id ~ '^group:[0-9]+$')
);
