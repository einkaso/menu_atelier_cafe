import dgram from "node:dgram";
import { fileURLToPath } from "node:url";
import { hostsFromCidr } from "../lighting/discovery.mjs";
import { decodeOscMessage, encodeOscMessage } from "./osc.mjs";

export const XR18_OSC_PORT = 10024;
const DISCOVERY_ADDRESS = "/xinfo";

export async function discoverXAirNetwork(cidr, { timeoutMs = 2500, port = XR18_OSC_PORT } = {}) {
  const hosts = hostsFromCidr(cidr);
  const socket = dgram.createSocket("udp4");
  const request = encodeOscMessage(DISCOVERY_ADDRESS);
  const devices = new Map();

  await new Promise((resolve, reject) => {
    let settled = false;
    const finish = (error) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      socket.close();
      error ? reject(error) : resolve();
    };
    const timer = setTimeout(() => finish(), timeoutMs);

    socket.on("error", finish);
    socket.on("message", (message, remote) => {
      try {
        const decoded = decodeOscMessage(message);
        if (decoded.address !== DISCOVERY_ADDRESS && decoded.address !== "/info") return;
        const values = decoded.args.map((argument) => argument.value);
        devices.set(remote.address, {
          host: remote.address,
          port: remote.port,
          address: decoded.address,
          values,
        });
      } catch {
        // Ignore unrelated UDP traffic and malformed packets.
      }
    });
    socket.bind(0, "0.0.0.0", () => {
      for (const host of hosts) socket.send(request, port, host);
    });
  });

  return {
    discoveredAt: new Date().toISOString(),
    cidr,
    scannedHosts: hosts.length,
    devices: [...devices.values()].sort((left, right) => left.host.localeCompare(right.host, undefined, { numeric: true })),
  };
}

function argumentValue(name) {
  const position = process.argv.indexOf(name);
  return position === -1 ? null : process.argv[position + 1];
}

if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1]) {
  const cidr = argumentValue("--cidr") ?? process.env.XR18_DISCOVERY_CIDR ?? "192.168.1.0/24";
  const timeoutMs = Number(argumentValue("--timeout-ms") ?? 2500);
  const result = await discoverXAirNetwork(cidr, { timeoutMs });
  process.stdout.write(`${JSON.stringify(result, null, 2)}\n`);
}
