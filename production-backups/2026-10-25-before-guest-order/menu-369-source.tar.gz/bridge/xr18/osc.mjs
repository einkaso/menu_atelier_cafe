const OSC_ALIGNMENT = 4;

function paddedLength(length) {
  return Math.ceil((length + 1) / OSC_ALIGNMENT) * OSC_ALIGNMENT;
}

function encodeString(value) {
  const bytes = Buffer.from(String(value), "utf8");
  const encoded = Buffer.alloc(paddedLength(bytes.length));
  bytes.copy(encoded);
  return encoded;
}

function readString(buffer, offset) {
  if (!Buffer.isBuffer(buffer) || offset < 0 || offset >= buffer.length) {
    throw new Error("Nieprawidłowy ciąg OSC.");
  }
  const end = buffer.indexOf(0, offset);
  if (end === -1) throw new Error("Ciąg OSC nie ma terminatora.");
  const nextOffset = offset + paddedLength(end - offset);
  if (nextOffset > buffer.length) throw new Error("Niepełny ciąg OSC.");
  return { value: buffer.toString("utf8", offset, end), nextOffset };
}

function normalizeArgument(argument) {
  if (typeof argument === "string") return { type: "s", value: argument };
  if (argument && typeof argument === "object" && ["s", "i", "f", "b"].includes(argument.type)) {
    return argument;
  }
  throw new Error("Nieobsługiwany argument OSC.");
}

export function encodeOscMessage(address, args = []) {
  if (typeof address !== "string" || !address.startsWith("/") || address.includes("\0")) {
    throw new Error("Nieprawidłowy adres OSC.");
  }
  const normalized = args.map(normalizeArgument);
  const parts = [encodeString(address), encodeString(`,${normalized.map((argument) => argument.type).join("")}`)];
  for (const argument of normalized) {
    if (argument.type === "s") {
      parts.push(encodeString(argument.value));
    } else if (argument.type === "i") {
      const value = Buffer.alloc(4);
      value.writeInt32BE(Number(argument.value), 0);
      parts.push(value);
    } else if (argument.type === "f") {
      const value = Buffer.alloc(4);
      value.writeFloatBE(Number(argument.value), 0);
      parts.push(value);
    } else if (argument.type === "b") {
      const bytes = Buffer.from(argument.value);
      const length = Buffer.alloc(4);
      length.writeInt32BE(bytes.length, 0);
      const padding = Buffer.alloc((OSC_ALIGNMENT - (bytes.length % OSC_ALIGNMENT)) % OSC_ALIGNMENT);
      parts.push(length, bytes, padding);
    }
  }
  return Buffer.concat(parts);
}

export function decodeOscMessage(buffer) {
  const addressPart = readString(buffer, 0);
  if (!addressPart.value.startsWith("/")) throw new Error("Odpowiedź nie jest komunikatem OSC.");
  const tagPart = readString(buffer, addressPart.nextOffset);
  if (!tagPart.value.startsWith(",")) throw new Error("Brak znaczników typów OSC.");
  let offset = tagPart.nextOffset;
  const args = [];
  for (const type of tagPart.value.slice(1)) {
    if (type === "s") {
      const part = readString(buffer, offset);
      args.push({ type, value: part.value });
      offset = part.nextOffset;
    } else if (type === "i" || type === "f") {
      if (offset + 4 > buffer.length) throw new Error("Niepełna wartość OSC.");
      args.push({ type, value: type === "i" ? buffer.readInt32BE(offset) : buffer.readFloatBE(offset) });
      offset += 4;
    } else if (type === "b") {
      if (offset + 4 > buffer.length) throw new Error("Niepełny blob OSC.");
      const length = buffer.readInt32BE(offset);
      offset += 4;
      if (length < 0 || offset + length > buffer.length) throw new Error("Nieprawidłowy blob OSC.");
      args.push({ type, value: buffer.subarray(offset, offset + length) });
      offset += Math.ceil(length / OSC_ALIGNMENT) * OSC_ALIGNMENT;
    } else if (type === "T" || type === "F") {
      args.push({ type, value: type === "T" });
    } else {
      throw new Error(`Nieobsługiwany typ OSC: ${type}`);
    }
  }
  return { address: addressPart.value, args };
}
