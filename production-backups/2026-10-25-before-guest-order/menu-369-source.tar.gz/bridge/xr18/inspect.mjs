import dgram from "node:dgram";
import { fileURLToPath } from "node:url";
import { decodeOscMessage, encodeOscMessage } from "./osc.mjs";

function validPrivateHost(host) {
  const parts = String(host).split(".").map(Number);
  if (parts.length !== 4 || parts.some((part) => !Number.isInteger(part) || part < 0 || part > 255)) return false;
  return parts[0] === 10 || (parts[0] === 172 && parts[1] >= 16 && parts[1] <= 31) || (parts[0] === 192 && parts[1] === 168);
}

export function requestOsc(host, address, { port = 10024, timeoutMs = 900 } = {}) {
  if (!validPrivateHost(host)) return Promise.reject(new Error("XR18 musi mieć prywatny adres IPv4."));
  if (!/^\/(xinfo|lr\/mix\/(on|fader|pan)|ch\/(0[1-9]|1[0-6])\/mix\/pan|(ch\/(0[1-9]|1[0-6])|rtn\/(aux|[1-4])|bus\/(0?[1-6]))\/(config\/name|mix\/(on|fader|pan))|dca\/[1-4]\/(config\/name|on|fader))$/.test(address)) {
    return Promise.reject(new Error("Niedozwolone zapytanie diagnostyczne XR18."));
  }
  return new Promise((resolve, reject) => {
    const socket = dgram.createSocket("udp4");
    let settled = false;
    const finish = (error, value) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      socket.close();
      error ? reject(error) : resolve(value);
    };
    const timer = setTimeout(() => finish(new Error(`Brak odpowiedzi XR18 dla ${address}.`)), timeoutMs);
    socket.on("error", (error) => finish(error));
    socket.on("message", (message, remote) => {
      if (remote.address !== host) return;
      try {
        const decoded = decodeOscMessage(message);
        if (decoded.address === address) finish(null, decoded.args.map((argument) => argument.value));
      } catch {
        // Ignore unrelated packets.
      }
    });
    socket.bind(0, "0.0.0.0", () => socket.send(encodeOscMessage(address), port, host));
  });
}

export async function inspectXr18(host) {
  const read = async (address) => (await requestOsc(host, address))[0] ?? null;
  const optionalRead = async (address) => {
    try { return await read(address); } catch { return null; }
  };
  const info = await requestOsc(host, "/xinfo");
  const channels = [];
  for (let index = 1; index <= 16; index += 1) {
    const channel = String(index).padStart(2, "0");
    const [name, on, fader] = await Promise.all([
      read(`/ch/${channel}/config/name`),
      read(`/ch/${channel}/mix/on`),
      read(`/ch/${channel}/mix/fader`),
    ]);
    channels.push({ index, name, on, fader });
  }
  const [auxName, auxOn, auxFader] = await Promise.all([
    read("/rtn/aux/config/name"),
    read("/rtn/aux/mix/on"),
    read("/rtn/aux/mix/fader"),
  ]);
  channels.push({ index: 17, name: auxName, on: auxOn, fader: auxFader, source: "aux" });
  const [mainOn, mainFader] = await Promise.all([read("/lr/mix/on"), read("/lr/mix/fader")]);
  const probes = {};
  for (const base of [
    ...Array.from({ length: 4 }, (_, index) => `/rtn/${index + 1}`),
    ...Array.from({ length: 6 }, (_, index) => `/bus/${index + 1}`),
    ...Array.from({ length: 4 }, (_, index) => `/dca/${index + 1}`),
  ]) {
    probes[base] = {};
    for (const suffix of base.startsWith("/dca/") ? ["config/name", "on", "fader"] : ["config/name", "mix/on", "mix/fader", "mix/pan"]) {
      probes[base][suffix] = await optionalRead(`${base}/${suffix}`);
    }
  }
  probes["/ch/01/mix/pan"] = await optionalRead("/ch/01/mix/pan");
  probes["/lr/mix/pan"] = await optionalRead("/lr/mix/pan");
  return { info, main: { on: mainOn, fader: mainFader }, channels, probes };
}

if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1]) {
  const host = process.argv[2] ?? process.env.XR18_HOST;
  if (!host) throw new Error("Podaj adres XR18 jako pierwszy argument.");
  process.stdout.write(`${JSON.stringify(await inspectXr18(host), null, 2)}\n`);
}
