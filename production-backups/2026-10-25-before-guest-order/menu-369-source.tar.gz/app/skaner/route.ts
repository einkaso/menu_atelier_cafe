import { currentAdmin } from "../../lib/admin-auth";
import { currentWorkforceKiosk, createKioskToken, workforceKioskCookie } from "../../lib/workforce-kiosk-auth";
export const dynamic = "force-dynamic";

// A standalone document keeps camera controls independent of the menu's React
// hydration, service-worker updates and navigation guards on older tablets.
export async function GET(request: Request) {
  const headers = { "Cache-Control": "private, no-store", "X-Robots-Tag": "noindex, nofollow" };
  let scheme = request.headers.get("x-forwarded-proto")?.split(",")[0]?.trim();
  try { scheme = JSON.parse(request.headers.get("cf-visitor") ?? "null")?.scheme ?? scheme; } catch { /* proxy header fallback */ }
  if (request.headers.get("host") === "menu.martabanaszek.pl" && scheme === "http") {
    return new Response(null, { status: 303, headers: { ...headers, Location: "https://menu.martabanaszek.pl/skaner" } });
  }
  const [admin, kiosk] = await Promise.all([currentAdmin(), currentWorkforceKiosk()]);
  if (!admin && !kiosk) return new Response(null, { status: 303, headers: { ...headers, Location: "/kiosk" } });
  const response = new Response(`<!doctype html>
<html lang="pl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="theme-color" content="#062856"><link rel="manifest" href="/kiosk.webmanifest"><meta name="mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-title" content="Kiosk MB Café"><link rel="apple-touch-icon" href="/apple-touch-icon.png"><title>Skaner obecności — Atelier Café</title><link rel="stylesheet" href="/kiosk-scanner-314.css"></head>
<body><main><header><img src="/brand/mb-cafe-black.svg" alt="MB — Marta Banaszek Café" width="900" height="690"><div><small>EWIDENCJA CZASU PRACY</small><h1>Skaner obecności</h1></div>${admin ? '<a href="/admin/workforce">Wyjdź z trybu tabletu</a>' : '<button id="logout" type="button">Wyloguj tablet</button>'}</header>
<section id="result" role="status" aria-live="polite" aria-atomic="true"><strong id="message">Zeskanuj kod QR pracownika</strong><b id="employee"></b><span id="reminder"></span><span id="details"></span><button id="dismiss-result" type="button" hidden>Gotowe</button></section>
<section class="camera"><video id="camera" autoplay muted playsinline webkit-playsinline width="1280" height="960"></video></section>
<button id="start" type="button">Uruchom skaner — przednia kamera</button>
<p id="camera-status" role="status">Uruchamiam kamerę…</p>

<form id="manual"><label for="employee-pin">Awaryjne logowanie PIN-em</label><div><input id="employee-pin" type="password" inputmode="numeric" pattern="[0-9]{4,8}" autocomplete="off" placeholder="Wpisz PIN pracownika" required minlength="4" maxlength="8"><button type="submit">Potwierdź</button></div></form>
<button id="switch-camera" type="button">Przełącz kamerę</button>
<noscript>Włącz JavaScript w ustawieniach przeglądarki, aby uruchomić kamerę.</noscript>
<button id="fullscreen" type="button">Powiększ skaner na cały ekran</button>
</main><script src="/vendor/jsqr-1.4.0/dist/jsQR.js"></script><script src="/vendor/zxing-0.21.3/index.min.js"></script><script src="/kiosk-qr-decoder-302.js"></script><script src="/kiosk-scanner-315.js"></script></body></html>`, { headers: { ...headers, "Content-Type": "text/html; charset=utf-8" } });
  if (admin && !kiosk) response.headers.append("Set-Cookie", `${workforceKioskCookie.name}=${createKioskToken()}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${workforceKioskCookie.maxAge}${process.env.NODE_ENV === "production" ? "; Secure" : ""}`);
  return response;
}
