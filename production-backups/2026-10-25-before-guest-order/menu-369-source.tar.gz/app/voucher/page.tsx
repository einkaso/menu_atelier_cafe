import {headers} from "next/headers";
import {redirect} from "next/navigation";
import {readGiftIntegrationStatus} from '../../lib/event-gifts-integration';
import {sql} from 'drizzle-orm';
import {getDb} from '../../db';
import EventGiftCreator from '../../components/event-gifts/event-gift-creator';
export const dynamic='force-dynamic';
export const metadata={title:'Voucher na wyjątkową okazję | Atelier Café'};
export default async function VoucherPage(){
 const incoming=await headers();
 let scheme=incoming.get('x-forwarded-proto')?.split(',')[0]?.trim();
 try { const visitor=JSON.parse(incoming.get('cf-visitor')??'null');if(visitor?.scheme)scheme=visitor.scheme; } catch {}
 if(incoming.get('host')?.split(':')[0]==='menu.martabanaszek.pl'&&scheme==='http')redirect('https://menu.martabanaszek.pl/voucher');
 const connection=await readGiftIntegrationStatus();
 const rows=await getDb().execute(sql`select external_id,title,starts_at from event_os_events where starts_at>now() and status<>'CANCELLED' order by starts_at`).catch(()=>[]);
 return <div className="is-art-menu gift-public-page"><nav className="gift-public-nav" aria-label="Nawigacja"><a href="/">← Wróć do menu</a><a href="/#menu=events">Koncerty i wydarzenia →</a></nav><EventGiftCreator testCheckoutAvailable={connection.compatible&&connection.capabilities?.testTicket?.available===true} artworkAvailable={connection.compatible&&connection.capabilities?.artworkGeneration?.available===true} publicPreview events={rows.map(r=>({id:String(r.external_id),title:String(r.title),startsAt:new Date(String(r.starts_at)).toISOString()}))}/></div>;
}
