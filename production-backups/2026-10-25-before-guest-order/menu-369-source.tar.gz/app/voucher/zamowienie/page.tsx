import GiftOrderStatus from '../../../components/event-gifts/gift-order-status';
import '../../../components/event-gifts/event-gifts.css';
export const metadata={title:'Status biletu testowego | Atelier Café',robots:{index:false,follow:false},referrer:'no-referrer'};
export default function OrderPage(){return <GiftOrderStatus/>;}
