"use client";
import { useEffect, useState, type ReactNode } from "react";
import {
  ArrowUpRight,
  ArrowRight,
  CalendarCheck,
  ChevronRight,
  Coffee,
  Leaf,
  CheckCheck,
  Settings2,
  ShieldCheck,
  CalendarDays,
} from "lucide-react";
import CalendarSheet from "./calendar-sheet";
import { todayWarsaw } from "../../lib/gastro/core";
type Notice = {
  key: string;
  title: string;
  message: string;
  eventId: string;
  year: number;
  level: string;
};
type Occasion = {
  id: string;
  title: string;
  date: string | null;
  year: number;
  state: { decision: string } | null;
};
export default function AtelierHome({
  name,
  tiles,
  activate,
  customize,
  icon,
  reviewCount,
}: {
  name: string;
  tiles: {
    id: string;
    title: string;
    description: string;
    background?: string;
    foreground?: string;
  }[];
  activate: (id: string) => void;
  customize: () => void;
  icon: (id: string) => ReactNode;
  reviewCount: number;
}) {
  const [data, setData] = useState<{
      notices: Notice[];
      occurrences: Occasion[];
      today: string;
    } | null>(null),
    [error, setError] = useState(false),
    [expanded, setExpanded] = useState(false);
  useEffect(() => {
    let active = true;
    async function load() {
      try {
        const r = await fetch("/api/admin/gastro-calendar", {
          cache: "no-store",
        });
        if (!r.ok) throw Error();
        const body = await r.json();
        if (active) {
          setData(body);
          setError(false);
        }
      } catch {
        if (active) setError(true);
      }
    }
    void load();
    const timer = setInterval(() => void load(), 300000);
    return () => {
      active = false;
      clearInterval(timer);
    };
  }, []);
  const today = data?.today || todayWarsaw();
  const notices =
    data?.notices
      .filter(
        (n, i, all) =>
          all.findIndex((x) => x.eventId === n.eventId && x.year === n.year) ===
          i,
      )
      .slice(0, 2) || [];
  const upcoming =
    data?.occurrences
      .filter((e) => e.date && e.date >= today && e.state?.decision !== "SKIP")
      .sort((a, b) => a.date!.localeCompare(b.date!))
      .slice(0, 3) || [];
  const url = (id: string, year: number) =>
    `/admin/gastro-calendar?event=${encodeURIComponent(id)}&year=${year}`;
  return (
    <div className="atelier-home">
      <header className="atelier-home-heading">
        <div>
          <p className="atelier-kicker">
            {new Date(today + "T12:00:00").toLocaleDateString("pl-PL", {
              weekday: "long",
              day: "numeric",
              month: "long",
            })}
          </p>
          <h2>
            {name.toLowerCase() === "admin"
              ? "Dzień dobry w atelier."
              : `Dzień dobry, ${name}.`}
          </h2>
          <p>Wszystko, czego potrzebujesz do prowadzenia kawiarni.</p>
        </div>
        <button className="atelier-button" onClick={() => activate("products")}>
          Otwórz menu <ArrowUpRight size={15} />
        </button>
      </header>
      <CalendarSheet />
      <div className="atelier-home-columns">
        <section className="atelier-card">
          <div className="atelier-card-heading">
            <h3>Na dobry początek</h3>
            <span>
              {data
                ? `${data.notices.length} spraw w kalendarzu`
                : "Przygotowania"}
            </span>
          </div>
          <div className="atelier-home-tasks">
            {notices.map((n) => (
              <article key={n.key}>
                <span
                  className={
                    "atelier-task-icon " +
                    (n.level === "urgent" ? "attention" : "")
                  }
                >
                  <CalendarCheck size={18} />
                </span>
                <div>
                  <h4>{n.title}</h4>
                  <p>{n.message}</p>
                  <a href={url(n.eventId, n.year)}>
                    Otwórz przygotowania <ArrowRight size={14} />
                  </a>
                </div>
                {n.level === "urgent" && <small>Wymaga uwagi</small>}
              </article>
            ))}
            {!notices.length && (
              <article>
                <span className="atelier-task-icon">
                  <CalendarDays size={18} />
                </span>
                <div>
                  <h4>
                    {error
                      ? "Sprawdź kalendarz gastronomiczny"
                      : data
                        ? "Wszystko na bieżąco"
                        : "Najbliższe okazje w kawiarni"}
                  </h4>
                  <p>
                    {error
                      ? "Nie udało się pobrać przypomnień. Otwórz kalendarz, aby spróbować ponownie."
                      : "Wybierz okazję i zaplanuj kolejne spotkanie z gośćmi."}
                  </p>
                  <a href="/admin/gastro-calendar">
                    Przejdź do kalendarza <ArrowRight size={14} />
                  </a>
                </div>
              </article>
            )}
            <article>
              <span className="atelier-task-icon">
                <Coffee size={18} />
              </span>
              <div>
                <h4>Zadbaj o aktualną kartę</h4>
                <p>
                  {reviewCount
                    ? `${reviewCount} pozycji wymaga przeglądu treści.`
                    : "Produkty, zdjęcia i dostępność w jednym miejscu."}
                </p>
                <button onClick={() => activate("products")}>
                  Przejdź do produktów <ArrowRight size={14} />
                </button>
              </div>
            </article>
          </div>
          <div className="atelier-card-note">
            <CheckCheck size={14} />
            Jedno miejsce na decyzje i kolejne kroki.
          </div>
        </section>
        <aside>
          <section className="atelier-card">
            <div className="atelier-card-heading">
              <h3>Na horyzoncie</h3>
              <a href="/admin/gastro-calendar" aria-label="Otwórz kalendarz">
                <ArrowUpRight size={16} />
              </a>
            </div>
            <div className="atelier-upcoming">
              {upcoming.map((e) => (
                <a key={e.id} href={url(e.id, e.year)}>
                  <span className="atelier-date-stamp">
                    <b>{Number(e.date!.slice(8))}</b>
                    {new Date(e.date! + "T12:00:00").toLocaleDateString(
                      "pl-PL",
                      { month: "short" },
                    )}
                  </span>
                  <span>
                    <strong>{e.title}</strong>
                    <small>
                      {e.state?.decision === "CELEBRATE"
                        ? "Obchodzimy"
                        : e.state?.decision === "LATER"
                          ? "Decyzja później"
                          : "Do decyzji"}
                    </small>
                  </span>
                  <ChevronRight size={15} />
                </a>
              ))}
              {!upcoming.length && (
                <a href="/admin/gastro-calendar">
                  Zobacz kalendarz na cały rok <ChevronRight size={15} />
                </a>
              )}
            </div>
          </section>
          <div className="atelier-home-note">
            <Leaf size={18} />
            Dobry plan zaczyna się miesiąc wcześniej.
          </div>
        </aside>
      </div>
      <div className="atelier-shortcuts-heading">
        <h3>Pod ręką</h3>
        <button onClick={customize}>
          <Settings2 size={14} />
          Dostosuj skróty
        </button>
      </div>
      <div className="atelier-shortcuts">
        {(expanded ? tiles : tiles.slice(0, 6)).map((tile) => (
          <button key={tile.id} onClick={() => activate(tile.id)}>
            <span
              className="atelier-shortcut-icon"
              style={
                tile.background && tile.background !== "paper"
                  ? {
                      background: tile.background,
                      color:
                        tile.foreground && tile.foreground !== "auto"
                          ? tile.foreground
                          : "#fff",
                    }
                  : undefined
              }
            >
              {icon(tile.id)}
            </span>
            <span>
              <strong>{tile.title}</strong>
              <small>{tile.description}</small>
            </span>
            <ChevronRight size={14} />
          </button>
        ))}
      </div>
      {tiles.length > 6 && (
        <button className="atelier-more" onClick={() => setExpanded(!expanded)}>
          {expanded ? "Pokaż mniej" : `Wszystkie moje skróty (${tiles.length})`}
          <ChevronRight size={14} />
        </button>
      )}
      <footer className="atelier-home-footer">
        <span>
          <ShieldCheck size={13} />
          Dostęp administratora
        </span>
        <span>Marta Banaszek atelier-café</span>
      </footer>
    </div>
  );
}
