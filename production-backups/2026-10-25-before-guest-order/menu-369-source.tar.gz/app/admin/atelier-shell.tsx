"use client";
import {
  createContext,
  useContext,
  useEffect,
  useState,
  type ReactNode,
} from "react";
import { usePathname } from "next/navigation";
import {
  LayoutDashboard,
  CalendarDays,
  Armchair,
  PartyPopper,
  Coffee,
  NotebookPen,
  Package,
  Users,
  ChartNoAxesCombined,
  SlidersHorizontal,
  Lightbulb,
  Flame,
  Thermometer,
  Wind,
  DoorOpen,
  Link2,
  BookOpen,
  Image,
  WalletCards,
  Menu,
  X,
  Bell,
  ChevronRight,
  Undo2,
  Check,
  LogOut,
  ShieldCheck,
} from "lucide-react";
const DesignContext = createContext(false);
export const useAtelierDesign = () => useContext(DesignContext);
const groups = [
  {
    label: "Twoja przestrzeń",
    items: [
      { label: "Pulpit", href: "/admin", icon: LayoutDashboard },
      {
        label: "Kalendarz gastro",
        href: "/admin/gastro-calendar",
        icon: CalendarDays,
      },
      { label: "Rezerwacje", href: "/admin/reservations", icon: Armchair },
      { label: "Wydarzenia", href: "/admin/event-os", icon: PartyPopper },
    ],
  },
  {
    label: "Karta i zaplecze",
    items: [
      { label: "Menu i produkty", href: "/admin?view=products", icon: Coffee },
      { label: "Zdjęcia produktów", href: "/admin/photo-review", icon: Image },
      { label: "Receptury", href: "/admin/recipes", icon: NotebookPen },
      { label: "Inwentaryzacja", href: "/admin/inventory", icon: Package },
      { label: "Stany magazynowe", href: "/admin?view=stock", icon: Package },
      { label: "Instrukcje", href: "/admin/instructions", icon: BookOpen },
    ],
  },
  {
    label: "Zarządzanie",
    items: [
      { label: "Zespół", href: "/admin/waiters", icon: Users },
      { label: "Grafik", href: "/admin/workforce", icon: CalendarDays },
      { label: "Plan managerki", href: "/admin/manager-plan", icon: CalendarDays },
      { label: "Raporty", href: "/admin/reports", icon: ChartNoAxesCombined },
      { label: "Rozliczenia", href: "/admin/settlements", icon: WalletCards },
    ],
  },
  {
    label: "Lokal i połączenia",
    items: [
      { label: "Oświetlenie", href: "/admin/lighting", icon: Lightbulb },
      { label: "Temperatury", href: "/admin/temperatury", icon: Thermometer },
      { label: "Klimatyzacja", href: "/kelner/klimatyzacja", icon: Wind },
      { label: "MIKSER XR18", href: "/kelner/xr18", icon: SlidersHorizontal },
      { label: "Ogrzewanie", href: "/admin/ogrzewanie", icon: Flame },
      { label: "Pomieszczenia", href: "/admin/rooms", icon: DoorOpen },
      { label: "Dotykačka", href: "/admin?view=connection", icon: Link2 },
    ],
  },
];
export const adminViewLabels: Record<string, string> = {
  home: "Pulpit",
  products: "Menu i produkty",
  stock: "Stany magazynowe",
  connection: "Dotykačka",
  categories: "Zakładki i kody PLU",
  productOrder: "Podgrupy i produkty",
  menuView: "Ustawienia widoku menu",
  offers: "Oferty czasowe",
  promotions: "Polecane",
  audit: "Kontrola karty",
  visibilityHistory: "Historia widoczności",
  rules: "Dokumentacja i reguły",
};
export default function AtelierShell({
  children,
  enabled,
  administrator,
}: {
  children: ReactNode;
  enabled: boolean;
  administrator: string | null;
}) {
  const pathname = usePathname();
  const [view, setView] = useState("home"),
    [open, setOpen] = useState(false),
    [switching, setSwitching] = useState(false),
    [error, setError] = useState(""),
    [loggingOut, setLoggingOut] = useState(false);
  const [pendingInventories, setPendingInventories] = useState(0);
  const [review, setReview] = useState<{ due: string; today: string } | null>(
    null,
  );
  useEffect(() => {
    const update = () =>
      setView(
        new URLSearchParams(window.location.search).get("view") || "home",
      );
    update();
    window.addEventListener("atelier:admin-view", update);
    window.addEventListener("popstate", update);
    return () => {
      window.removeEventListener("atelier:admin-view", update);
      window.removeEventListener("popstate", update);
    };
  }, [pathname]);
  useEffect(() => {
    if (!administrator) return;
    let active = true;
    async function load() {
      try {
        const r = await fetch("/api/admin/appearance", { cache: "no-store" });
        if (r.ok && active) setReview(await r.json());
      } catch {}
    }
    void load();
    const id = setInterval(() => void load(), 60000);
    return () => {
      active = false;
      clearInterval(id);
    };
  }, [administrator]);
  useEffect(() => {
    if (!administrator) return;
    let active = true;
    let request: AbortController | null = null;
    const refresh = async () => {
      if (document.visibilityState === "hidden") return;
      request?.abort();
      const controller = new AbortController();
      request = controller;
      try {
        const response = await fetch("/api/admin/inventory/pending-count", {cache:"no-store", signal:controller.signal});
        if (response.status === 401) { if (active) setPendingInventories(0); return; }
        if (!response.ok) return;
        const body = await response.json();
        if (active && !controller.signal.aborted && Number.isInteger(body.count) && body.count >= 0) setPendingInventories(body.count);
      } catch { /* Keep last known count on temporary connection loss. */ }
    };
    void refresh();
    const timer = window.setInterval(() => void refresh(), 15000);
    window.addEventListener("inventory:changed", refresh);
    window.addEventListener("focus", refresh);
    document.addEventListener("visibilitychange", refresh);
    return () => {active=false;request?.abort();window.clearInterval(timer);window.removeEventListener("inventory:changed",refresh);window.removeEventListener("focus",refresh);document.removeEventListener("visibilitychange",refresh);};
  }, [administrator]);
  useEffect(() => {
    if (!open) return;
    const esc = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpen(false);
    };
    document.addEventListener("keydown", esc);
    return () => document.removeEventListener("keydown", esc);
  }, [open]);
  async function changeAppearance() {
    if (
      document.documentElement.dataset.adminFormDirty === "true" &&
      !window.confirm(
        "Masz niezapisane zmiany. Zmienić wygląd bez zapisywania?",
      )
    )
      return;
    setSwitching(true);
    try {
      const r = await fetch("/api/admin/appearance", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ appearance: enabled ? "legacy" : "atelier" }),
      });
      if (!r.ok) throw Error("Nie udało się zmienić wyglądu.");
      window.location.reload();
    } catch (e) {
      setError(
        e instanceof Error ? e.message : "Nie udało się zmienić wyglądu.",
      );
      setSwitching(false);
    }
  }
  async function defer() {
    try {
      const r = await fetch("/api/admin/appearance", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "DEFER_REVIEW" }),
      });
      if (!r.ok) throw Error();
      const d = await r.json();
      setReview((v) => (v ? { ...v, due: d.due } : null));
    } catch {
      setError("Nie udało się odłożyć przypomnienia.");
    }
  }
  async function logout() {
    if (
      document.documentElement.dataset.adminFormDirty === "true" &&
      !window.confirm("Masz niezapisane zmiany. Wylogować bez zapisywania?")
    )
      return;
    setLoggingOut(true);
    try {
      const r = await fetch("/api/admin/session", { method: "DELETE" });
      if (!r.ok) throw Error();
      window.location.assign("/admin");
    } catch {
      setError("Nie udało się wylogować. Spróbuj ponownie.");
      setLoggingOut(false);
    }
  }
  const title =
    pathname === "/admin"
      ? adminViewLabels[view] || "Panel administratora"
      : groups
          .flatMap((g) => g.items)
          .find((i) => i.href.split("?")[0] === pathname || (i.href === "/admin/reports" && pathname.startsWith("/admin/reports/")))?.label ||
        "Panel administratora";
  const reminder =
    administrator && review && review.today >= review.due ? (
      <section className="atelier-review" role="status">
        <Undo2 size={19} />
        <div>
          <strong>Czy możemy już usunąć kopię poprzedniego wyglądu?</strong>
          <p>
            Minął okres testów. Daj znać w rozmowie, czy nowy panel zostaje.
            Kopia jest zachowana i nic nie usunie się automatycznie.
          </p>
        </div>
        <button onClick={() => void defer()}>Przypomnij za 7 dni</button>
      </section>
    ) : null;
  if (!enabled)
    return (
      <DesignContext.Provider value={false}>
        <div className="admin-shell">
          {administrator && (
            <div className="atelier-legacy-banner">
              <span>Wyświetlasz poprzedni wygląd panelu.</span>
              <button
                onClick={() => void changeAppearance()}
                disabled={switching}
              >
                Włącz Atelier Workspace
              </button>
              {error && <span role="alert">{error}</span>}
            </div>
          )}
          {reminder}
          {children}
        </div>
      </DesignContext.Provider>
    );
  if (!administrator)
    return (
      <DesignContext.Provider value={true}>
        <div className="admin-shell atelier-admin atelier-login">
          {children}
        </div>
      </DesignContext.Provider>
    );
  return (
    <DesignContext.Provider value={true}>
      <div className="admin-shell atelier-admin">
        <div className={"atelier-frame " + (open ? "atelier-nav-open" : "")}>
          {open && (
            <button
              className="atelier-nav-scrim"
              aria-label="Zamknij nawigację"
              onClick={() => setOpen(false)}
            />
          )}
          <aside className="atelier-sidebar" aria-label="Panel administratora">
            <button className="atelier-logout-top" onClick={() => void logout()} disabled={loggingOut}><LogOut size={17} />{loggingOut ? "Wylogowuję…" : "Wyloguj"}</button>
            <a className="atelier-brand" href="/admin">
              <img className="atelier-brand-logo" src="/brand/mb-cafe-black.svg" alt="MB Marta Banaszek Café" width={164} height={126} />
            </a>
            <button
              className="atelier-nav-close"
              aria-label="Zamknij nawigację"
              onClick={() => setOpen(false)}
            >
              <X size={21} />
            </button>
            <nav aria-label="Obszary administratora">
              {groups.map((group) => (
                <div className="atelier-nav-group" key={group.label}>
                  <span>{group.label}</span>
                  {group.items.map((item) => {
                    const active =
                      item.href ===
                      (pathname === "/admin"
                        ? view === "home"
                          ? "/admin"
                          : "/admin?view=" + view
                        : pathname) || (item.href === "/admin/reports" && pathname.startsWith("/admin/reports/"));
                    return (
                      <a
                        href={item.href}
                        key={item.href}
                        className={[item.href === "/admin?view=products" ? "atelier-menu-entry" : "", active ? "is-current" : ""].filter(Boolean).join(" ")}
                        aria-current={active ? "page" : undefined}
                        onClick={(e) => {
                          if (
                            document.documentElement.dataset.adminFormDirty ===
                              "true" &&
                            !window.confirm(
                              "Masz niezapisane zmiany. Przejść bez zapisywania?",
                            )
                          )
                            e.preventDefault();
                          else setOpen(false);
                        }}
                      >
                        <item.icon size={17} />
                        <span>{item.label}</span>
                        {item.href === "/admin/inventory" && pendingInventories > 0 && <b className="atelier-inventory-badge" aria-label={`${pendingInventories} inwentaryzacji oczekuje na zatwierdzenie`} title="Inwentaryzacje oczekujące na zatwierdzenie" aria-live="polite">{pendingInventories}</b>}
                      </a>
                    );
                  })}
                </div>
              ))}
            </nav>
            <div className="atelier-sidebar-bottom">
              <button
                className="atelier-restore"
                onClick={() => void changeAppearance()}
                disabled={switching}
              >
                <Undo2 size={15} />
                {switching ? "Zmieniam wygląd…" : "Poprzedni wygląd"}
                <small>Kopia do testów · pytanie 22.10</small>
              </button>
              <div className="atelier-account">
                <span className="atelier-avatar">
                  {administrator.trim().slice(0, 2).toUpperCase()}
                </span>
                <span>
                  <b>{administrator}</b>
                  <small>Administrator</small>
                </span>
                <button onClick={() => void logout()} aria-label="Wyloguj">
                  <LogOut size={16} />
                </button>
              </div>
            </div>
          </aside>
          <div className="atelier-stage">
            <header className="atelier-topbar">
              <button
                className="atelier-nav-toggle"
                aria-label="Otwórz nawigację"
                aria-expanded={open}
                onClick={() => setOpen(!open)}
              >
                <Menu size={21} />
              </button>
              <button className="atelier-logout-top atelier-logout-mobile" onClick={() => void logout()} disabled={loggingOut}><LogOut size={17} />{loggingOut ? "Wylogowuję…" : "Wyloguj"}</button>
              <span className="atelier-breadcrumb">
                MENU <ChevronRight size={13} />
                <b>{title}</b>
              </span>
              <div>
                <div id="atelier-sync-toolbar" />
                <span className="atelier-access">
                  <ShieldCheck size={14} />
                  Strefa administratora
                </span>
                <a
                  href="/admin/gastro-calendar"
                  aria-label="Przypomnienia i kalendarz"
                >
                  <Bell size={18} />
                </a>
              </div>
            </header>
            {error && (
              <p className="atelier-shell-error" role="alert">
                {error}
              </p>
            )}
            {reminder}
            <div className="atelier-content">{children}</div>
          </div>
        </div>
      </div>
    </DesignContext.Provider>
  );
}
