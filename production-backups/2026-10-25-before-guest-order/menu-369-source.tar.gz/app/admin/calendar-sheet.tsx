"use client";
import { useEffect, useState } from "react";
import names from "../../lib/polish-name-days.json";
const zone = "Europe/Warsaw";
const format = (now: Date, options: Intl.DateTimeFormatOptions) => new Intl.DateTimeFormat("pl-PL", {timeZone: zone, ...options}).format(now);
export default function CalendarSheet() {
  const [now, setNow] = useState<Date | null>(null);
  useEffect(() => {
    const update = () => setNow(new Date());
    update();
    const timer = setInterval(update, 1000);
    document.addEventListener("visibilitychange", update);
    return () => { clearInterval(timer); document.removeEventListener("visibilitychange", update); };
  }, []);
  const date = now ? new Intl.DateTimeFormat("en-CA", {timeZone: zone, year:"numeric", month:"2-digit", day:"2-digit"}).format(now) : "";
  const nameDays = (names as Record<string,string>)[date.slice(5)];
  return <section className="atelier-calendar-sheet" aria-label="Dzisiejsza kartka z kalendarza">
    <div className="atelier-calendar-ribbon">Dzisiaj w kawiarni</div>
    <div className="atelier-calendar-body">
      <div className="atelier-calendar-date"><span>{now ? format(now, {weekday:"long"}) : "Dzisiaj"}</span><strong>{now ? format(now, {day:"numeric"}) : "—"}</strong><time dateTime={date || undefined}>{now ? format(now, {month:"long", year:"numeric"}) : "Ładowanie daty…"}</time></div>
      <div className="atelier-calendar-details"><span className="atelier-kicker">Aktualna godzina</span><time className="atelier-calendar-clock" aria-label="Aktualna godzina w Polsce">{now ? format(now, {hour:"2-digit", minute:"2-digit", second:"2-digit", hourCycle:"h23"}) : "—:—:—"}</time><small>Czas polski · Warszawa</small><div className="atelier-calendar-names"><span>Imieniny obchodzą</span><p>{now ? nameDays || "Brak danych na ten dzień" : "Ładowanie imienin…"}</p></div><a href="/admin/gastro-calendar">Otwórz kalendarz gastronomiczny →</a></div>
    </div>
  </section>;
}
