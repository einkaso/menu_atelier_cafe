import {readGiftIntegrationStatus} from '../../../lib/event-gifts-integration';
import GiftConnectionStatus from '../../../components/event-gifts/gift-integration-status';
import {sql} from 'drizzle-orm';
import {getDb} from '../../../db';
import {isAdmin} from '../../../lib/admin-auth';
import AdminLogin from '../admin-login';
import EventGiftCreator from '../../../components/event-gifts/event-gift-creator';
export const dynamic='force-dynamic';
export default async function EventGiftPreview(){
 if(!await isAdmin().catch(()=>false))return <AdminLogin/>;
 const connection=await readGiftIntegrationStatus();
 const rows=await getDb().execute(sql`select external_id,title,starts_at from event_os_events where starts_at>now() and status<>'CANCELLED' order by starts_at`);
 return <div className="is-art-menu"><aside className="gift-admin-notice"><a href="/admin/event-os">← EVENT OS</a><b>Podgląd administratora — sprzedaż nie jest jeszcze uruchomiona</b><p>Kreator nie rezerwuje miejsc, nie pobiera płatności i nie wysyła e-maili. Lista poniżej pochodzi z synchronizacji programu Events, nie potwierdza aktualnej dostępności ani ceny biletów. Do uruchomienia potrzebny jest kontrakt zakupu, płatności i realizacji voucherów z Events.</p><GiftConnectionStatus initial={connection}/></aside><EventGiftCreator artworkAvailable={connection.compatible&&connection.capabilities?.artworkGeneration?.available===true} events={rows.map(r=>({id:String(r.external_id),title:String(r.title),startsAt:new Date(String(r.starts_at)).toISOString()}))}/></div>;
}
