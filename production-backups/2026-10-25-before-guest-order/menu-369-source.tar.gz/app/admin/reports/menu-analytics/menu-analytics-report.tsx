"use client";
import { useEffect, useRef, useState } from "react";
import AdminSectionHeader from "../../admin-section-header";
import { isoDate } from "../../../../lib/workforce";
import "../reports.css";
import "../revenue/revenue-report.css";

type Product = { id: number; name: string; opens: number; sessions: number; allergens: number; durationMs: number; engaged: number; views: number };
type Report = { from: string; to: string; device: string; summary: { sessions: number; categories: number; opens: number; allergens: number; durationMs: number; productSessions: number }; categories: { id: string; name: string; opens: number; sessions: number }[]; products: Product[]; hourly: { hour: number; opens: number; categories: number }[]; coverage: { firstEvent: string | null; lastEvent: string | null } };
export default function MenuAnalyticsReport() {
  const [from, setFrom] = useState(() => `${isoDate(new Date()).slice(0,7)}-01`), [to, setTo] = useState(() => isoDate(new Date()));
  const [device, setDevice] = useState("all"), [metric, setMetric] = useState<"opens" | "engaged" | "durationMs">("opens");
  const [report, setReport] = useState<Report | null>(null), [error, setError] = useState(""), [loading, setLoading] = useState(false);
  const request = useRef(0);
  async function load(first: string, last: string, type: string) {
    const id = ++request.current; setLoading(true); setError(""); setReport(null);
    try {
      const response = await fetch(`/api/reports/menu-analytics?${new URLSearchParams({from:first,to:last,device:type})}`, {cache:"no-store"});
      const body = await response.json(); if (!response.ok) throw Error(body.error || "Nie udało się pobrać raportu.");
      if (id === request.current) setReport(body);
    } catch (error) { if (id === request.current) setError(error instanceof Error ? error.message : "Błąd połączenia."); }
    finally { if (id === request.current) setLoading(false); }
  }
  useEffect(() => { const today=isoDate(new Date()); void load(`${today.slice(0,7)}-01`,today,"all"); return () => { request.current++; }; },[]);
  const current = report && report.from===from && report.to===to && report.device===device;
  const products = [...(report?.products??[])].sort((a,b)=>b[metric]-a[metric]||a.name.localeCompare(b.name,"pl"));
  const top=products.slice(0,15), max=Math.max(1,...top.map(product=>product[metric]));
  const categoryMax=Math.max(1,...(report?.categories??[]).map(category=>category.opens));
  const hourMax=Math.max(1,...(report?.hourly??[]).map(hour=>hour.opens));
  const minutes=(ms:number)=>(ms/60000).toLocaleString("pl-PL",{maximumFractionDigits:1});
  return <div className="work-reports"><AdminSectionHeader eyebrow="ZAINTERESOWANIE GOŚCI" title="Raporty" links={[]}/>
    <main className="reports-main"><nav className="reports-catalog" aria-label="Dostępne raporty"><a href="/admin/reports"><span>RAPORT 01</span><strong>Praca i rozliczenia</strong></a><a href="/admin/reports/revenue"><span>RAPORT 02</span><strong>Przychód na pracownika</strong></a><a href="/admin/reports/menu-analytics" aria-current="page"><span>RAPORT 03</span><strong>Co interesuje gości w menu</strong></a></nav>
    <section className="reports-panel" aria-busy={loading}><h2>Co interesuje gości w menu</h2><p>Otwarcia kategorii, szczegółów produktów i alergenów oraz czas aktywnego wyświetlania.</p>
      <form className="reports-filters" onSubmit={event=>{event.preventDefault();void load(from,to,device);}}><label>Od<input type="date" required value={from} max={to} onChange={event=>setFrom(event.target.value)}/></label><label>Do<input type="date" required value={to} min={from} max={isoDate(new Date())} onChange={event=>setTo(event.target.value)}/></label><label>Urządzenia<select value={device} onChange={event=>setDevice(event.target.value)}><option value="all">Wszystkie ekrany menu</option><option value="tablet">Tablety (szacunkowo)</option><option value="phone">Telefony (szacunkowo)</option><option value="desktop">Komputery (szacunkowo)</option></select></label><button className="admin-primary" disabled={loading}>{loading?"Pobieram…":"Pokaż raport"}</button></form>
      {error&&<p className="reports-error" role="alert">{error}</p>}
      {report&&!current&&<p className="reports-warning">Zmieniono filtry. Kliknij „Pokaż raport”.</p>}
      {current&&report&&<>
        <p>{from} — {to}. {report.coverage.firstEvent?`Najstarszy zachowany pomiar: ${new Date(report.coverage.firstEvent).toLocaleString("pl-PL",{timeZone:"Europe/Warsaw"})}.`:"Nie zebrano jeszcze pomiarów. Dane pojawią się po uruchomieniu pomiaru i pierwszych interakcjach gości."}</p>
        <div className="reports-summary"><article><span>Sesje przeglądania</span><strong>{report.summary.sessions}</strong><small>Sesje, nie liczba osób</small></article><article><span>Otwarcia produktów</span><strong>{report.summary.opens}</strong><small>W {report.summary.productSessions} sesjach</small></article><article><span>Aktywne wyświetlanie szczegółów</span><strong>{minutes(report.summary.durationMs)} min</strong><small>Nie jest potwierdzeniem przeczytania</small></article></div>
        {!report.summary.sessions&&<p className="reports-warning">Brak interakcji w tym okresie i dla wybranych urządzeń. Historycznych kliknięć sprzed włączenia pomiaru nie da się odtworzyć.</p>}
        <div className="revenue-metric"><label>Ranking produktów według<select value={metric} onChange={event=>setMetric(event.target.value as typeof metric)}><option value="opens">Liczby otwarć</option><option value="engaged">Wyświetleń aktywnych co najmniej 10 sekund</option><option value="durationMs">Łącznego czasu aktywnego wyświetlania</option></select></label></div>
        <h3>Produkty przyciągające uwagę — pierwsze 15</h3><ol className="revenue-chart" aria-label="Zainteresowanie produktami">{top.map(product=><li key={product.id}><div><b>{product.name}</b><strong>{metric==="durationMs"?`${minutes(product.durationMs)} min`:product[metric]}</strong></div><div className="revenue-track" aria-hidden="true"><span style={{width:`${product[metric]/max*100}%`}}/></div></li>)}</ol>
        <div className="reports-table-wrap"><table><thead><tr><th>Produkt</th><th>Otwarcia</th><th>Sesje z otwarciem</th><th>≥10 sek.</th><th>Śr. aktywny czas / widok</th><th>Alergeny</th></tr></thead><tbody>{products.map(product=><tr key={product.id}><th scope="row">{product.name}</th><td>{product.opens}</td><td>{product.sessions}</td><td>{product.engaged}</td><td>{product.views?`${Math.round(product.durationMs/product.views/1000)} s`:"—"}</td><td>{product.allergens}</td></tr>)}</tbody></table></div>
        <h3>Najczęściej otwierane kategorie</h3><ol className="revenue-chart" aria-label="Popularność kategorii">{report.categories.map(category=><li key={category.id}><div><b>{category.name}</b><span>{category.opens} otwarć · {category.sessions} sesji</span></div><div className="revenue-track" aria-hidden="true"><span style={{width:`${category.opens/categoryMax*100}%`}}/></div></li>)}</ol>
        <h3>O której godzinie goście otwierają produkty?</h3><ol className="revenue-chart" aria-label="Aktywność według godzin">{Array.from({length:24},(_,hour)=>{const value=report.hourly.find(item=>item.hour===hour)?.opens??0;return <li key={hour}><div><b>{String(hour).padStart(2,"0")}:00–{String(hour).padStart(2,"0")}:59</b><span>{value} otwarć</span></div><div className="revenue-track" aria-hidden="true"><span style={{width:`${value/hourMax*100}%`}}/></div></li>;})}</ol>
        <div className="reports-notes"><p>Pomiar obejmuje interakcje w menu gościa, a nie sprzedaż. Otwarcie produktu ani długi czas wyświetlania nie dowodzą przeczytania opisu lub zakupu. Lista obejmuje do 100 najczęściej otwieranych produktów i kategorii.</p><p>Czas naliczamy tylko na widocznej stronie i przez maksymalnie 30 sekund od ostatniej interakcji. Po 5 minutach bez interakcji lub ponownym załadowaniu strony zaczyna się nowa sesja. Wspólny tablet może obsługiwać kilka osób w jednej sesji. Wznowienie otwartego produktu w nowej sesji liczy się jako kolejne otwarcie.</p><p>Typ urządzenia szacujemy na podstawie wielkości ekranu i obsługi dotyku. Nie zapisujemy nazwisk, kont klientów, treści formularzy ani trwałego identyfikatora urządzenia. Zdarzenia przechowujemy do 180 dni. Raport używa czasu Warszawy; utrata sieci lub zamknięcie przeglądarki może spowodować brak części pomiarów.</p></div>
      </>}
    </section></main></div>;
}
