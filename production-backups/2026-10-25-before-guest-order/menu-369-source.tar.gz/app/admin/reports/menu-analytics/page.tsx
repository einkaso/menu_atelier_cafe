import { isAdmin } from "../../../../lib/admin-auth";
import AdminLogin from "../../admin-login";
import MenuAnalyticsReport from "./menu-analytics-report";
export const dynamic = "force-dynamic";
export default async function MenuAnalyticsPage() { return await isAdmin() ? <MenuAnalyticsReport/> : <AdminLogin/>; }
