"use client";
import { type FormEvent, useEffect, useRef, useState } from "react";
import AdminSectionHeader from "../../admin-section-header";
import { isoDate } from "../../../../lib/workforce";
import type { RevenueRow } from "../../../../lib/revenue-report";
import "../reports.css";
import "./revenue-report.css";

type Report = { from: string; to: string; source: string; generatedAt: string; effectiveEnd: string; openEntries: number; skipped: number; totalCents: number; unassignedCents: number; unassignedReceipts: number; saleCount: number; rows: RevenueRow[] };
const money = (cents: number) => (cents / 100).toLocaleString("pl-PL", { style: "currency", currency: "PLN" });
const hours = (value: number) => value.toLocaleString("pl-PL", { maximumFractionDigits: 2 });
export default function RevenueReportClient() {
  const [from, setFrom] = useState(() => `${isoDate(new Date()).slice(0, 7)}-01`);
  const [to, setTo] = useState(() => isoDate(new Date()));
  const [source, setSource] = useState("schedule");
  const [metric, setMetric] = useState<"revenueCents" | "perHourCents">("revenueCents");
  const [report, setReport] = useState<Report | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const requestId = useRef(0);
  async function load(first: string, last: string, mode: string) {
    const id = ++requestId.current; setLoading(true); setError(""); setReport(null);
    try {
      const response = await fetch(`/api/reports/revenue?${new URLSearchParams({ from: first, to: last, source: mode })}`, { cache: "no-store" });
      const body = await response.json();
      if (!response.ok) throw Error(body.error || "Nie udało się pobrać raportu.");
      if (id === requestId.current) setReport(body);
    } catch (error) { if (id === requestId.current) setError(error instanceof Error ? error.message : "Błąd połączenia."); }
    finally { if (id === requestId.current) setLoading(false); }
  }
  useEffect(() => { const today = isoDate(new Date()); void load(`${today.slice(0, 7)}-01`, today, "schedule"); return () => { requestId.current++; }; }, []);
  const current = report && report.from === from && report.to === to && report.source === source;
  const rows = [...(report?.rows ?? [])].sort((a, b) => b[metric] - a[metric] || a.name.localeCompare(b.name, "pl"));
  const max = Math.max(1, ...rows.map(row => Math.abs(row[metric])));
  function generate(event: FormEvent) { event.preventDefault(); void load(from, to, source); }
  return <div className="work-reports">
    <AdminSectionHeader eyebrow="ZESTAWIENIA I ROZLICZENIA" title="Raporty" links={[{ href: "/admin/workforce", label: "Grafik i czas pracy" }]}/>
    <main className="reports-main">
      <nav className="reports-catalog" aria-label="Dostępne raporty"><a href="/admin/reports"><span>RAPORT 01</span><strong>Praca i rozliczenia pracowników</strong><small>Godziny · wynagrodzenia · napiwki</small></a><a href="/admin/reports/revenue" aria-current="page"><span>RAPORT 02</span><strong>Przychód na pracownika</strong><small>Sprzedaż · godziny · porównanie</small></a><a href="/admin/reports/menu-analytics"><span>RAPORT 03</span><strong>Co interesuje gości w menu</strong><small>Kategorie · produkty · czas wyświetlania</small></a></nav>
      <section className="reports-panel" aria-busy={loading}>
        <h2>Przychód na pracownika</h2>
        <p>Każdy rachunek dzielimy równo między osoby pracujące w chwili jego zamknięcia.</p>
        <form className="reports-filters" onSubmit={generate}>
          <label>Od<input type="date" required value={from} max={to} onChange={event => setFrom(event.target.value)}/></label>
          <label>Do<input type="date" required value={to} min={from} max={isoDate(new Date())} onChange={event => setTo(event.target.value)}/></label>
          <label>Źródło godzin<select value={source} onChange={event => setSource(event.target.value)}><option value="schedule">Zatwierdzony grafik</option><option value="actual">Ewidencja czasu pracy</option></select></label>
          <button className="admin-primary" disabled={loading}>{loading ? "Pobieram dane…" : "Pokaż raport"}</button>
        </form>
        {error && <p className="reports-error" role="alert">{error}</p>}
        {report && !current && <p className="reports-warning">Zmieniono okres lub źródło godzin. Kliknij „Pokaż raport”.</p>}
        {current && report && <>
          <p>Okres: <b>{report.from} — {report.to}</b> · {source === "schedule" ? "Zatwierdzony grafik" : "Zamknięte wpisy ewidencji i zatwierdzone korekty"}. Dane do {new Date(report.effectiveEnd).toLocaleString("pl-PL", { timeZone: "Europe/Warsaw" })}.</p>
          <div className="reports-summary"><article><span>Przychód w okresie</span><strong>{money(report.totalCents)}</strong><small>{report.saleCount} rachunków</small></article><article><span>Przypisany pracownikom</span><strong>{money(report.totalCents - report.unassignedCents)}</strong></article><article><span>Bez obsady w źródle godzin</span><strong>{money(report.unassignedCents)}</strong><small>{report.unassignedReceipts} rachunków nieprzypisanych</small></article></div>
          {report.unassignedReceipts > 0 && <p className="reports-warning">Część sprzedaży nie ma pasujących godzin pracy. Uzupełnij grafik lub ewidencję, aby uzyskać pełne porównanie.</p>}
          {report.openEntries > 0 && <p className="reports-warning">Pominięto {report.openEntries} otwartych wpisów czasu pracy. Nie zastępujemy ich godzinami z grafiku.</p>}
          {report.skipped > 0 && <p className="reports-warning">Pominięto {report.skipped} dokumentów: np. nieopłaconych, innych niż sprzedaż, w innej walucie lub z niepełnymi danymi.</p>}
          <div className="revenue-metric"><label>Porównaj według<select value={metric} onChange={event => setMetric(event.target.value as typeof metric)}><option value="revenueCents">Łączny przychód na pracownika</option><option value="perHourCents">Przychód na godzinę pracy</option></select></label></div>
          <h3>{metric === "revenueCents" ? "Przychód przypisany pracownikom" : "Przychód na godzinę pracy"}</h3>
          <ol className="revenue-chart" aria-label="Wykres przychodów pracowników">{rows.map(row => <li key={row.id}><div><b>{row.name}</b><strong>{money(row[metric])}{metric === "perHourCents" ? "/h" : ""}</strong></div><div className="revenue-track" aria-hidden="true"><span className={row[metric] < 0 ? "is-negative" : ""} style={{ width: `${Math.abs(row[metric]) / max * 100}%` }}/></div></li>)}</ol>
          {!rows.length && <p>Brak godzin pracy w wybranym źródle i okresie. Sprzedaż pozostaje nieprzypisana.</p>}
          <div className="reports-table-wrap"><table><thead><tr><th>Pracownik</th><th>Godziny</th><th>Przypisany przychód</th><th>Przychód / godz.</th></tr></thead><tbody>{rows.map(row => <tr key={row.id}><th scope="row">{row.name}</th><td>{hours(row.hours)}</td><td>{money(row.revenueCents)}</td><td>{money(row.perHourCents)}</td></tr>)}</tbody></table></div>
          <div className="reports-notes"><p>Przykład: rachunek 300 zł przy trzech pracujących osobach dodaje po 100 zł każdej. Przychód na godzinę = przypisany przychód ÷ godziny pracy w badanym okresie.</p><p>To przychód brutto przypisany według obecności, a nie indywidualna sprzedaż ani zysk pracownika. Wynik zależy również od pory zmiany i ruchu w lokalu.</p><p>Uwzględniamy zamknięte, opłacone paragony, faktury i faktury korygujące w PLN z wybranego oddziału. Kwoty ujemne zmniejszają wynik w chwili zamknięcia dokumentu. Nie doliczamy oddzielnych napiwków. Faktury wystawione do paragonów i operacje kasowe nie są liczone ponownie.</p><p>Godziny i daty są liczone według czasu Warszawy. Zmiany przechodzące przez północ są przycinane do badanego okresu; dzisiejsze godziny liczymy do chwili wygenerowania raportu. Nakładające się wpisy tej samej osoby liczymy tylko raz. Podział zaokrąglamy do groszy z zachowaniem sumy.</p></div>
        </>}
      </section>
    </main>
  </div>;
}
