import { isAdmin } from "../../../../lib/admin-auth";
import AdminLogin from "../../admin-login";
import RevenueReportClient from "./revenue-report-client";
export const dynamic = "force-dynamic";
export default async function RevenueReportPage() {
  return await isAdmin() ? <RevenueReportClient/> : <AdminLogin/>;
}
