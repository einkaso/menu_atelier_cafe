"use client";
import { FormEvent, useCallback, useEffect, useRef, useState } from "react";
import AdminSectionHeader from "../admin-section-header";
import { WaiterSectionHeader } from "../../kelner/staff-navigation";
import { waiterSessionHeaders } from "../../kelner/waiter-session-client";
import { addDays, isoDate } from "../../../lib/workforce";
import type { WorkReportRow } from "../../../lib/work-report";
import "./reports.css";

type Report = { from: string; to: string; generatedAt: string; rows: WorkReportRow[] };
const money = (value: number) => new Intl.NumberFormat("pl-PL", { style: "currency", currency: "PLN" }).format(value / 100);
const duration = (minutes: number) => `${Math.floor(minutes / 60)} godz. ${minutes % 60} min`;
const dateLabel = (date: string) => date.split("-").reverse().join(".");
export default function WorkReportsClient({ employeeMode = false }: { employeeMode?: boolean }) {
  const [from, setFrom] = useState(() => `${isoDate(new Date()).slice(0, 7)}-01`);
  const [to, setTo] = useState(() => isoDate(new Date()));
  const [hideWithoutHours, setHideWithoutHours] = useState(true);
  const [showRate, setShowRate] = useState(false);
  const [report, setReport] = useState<Report | null>(null);
  const [loading, setLoading] = useState(true);
  const [paying, setPaying] = useState("");
  const [exporting, setExporting] = useState(false);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  const [denied, setDenied] = useState(false);
  const latestRequest = useRef(0);
  const mounted = useRef(true);
  const headers = useCallback(() => employeeMode ? waiterSessionHeaders() : {}, [employeeMode]);
  const load = useCallback(async (first: string, last: string) => {
    const requestId = ++latestRequest.current; setLoading(true); setError("");
    try {
      const response = await fetch(`/api/reports/work?from=${encodeURIComponent(first)}&to=${encodeURIComponent(last)}`, { cache: "no-store", headers: headers() });
      const body = await response.json();
      if (requestId !== latestRequest.current || !mounted.current) return;
      if (!response.ok) { setReport(null); setDenied(response.status === 401 || response.status === 403); throw new Error(body.error || "Nie udało się pobrać raportu."); }
      setDenied(false); setReport(body);
    } catch (e) { if (requestId === latestRequest.current && mounted.current) { setReport(null); setError(e instanceof Error ? e.message : "Błąd połączenia."); } }
    finally { if (requestId === latestRequest.current && mounted.current) setLoading(false); }
  }, [headers]);
  useEffect(() => { mounted.current = true; const now = isoDate(new Date()); void load(`${now.slice(0, 7)}-01`, now); return () => { mounted.current = false; latestRequest.current++; }; }, [load]);
  // Recheck permission on focus without overwriting the chosen dates.
  useEffect(() => {
    if (!report) return;
    const refresh = () => { if (document.visibilityState === "visible" && !paying) void load(report.from, report.to); };
    window.addEventListener("focus", refresh);
    const timer = window.setInterval(refresh, 60_000);
    return () => { window.removeEventListener("focus", refresh); window.clearInterval(timer); };
  }, [report?.from, report?.to, load, paying]);
  const changed = !report || report.from !== from || report.to !== to;
  const unavailable = loading || Boolean(paying) || changed;
  const allRows = report?.rows ?? [];
  const rows = hideWithoutHours ? allRows.filter(row => row.minutes > 0) : allRows;
  const hiddenCount = allRows.length - rows.length;
  const minutes = rows.reduce((sum, r) => sum + r.minutes, 0);
  const salary = rows.reduce((sum, r) => sum + (r.salaryCents ?? 0), 0);
  const due = rows.reduce((sum, r) => sum + r.tipsDueCents, 0);
  const missing = rows.filter(r => r.salaryCents === null).length;
  const open = allRows.reduce((sum, r) => sum + r.openEntries, 0);
  function generate(event: FormEvent) { event.preventDefault(); setMessage(""); void load(from, to); }
  function shiftPeriod(direction: number) {
    if (!from || !to || from > to) return;
    const days = Math.round((Date.parse(`${to}T12:00:00Z`) - Date.parse(`${from}T12:00:00Z`)) / 86400000) + 1;
    const first = addDays(from, direction * days), last = addDays(to, direction * days);
    setFrom(first); setTo(last); setMessage(""); void load(first, last);
  }
  async function pay(row: WorkReportRow) {
    if (!report || unavailable || row.tipsDueCents <= 0) return;
    if (!window.confirm(`Oznaczyć jako wypłacone napiwki dla ${row.name}: ${money(row.tipsDueCents)} za ${dateLabel(report.from)}–${dateLabel(report.to)}? Potwierdź dopiero po przekazaniu pieniędzy. Wynagrodzenie za godziny nie jest objęte tą operacją.`)) return;
    setPaying(row.id); setError(""); setMessage("");
    try {
      const response = await fetch("/api/reports/work", { method: "POST", headers: { ...headers(), "content-type": "application/json" }, body: JSON.stringify({ action: "MARK_TIPS_PAID", from: report.from, to: report.to, employeeId: row.id, snapshot: row.snapshot }) });
      const body = await response.json();
      if (!response.ok) { if ([401, 403].includes(response.status)) { setReport(null); setDenied(true); } throw new Error(body.error || "Nie udało się oznaczyć wypłaty."); }
      setMessage(`Napiwki ${row.name}: oznaczono ${money(body.amountCents)} jako wypłacone.`);
      await load(report.from, report.to);
    } catch (e) { setError(e instanceof Error ? e.message : "Błąd połączenia. Odśwież raport przed ponowną próbą."); }
    finally { setPaying(""); }
  }
  async function exportCsv() {
    if (!report || unavailable) return;
    setExporting(true); setError("");
    try {
      const response = await fetch(`/api/reports/work?from=${report.from}&to=${report.to}&format=csv&hideWithoutHours=${hideWithoutHours}&showRate=${showRate}`, { cache: "no-store", headers: headers() });
      if (!response.ok) { if ([401, 403].includes(response.status)) { setReport(null); setDenied(true); } const body = await response.json(); throw new Error(body.error || "Nie udało się wyeksportować raportu."); }
      const url = URL.createObjectURL(await response.blob()); const link = document.createElement("a"); link.href = url; link.download = `raport-pracy-${report.from}-${report.to}.csv`; link.click(); setTimeout(() => URL.revokeObjectURL(url), 1000);
    } catch (e) { setError(e instanceof Error ? e.message : "Błąd eksportu."); }
    finally { setExporting(false); }
  }
  return <div className="work-reports">
    {employeeMode ? <WaiterSectionHeader eyebrow="ATELIER CAFÉ" title="Raporty"/> : <AdminSectionHeader eyebrow="ZESTAWIENIA I ROZLICZENIA" title="Raporty" links={[{ href: "/admin/workforce", label: "Czas pracy" }, { href: "/admin/settlements", label: "Rozliczenia" }, { href: "/admin/waiters", label: "Stawki i dostępy" }]}/>}
    <main className="reports-main"><nav className="reports-catalog" aria-label="Dostępne raporty"><a href="#work-report" aria-current="page"><span>RAPORT 01</span><strong>Praca i rozliczenia pracowników</strong><small>Godziny · wynagrodzenia · napiwki</small></a>{!employeeMode && <a href="/admin/reports/revenue"><span>RAPORT 02</span><strong>Przychód na pracownika</strong><small>Sprzedaż · godziny · porównanie</small></a>}{!employeeMode && <a href="/admin/reports/menu-analytics"><span>RAPORT 03</span><strong>Co interesuje gości w menu</strong><small>Kategorie · produkty · czas wyświetlania</small></a>}</nav>
    <section id="work-report" className="reports-panel"><header><span>RAPORT OKRESOWY</span><h2>Praca i rozliczenia pracowników</h2><p>Wybierz dowolny okres od dnia do dnia. Następny cykl zachowuje taką samą liczbę dni.</p></header>
    {!denied && <form className="reports-filters" onSubmit={generate}><label>Od dnia<input type="date" required value={from} onChange={e => setFrom(e.target.value)} disabled={Boolean(paying)} min="1900-01-01" max="2100-12-31"/></label><label>Do dnia włącznie<input type="date" required value={to} onChange={e => setTo(e.target.value)} disabled={Boolean(paying)} min={from || "1900-01-01"} max="2100-12-31"/></label><button className="admin-primary" disabled={loading || Boolean(paying)}>Generuj raport</button><button type="button" className="admin-secondary" disabled={loading || Boolean(paying) || !from || !to || from > to} onClick={() => shiftPeriod(-1)}>← Poprzedni cykl</button><button type="button" className="admin-secondary" disabled={loading || Boolean(paying) || !from || !to || from > to} onClick={() => shiftPeriod(1)}>Następny cykl →</button></form>}
    {!denied && <label className="reports-hours-filter"><input type="checkbox" checked={hideWithoutHours} onChange={event => setHideWithoutHours(event.target.checked)} disabled={Boolean(paying) || exporting}/>Ukryj osoby bez godzin pracy</label>}
    {!denied && <label className="reports-hours-filter"><input type="checkbox" checked={showRate} onChange={event => setShowRate(event.target.checked)} disabled={Boolean(paying) || exporting}/>Pokaż stawkę</label>}
    {error && <p className="reports-error" role="alert">{error}</p>}{denied && <a href={employeeMode ? "/kelner" : "/admin"}>Przejdź do logowania</a>}
    {message && <p className="reports-success" role="status">{message}</p>}{loading && <p role="status">Generuję raport…</p>}
    {report && <><div className="reports-result-heading"><div><h3>{dateLabel(report.from)} — {dateLabel(report.to)}</h3><small>Wygenerowano {new Date(report.generatedAt).toLocaleString("pl-PL", { timeZone: "Europe/Warsaw" })}</small></div><div className="reports-export"><button className="admin-secondary" disabled={unavailable || exporting} onClick={() => void exportCsv()}>{exporting ? "Eksportuję…" : "Pobierz CSV do Excela"}</button><button className="admin-secondary" disabled={unavailable} onClick={() => window.print()}>Drukuj / PDF</button></div></div>
    {changed && <p className="reports-warning">Daty zostały zmienione. Kliknij „Generuj raport”, aby przeliczyć kwoty i odblokować wypłaty.</p>}
    {hideWithoutHours && <p className="reports-filter-info">Raport obejmuje osoby z przepracowanym czasem w wybranym okresie. Ukryto: {hiddenCount}. Podsumowanie i eksport dotyczą widocznych osób.</p>}
    <div className="reports-summary"><article><span>Przepracowany czas</span><strong>{duration(minutes)}</strong></article><article><span>{missing ? "Wynagrodzenia — suma częściowa" : "Wynagrodzenia"}</span><strong>{money(salary)}</strong></article><article><span>Napiwki do wypłaty</span><strong>{money(due)}</strong></article></div>
    {(missing > 0 || open > 0) && <p className="reports-warning">{missing > 0 && `Osoby z godzinami, ale bez stawki: ${missing}. Ich wynagrodzeń nie uwzględniono w sumie. `}{open > 0 && `Otwarte lub nieprawidłowe wpisy czasu pracy pominięte w sumie godzin: ${open}.`}</p>}
    <div className="reports-table-wrap" tabIndex={0} role="region" aria-label="Godziny, wynagrodzenia i napiwki pracowników"><table><thead><tr><th>Pracownik</th><th>Przepracowano</th>{showRate && <th>Stawka / godz.</th>}<th>Wynagrodzenie</th><th>Napiwki do wypłaty</th><th className="reports-total">Razem</th><th>Napiwki wypłacone</th><th>Do zatwierdzenia</th><th className="reports-action">Wypłata napiwków</th></tr></thead><tbody>{rows.map(row => <tr key={row.id}><th scope="row">{row.name}{!row.active && <small>Nieaktywny — dane historyczne</small>}{row.openEntries > 0 && <small className="reports-alert-text">Otwarte wpisy: {row.openEntries}</small>}</th><td>{duration(row.minutes)}<small>{(row.minutes / 60).toLocaleString("pl-PL", { maximumFractionDigits: 4 })} godz. × stawka</small></td>{showRate && <td>{row.hourlyRateCents === null ? <span className="reports-alert-text">Brak stawki</span> : money(row.hourlyRateCents)}</td>}<td>{row.salaryCents === null ? "Nie wyliczono" : money(row.salaryCents)}</td><td><strong>{money(row.tipsDueCents)}</strong>{row.tipsDueCents < 0 && <small>Ujemne saldo korekt</small>}</td><td className="reports-total">{row.salaryCents === null ? <span className="reports-alert-text">Nie wyliczono<small>Brak stawki</small></span> : <strong>{money(row.salaryCents + row.tipsDueCents)}</strong>}</td><td>{money(row.tipsPaidCents)}</td><td>{money(row.tipsPendingCents)}</td><td className="reports-action"><button className="admin-primary" disabled={unavailable || row.tipsDueCents <= 0} onClick={() => void pay(row)} aria-label={`Oznacz napiwki wypłacone: ${row.name}`}>{paying === row.id ? "Zapisuję…" : row.tipsDueCents > 0 ? "Oznacz wypłacone" : "Brak do wypłaty"}</button></td></tr>)}</tbody></table>{!rows.length && <p>{hideWithoutHours ? "Brak osób z naliczonymi godzinami pracy w wybranym okresie. Odznacz filtr, aby zobaczyć pozostałe osoby." : "Brak pracowników i danych w wybranym okresie."}</p>}</div>
    <div className="reports-notes"><p>Oba dni okresu są wliczone. Czas pracy jest przypisany do dnia rozpoczęcia zmiany według czasu Warszawy, także gdy zmiana kończy się po północy. Uwzględniamy zamknięte wpisy i zatwierdzone korekty.</p><p>Wynagrodzenie = przepracowane minuty ÷ 60 × aktualna stawka z profilu pracownika, zaokrąglone do grosza po zsumowaniu czasu. Jest to kwota wynikająca ze stawki, bez dodatkowych składników i potrąceń.</p><p>Napiwki dotyczą dat rozliczeń w wybranym okresie, zawierają aktywne korekty i są wspólne ze strefą Rozliczenia. Przycisk „Oznacz wypłacone” zapisuje wypłatę napiwków; nie wykonuje przelewu i nie oznacza wypłaty wynagrodzenia za godziny.</p></div></>}
    </section></main></div>;
}
