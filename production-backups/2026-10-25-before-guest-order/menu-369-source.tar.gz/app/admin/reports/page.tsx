import { isAdmin } from "../../../lib/admin-auth";
import AdminLogin from "../admin-login";
import WorkReportsClient from "./work-reports-client";
export const dynamic = "force-dynamic";
export default async function ReportsPage() {
  return await isAdmin() ? <WorkReportsClient/> : <AdminLogin/>;
}
