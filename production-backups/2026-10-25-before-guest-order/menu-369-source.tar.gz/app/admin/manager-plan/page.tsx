import { isAdmin } from "../../../lib/admin-auth";
import AdminLogin from "../admin-login";
import ManagerPlanClient from "../../../components/manager-plan/manager-plan-client";
export const dynamic = "force-dynamic";
export default async function ManagerPlanPage(){return await isAdmin().catch(()=>false)?<ManagerPlanClient/>:<AdminLogin/>;}
