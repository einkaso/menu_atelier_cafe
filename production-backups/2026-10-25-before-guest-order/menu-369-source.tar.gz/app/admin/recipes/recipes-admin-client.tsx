"use client";

import { useEffect, useState } from "react";
import AdminSectionHeader from "../admin-section-header";
import { RECIPE_CATEGORIES, recipePublicationIssues, type RecipeContent, type RecipeLibraryItem, type RecipeVersion } from "../../../lib/kitchen-recipes";
import DishLibrary from "./dish-library";
import RecipeIngredients from "../../../components/kitchen/recipe-ingredients";
import RecipeDetails from "../../../components/kitchen/recipe-details";

const blank = (): RecipeContent => ({ name: "", category: "Sosy", yieldQuantity: "", yieldUnit: "", ingredients: [{ name: "", quantity: "", unit: "g" }], steps: "", allergens: "", storage: "", notes: "" });
const mediaAccept = "image/jpeg,image/png,image/webp,image/avif,image/heic,image/heif,image/gif,video/quicktime,video/mp4,video/webm,.jpg,.jpeg,.png,.webp,.avif,.heic,.heif,.gif,.mov,.m4v,.mp4,.webm";

export default function RecipesAdminClient() {
  const [recipes, setRecipes] = useState<RecipeLibraryItem[]>([]);
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [versionId, setVersionId] = useState<number | null>(null);
  const [copy, setCopy] = useState<RecipeContent>(blank);
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("");
  const [usageFilter, setUsageFilter] = useState("");
  const [showArchive, setShowArchive] = useState(false);
  const [dirty, setDirty] = useState(false);
  const [busy, setBusy] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  const selected = recipes.find((recipe) => recipe.id === selectedId);
  const version = selected?.versions.find((item) => item.id === versionId);
  const editable = !version || version.status === "DRAFT" && !selected?.archived;

  async function load(recipeId?: number | null, requestedVersion?: number | null) {
    const response = await fetch("/api/admin/recipes", { cache: "no-store" });
    const body = await response.json();
    if (!response.ok) throw new Error(body.error ?? "Nie udało się pobrać przepisów.");
    const library = body.recipes as RecipeLibraryItem[];
    setRecipes(library);
    const requestedRecipeId = recipeId ?? (!selectedId ? Number(new URLSearchParams(window.location.search).get("recipe")) || null : null);
    if (requestedRecipeId) {
      const recipe = library.find((item) => item.id === requestedRecipeId);
      const next = recipe?.versions.find((item) => item.id === requestedVersion) ?? recipe?.versions.at(-1);
      setSelectedId(requestedRecipeId); setVersionId(next?.id ?? null); if (next) setCopy(next.content);
    }
    setDirty(false);
  }
  useEffect(() => { let active = true; void load().catch((error) => { if (active) setError(error instanceof Error ? error.message : "Błąd połączenia."); }).finally(() => { if (active) setLoading(false); }); return () => { active = false; }; }, []);
  useEffect(() => { const handler = (event: BeforeUnloadEvent) => { if (dirty) { event.preventDefault(); event.returnValue = ""; } }; window.addEventListener("beforeunload", handler); return () => window.removeEventListener("beforeunload", handler); }, [dirty]);
  useEffect(() => { document.documentElement.dataset.kitchenFormDirty = String(dirty); return () => { delete document.documentElement.dataset.kitchenFormDirty; }; }, [dirty]);
  useEffect(() => {
    if (selectedId && versionId) document.getElementById("recipe-content-editor")?.scrollIntoView({ block: "start" });
  }, [selectedId, versionId]);
  function select(recipe: RecipeLibraryItem | null, next?: RecipeVersion) {
    if (dirty && !window.confirm("Odrzucić niezapisane zmiany przepisu?")) return;
    const chosen = next ?? recipe?.versions.at(-1);
    if (recipe) document.getElementById("recipe-content-editor")?.scrollIntoView({ block: "start" });
    setSelectedId(recipe?.id ?? null); setVersionId(chosen?.id ?? null); setCopy(chosen?.content ?? blank()); setDirty(false); setError(""); setMessage("");
  }
  function change(patch: Partial<RecipeContent>) { setCopy((current) => ({ ...current, ...patch })); setDirty(true); setMessage(""); }
  async function action(kind: "SAVE" | "PUBLISH" | "NEW_VERSION" | "ARCHIVE" | "RESTORE") {
    if (kind === "PUBLISH" && !window.confirm("Zatwierdzić tę wersję? Nie będzie można jej edytować. Dania oczekujące na ten przepis otrzymają go automatycznie. Dania z wcześniej przypisaną wersją pozostaną bez zmian.")) return;
    if ((kind === "ARCHIVE" || kind === "RESTORE") && dirty) { setError("Najpierw zapisz szkic albo odrzuć zmiany."); return; }
    if (kind === "ARCHIVE" && !window.confirm("Przenieść przepis do archiwum? Istniejące dania zachowają swoje zatwierdzone przepisy; nie będzie można dodawać go do nowych dań.")) return;
    setBusy(true); setError(""); setMessage("");
    try {
      const create = !selectedId;
      const response = await fetch("/api/admin/recipes", { method: create ? "POST" : "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(create ? copy : { recipeId: selectedId, action: kind, versionId: version?.id, expectedRevision: version?.editRevision, ...(["SAVE", "PUBLISH"].includes(kind) ? { content: copy } : {}) }) });
      const body = await response.json();
      if (!response.ok) throw new Error(body.error ?? "Nie udało się zapisać przepisu.");
      await load(create ? body.recipe.id : selectedId, kind === "NEW_VERSION" ? null : versionId);
      setMessage(kind === "PUBLISH" ? "Wersja zatwierdzona i udostępniona w daniach oczekujących na ten przepis." : "Zapisano zmiany.");
    } catch (error) { setError(error instanceof Error ? error.message : "Błąd połączenia."); }
    finally { setBusy(false); }
  }
  async function upload(files: FileList | null) {
    if (!version || !files?.length) return;
    if (dirty) { setError("Zapisz treść szkicu przed dodaniem plików."); return; }
    setBusy(true); setError("");
    try {
      const form = new FormData(); form.set("expectedRevision", String(version.editRevision)); for (const file of files) form.append("media", file);
      const response = await fetch(`/api/admin/recipes/${version.id}/media`, { method: "POST", body: form });
      const body = await response.json(); if (!response.ok) throw new Error(body.error ?? "Nie udało się dodać plików.");
      await load(selectedId, versionId); setMessage("Dodano materiały do szkicu.");
    } catch (error) { setError(error instanceof Error ? error.message : "Błąd połączenia."); }
    finally { setBusy(false); }
  }
  async function removeMedia(mediaId: string) {
    if (!version || dirty) { setError("Zapisz treść przed zmianą plików."); return; }
    setBusy(true); setError("");
    try {
      const response = await fetch(`/api/admin/recipes/${version.id}/media`, { method: "DELETE", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ mediaId, expectedRevision: version.editRevision }) });
      const body = await response.json(); if (!response.ok) throw new Error(body.error ?? "Nie udało się usunąć pliku ze szkicu.");
      await load(selectedId, versionId);
    } catch (error) { setError(error instanceof Error ? error.message : "Błąd połączenia."); }
    finally { setBusy(false); }
  }
  const filtered = recipes.filter((recipe) => {
    const content = recipe.versions.at(-1)?.content;
    return recipe.archived === showArchive && (!category || content?.category === category) && (!usageFilter || (usageFilter === "unlinked" ? !recipe.usages.length : !!recipe.usages.length)) && content?.name.toLocaleLowerCase("pl").includes(query.trim().toLocaleLowerCase("pl"));
  });
  return <main className="admin-dashboard kitchen-admin"><AdminSectionHeader eyebrow="TYLKO DLA PERSONELU" title="Baza przepisów"/>
    <DishLibrary recipes={recipes} query={query} onQuery={setQuery} busy={busy || loading} onSelect={(recipe) => { select(recipe); }}/><h2>Przepisy bazowe i półprodukty</h2>
    <p className="kitchen-intro">Jeden przepis, wiele dań. Szkice są prywatne dla administratora. Pracownik widzi wyłącznie zatwierdzoną wersję przypisaną do dania.</p>
    {error && <p className="kitchen-error" role="alert">{error}</p>}{message && <p className="kitchen-success" role="status">{message}</p>}
    <div className="kitchen-library"><aside className="kitchen-library-list"><button type="button" disabled={busy || loading} onClick={() => select(null)}>+ Nowy przepis</button><label>Szukaj przepisu<input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Sos, kurczak, grzanki…"/></label><label>Kategoria<select value={category} onChange={(event) => setCategory(event.target.value)}><option value="">Wszystkie kategorie</option>{RECIPE_CATEGORIES.map((item) => <option key={item}>{item}</option>)}</select></label><label className="kitchen-check"><input type="checkbox" checked={showArchive} onChange={(event) => setShowArchive(event.target.checked)}/>Pokaż archiwum</label>
      <label>Powiązania<select value={usageFilter} onChange={(event) => setUsageFilter(event.target.value)}><option value="">Wszystkie przepisy</option><option value="linked">Powiązane z daniami</option><option value="unlinked">Baza wiedzy — niepowiązane</option></select></label>
      {loading ? <p>Wczytuję przepisy…</p> : filtered.length ? filtered.map((recipe) => <button type="button" className={recipe.id === selectedId ? "is-selected" : ""} disabled={busy} key={recipe.id} onClick={() => select(recipe)}><b>{recipe.versions.at(-1)?.content.name}</b><small>{recipe.versions.at(-1)?.content.category} · {recipe.versions.at(-1)?.status === "DRAFT" ? "Szkic" : "Zatwierdzony"} · {new Set(recipe.usages.map((item) => item.productId)).size} dań</small></button>) : <p>Brak przepisów w tej kategorii.</p>}
    </aside><section id="recipe-content-editor" style={{ scrollMarginTop: 90 }} className="kitchen-library-editor" aria-busy={busy}>
      <header><div><span className="kitchen-eyebrow">{version ? `WERSJA ${version.version} · ${version.status === "DRAFT" ? "SZKIC" : "ZATWIERDZONA"}` : "NOWY PRZEPIS"}</span><h2>{version?.content.name ?? "Dodaj przepis bazowy"}</h2></div>{selected && <button type="button" disabled={busy || dirty} onClick={() => void action(selected.archived ? "RESTORE" : "ARCHIVE")}>{selected.archived ? "Przywróć" : "Archiwizuj"}</button>}</header>
      {selected && <nav className="kitchen-version-tabs" aria-label="Historia wersji">{selected.versions.map((item) => <button type="button" key={item.id} disabled={busy} className={item.id === versionId ? "is-selected" : ""} onClick={() => select(selected, item)}>v{item.version} · {item.status === "DRAFT" ? "szkic" : "zatwierdzona"}</button>)}</nav>}
      {!editable && version ? <><RecipeDetails recipe={version}/>{!selected?.archived && <button type="button" disabled={busy || selected?.versions.some((item) => item.status === "DRAFT")} onClick={() => void action("NEW_VERSION")}>Utwórz nową wersję z tej receptury</button>}</> : <>
        <fieldset disabled={busy || loading} className="kitchen-copy-fieldset"><div className="kitchen-form-grid"><label>Nazwa przepisu<input value={copy.name} maxLength={180} onChange={(event) => change({ name: event.target.value })}/></label><label>Kategoria<select value={copy.category} onChange={(event) => change({ category: event.target.value as RecipeContent["category"] })}>{RECIPE_CATEGORIES.map((item) => <option key={item}>{item}</option>)}</select></label><label>Wydajność partii (opcjonalnie)<input inputMode="decimal" value={copy.yieldQuantity} maxLength={40} onChange={(event) => change({ yieldQuantity: event.target.value })}/></label><label>Jednostka partii (opcjonalnie)<input value={copy.yieldUnit} maxLength={40} onChange={(event) => change({ yieldUnit: event.target.value })}/></label></div>
        <h3>Składniki partii bazowej</h3><div className="kitchen-ingredients-editor">{copy.ingredients.map((item, index) => <div key={index}><label>Składnik {index + 1}<input value={item.name} maxLength={180} onChange={(event) => change({ ingredients: copy.ingredients.map((row, i) => i === index ? { ...row, name: event.target.value } : row) })}/></label><label>Ilość<input inputMode="decimal" value={item.quantity} maxLength={40} onChange={(event) => change({ ingredients: copy.ingredients.map((row, i) => i === index ? { ...row, quantity: event.target.value } : row) })}/></label><label>Jednostka<input value={item.unit} maxLength={40} onChange={(event) => change({ ingredients: copy.ingredients.map((row, i) => i === index ? { ...row, unit: event.target.value } : row) })}/></label><button type="button" aria-label={`Usuń składnik ${index + 1}`} onClick={() => change({ ingredients: copy.ingredients.filter((_, i) => i !== index) })}>×</button></div>)}</div><button type="button" disabled={copy.ingredients.length >= 100} onClick={() => change({ ingredients: [...copy.ingredients, { name: "", quantity: "", unit: "g" }] })}>+ Dodaj składnik</button>
        <label>Przygotowanie krok po kroku<textarea rows={8} value={copy.steps} maxLength={20000} onChange={(event) => change({ steps: event.target.value })} placeholder="1. Przygotuj składniki…"/></label><label>Alergeny<textarea rows={2} value={copy.allergens} maxLength={2000} onChange={(event) => change({ allergens: event.target.value })}/></label><label>Przechowywanie — zasady zatwierdzone przez kuchnię<textarea rows={3} value={copy.storage} maxLength={4000} onChange={(event) => change({ storage: event.target.value })} placeholder="Warunki, czas przechowywania, oznaczenie pojemnika…"/></label><label>Sprzęt i dodatkowe wskazówki<textarea rows={3} value={copy.notes} maxLength={4000} onChange={(event) => change({ notes: event.target.value })}/></label>
        </fieldset>
        {version && <details><summary>Sprawdź przeliczanie składników zapisanej receptury</summary><RecipeIngredients key={`${version.id}-${version.editRevision}`} content={version.content}/></details>}
        {version && <section><h3>Zdjęcia i filmy</h3><div className="kitchen-media">{version.media.map((item) => <figure key={item.id}>{item.type === "IMAGE" ? <img src={item.path} alt={item.name}/> : <video src={item.path} controls playsInline preload="metadata"/>}<figcaption>{item.name}</figcaption><button type="button" disabled={busy || dirty} onClick={() => void removeMedia(item.id)}>Usuń ze szkicu</button></figure>)}</div><label>Dodaj materiały<input type="file" accept={mediaAccept} multiple disabled={busy || dirty || version.media.length >= 8} onChange={(event) => { void upload(event.target.files); event.target.value = ""; }}/></label><small>Do 8 plików. Zdjęcie maks. 50 MB, film maks. 95 MB. Zapisz treść przed dodaniem materiałów.</small></section>}
        <div className="kitchen-actions"><button type="button" disabled={busy || loading || !copy.name.trim()} onClick={() => void action("SAVE")}>{busy ? "Zapisuję…" : version ? "Zapisz szkic" : "Utwórz szkic"}</button>{version && <button type="button" disabled={busy || recipePublicationIssues(copy).length > 0} onClick={() => void action("PUBLISH")}>Zatwierdź wersję</button>}</div>
        {version && !!recipePublicationIssues(copy).length && <div className="kitchen-status is-incomplete"><b>Przed zatwierdzeniem:</b><ul>{recipePublicationIssues(copy).map((issue) => <li key={issue}>{issue}</li>)}</ul></div>}
      </>}
      {selected && <section className="kitchen-usages"><h3>Powiązane dania</h3><p>Zatwierdzenie automatycznie udostępnia przepis w daniach z powiązaniem roboczym. Dania z już przypisaną wersją zachowują ją do ręcznej zmiany.</p>{selected.usages.length ? [...new Map(selected.usages.map((item) => [`${item.productId}-${item.recipeVersionId}`, item])).values()].map((item) => <a key={`${item.productId}-${item.recipeVersionId}`} href={`/admin/recipes/dishes/${item.productId}`}>{item.productName}<small>{item.planned ? "powiązanie robocze · do zatwierdzenia" : `przepis v${selected.versions.find((version) => version.id === item.recipeVersionId)?.version}`} →</small></a>) : <p>Niepowiązany zasób bazy wiedzy. Nie zmienia aktualnego menu ani instrukcji dań.</p>}</section>}
    </section></div>
  </main>;
}
