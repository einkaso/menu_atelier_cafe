"use client";

import { useCallback, useEffect, useState } from "react";
import { preparationIssues, type DishComponent, type PreparationCard, type RecipeLibraryItem } from "../../../lib/kitchen-recipes";

const emptyPart = (): DishComponent => ({ name: "", mode: "RECIPE", recipeVersionId: null, pendingRecipeId: null, quantity: "", unit: "g", notes: "" });

export default function DishRecipeEditor({ productId, manualRevision = "" }: { productId: number; manualRevision?: string }) {
  const [card, setCard] = useState<PreparationCard | null>(null);
  const [components, setComponents] = useState<DishComponent[]>([]);
  const [library, setLibrary] = useState<RecipeLibraryItem[]>([]);
  const [busy, setBusy] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  const [dirty, setDirty] = useState(false);
  const load = useCallback(async (signal?: AbortSignal) => {
    try {
      const [cardResponse, recipesResponse] = await Promise.all([fetch(`/api/admin/products/${productId}/recipes`, { cache: "no-store", signal }), fetch("/api/admin/recipes", { cache: "no-store", signal })]);
      const [cardBody, recipeBody] = await Promise.all([cardResponse.json(), recipesResponse.json()]);
      if (!cardResponse.ok || !recipesResponse.ok) throw new Error(cardBody.error ?? recipeBody.error ?? "Nie udało się pobrać przepisów.");
      setCard(cardBody.card); setComponents(cardBody.card.components.map(({ name, mode, recipeVersionId, pendingRecipeId, quantity, unit, notes }: DishComponent) => ({ name, mode, recipeVersionId, pendingRecipeId: pendingRecipeId ?? null, quantity, unit, notes })));
      setLibrary(recipeBody.recipes); setDirty(false); setError("");
    } catch (error) { if (!signal?.aborted) setError(error instanceof Error ? error.message : "Błąd połączenia."); }
    finally { if (!signal?.aborted) setLoading(false); }
  }, [productId]);
  useEffect(() => { const controller = new AbortController(); void load(controller.signal); return () => controller.abort(); }, [load]);
  // Saving the assembly manual updates completeness, but must not overwrite unsaved components.
  useEffect(() => {
    const controller = new AbortController();
    void fetch(`/api/admin/products/${productId}/recipes`, { cache: "no-store", signal: controller.signal }).then((response) => response.ok ? response.json() : null).then((body) => { if (body) setCard((current) => current ? { ...current, instructions: body.card.instructions, media: body.card.media } : body.card); }).catch(() => {});
    return () => controller.abort();
  }, [productId, manualRevision]);
  useEffect(() => {
    document.documentElement.dataset.kitchenFormDirty = String(dirty);
    const onLeave = (event: BeforeUnloadEvent) => { if (dirty) { event.preventDefault(); event.returnValue = ""; } };
    window.addEventListener("beforeunload", onLeave); return () => { window.removeEventListener("beforeunload", onLeave); delete document.documentElement.dataset.kitchenFormDirty; };
  }, [dirty]);
  const versions = library.flatMap((recipe) => recipe.versions.filter((version) => version.status === "PUBLISHED").map((version) => ({ ...version, archived: recipe.archived })));
  function change(index: number, patch: Partial<DishComponent>) { setComponents((current) => current.map((part, i) => i === index ? { ...part, ...patch } : part)); setDirty(true); setMessage(""); }
  async function save() {
    if (!card) return;
    setBusy(true); setError(""); setMessage("");
    try {
      const response = await fetch(`/api/admin/products/${productId}/recipes`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ expectedRevision: card.revision, components }) });
      const body = await response.json();
      if (!response.ok) throw new Error(body.error ?? "Nie udało się zapisać elementów.");
      setCard(body.card); setDirty(false); setMessage("Elementy zapisane. Pracownik zobaczy wskazane wersje przepisów.");
    } catch (error) { setError(error instanceof Error ? error.message : "Błąd połączenia."); }
    finally { setBusy(false); }
  }
  const issues = card ? preparationIssues(card.instructions, card.media, components.map((part) => ({ ...part, recipe: versions.find((item) => item.id === part.recipeVersionId) ?? null }))) : [];
  return <section className="kitchen-dish-editor" onInput={(event) => event.stopPropagation()} onKeyDown={(event) => { if (event.key === "Enter" && event.target instanceof HTMLInputElement) event.preventDefault(); }}>
    <header><div><span className="kitchen-eyebrow">PÓŁPRODUKTY · JEDNA PORCJA</span><h3>Elementy dania i przepisy</h3></div><a href="/admin/recipes" target="_blank" rel="noreferrer">Otwórz bazę przepisów ↗</a></header>
    <p>Wybierz zatwierdzone przepisy albo oznacz produkty gotowe. Robocze powiązanie udostępni przepis pracownikowi automatycznie po zatwierdzeniu. Ta lista zapisuje się osobno od manuala powyżej.</p>
    {error && <p className="kitchen-error" role="alert">{error}</p>}{message && <p role="status" className="kitchen-success">{message}</p>}
    {loading ? <p>Wczytuję elementy…</p> : card && <>
      <div className={`kitchen-status ${issues.length ? "is-incomplete" : "is-complete"}`}><b>{issues.length ? "Do uzupełnienia" : "Komplet przygotowania"}{dirty ? " · niezapisane zmiany" : ""}</b>{!!issues.length && <ul>{issues.map((issue) => <li key={issue}>{issue}</li>)}</ul>}</div>
      <fieldset disabled={busy} className="kitchen-parts-fieldset">{components.map((part, index) => {
        const selected = versions.find((version) => version.id === part.recipeVersionId);
        const newer = selected && versions.find((version) => !version.archived && version.recipeId === selected.recipeId && version.version > selected.version);
        return <section className="kitchen-part-editor" key={index}>
          <header><b>Element {index + 1}</b><div><button type="button" disabled={index === 0} aria-label={`Przenieś ${part.name || "element"} wyżej`} onClick={() => { setComponents((current) => { const next = [...current]; [next[index - 1], next[index]] = [next[index], next[index - 1]]; return next; }); setDirty(true); }}>↑</button><button type="button" onClick={() => { setComponents((current) => current.filter((_, i) => i !== index)); setDirty(true); }}>Usuń element</button></div></header>
          <div className="kitchen-form-grid"><label>Nazwa elementu<input value={part.name} maxLength={180} onChange={(event) => change(index, { name: event.target.value })}/></label>
          <label>Rodzaj<select value={part.mode} onChange={(event) => change(index, { mode: event.target.value as DishComponent["mode"], recipeVersionId: null, pendingRecipeId: null })}><option value="RECIPE">Własny przepis</option><option value="PURCHASED">Produkt gotowy / kupowany</option></select></label>
          <label>Ilość na porcję<input inputMode="decimal" value={part.quantity} maxLength={40} onChange={(event) => change(index, { quantity: event.target.value })}/></label><label>Jednostka<input value={part.unit} maxLength={40} placeholder="g, ml, szt." onChange={(event) => change(index, { unit: event.target.value })}/></label></div>
          {part.mode === "RECIPE" && <>
            <label>Przepis i wersja<select value={part.pendingRecipeId ? `pending:${part.pendingRecipeId}` : part.recipeVersionId ?? ""} onChange={(event) => {
              const value = event.target.value;
              if (value.startsWith("pending:")) { change(index, { pendingRecipeId: Number(value.slice(8)), recipeVersionId: null }); return; }
              const version = versions.find((item) => item.id === Number(value));
              change(index, { pendingRecipeId: null, recipeVersionId: version?.id ?? null, ...(!part.name && version ? { name: version.content.name } : {}) });
            }}><option value="">Brak przypisanego przepisu</option>
              <optgroup label="Zatwierdzone wersje dla pracownika">{versions.filter((item) => !item.archived || item.id === part.recipeVersionId).map((version) => <option key={version.id} value={version.id}>{version.content.name} · v{version.version}{version.archived ? " · archiwum" : ""}</option>)}</optgroup>
              <optgroup label="Robocze powiązania — tylko administrator">{library.filter((recipe) => !recipe.archived || recipe.id === part.pendingRecipeId).map((recipe) => <option key={recipe.id} value={`pending:${recipe.id}`}>{recipe.versions.at(-1)?.content.name} · do zatwierdzenia</option>)}</optgroup>
            </select></label>
            {part.pendingRecipeId && <p className="kitchen-update-note">Receptura nie jest udostępniona pracownikowi. <a href={`/admin/recipes?recipe=${part.pendingRecipeId}`} target="_blank" rel="noreferrer">Otwórz przepis do uzupełnienia ↗</a>. Po zatwierdzeniu przepis pojawi się w tym daniu automatycznie.</p>}
          </>}
          {newer && <p className="kitchen-update-note">Dostępna jest nowsza zatwierdzona wersja. Zmień ją w wyborze przepisu, jeśli ma obowiązywać w tym daniu.</p>}
          <label>Wskazówki dla tego dania<input value={part.notes} maxLength={1000} onChange={(event) => change(index, { notes: event.target.value })}/></label>
        </section>;
      })}</fieldset>
      <div className="kitchen-actions"><button type="button" disabled={busy || components.length >= 40} onClick={() => { setComponents((current) => [...current, emptyPart()]); setDirty(true); }}>+ Dodaj element</button><button type="button" disabled={busy || dirty} onClick={() => void load()}>Odśwież bazę</button><button type="button" disabled={busy || !dirty} onClick={() => void save()}>{busy ? "Zapisuję…" : "Zapisz elementy dania"}</button></div>
    </>}
  </section>;
}
