import { isAdmin } from "../../../lib/admin-auth";
import AdminLogin from "../admin-login";
import RecipesAdminClient from "./recipes-admin-client";

export const dynamic = "force-dynamic";
export default async function RecipesPage() {
  return await isAdmin().catch(() => false) ? <RecipesAdminClient/> : <AdminLogin/>;
}
