import { notFound } from "next/navigation";
import { isAdmin } from "../../../../../lib/admin-auth";
import { readPreparationCard } from "../../../../../lib/kitchen-recipes-server";
import AdminLogin from "../../../admin-login";
import AdminSectionHeader from "../../../admin-section-header";
import DishManualEditor from "../../dish-manual-editor";
import PreparationCardView from "../../../../../components/kitchen/preparation-card";

export const dynamic = "force-dynamic";
export default async function DishRecipesPage({ params }: { params: Promise<{ id: string }> }) {
  if (!(await isAdmin().catch(() => false))) return <AdminLogin/>;
  const id = Number((await params).id);
  if (!Number.isSafeInteger(id) || id < 1) notFound();
  const card = await readPreparationCard(id);
  if (!card) notFound();
  return <main className="admin-dashboard kitchen-admin"><AdminSectionHeader eyebrow="KARTA PRZYGOTOWANIA" title={card.productName} links={[{ href: "/admin/recipes", label: "Baza przepisów" }]}/><DishManualEditor productId={id}/><details><summary>Podgląd ostatnio zapisanej karty pracownika</summary><PreparationCardView card={card}/></details></main>;
}
