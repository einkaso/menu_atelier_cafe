"use client";
import { useEffect, useState } from "react";
import type { RecipeLibraryItem } from "../../../lib/kitchen-recipes";
type Dish = { id: number; name: string; featured: boolean; deleted: boolean; hasPublished: boolean; hasDraft: boolean };
export default function DishLibrary({ recipes, onSelect, query, onQuery, busy }: { recipes: RecipeLibraryItem[]; onSelect: (recipe: RecipeLibraryItem) => void; query: string; onQuery: (query: string) => void; busy: boolean }) {
  const [dishes, setDishes] = useState<Dish[]>([]);
  const [filter, setFilter] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  useEffect(() => {
    const controller = new AbortController();
    void fetch("/api/admin/recipes/dishes", { cache: "no-store", signal: controller.signal }).then(async response => {
      const body = await response.json(); if (!response.ok) throw new Error(body.error);
      setDishes(body.dishes);
    }).catch(e => { if (!controller.signal.aborted) setError(e.message); }).finally(() => { if (!controller.signal.aborted) setLoading(false); });
    return () => controller.abort();
  }, []);
  const visible = dishes.filter(d => d.name.toLocaleLowerCase("pl").includes(query.trim().toLocaleLowerCase("pl")) && (!filter || (filter === "featured" ? d.featured : filter === "draft" ? d.hasDraft : filter === "published" ? d.hasPublished : !d.hasPublished && !d.hasDraft)))
    .sort((a,b) => Number(b.featured) - Number(a.featured) || Number(b.hasPublished || b.hasDraft) - Number(a.hasPublished || a.hasDraft) || a.name.localeCompare(b.name, "pl"));
  const baseRecipes = recipes.filter(recipe => recipe.versions.at(-1)?.content.name.toLocaleLowerCase("pl").includes(query.trim().toLocaleLowerCase("pl")));
  return <section className="kitchen-library-editor" aria-label="Wszystkie receptury">
    <h2>Wszystkie receptury</h2><p>Wyszukaj danie, napój lub półprodukt — również szkice i przepisy przed publikacją.</p>
    <div className="kitchen-form-grid"><label>Szukaj we wszystkich recepturach<input value={query} onChange={e => onQuery(e.target.value)} placeholder="Np. oliwa szczypiorkowa, sos, sałata…"/></label>
    <label>Filtr dań i napojów<select value={filter} onChange={e => setFilter(e.target.value)}><option value="">Wszystkie produkty</option><option value="featured">Promowane</option><option value="draft">Ze szkicem</option><option value="published">Z opublikowaną instrukcją</option><option value="empty">Do uzupełnienia</option></select></label></div>
    <h3>Przepisy bazowe i półprodukty ({baseRecipes.length})</h3>
    <div className="kitchen-library-list" style={{ maxHeight: 280, overflowY: "auto" }}>{baseRecipes.map(recipe => <button key={recipe.id} type="button" disabled={busy} onClick={() => onSelect(recipe)}><b>{recipe.versions.at(-1)?.content.name}</b><small>{recipe.archived ? "Archiwum" : recipe.versions.at(-1)?.status === "DRAFT" ? "Szkic" : "Zatwierdzony"} · Edytuj recepturę →</small></button>)}</div>
    {!!query.trim() && !baseRecipes.length && <p>Brak pasujących przepisów bazowych.</p>}
    <h3>Dania i napoje</h3>
    {error && <p role="alert" className="kitchen-error">{error}</p>}
    {loading ? <p>Wczytuję dania…</p> : <><p>{visible.length} pozycji</p><div className="kitchen-usages" style={{ maxHeight: 420, overflowY: "auto" }}>{visible.map(d => <a key={d.id} href={`/admin/recipes/dishes/${d.id}`}><b>{d.name}</b><small>{d.featured ? "Promowane · " : ""}{d.deleted ? "Archiwalny produkt · " : ""}{d.hasDraft ? "Szkic do publikacji" : d.hasPublished ? "Opublikowana instrukcja" : "Do uzupełnienia"} · Edytuj recepturę →</small></a>)}</div></>}
  </section>;
}
