"use client";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import DishRecipeEditor from "./dish-recipe-editor";
type State = { published: string; draft: string | null; revision: number };
export default function DishManualEditor({ productId }: { productId: number }) {
  const router = useRouter();
  const [state, setState] = useState<State | null>(null);
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  const dirty = !!state && text !== (state.draft ?? state.published);
  useEffect(() => {
    const controller = new AbortController();
    void fetch(`/api/admin/products/${productId}/manual-draft`, { cache: "no-store", signal: controller.signal }).then(async response => {
      const body = await response.json(); if (!response.ok) throw new Error(body.error);
      setState(body); setText(body.draft ?? body.published);
    }).catch(e => { if (!controller.signal.aborted) setError(e.message); });
    return () => controller.abort();
  }, [productId]);
  useEffect(() => {
    const leave = (event: BeforeUnloadEvent) => { if (dirty) { event.preventDefault(); event.returnValue = ""; } };
    document.documentElement.dataset.dishManualDirty = String(dirty);
    window.addEventListener("beforeunload", leave); return () => { window.removeEventListener("beforeunload", leave); delete document.documentElement.dataset.dishManualDirty; };
  }, [dirty]);
  async function save(action: "SAVE" | "PUBLISH") {
    if (!state) return;
    if (action === "PUBLISH" && !window.confirm("Opublikować tę recepturę dla pracowników? Zastąpi dotychczasową instrukcję dania.")) return;
    setBusy(true); setError(""); setMessage("");
    try {
      const response = await fetch(`/api/admin/products/${productId}/manual-draft`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action, instructions: text, expectedRevision: state.revision, expectedPublished: state.published }) });
      const body = await response.json(); if (!response.ok) throw new Error(body.error);
      setState(body); setText(body.draft ?? body.published);
      setMessage(action === "SAVE" ? "Szkic zapisany. Pracownicy nadal widzą poprzednią opublikowaną instrukcję." : "Receptura opublikowana dla pracowników.");
      if (action === "PUBLISH") router.refresh();
    } catch (e) { setError(e instanceof Error ? e.message : "Nie udało się zapisać receptury."); }
    finally { setBusy(false); }
  }
  return <><section className="kitchen-library-editor">
    <h2>Receptura i przygotowanie dania</h2>
    <p>Najpierw popraw treść i zapisz szkic. Dopiero publikacja udostępnia zmiany pracownikom. Zdjęcia i przypisane półprodukty pozostają przy daniu.</p>
    {error && <p role="alert" className="kitchen-error">{error}</p>}{message && <p role="status" className="kitchen-success">{message}</p>}
    {state && <><p>{state.draft !== null ? "Szkic do publikacji" : state.published ? "Opublikowana instrukcja — możesz przygotować poprawki" : "Brak receptury — uzupełnij szkic"}{dirty ? " · niezapisane zmiany" : ""}</p>
    <label>Składniki, proporcje i przygotowanie<textarea style={{ width: "100%", minHeight: 360 }} rows={18} maxLength={12000} value={text} disabled={busy} onChange={event => { setText(event.target.value); setMessage(""); }}/></label>
    <div className="kitchen-actions"><button type="button" disabled={busy} onClick={() => void save("SAVE")}>Zapisz szkic receptury</button><button type="button" disabled={busy || !text.trim()} onClick={() => void save("PUBLISH")}>Opublikuj dla pracowników</button></div></>}
  </section><DishRecipeEditor productId={productId} manualRevision={state?.published ?? ""}/></>;
}
