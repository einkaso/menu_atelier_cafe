import { isAdmin } from "../../../lib/admin-auth";
import { readUnassignedPhotoManifest, type UnassignedPhotoEntry, unassignedPhotoSources } from "../../../lib/unassigned-photo-review";
import AdminLogin from "../admin-login";

export const dynamic = "force-dynamic";

const sourceNames = {
  "local-uploads": "Zdjęcia dodane lokalnie",
  "professional-archive": "Archiwum fotografa",
} as const;

function photoUrl(entry: UnassignedPhotoEntry, mode: "preview" | "download") {
  const base = `/api/admin/unassigned-photos/${encodeURIComponent(entry.source)}/${encodeURIComponent(entry.file)}`;
  return `${base}?${mode}=1`;
}

export default async function UnassignedPhotosPage() {
  if (!(await isAdmin().catch(() => false))) return <AdminLogin />;
  const manifest = await readUnassignedPhotoManifest();

  return (
    <main className="unassigned-photos-page">
      <header className="unassigned-photos-header">
        <div>
          <p className="admin-eyebrow">Atelier photo review</p>
          <h1>Zdjęcia do przypisania</h1>
          <p>Odzyskane fotografie, które nie są przypisane do żadnego produktu w bazie.</p>
        </div>
        <a className="unassigned-photos-back" href="/admin">Wróć do panelu</a>
      </header>

      {!manifest ? (
        <p className="admin-alert">Nie udało się odczytać manifestu odzyskanych zdjęć.</p>
      ) : (
        <>
          <section className="unassigned-photos-summary" aria-label="Podsumowanie">
            <strong>{manifest.files.length}</strong>
            <span>zdjęcia bez przypisania · {(manifest.totalBytes / 1024 / 1024).toLocaleString("pl-PL", { maximumFractionDigits: 1 })} MB</span>
          </section>
          {unassignedPhotoSources.map((source) => {
            const photos = manifest.files.filter((entry) => entry.source === source);
            return (
              <section className="unassigned-photos-section" key={source}>
                <div className="unassigned-photos-section-title">
                  <h2>{sourceNames[source]}</h2>
                  <span>{photos.length}</span>
                </div>
                <div className="unassigned-photos-grid">
                  {photos.map((entry) => (
                    <article className="unassigned-photo-card" key={`${entry.source}/${entry.file}`}>
                      <a href={photoUrl(entry, "download")} title="Pobierz oryginał">
                        <img src={photoUrl(entry, "preview")} alt={entry.originalName || entry.file} loading="lazy" />
                      </a>
                      <div>
                        <strong>{entry.originalName || entry.file}</strong>
                        <span>{(entry.size / 1024 / 1024).toLocaleString("pl-PL", { maximumFractionDigits: 1 })} MB</span>
                      </div>
                    </article>
                  ))}
                </div>
              </section>
            );
          })}
        </>
      )}
    </main>
  );
}
