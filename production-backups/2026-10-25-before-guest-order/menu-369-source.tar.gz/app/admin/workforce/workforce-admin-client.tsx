"use client";

import { FormEvent, useCallback, useEffect, useMemo, useRef, useState } from "react";
import { addDays, mondayFor, WEEK_DAYS, weekDates } from "../../../lib/workforce";
import { Dialog, DialogContent, DialogTitle, DialogDescription } from "../../../components/ui/dialog";
import AdminSectionHeader from "../admin-section-header";

type Employee = { dotykackaId: string; name: string; includeInSchedule: boolean };
type AvailabilityDay = { date: string; available: boolean; free?: boolean; from: string | null; to: string | null; note: string | null };
type Availability = { employeeDotykackaId: string; employeeName: string; minShifts: number; maxShifts: number; days: AvailabilityDay[]; submittedAt: string; updatedAt: string };
type Shift = { id?: number; employeeDotykackaId: string; employeeName?: string; workDate: string; startsAt?: string; endsAt?: string; from: string; to: string; note: string };
type Schedule = { id: number; status: "DRAFT" | "PUBLISHED"; version: number; openingHours: Opening[]; availabilityLocked: boolean; publishedAt: string | null };
type Opening = { date: string; closed: boolean; from: string | null; to: string | null };
type Correction = { id: number; employeeName: string; workDate: string; requestedStart: string; requestedEnd: string; reason: string };
type Entry = { id: number; employeeDotykackaId: string; employeeName: string; startedAt: string; endedAt: string | null; workedMinutes: number | null; status: string; source: string };
type CalendarEvent = { uid: string; title: string; startsAt: string; endsAt: string | null; allDay: boolean };
type Reservation = { id: number; guestName: string | null; partySize: number | null; startsAt: string; endsAt: string; location: string | null; specialRequest: string | null };
type Data = { employees: Employee[]; settlementEmployees: Employee[]; availability: Availability[]; schedule: Schedule | null; shifts: Array<Omit<Shift, "from" | "to"> & { startsAt: string; endsAt: string }>; corrections: Correction[]; entries: Entry[]; weekEntries: Entry[]; events: CalendarEvent[]; reservations: Reservation[]; calendar: { connected: boolean; name: string; error: string | null }; teamCalendarUrl: string };
type SelectedCell = { employeeDotykackaId: string; date: string } | null;
type AvailabilityDraft = { day: AvailabilityDay; minShifts: number; maxShifts: number };
type ShiftPreset = "FIRST" | "SECOND" | "MIDDLE";

const polishDate = new Intl.DateTimeFormat("pl-PL", { weekday: "short", day: "numeric", month: "short" });
const polishTime = new Intl.DateTimeFormat("pl-PL", { hour: "2-digit", minute: "2-digit" });
const warsawDate = new Intl.DateTimeFormat("en-CA", { timeZone: "Europe/Warsaw", year: "numeric", month: "2-digit", day: "2-digit" });
const inputTime = (value: string) => new Intl.DateTimeFormat("en-GB", { timeZone: "Europe/Warsaw", hour: "2-digit", minute: "2-digit", hourCycle: "h23" }).format(new Date(value));

function standardOpenings(weekStart: string): Opening[] {
  return weekDates(weekStart).map((date, index) => ({ date, closed: false, from: "09:00", to: index <= 2 || index === 6 ? "21:00" : "22:00" }));
}

function isLegacyOpeningHours(openings: Opening[]) {
  return openings.length === 7 && openings.every((opening) => !opening.closed && opening.from === "08:00" && opening.to === "22:00");
}

function addMinutes(time: string, minutes: number) {
  const [hour, minute] = time.split(":").map(Number);
  const total = hour * 60 + minute + minutes;
  return `${String(Math.floor(total / 60) % 24).padStart(2, "0")}:${String(total % 60).padStart(2, "0")}`;
}

function durationLabel(minutes: number) {
  return `${Math.floor(minutes / 60)} h ${minutes % 60} min`;
}

export default function WorkforceAdminClient() {
  const [weekStart, setWeekStart] = useState(mondayFor());
  const [dataWeekStart, setDataWeekStart] = useState("");
  const [data, setData] = useState<Data | null>(null);
  const [shifts, setShifts] = useState<Shift[]>([]);
  const [openings, setOpenings] = useState<Opening[]>(standardOpenings(weekStart));
  const cellButton = useRef<HTMLButtonElement | null>(null);
  const cellSnapshot = useRef<Shift[] | null>(null);
  const cellScroll = useRef({ x: 0, y: 0 });
  const [selectedCell, setSelectedCell] = useState<SelectedCell>(null);
  const [availabilityDraft, setAvailabilityDraft] = useState<AvailabilityDraft | null>(null);
  const [busy, setBusy] = useState("");
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [calendarForm, setCalendarForm] = useState({ name: "Kalendarz wydarzeń", url: "" });
  const [visibleLayers, setVisibleLayers] = useState({ availability: true, schedule: true, actual: true });
  const [showEmployeesWithoutAvailability, setShowEmployeesWithoutAvailability] = useState(true);
  const [calculationNow, setCalculationNow] = useState(() => Date.now());

  const load = useCallback(async () => {
    setError("");
    const response = await fetch(`/api/admin/workforce?weekStart=${weekStart}`, { cache: "no-store" });
    const body = await response.json().catch(() => ({})) as Data & { error?: string };
    if (!response.ok) setError(body.error ?? "Nie udało się pobrać grafiku.");
    else {
      const savedOpenings = body.schedule?.openingHours ?? [];
      const planningEmployeeIds = new Set(body.employees.map((employee) => employee.dotykackaId));
      setData(body); setDataWeekStart(weekStart);
      setOpenings(savedOpenings.length && !isLegacyOpeningHours(savedOpenings) ? savedOpenings : standardOpenings(weekStart));
      setShifts(body.shifts.filter((shift) => planningEmployeeIds.has(shift.employeeDotykackaId)).map((shift) => ({ ...shift, from: inputTime(shift.startsAt), to: inputTime(shift.endsAt), note: shift.note ?? "" })));
      setCalendarForm((current) => ({ ...current, name: body.calendar.name }));
      setSelectedCell(null);
      setAvailabilityDraft(null);
    }
  }, [weekStart]);

  // Initial administrator planner hydration.
  // eslint-disable-next-line react-hooks/set-state-in-effect
  useEffect(() => { void load(); }, [load]);
  useEffect(() => {
    let active = true;
    async function refreshWorkedTime() {
      const response = await fetch(`/api/admin/workforce?weekStart=${weekStart}&live=1`, { cache: "no-store" });
      const body = await response.json().catch(() => ({})) as { weekEntries?: Entry[] };
      if (active && response.ok && body.weekEntries) setData((current) => current ? { ...current, weekEntries: body.weekEntries ?? current.weekEntries } : current);
    }
    const timer = window.setInterval(() => { setCalculationNow(Date.now()); void refreshWorkedTime(); }, 60_000);
    return () => { active = false; window.clearInterval(timer); };
  }, [weekStart]);

  const dates = weekDates(weekStart);
  const employeeById = new Map((data?.employees ?? []).map((employee) => [employee.dotykackaId, employee]));
  const monthly = useMemo(() => {
    const result = new Map<string, number>();
    for (const entry of data?.entries ?? []) result.set(entry.employeeDotykackaId, (result.get(entry.employeeDotykackaId) ?? 0) + (entry.workedMinutes ?? 0));
    return result;
  }, [data]);
  const pendingAvailability = useMemo(() => (data?.availability ?? []).filter((availability) => !data?.schedule?.publishedAt || data.schedule.status !== "PUBLISHED" || new Date(availability.updatedAt) > new Date(data.schedule.publishedAt)), [data]);
  const visibleLayerCount = Number(visibleLayers.availability) + Number(visibleLayers.schedule) + Number(visibleLayers.actual);
  const employeesWithAvailability = new Set((data?.availability ?? []).map((availability) => availability.employeeDotykackaId));
  const employeesWithoutAvailabilityCount = (data?.employees ?? []).filter((employee) => !employeesWithAvailability.has(employee.dotykackaId)).length;
  const displayedEmployees = (data?.employees ?? []).filter((employee) => showEmployeesWithoutAvailability || employeesWithAvailability.has(employee.dotykackaId));
  const planningEmployeeIds = new Set((data?.employees ?? []).map((employee) => employee.dotykackaId));

  const selectedShiftIndex = selectedCell ? shifts.findIndex((shift) => shift.employeeDotykackaId === selectedCell.employeeDotykackaId && shift.workDate === selectedCell.date) : -1;
  const selectedShift = selectedShiftIndex >= 0 ? shifts[selectedShiftIndex] : null;
  const selectedEmployee = selectedCell ? employeeById.get(selectedCell.employeeDotykackaId) : null;
  function selectCell(employeeDotykackaId: string, date: string, button: HTMLButtonElement) {
    cellButton.current = button;
    cellSnapshot.current = shifts;
    cellScroll.current = { x: window.scrollX, y: window.scrollY };
    setError(""); setMessage("");
    const availability = data?.availability.find((row) => row.employeeDotykackaId === employeeDotykackaId);
    const day = availability?.days.find((item) => item.date === date);
    setSelectedCell({ employeeDotykackaId, date });
    setAvailabilityDraft({
      day: day ? { ...day, free: day.free === true } : { date, available: false, free: false, from: null, to: null, note: null },
      minShifts: availability?.minShifts ?? 2,
      maxShifts: availability?.maxShifts ?? 4,
    });
  }

  function closeCellEditor() {
    if (busy) return;
    if (cellSnapshot.current) setShifts(cellSnapshot.current);
    setSelectedCell(null); setAvailabilityDraft(null); setError("");
  }

  function updateAvailabilityDay(patch: Partial<AvailabilityDay>) {
    setAvailabilityDraft((current) => current ? { ...current, day: { ...current.day, ...patch } } : current);
  }

  function toggleEmployeesWithoutAvailability() {
    const next = !showEmployeesWithoutAvailability;
    if (!next && selectedCell && !employeesWithAvailability.has(selectedCell.employeeDotykackaId)) {
      setSelectedCell(null);
      setAvailabilityDraft(null);
    }
    setShowEmployeesWithoutAvailability(next);
  }

  function updateOpening(index: number, patch: Partial<Opening>) {
    setOpenings((current) => current.map((opening, position) => position === index ? { ...opening, ...patch } : opening));
  }

  function presetTimes(date: string, preset: ShiftPreset) {
    if (preset === "FIRST") return { from: "08:30", to: "15:30" };
    if (preset === "MIDDLE") return { from: "11:00", to: "19:00" };
    const closing = openings.find((opening) => opening.date === date)?.to ?? "21:00";
    return { from: "15:30", to: addMinutes(closing, 30) };
  }

  function assignPreset(preset: ShiftPreset) {
    if (!selectedCell || !selectedEmployee) return;
    if (availabilityDraft?.day.free) { setError(`${selectedEmployee.name} ma w tym dniu oznaczone WOLNE.`); return; }
    const times = presetTimes(selectedCell.date, preset);
    const next: Shift = { ...(selectedShift ?? {}), employeeDotykackaId: selectedEmployee.dotykackaId, employeeName: selectedEmployee.name, workDate: selectedCell.date, ...times, note: selectedShift?.note ?? "" };
    setShifts((current) => selectedShiftIndex >= 0 ? current.map((shift, index) => index === selectedShiftIndex ? next : shift) : [...current, next]);
  }

  function updateSelectedShift(patch: Partial<Shift>) {
    if (selectedShiftIndex < 0) return;
    setShifts((current) => current.map((shift, index) => index === selectedShiftIndex ? { ...shift, ...patch } : shift));
  }

  function removeSelectedShift() {
    if (selectedShiftIndex < 0) return;
    setShifts((current) => current.filter((_, index) => index !== selectedShiftIndex));
  }

  async function saveEmployeeAvailability() {
    if (!selectedCell || !selectedEmployee || !availabilityDraft || busy) return;
    setBusy("availability"); setError(""); setMessage("");
    try {
      const response = await fetch("/api/admin/workforce", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ action: "SAVE_EMPLOYEE_AVAILABILITY", weekStart, employeeDotykackaId: selectedEmployee.dotykackaId, date: selectedCell.date, minShifts: availabilityDraft.minShifts, maxShifts: availabilityDraft.maxShifts, day: availabilityDraft.day }) });
      const body = await response.json() as { error?: string; saved?: Availability };
      if (!response.ok || !body.saved) throw new Error(body.error ?? "Nie udało się zmienić dyspozycji pracownika.");
      const saved = body.saved;
      setData(current => current ? { ...current, availability: [...current.availability.filter(item => item.employeeDotykackaId !== saved.employeeDotykackaId), saved] } : current);
      setMessage(`Dyspozycja pracownika ${selectedEmployee.name} została zapisana.`);
    } catch (error) { setError(error instanceof Error ? error.message : "Nie udało się zapisać dyspozycji."); }
    finally { setBusy(""); }
  }

  function entriesFor(employeeDotykackaId: string, date: string) {
    return (data?.weekEntries ?? []).filter((entry) => entry.employeeDotykackaId === employeeDotykackaId && warsawDate.format(new Date(entry.startedAt)) === date);
  }

  function shiftMinutes(shift: Shift) {
    const [fromHour, fromMinute] = shift.from.split(":").map(Number);
    const [toHour, toMinute] = shift.to.split(":").map(Number);
    const start = fromHour * 60 + fromMinute;
    const end = toHour * 60 + toMinute;
    return end <= start ? end + 24 * 60 - start : end - start;
  }

  function plannedMinutesFor(employeeDotykackaId: string, date: string) {
    return shifts.filter((shift) => shift.employeeDotykackaId === employeeDotykackaId && shift.workDate === date).reduce((sum, shift) => sum + shiftMinutes(shift), 0);
  }

  function entryMinutes(entry: Entry) {
    if (entry.workedMinutes !== null) return entry.workedMinutes;
    const startedAt = new Date(entry.startedAt).getTime();
    const endedAt = entry.endedAt ? new Date(entry.endedAt).getTime() : calculationNow;
    return Math.max(0, Math.round((endedAt - startedAt) / 60_000));
  }

  function actualMinutesFor(employeeDotykackaId: string, date: string) {
    return entriesFor(employeeDotykackaId, date).reduce((sum, entry) => sum + entryMinutes(entry), 0);
  }

  function teamPlannedMinutes(date: string) {
    return shifts.filter((shift) => planningEmployeeIds.has(shift.employeeDotykackaId) && shift.workDate === date).reduce((sum, shift) => sum + shiftMinutes(shift), 0);
  }

  function teamActualMinutes(date: string) {
    return (data?.weekEntries ?? []).filter((entry) => planningEmployeeIds.has(entry.employeeDotykackaId) && warsawDate.format(new Date(entry.startedAt)) === date).reduce((sum, entry) => sum + entryMinutes(entry), 0);
  }

  function actualSummary(employeeDotykackaId: string, date: string) {
    const entries = entriesFor(employeeDotykackaId, date);
    if (!entries.length) return null;
    const legacyDurationOnly = entries.every((entry) => entry.source === "LEGACY_IMPORT_DURATION_ONLY");
    const first = entries.reduce((earliest, entry) => new Date(entry.startedAt) < new Date(earliest.startedAt) ? entry : earliest);
    const hasOpen = entries.some((entry) => !entry.endedAt);
    const completed = entries.filter((entry) => entry.endedAt);
    const last = completed.length ? completed.reduce((latest, entry) => new Date(entry.endedAt as string) > new Date(latest.endedAt as string) ? entry : latest) : null;
    const minutes = entries.reduce((sum, entry) => sum + entryMinutes(entry), 0);
    return { range: legacyDurationOnly ? "poprzedni system" : `${polishTime.format(new Date(first.startedAt))}–${hasOpen ? "trwa" : last?.endedAt ? polishTime.format(new Date(last.endedAt)) : "—"}`, duration: (hasOpen ? "w trakcie" : durationLabel(minutes)) + (entries.some((entry) => entry.source === "QR_KIOSK_AUTO_CLOSE") ? " · wyjście automatyczne" : "") };
  }

  async function savePlan(publish = false) {
    if (busy) return;
    setBusy(publish ? "publish" : "save"); setError(""); setMessage("");
    try {
      const save = await fetch("/api/admin/workforce", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ action: "SAVE_PLAN", weekStart, openingHours: openings, shifts: shifts.map(({ employeeDotykackaId, workDate, from, to, note }) => ({ employeeDotykackaId, workDate, from, to, note })) }) });
      const saveBody = await save.json().catch(() => ({})) as { error?: string };
      if (!save.ok) throw new Error(saveBody.error ?? "Nie udało się zapisać planu.");
      if (publish) {
        const response = await fetch("/api/admin/workforce", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ action: "PUBLISH", weekStart }) });
        const body = await response.json().catch(() => ({})) as { error?: string };
        if (!response.ok) throw new Error(body.error ?? "Nie udało się opublikować grafiku.");
        setMessage("Grafik opublikowany. Pracownicy zobaczą swoje zmiany, a kalendarze wymagające odświeżenia zostaną oznaczone.");
      } else setMessage("Szkic grafiku zapisany.");
      cellSnapshot.current = null;
      await load();
    } catch (error) {
      setError(error instanceof Error ? error.message : "Nie udało się zapisać planu. Sprawdź połączenie i spróbuj ponownie.");
    } finally { setBusy(""); }
  }

  async function toggleAvailabilityLock() {
    if (!data || busy || dataWeekStart !== weekStart) return;
    const locked = !data.schedule?.availabilityLocked;
    setBusy("availability-lock"); setError(""); setMessage("");
    try {
      const response = await fetch("/api/admin/workforce", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ action: "SET_AVAILABILITY_LOCK", weekStart, locked }) });
      const body = await response.json() as { error?: string; schedule?: Schedule };
      if (!response.ok || !body.schedule) throw new Error(body.error ?? "Nie udało się zmienić blokady dyspozycji.");
      const schedule = body.schedule;
      setData(current => current ? { ...current, schedule } : current);
      setMessage(locked ? "Zmiany dyspozycji w tym tygodniu zostały zablokowane dla pracowników." : "Pracownicy mogą ponownie zmieniać dyspozycje w tym tygodniu.");
    } catch (error) {
      setError(error instanceof Error ? error.message : "Nie udało się zmienić blokady dyspozycji.");
    } finally { setBusy(""); }
  }

  async function reviewCorrection(id: number, decision: "APPROVE" | "REJECT") {
    setBusy(`correction:${id}`);
    const response = await fetch("/api/admin/workforce", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ action: "REVIEW_CORRECTION", weekStart, id, decision }) });
    const body = await response.json().catch(() => ({})) as { error?: string };
    if (!response.ok) setError(body.error ?? "Nie udało się rozpatrzyć wniosku."); else setMessage(decision === "APPROVE" ? "Godziny zostały dopisane." : "Wniosek odrzucony.");
    await load(); setBusy("");
  }

  async function saveCalendar(event: FormEvent) {
    event.preventDefault(); setBusy("calendar");
    const response = await fetch("/api/admin/workforce", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ action: "SAVE_CALENDAR", ...calendarForm }) });
    const body = await response.json().catch(() => ({})) as { error?: string };
    if (!response.ok) setError(body.error ?? "Nie udało się połączyć kalendarza."); else setMessage(calendarForm.url ? "Kalendarz wydarzeń został połączony." : "Połączenie kalendarza usunięte.");
    await load(); setBusy("");
  }

  function openTeamCalendar(action: "subscribe" | "download") {
    if (!data?.teamCalendarUrl) return;
    window.location.href = action === "download" ? `${data.teamCalendarUrl}?download=1` : data.teamCalendarUrl.replace(/^https?:/, "webcal:");
  }

  return <main className="workforce-admin">
    <AdminSectionHeader eyebrow="Zespół i czas pracy" title="Grafik pracy" links={[{ href: "/admin/waiters", label: "Pracownicy i dostępy" }]}/>
    <section className="workforce-week-nav"><button disabled={Boolean(busy)} onClick={() => setWeekStart(addDays(weekStart, -7))}>← Poprzedni</button><div><span>TYDZIEŃ</span><strong>{polishDate.format(new Date(`${weekStart}T12:00:00Z`))} — {polishDate.format(new Date(`${addDays(weekStart, 6)}T12:00:00Z`))}</strong>{data?.schedule && <small>{data.schedule.status === "PUBLISHED" ? `Opublikowany · wersja ${data.schedule.version}` : "Szkic"}</small>}</div><button disabled={Boolean(busy)} onClick={() => setWeekStart(addDays(weekStart, 7))}>Następny →</button></section>
    {(message || error) && <p className={`workforce-status${error ? " is-error" : ""}`}>{error || message}</p>}

    <section className="workforce-panel workforce-planner workforce-planner-grid">
      <header><div><span>PLAN TYGODNIA</span><h2>Dyspozycja · grafik · faktyczny czas</h2></div><div className="workforce-planner-controls"><div className="workforce-layer-toggles" role="group" aria-label="Widoczne warstwy grafiku"><button type="button" className={visibleLayers.availability ? "is-active is-availability" : "is-availability"} aria-pressed={visibleLayers.availability} onClick={() => setVisibleLayers((current) => ({ ...current, availability: !current.availability }))}><i/>{visibleLayers.availability ? "Ukryj dyspozycje" : "Pokaż dyspozycje"}</button><button type="button" className={visibleLayers.schedule ? "is-active is-plan" : "is-plan"} aria-pressed={visibleLayers.schedule} onClick={() => setVisibleLayers((current) => ({ ...current, schedule: !current.schedule }))}><i/>{visibleLayers.schedule ? "Ukryj grafik" : "Pokaż grafik"}</button><button type="button" className={visibleLayers.actual ? "is-active is-actual" : "is-actual"} aria-pressed={visibleLayers.actual} onClick={() => setVisibleLayers((current) => ({ ...current, actual: !current.actual }))}><i/>{visibleLayers.actual ? "Ukryj godziny pracy" : "Pokaż godziny pracy"}</button></div><button type="button" className={`workforce-missing-availability-toggle${showEmployeesWithoutAvailability ? "" : " is-active"}`} aria-pressed={!showEmployeesWithoutAvailability} disabled={employeesWithoutAvailabilityCount === 0} onClick={toggleEmployeesWithoutAvailability}>{showEmployeesWithoutAvailability ? "Ukryj bez dyspozycji" : "Pokaż bez dyspozycji"} <b>{employeesWithoutAvailabilityCount}</b></button></div></header>
      <div className="workforce-availability-lock"><div><strong>{dataWeekStart !== weekStart ? "Wczytywanie dyspozycji…" : data?.schedule?.availabilityLocked ? "Dyspozycje zablokowane" : "Dyspozycje odblokowane"}</strong><span>Blokada dotyczy zmian pracowników w wybranym tygodniu. Administrator nadal może je poprawiać.</span></div><button type="button" disabled={Boolean(busy) || !data || dataWeekStart !== weekStart} onClick={() => void toggleAvailabilityLock()}>{busy === "availability-lock" ? "Zapisuję…" : data?.schedule?.availabilityLocked ? "Odblokuj zmiany dyspozycji" : "Zablokuj zmiany dyspozycji"}</button></div>
      {!data?.employees.length && <p className="workforce-empty">Brak pracowników włączonych do planowania. Zmień ustawienie „Bierze udział w grafiku” w panelu Pracownicy.</p>}
      {pendingAvailability.length > 0 && <div className="workforce-pending-availability"><strong>NOWE DYSPOZYCJE DO ROZPATRZENIA</strong><span>{pendingAvailability.map((item) => item.employeeName).join(", ")}</span><small>Dyspozycja nie zmienia opublikowanego grafiku automatycznie. Ułóż lub popraw zmiany, zapisz plan i opublikuj nową wersję.</small></div>}
      {Boolean(data?.employees.length) && displayedEmployees.length === 0 && <p className="workforce-filter-empty">Wszyscy pracownicy bez złożonej dyspozycji są ukryci. Użyj „Pokaż bez dyspozycji”, aby przywrócić pełną listę.</p>}
      <div className="workforce-schedule-table" data-visible-layers={visibleLayerCount} data-availability-summary={visibleLayers.availability ? "shown" : "hidden"}>
        <div className="is-head"><b>Pracownik</b>{dates.map((date, index) => <span key={date}>{WEEK_DAYS[index].slice(0, 3)}<small>{date.slice(8)}.{date.slice(5, 7)}</small></span>)}{visibleLayers.availability && <b>Preferencja</b>}<b>Suma tygodnia</b></div>
        {displayedEmployees.map((employee) => {
          const availability = data?.availability.find((row) => row.employeeDotykackaId === employee.dotykackaId);
          const weeklyPlannedMinutes = dates.reduce((sum, date) => sum + plannedMinutesFor(employee.dotykackaId, date), 0);
          const weeklyActualMinutes = dates.reduce((sum, date) => sum + actualMinutesFor(employee.dotykackaId, date), 0);
          return <div className="workforce-schedule-row" key={employee.dotykackaId}>
            <strong>{employee.name}{visibleLayers.availability && availability && <small className="workforce-submitted-mark">DYSP. ZŁOŻONA</small>}</strong>
            {dates.map((date) => {
              const day = availability?.days.find((item) => item.date === date);
              const shift = shifts.find((item) => item.employeeDotykackaId === employee.dotykackaId && item.workDate === date);
              const actual = actualSummary(employee.dotykackaId, date);
              const selected = selectedCell?.employeeDotykackaId === employee.dotykackaId && selectedCell.date === date;
              return <button type="button" key={date} title={visibleLayers.availability ? day?.note ?? "" : ""} className={`workforce-schedule-cell${selected ? " is-selected" : ""}`} onClick={(event) => selectCell(employee.dotykackaId, date, event.currentTarget)}>
                {visibleLayers.availability && <span className={day?.free ? "is-free" : day?.available ? "is-available" : "is-unavailable"}><small>DYSPOZYCJA</small><b>{day?.free ? "WOLNE" : day?.available ? `${day.from || "cały dzień"}${day.from && day.to ? `–${day.to}` : ""}` : availability ? "BRAK" : "nie złożono"}</b></span>}
                {visibleLayers.schedule && <span className={shift ? "is-assigned" : "is-empty"}><small>GRAFIK</small><b>{shift ? `${shift.from}–${shift.to}` : day?.free ? "brak zmiany" : "+ wybierz zmianę"}</b></span>}
                {visibleLayers.actual && <span className={actual ? "is-recorded" : "is-empty"}><small>GODZINY PRACY</small><b>{actual ? actual.range : "brak odbić"}</b>{actual && <em>{actual.duration}</em>}</span>}
                {visibleLayerCount === 0 && <span className="is-layers-empty"><b>Warstwy ukryte</b></span>}
              </button>;
            })}
            {visibleLayers.availability && <b>{availability ? <>{availability.minShifts}–{availability.maxShifts} zmian<small className="workforce-submitted-time">zapisano {polishTime.format(new Date(availability.updatedAt))}</small></> : "nie złożono"}</b>}
            <b className="workforce-row-total">{visibleLayers.schedule && <span><small>GRAFIK</small>{durationLabel(weeklyPlannedMinutes)}</span>}{visibleLayers.actual && <span><small>PRACA</small>{durationLabel(weeklyActualMinutes)}</span>}{!visibleLayers.schedule && !visibleLayers.actual && <span>—</span>}</b>
          </div>;
        })}
        <div className="workforce-schedule-totals"><strong>SUMA ZESPOŁU</strong>{dates.map((date) => <span key={date}>{visibleLayers.schedule && <span><small>GRAFIK</small><b>{durationLabel(teamPlannedMinutes(date))}</b></span>}{visibleLayers.actual && <span><small>PRACA</small><b>{durationLabel(teamActualMinutes(date))}</b></span>}{!visibleLayers.schedule && !visibleLayers.actual && "—"}</span>)}{visibleLayers.availability && <span className="is-preference">—</span>}<b>{visibleLayers.schedule && <span><small>GRAFIK</small>{durationLabel(dates.reduce((sum, date) => sum + teamPlannedMinutes(date), 0))}</span>}{visibleLayers.actual && <span><small>PRACA</small>{durationLabel(dates.reduce((sum, date) => sum + teamActualMinutes(date), 0))}</span>}{!visibleLayers.schedule && !visibleLayers.actual && <span>—</span>}</b></div>
      </div>
      {selectedCell && selectedEmployee && availabilityDraft && <Dialog open onOpenChange={(open) => { if (!open) closeCellEditor(); }}><DialogContent className="workforce-cell-dialog" overlayClassName="workforce-cell-overlay" showCloseButton={false} onCloseAutoFocus={(event) => { event.preventDefault(); cellButton.current?.focus({ preventScroll: true }); window.scrollTo(cellScroll.current.x, cellScroll.current.y); }} onEscapeKeyDown={(event) => { if (busy) event.preventDefault(); }} onInteractOutside={(event) => { if (busy) event.preventDefault(); }}><div className="workforce-cell-editor"><header><div><span>WYBRANA KRATKA</span><DialogTitle>{selectedEmployee.name} · {polishDate.format(new Date(`${selectedCell.date}T12:00:00Z`))}</DialogTitle></div><button type="button" aria-label="Zamknij edycję zmiany" disabled={Boolean(busy)} onClick={closeCellEditor}>×</button></header><DialogDescription>Wybierz zmianę lub popraw godziny. Zapis zachowa szkic całego tygodnia; publikacja grafiku pozostaje osobną czynnością.</DialogDescription>{availabilityDraft.day.free ? <p className="workforce-free-warning"><strong>WOLNE</strong> — w tym dniu nie można zaplanować zmiany.{selectedShift && <button type="button" className="is-remove" onClick={removeSelectedShift}>Usuń istniejącą zmianę</button>}</p> : <><div className="workforce-shift-presets"><button type="button" onClick={() => assignPreset("FIRST")}><b>Zmiana 1</b><span>08:30–15:30</span></button><button type="button" onClick={() => assignPreset("SECOND")}><b>Zmiana 2</b><span>15:30–{presetTimes(selectedCell.date, "SECOND").to}</span></button><button type="button" onClick={() => assignPreset("MIDDLE")}><b>Zmiana 3</b><span>11:00–19:00 · edytowalna</span></button></div>{selectedShift ? <div className="workforce-shift-editor"><label>Od<input type="time" value={selectedShift.from} onChange={(event) => updateSelectedShift({ from: event.target.value })}/></label><label>Do<input type="time" value={selectedShift.to} onChange={(event) => updateSelectedShift({ to: event.target.value })}/></label><label className="is-note">Notatka<input value={selectedShift.note} placeholder="Opcjonalnie" onChange={(event) => updateSelectedShift({ note: event.target.value })}/></label><button type="button" className="is-remove" onClick={removeSelectedShift}>Usuń zmianę</button></div> : <p>Wybierz jeden z trzech wariantów. Godziny będzie można od razu skorygować.</p>}</>}<details className="workforce-cell-availability"><summary>Popraw dyspozycję pracownika</summary><section className="workforce-admin-availability-editor"><header><div><span>DYSPOZYCJA PRACOWNIKA</span><strong>Administrator może poprawić ją niezależnie od daty</strong></div><div className="workforce-admin-availability-choice"><button type="button" aria-pressed={!availabilityDraft.day.available && !availabilityDraft.day.free} className={!availabilityDraft.day.available && !availabilityDraft.day.free ? "is-active" : ""} onClick={() => updateAvailabilityDay({ available: false, free: false, from: null, to: null })}>BRAK</button><button type="button" aria-pressed={availabilityDraft.day.available} className={availabilityDraft.day.available ? "is-active" : ""} onClick={() => updateAvailabilityDay({ available: true, free: false, from: availabilityDraft.day.from ?? "09:00", to: availabilityDraft.day.to ?? "18:00" })}>MOGĘ</button><button type="button" aria-pressed={availabilityDraft.day.free === true} className={availabilityDraft.day.free ? "is-active is-free" : "is-free"} onClick={() => updateAvailabilityDay({ available: false, free: true, from: null, to: null })}>WOLNE</button></div></header><div className="workforce-admin-availability-fields"><label>Od<input type="time" disabled={!availabilityDraft.day.available} value={availabilityDraft.day.from ?? ""} onChange={(event) => updateAvailabilityDay({ from: event.target.value })}/></label><label>Do<input type="time" disabled={!availabilityDraft.day.available} value={availabilityDraft.day.to ?? ""} onChange={(event) => updateAvailabilityDay({ to: event.target.value })}/></label><label>Minimum zmian<input type="number" min="0" max="7" value={availabilityDraft.minShifts} onChange={(event) => setAvailabilityDraft((current) => current ? { ...current, minShifts: Number(event.target.value) } : current)}/></label><label>Maksimum zmian<input type="number" min="0" max="7" value={availabilityDraft.maxShifts} onChange={(event) => setAvailabilityDraft((current) => current ? { ...current, maxShifts: Number(event.target.value) } : current)}/></label><label className="is-note">Notatka<input value={availabilityDraft.day.note ?? ""} placeholder="Opcjonalnie" onChange={(event) => updateAvailabilityDay({ note: event.target.value })}/></label><button type="button" className="is-save" disabled={Boolean(busy)} onClick={() => void saveEmployeeAvailability()}>{busy === "availability" ? "Zapisuję…" : "Zapisz dyspozycję"}</button></div></section></details>{error && <p role="alert" className="workforce-status is-error">{error}</p>}{message && !error && <p role="status">{message}</p>}<footer className="workforce-cell-actions"><button type="button" disabled={Boolean(busy)} onClick={closeCellEditor}>Anuluj</button><button type="button" className="is-save" disabled={Boolean(busy)} onClick={() => void savePlan(false)}>{busy === "save" ? "Zapisuję…" : "Zapisz zmianę w szkicu"}</button></footer></div></DialogContent></Dialog>}
      <footer><button disabled={Boolean(busy)} onClick={() => void savePlan(false)}>Zapisz szkic</button><button className="is-primary" disabled={Boolean(busy) || !shifts.length} onClick={() => void savePlan(true)}>{busy === "publish" ? "Publikuję…" : data?.schedule?.status === "PUBLISHED" ? "Opublikuj aktualizację" : "Opublikuj grafik"}</button></footer>
    </section>

    <section className="workforce-admin-grid workforce-context-grid">
      <article className="workforce-panel workforce-context"><header><div><span>GODZINY KAWIARNI</span><h2>Standard tygodnia i kontekst dnia</h2></div><button type="button" onClick={() => setOpenings(standardOpenings(weekStart))}>Przywróć standard</button></header><div className="workforce-opening-list">{openings.map((opening, index) => <div key={opening.date}><b>{WEEK_DAYS[index]}</b><label><input type="checkbox" checked={opening.closed} onChange={(event) => updateOpening(index, { closed: event.target.checked })}/> zamknięte</label><input type="time" disabled={opening.closed} value={opening.from ?? ""} onChange={(event) => updateOpening(index, { from: event.target.value })}/><span>—</span><input type="time" disabled={opening.closed} value={opening.to ?? ""} onChange={(event) => updateOpening(index, { to: event.target.value })}/></div>)}</div><div className="workforce-events workforce-reservation-context"><h3>Rezerwacje w tym tygodniu</h3>{data?.reservations.map((reservation) => <div key={reservation.id}><time>{polishDate.format(new Date(reservation.startsAt))} · {polishTime.format(new Date(reservation.startsAt))}–{polishTime.format(new Date(reservation.endsAt))}</time><strong>{reservation.guestName || "Rezerwacja bez nazwy"}{reservation.partySize !== null ? ` · ${reservation.partySize} os.` : ""}</strong><span>{[reservation.location, reservation.specialRequest].filter(Boolean).join(" · ") || "Brak dodatkowych informacji"}</span></div>)}{!data?.reservations.length && <p>Brak rezerwacji w tym tygodniu.</p>}</div><div className="workforce-events"><h3>Wydarzenia · tylko dla administratora</h3>{data?.events.map((event) => <div key={event.uid}><time>{polishDate.format(new Date(event.startsAt))}{!event.allDay && ` · ${polishTime.format(new Date(event.startsAt))}`}</time><strong>{event.title}</strong><span>Wymagane minimum 2 osoby na zmianie.</span></div>)}{!data?.events.length && <p>{data?.calendar.connected ? data.calendar.error || "Brak wydarzeń w tym tygodniu." : "Połącz współdzielony kalendarz poniżej."}</p>}</div></article>
      <article className="workforce-panel"><header><div><span>KONTROLA CZASU</span><h2>Miesięczne godziny</h2></div></header><div className="workforce-hours-list">{data?.settlementEmployees.map((employee) => <div key={employee.dotykackaId}><strong>{employee.name}{!employee.includeInSchedule && <small> · poza grafikiem</small>}</strong><b>{durationLabel(monthly.get(employee.dotykackaId) ?? 0)}</b></div>)}</div></article>
    </section>
    <section className="workforce-panel workforce-calendar-standalone workforce-team-calendar"><header><div><span>KALENDARZ ADMINISTRATORA</span><h2>Plan zespołu, odbicia kart i MANAGER Ola</h2></div></header><p>Subskrypcja pokazuje każdą opublikowaną zmianę jako „PLAN”, a każde odbicie czytnika jako osobny punkt „WEJŚCIE” albo „WYJŚCIE” z dokładną godziną i nazwiskiem. Dodatkowo pokazuje wpisy „MANAGER Ola” z prywatnego planu managerki, w tym urlop i zwolnienie. Kalendarz jest prywatny — nie udostępniaj jego adresu.</p><div className="workforce-team-calendar-actions"><button type="button" onClick={() => openTeamCalendar("download")}>Pobierz plik .ics</button><button type="button" className="is-primary" onClick={() => openTeamCalendar("subscribe")}>Dodaj kalendarz zespołu</button></div><small>Po dodaniu kalendarz aktualizuje się automatycznie. Częstotliwość odświeżania wybiera telefon, dlatego nowe odbicie może pojawić się z opóźnieniem.</small></section>
    <section className="workforce-admin-grid">
      <article className="workforce-panel"><header><div><span>WYMAGA DECYZJI</span><h2>Wnioski o dopisanie godzin</h2></div><b>{data?.corrections.length ?? 0}</b></header><div className="workforce-corrections">{data?.corrections.map((request) => <div key={request.id}><strong>{request.employeeName}</strong><span>{request.workDate} · {polishTime.format(new Date(request.requestedStart))}–{polishTime.format(new Date(request.requestedEnd))}</span><p>{request.reason}</p><footer><button disabled={Boolean(busy)} onClick={() => void reviewCorrection(request.id, "REJECT")}>Odrzuć</button><button disabled={Boolean(busy)} onClick={() => void reviewCorrection(request.id, "APPROVE")}>Zatwierdź i dopisz</button></footer></div>)}{!data?.corrections.length && <p>Brak wniosków oczekujących.</p>}</div></article>
      <article className="workforce-panel workforce-calendar-config"><header><div><span>PLANOWANE WYDARZENIA</span><h2>Współdzielony kalendarz</h2></div></header><p>Wklej prywatny adres subskrypcji iCal/ICS. Adres jest szyfrowany, wydarzenia widzi wyłącznie administrator podczas planowania.</p><form onSubmit={saveCalendar}><label>Nazwa<input value={calendarForm.name} onChange={(event) => setCalendarForm({ ...calendarForm, name: event.target.value })}/></label><label>Adres ICS<input type="url" value={calendarForm.url} placeholder={data?.calendar.connected ? "Połączono — wklej adres tylko, aby go zmienić" : "https://…/calendar.ics"} onChange={(event) => setCalendarForm({ ...calendarForm, url: event.target.value })}/></label><button disabled={Boolean(busy)}>Zapisz połączenie</button></form></article>
    </section>
  </main>;
}
