import { redirect } from "next/navigation";
export default function WorkforceKioskPage(){redirect("/kiosk")}
