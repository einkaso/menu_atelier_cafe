import { isAdmin } from "../../../lib/admin-auth";
import AdminLogin from "../admin-login";
import HeatingAdminClient from "./heating-admin-client";
import "./heating-admin.css";

export const dynamic = "force-dynamic";

export default async function HeatingAdminPage() {
  let authenticated = false;
  try { authenticated = await isAdmin(); } catch { authenticated = false; }
  return authenticated ? <HeatingAdminClient/> : <AdminLogin/>;
}
