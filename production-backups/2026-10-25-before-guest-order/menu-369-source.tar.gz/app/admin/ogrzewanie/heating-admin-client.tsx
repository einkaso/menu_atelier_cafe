"use client";

import { useCallback, useEffect, useState } from "react";
import AdminSectionHeader from "../admin-section-header";

type HeatingModule = { id: string; name: string; type: string; reachable: boolean; batteryState: string | null; signal: number | null };
type HeatingRoom = { id: string; name: string; type: string | null; reachable: boolean; temperature: number | null; targetTemperature: number | null; mode: string; heatingPower: number | null; openWindow: boolean; anticipating: boolean; setpointEndsAt: string | null; modules: HeatingModule[] };
type HeatingHome = { id: string; name: string; timezone: string | null; mode: "schedule" | "away" | "hg"; boilerOn: boolean; defaultSetpointMinutes: number; defaultBoostMinutes: number; rooms: HeatingRoom[]; observedAt: string };
type NetatmoStatus = {
  credentialsConfigured: boolean; connected: boolean; redirectUri?: string | null; scopes?: string[];
  connectedBy?: string; connectedAt?: string; homes?: HeatingHome[]; heatingError?: string | null; error?: string;
};

const modeLabels: Record<string, string> = { schedule: "Harmonogram", home: "Harmonogram", manual: "Ręcznie", max: "Boost", away: "Poza lokalem", hg: "Przeciwzamrożeniowy", off: "Wyłączone" };
const batteryLabels: Record<string, string> = { full: "pełna", high: "wysoka", medium: "średnia", low: "niska", very_low: "bardzo niska" };
const durationOptions = [30, 60, 120, 240, 480, 720, 1440] as const;

function dateTime(value?: string) {
  return value ? new Intl.DateTimeFormat("pl-PL", { dateStyle: "medium", timeStyle: "short" }).format(new Date(value)) : "—";
}

function temperature(value: number | null) {
  return value === null ? "—" : `${value.toLocaleString("pl-PL", { minimumFractionDigits: 1, maximumFractionDigits: 1 })}°C`;
}

function durationLabel(minutes: number) {
  if (minutes < 60) return `${minutes} min`;
  if (minutes === 1440) return "24 godziny";
  return `${minutes / 60} godz.`;
}

function moduleLabel(type: string) {
  if (type === "NRV") return "Głowica grzejnikowa";
  if (type === "NATherm1") return "Termostat";
  if (type === "NAPlug") return "Przekaźnik kotła";
  return type || "Urządzenie Netatmo";
}

function roomKey(home: HeatingHome, room: HeatingRoom) {
  return `${home.id}:${room.id}`;
}

export default function HeatingAdminClient() {
  const [status, setStatus] = useState<NetatmoStatus | null>(null);
  const [drafts, setDrafts] = useState<Record<string, number>>({});
  const [durations, setDurations] = useState<Record<string, number>>({});
  const [busy, setBusy] = useState("");
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");

  const load = useCallback(async () => {
    const response = await fetch("/api/admin/netatmo", { cache: "no-store" }).catch(() => null);
    const body = await response?.json().catch(() => ({})) as NetatmoStatus | undefined;
    if (!response?.ok) { setError(body?.error ?? "Nie udało się odczytać Netatmo."); return; }
    setStatus(body ?? null);
    setError(body?.heatingError ?? "");
  }, []);

  useEffect(() => {
    const initial = window.setTimeout(() => {
      const parameters = new URLSearchParams(window.location.search);
      if (parameters.get("connected")) setMessage("Konto połączone. Poniżej widać pomieszczenia, temperatury i przypisane urządzenia.");
      const failure = parameters.get("error");
      if (failure === "config") setError("Najpierw zapisz dane aplikacji Netatmo na serwerze.");
      else if (failure === "denied") setError("Połączenie zostało anulowane na stronie Netatmo.");
      else if (failure === "invalid") setError("Sesja łączenia wygasła. Rozpocznij połączenie ponownie.");
      else if (failure === "failed") setError("Netatmo nie przyjęło połączenia. Sprawdź adres przekierowania i dane aplikacji.");
      void load();
    }, 0);
    const interval = window.setInterval(() => { if (document.visibilityState === "visible") void load(); }, 30_000);
    const focus = () => void load();
    window.addEventListener("focus", focus);
    return () => { window.clearTimeout(initial); window.clearInterval(interval); window.removeEventListener("focus", focus); };
  }, [load]);

  async function command(home: HeatingHome, payload: Record<string, unknown>, key: string) {
    setBusy(key); setError(""); setMessage("");
    const response = await fetch("/api/admin/netatmo", {
      method: "PATCH", headers: { "content-type": "application/json" }, body: JSON.stringify({ homeId: home.id, ...payload }),
    }).catch(() => null);
    const body = await response?.json().catch(() => ({})) as { home?: HeatingHome; error?: string } | undefined;
    if (!response?.ok) setError(body?.error ?? "Nie udało się wysłać ustawienia do Netatmo.");
    else if (body?.home) {
      setStatus((current) => current ? { ...current, homes: current.homes?.map((item) => item.id === body.home?.id ? body.home : item) } : current);
      setMessage("Ustawienie zostało przyjęte przez Netatmo.");
    }
    setBusy("");
  }

  function draft(home: HeatingHome, room: HeatingRoom) {
    return drafts[roomKey(home, room)] ?? room.targetTemperature ?? 20;
  }

  function selectedDuration(home: HeatingHome, room: HeatingRoom) {
    return durations[roomKey(home, room)] ?? home.defaultSetpointMinutes ?? 120;
  }

  function changeDraft(home: HeatingHome, room: HeatingRoom, delta: number) {
    const key = roomKey(home, room);
    setDrafts((current) => ({ ...current, [key]: Math.max(7, Math.min(30, Math.round((draft(home, room) + delta) * 2) / 2)) }));
  }

  return <main className="heating-admin-page">
    <AdminSectionHeader eyebrow="Komfort lokalu" title="OGRZEWANIE" links={[{ href: "/admin/waiters", label: "Uprawnienia pracowników" }]}/>
    <section className="heating-admin-hero"><div><span>NETATMO · TERMOSTAT I GŁOWICE</span><h2>Temperatura w pomieszczeniach</h2><p>Każda karta odpowiada pomieszczeniu z Netatmo i pokazuje przypisane głowice, temperaturę oraz czas ręcznego ustawienia.</p></div><div className="heating-admin-hero-actions"><b data-connected={status?.connected ? "true" : "false"}>{status?.connected ? "POŁĄCZONO" : "NIEPOŁĄCZONE"}</b><button type="button" onClick={() => void load()}>Odśwież</button></div></section>
    {message && <p className="heating-admin-message is-success">{message}</p>}
    {error && <p className="heating-admin-message is-error" role="alert">{error}</p>}
    {!status && !error && <section className="heating-admin-card heating-admin-loading"><strong>Odczytuję pomieszczenia i temperatury…</strong></section>}
    {status?.connected && status.homes?.length === 0 && !status.heatingError && <section className="heating-admin-card heating-admin-loading"><strong>Netatmo nie zwróciło żadnego domu ani pomieszczenia.</strong><p>Sprawdź, czy połączone konto ma dostęp do Smart Thermostat.</p></section>}

    {status?.homes?.map((home) => <section className="heating-admin-home" key={home.id}>
      <header><div><span>{home.boilerOn ? "KOCIOŁ TERAZ GRZEJE" : "KOCIOŁ W GOTOWOŚCI"}</span><h2>{home.name}</h2><p>Tryb lokalu: <b>{modeLabels[home.mode] ?? home.mode}</b></p></div><nav><button className={home.mode === "schedule" ? "is-active" : ""} disabled={busy === `${home.id}:home`} onClick={() => void command(home, { action: "home", mode: "schedule" }, `${home.id}:home`)}>Harmonogram</button><button className={home.mode === "away" ? "is-active" : ""} disabled={busy === `${home.id}:home`} onClick={() => void command(home, { action: "home", mode: "away", durationMinutes: 1440 }, `${home.id}:home`)}>Poza lokalem · 24 h</button><button className={home.mode === "hg" ? "is-active" : ""} disabled={busy === `${home.id}:home`} onClick={() => void command(home, { action: "home", mode: "hg", durationMinutes: 1440 }, `${home.id}:home`)}>Ochrona 7°C · 24 h</button></nav></header>
      <div className="heating-admin-room-grid">{home.rooms.map((room) => {
        const key = roomKey(home, room);
        const target = draft(home, room);
        const minutes = selectedDuration(home, room);
        const roomBusy = busy === key;
        return <article className={`heating-admin-room${room.heatingPower && room.heatingPower > 0 ? " is-heating" : ""}${room.reachable ? "" : " is-offline"}`} key={room.id}>
          <header><div><span>{room.reachable ? room.heatingPower && room.heatingPower > 0 ? `GRZANIE ${room.heatingPower}%` : "ONLINE" : "BRAK ŁĄCZNOŚCI"}</span><h3>{room.name}</h3></div><b>{modeLabels[room.mode] ?? room.mode}</b></header>
          {room.openWindow && <p className="heating-admin-window">Wykryto otwarte okno — ogrzewanie może być czasowo wstrzymane.</p>}
          <div className="heating-admin-readings"><div><span>Aktualna temperatura</span><strong>{temperature(room.temperature)}</strong></div><div><span>Teraz zadana</span><strong>{temperature(room.targetTemperature)}</strong></div></div>
          <section className="heating-admin-devices"><span>Urządzenia przypisane do tego pomieszczenia</span>{room.modules.length ? room.modules.map((module) => <div key={module.id}><i className={module.reachable ? "is-online" : ""}/><p><b>{module.name}</b><small>{moduleLabel(module.type)} · {module.reachable ? "online" : "offline"}{module.batteryState ? ` · bateria ${batteryLabels[module.batteryState] ?? module.batteryState}` : ""}</small></p></div>) : <p className="is-empty">Brak urządzeń przypisanych w Netatmo.</p>}</section>
          <section className="heating-admin-setpoint"><span>Ustaw temperaturę</span><div className="heating-admin-temperature"><button type="button" aria-label="Zmniejsz temperaturę" disabled={!room.reachable || roomBusy || target <= 7} onClick={() => changeDraft(home, room, -0.5)}>−</button><strong>{temperature(target)}</strong><button type="button" aria-label="Zwiększ temperaturę" disabled={!room.reachable || roomBusy || target >= 30} onClick={() => changeDraft(home, room, 0.5)}>+</button></div><label><span>Na jaki czas</span><select value={minutes} disabled={roomBusy} onChange={(event) => setDurations((current) => ({ ...current, [key]: Number(event.target.value) }))}>{durationOptions.map((value) => <option value={value} key={value}>{durationLabel(value)}</option>)}</select></label><button type="button" className="is-apply" disabled={!room.reachable || roomBusy} onClick={() => void command(home, { action: "room", roomId: room.id, mode: "manual", temperature: target, durationMinutes: minutes }, key)}>Ustaw {temperature(target)} na {durationLabel(minutes)}</button></section>
          <div className="heating-admin-room-actions"><button type="button" disabled={!room.reachable || roomBusy} onClick={() => void command(home, { action: "room", roomId: room.id, mode: "home" }, key)}>Wróć do harmonogramu</button><button type="button" className="is-boost" disabled={!room.reachable || roomBusy} onClick={() => void command(home, { action: "room", roomId: room.id, mode: "max", durationMinutes: minutes }, key)}>Boost na {durationLabel(minutes)}</button></div>
          <footer>{room.setpointEndsAt ? <span>Ręczne ustawienie obowiązuje do <b>{dateTime(room.setpointEndsAt)}</b></span> : <span>Temperatura według harmonogramu</span>}{roomBusy && <span>Wysyłam do Netatmo…</span>}</footer>
        </article>;
      })}</div>
    </section>)}

    {status && <details className="heating-admin-technical" open={!status.connected}><summary>Połączenie techniczne Netatmo</summary><section className="heating-admin-grid">
      <article className="heating-admin-card"><span>KROK 1</span><h3>Aplikacja Netatmo</h3>{status.credentialsConfigured ? <><strong className="is-ready">Dane serwerowe zapisane</strong><p>Client ID, Client Secret i klucz szyfrowania są zapisane po stronie serwera.</p></> : <><strong>Wymaga konfiguracji</strong><p>Zapisz dane aplikacji Netatmo na serwerze.</p></>}{status.redirectUri && <label>Callback URL<code>{status.redirectUri}</code></label>}</article>
      <article className="heating-admin-card"><span>KROK 2</span><h3>Konto Netatmo</h3>{status.connected ? <><strong className="is-ready">Konto połączone</strong><dl><div><dt>Połączył</dt><dd>{status.connectedBy ?? "—"}</dd></div><div><dt>Data</dt><dd>{dateTime(status.connectedAt)}</dd></div></dl><a className="admin-secondary" href="/api/admin/netatmo/connect">Połącz ponownie</a></> : <><p>Netatmo poprosi o zgodę na odczyt i sterowanie ogrzewaniem.</p><a className={`admin-primary${status.credentialsConfigured ? "" : " is-disabled"}`} aria-disabled={!status.credentialsConfigured} href={status.credentialsConfigured ? "/api/admin/netatmo/connect" : undefined}>Połącz konto Netatmo</a></>}</article>
    </section></details>}
  </main>;
}
