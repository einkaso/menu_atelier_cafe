import { isAdmin } from "../../../lib/admin-auth";
import AdminLogin from "../admin-login";
import ColdStorageClient from "../../kelner/chlodnie/cold-storage-client";
import "../../kelner/chlodnie/cold-storage.css";

export const dynamic = "force-dynamic";

export default async function TemperaturesAdminPage() {
  const authenticated = await isAdmin().catch(() => false);
  return authenticated ? <ColdStorageClient admin/> : <AdminLogin/>;
}
