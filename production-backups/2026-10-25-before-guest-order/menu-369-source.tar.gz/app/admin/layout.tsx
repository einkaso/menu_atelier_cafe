import type { Metadata } from "next";
import { cookies } from "next/headers";
import { currentAdmin } from "../../lib/admin-auth";
import AtelierShell from "./atelier-shell";
import "./admin.css";
import "./cash-day-admin.css";
import "./instructions/instructions.css";
import "./instructions/attachments.css";
import "./workforce/workforce.css";
import "./reservations/reservations.css";
import "./new-modules-tablet.css";
import "./waiters/employee-qr.css";
import "./unified-header.css";
import "./lighting/lighting.css";
import "./lighting/scenes.css";
import "./rooms/rooms.css";
import "./zdjecia-do-przypisania/photo-review.css";
import "../../components/kitchen/kitchen.css";

export const metadata: Metadata = {
  title: "Panel menu — Banaszek Café",
  robots: { index: false, follow: false },
};

import "./atelier-admin.css";

export default async function AdminLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  const administrator = await currentAdmin().catch(() => null);
  const enabled =
    process.env.ADMIN_WORKSPACE_ENABLED !== "false" &&
    (await cookies()).get("mb_admin_appearance")?.value !== "legacy";
  return (
    <AtelierShell
      enabled={enabled}
      administrator={
        administrator
          ? (administrator.employeeName ?? administrator.username)
          : null
      }
    >
      {children}
    </AtelierShell>
  );
}
