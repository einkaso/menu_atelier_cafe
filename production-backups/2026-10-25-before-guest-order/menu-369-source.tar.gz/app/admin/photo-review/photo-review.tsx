"use client";
import { useEffect, useState } from "react";
import "./photo-review.css";
type Photo = { id: string; name: string; source: string; label?: string; category?: string; candidates: number[] };
type Product = { id: number; name: string; category: string; hasImage: boolean };
type Data = { photos: Photo[]; products: Product[]; total: number };
export default function PhotoReview() {
  const [data, setData] = useState<Data | null>(null), [error, setError] = useState(""), [message, setMessage] = useState("");
  const [category, setCategory] = useState(""), [query, setQuery] = useState(""), [missing, setMissing] = useState(true), [source, setSource] = useState("");
  const [chosen, setChosen] = useState<Record<string, string>>({}), [busy, setBusy] = useState(""), [zoom, setZoom] = useState<Photo | null>(null);
  const [uploadProgress, setUploadProgress] = useState("");
  async function load() {
    try { const r = await fetch("/api/admin/photo-review", { cache: "no-store" }); const d = await r.json(); if (!r.ok) throw Error(d.error || "Nie udało się pobrać zdjęć."); setData(d); setError(""); }
    catch (e) { setError(e instanceof Error ? e.message : "Błąd połączenia."); }
  }
  useEffect(() => { void load(); }, []);
  async function assign(photo: Photo) {
    if (busy || !chosen[photo.id]) return;
    setBusy(photo.id); setError(""); setMessage("");
    try {
      const response = await fetch(`/api/admin/photo-review/${photo.id}`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ productId: Number(chosen[photo.id]) }) });
      const result = await response.json(); if (!response.ok) throw Error(result.error);
      setData(current => current ? { ...current, photos: current.photos.filter(p => p.id !== photo.id), products: current.products.map(p => p.id === Number(chosen[photo.id]) ? { ...p, hasImage: true } : p) } : current);
      setMessage(`Zapisano zdjęcie: ${result.product}.`);
    } catch (e) { setError(e instanceof Error ? e.message : "Nie udało się zapisać."); }
    finally { setBusy(""); }
  }
  async function upload(files: File[]) {
    if (busy || !files.length) return;
    setBusy("upload"); setError(""); setMessage("");
    let added = 0, duplicates = 0;
    const failures: string[] = [];
    try {
      for (let i = 0; i < files.length; i++) {
        const file = files[i]; setUploadProgress(`Wgrywanie ${i + 1} z ${files.length}: ${file.name}`);
        try {
          if (file.size > 50 * 1024 * 1024) throw Error("Limit wynosi 50 MB.");
          const form = new FormData(); form.append("image", file);
          const response = await fetch("/api/admin/photo-review", { method: "POST", body: form });
          const result = await response.json().catch(() => ({}));
          if (!response.ok) throw Error(result.error || "Nie udało się wgrać zdjęcia.");
          if(result.duplicate) duplicates++; else added++;
        } catch(e) { failures.push(`${file.name}: ${e instanceof Error ? e.message : "Błąd połączenia."}`); }
      }
      if (added || duplicates) { setSource(""); setMissing(false); setCategory(""); setQuery(""); await load(); }
      setMessage(`Dodano nowych zdjęć: ${added}.${duplicates ? ` Pominięto już zapisane pliki: ${duplicates}.` : ""}${added ? " Wybierz produkt pod zdjęciem i zatwierdź przypisanie." : ""}`);
      if (failures.length) setError(failures.join("\n"));
    } finally { setBusy(""); setUploadProgress(""); }
  }
  const norm = (s: string) => s.toLocaleLowerCase("pl").normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  const products = (data?.products ?? []).filter(p => (!category || p.category === category) && (!missing || !p.hasImage) && norm(p.name).includes(norm(query))).sort((a,b) => a.name.localeCompare(b.name,"pl"));
  const photos = (data?.photos ?? []).filter(p => !source || p.source === source);
  return <main className="recovered-review">
    <a href="/admin">← Panel administratora</a>
    <h1>Zdjęcia produktów</h1>
    <p>Pokazujemy wyłącznie zdjęcia bez przypisania. Wybierz produkt pod zdjęciem i kliknij „Zatwierdź i przypisz”. Zapis trafi od razu do bazy i menu. Jeśli produkt ma już zdjęcie główne, nowe zdjęcie zostanie dodane do galerii.</p>
    <section className="photo-upload" aria-label="Dodawanie zdjęć">
      <label>Dodaj zdjęcia z komputera<input type="file" multiple disabled={Boolean(busy)} accept="image/jpeg,image/png,image/webp,image/avif,image/heic,image/heif,.jpg,.jpeg,.png,.webp,.avif,.heic,.heif" onChange={e => { const files = Array.from(e.target.files ?? []); e.target.value = ""; void upload(files); }}/></label>
      <p>Wybierz jedno lub kilka zdjęć. JPG, PNG, WebP, AVIF, HEIC i HEIF — do 50 MB na plik. Zdjęcia zostaną zapisane na liście do przypisania, również po zamknięciu strony.</p>
      {uploadProgress && <p role="status">{uploadProgress}</p>}
    </section>
    <div className="photo-review-filters">
      <label>Kategoria produktów<select value={category} onChange={e => setCategory(e.target.value)}><option value="">Wszystkie kategorie</option>{[...new Set((data?.products ?? []).map(p => p.category))].sort((a,b)=>a.localeCompare(b,"pl")).map(c => <option key={c}>{c}</option>)}</select></label>
      <label>Szukaj produktu<input type="search" placeholder="Nazwa dania lub napoju" value={query} onChange={e => setQuery(e.target.value)}/></label>
      <label className="check"><input type="checkbox" checked={missing} onChange={e => setMissing(e.target.checked)}/>Tylko produkty bez zdjęcia</label>
      <label>Źródło zdjęć<select value={source} onChange={e => setSource(e.target.value)}><option value="">Wszystkie zdjęcia</option><option value="computer-uploads">Dodane z komputera</option><option value="local-uploads">Zdjęcia dodane 7 października</option><option value="professional-archive">Wcześniejsza sesja fotograficzna</option></select></label>
      <button disabled={Boolean(busy)} onClick={() => void load()}>Odśwież</button>
    </div>
    {error && <p role="alert" className="photo-error">{error}</p>}{message && <p role="status" className="photo-success">{message}</p>}
    {!data ? <p>Wczytywanie zdjęć…</p> : <>
      <p><strong>{data.photos.length} zdjęć bez przypisania</strong> z {data.total} zapisanych · {products.length} produktów pasuje do filtrów.</p>
      <details><summary>Produkty pasujące do filtrów ({products.length})</summary><div className="missing-product-list">{products.map(p => <span key={p.id}>{p.name} · {p.hasImage ? "ma zdjęcie" : "brak zdjęcia"}</span>)}</div></details>
      <div className="recovered-grid">{photos.map((photo, index) => {
        const selected = data.products.find(p => String(p.id) === chosen[photo.id]);
        const options = [...products]; if (selected && !options.some(p => p.id === selected.id)) options.unshift(selected);
        const suggestions = products.filter(p => photo.candidates.includes(p.id));
        return <article key={photo.id}>
          <button className="photo-preview" onClick={() => setZoom(photo)} aria-label={`Powiększ ${photo.name}`}><img loading="lazy" src={`/api/admin/photo-review/${photo.id}`} alt={photo.label || photo.name}/></button>
          <div className="photo-body"><small>{index + 1}. {photo.name}</small><h2>{photo.label || "Wybierz pasujący produkt"}</h2>
            {suggestions.length > 0 && <div className="photo-suggestions"><span>Podpowiedzi do sprawdzenia:</span>{suggestions.map(p => <button key={p.id} onClick={() => setChosen(c => ({ ...c, [photo.id]: String(p.id) }))}>{p.name}</button>)}</div>}
            <label>Produkt<select aria-label={`Produkt dla ${photo.name}`} value={chosen[photo.id] || ""} onChange={e => setChosen(c => ({ ...c, [photo.id]: e.target.value }))}><option value="">Wybierz produkt…</option>{options.map(p => <option key={p.id} value={p.id}>{p.name} · {p.hasImage ? "ma zdjęcie" : "brak zdjęcia"}</option>)}</select></label>
            {selected && !products.some(p => p.id === selected.id) && <small>Wybrany produkt jest poza aktualnym filtrem.</small>}
            <button className="photo-save" disabled={Boolean(busy) || !selected} onClick={() => void assign(photo)}>{busy === photo.id ? "Zapisywanie…" : "Zatwierdź i przypisz"}</button>
          </div>
        </article>;
      })}</div>{!photos.length && <p>Brak nieprzypisanych zdjęć dla wybranego źródła.</p>}
    </>}
    {zoom && <div className="photo-zoom" role="dialog" aria-modal="true" aria-label="Podgląd zdjęcia" onClick={() => setZoom(null)}><button autoFocus onClick={() => setZoom(null)} onKeyDown={e => { if(e.key === "Escape")setZoom(null); }}>Zamknij podgląd</button><img src={`/api/admin/photo-review/${zoom.id}`} alt={zoom.label || zoom.name}/></div>}
  </main>;
}
