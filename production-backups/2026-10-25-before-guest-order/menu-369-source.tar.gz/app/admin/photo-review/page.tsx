import { isAdmin } from "../../../lib/admin-auth";
import AdminLogin from "../admin-login";
import PhotoReview from "./photo-review";
export const dynamic = "force-dynamic";
export default async function Page() { return await isAdmin() ? <PhotoReview/> : <AdminLogin/>; }
