"use client";
import { useState, useEffect, useCallback } from "react";
import {
  ArrowUpRight,
  CalendarDays,
  ChevronLeft,
  ChevronRight,
  Check,
  Clock3,
  Flower2,
  Leaf,
  Plus,
  Sparkles,
  X,
  BookOpen,
  Bell,
  CheckCircle2,
} from "lucide-react";
import AdminSectionHeader from "../admin-section-header";
import {
  milestones,
  plusDays,
  ruleLabel,
  todayWarsaw,
} from "../../../lib/gastro/core";
import type { calendarData } from "../../../lib/gastro/service";
import "./gastro-calendar.css";
import DailySlogan from "./daily-slogan";
type Data = Awaited<ReturnType<typeof calendarData>>;
type Event = Data["occurrences"][number];
type Plan = {
  objective: string;
  offer: string;
  owner: string;
  budget: string;
  channels: string;
  notes: string;
  lateReason: string;
};
type Stage = {
  id?: number;
  title: string;
  due_date: string;
  owner: string;
  status?: string;
  completion_note?: string;
};
const months = [
  "Styczeń",
  "Luty",
  "Marzec",
  "Kwiecień",
  "Maj",
  "Czerwiec",
  "Lipiec",
  "Sierpień",
  "Wrzesień",
  "Październik",
  "Listopad",
  "Grudzień",
];
const categories: Record<string, string> = {
  coffee: "Kawa i herbata",
  sweet: "Słodkie chwile",
  food: "Smaki i kuchnia",
  culture: "Tradycja i kultura",
  family: "Blisko ludzi",
  drinks: "Napoje i degustacje",
  season: "Sezon i wydarzenia",
};
const decisions: Record<string, string> = {
  UNDECIDED: "Do decyzji",
  CELEBRATE: "Obchodzimy",
  SKIP: "Pomijamy",
  LATER: "Wrócimy później",
};
const fmt = (d: string | null) =>
  d
    ? new Intl.DateTimeFormat("pl-PL", {
        day: "numeric",
        month: "long",
      }).format(new Date(d + "T12:00:00"))
    : "Potwierdź termin";
const state = (e: Event) => e.state?.decision || "UNDECIDED";
export default function GastroCalendar() {
  const now = todayWarsaw();
  const [year, setYear] = useState(Number(now.slice(0, 4))),
    [month, setMonth] = useState(Number(now.slice(5, 7)) - 1);
  const [data, setData] = useState<Data | null>(null),
    [error, setError] = useState(""),
    [loading, setLoading] = useState(true),
    [selected, setSelected] = useState<string | null>(null),
    [view, setView] = useState("month"),
    [category, setCategory] = useState(""),
    [decision, setDecision] = useState(""),
    [search, setSearch] = useState(""),
    [sources, setSources] = useState(false),
    [queue, setQueue] = useState(false),
    [detailTab, setDetailTab] = useState("idea");
  const load = useCallback(async () => {
    setLoading(true);
    try {
      const r = await fetch(`/api/admin/gastro-calendar?year=${year}`, {
        cache: "no-store",
      });
      const d = await r.json();
      if (!r.ok) throw Error(d.error);
      setData(d);
      setError("");
    } catch (e) {
      setError(
        e instanceof Error ? e.message : "Nie udało się wczytać kalendarza.",
      );
    } finally {
      setLoading(false);
    }
  }, [year]);
  useEffect(() => {
    void load();
  }, [load]);
  useEffect(() => {
    if (window.matchMedia("(max-width: 700px)").matches) setView("list");
  }, []);
  useEffect(() => {
    const q = new URLSearchParams(window.location.search); const y = Number(q.get("year"));
    if (q.get("year") && y >= 2025 && y <= 2199) setYear(y);
    if (q.get("event")) { setSelected(q.get("event")); setDetailTab("idea"); }
  }, []);
  const active = data?.year === year ? data : null;
  const events = (active?.occurrences || []).filter(
    (e) =>
      (!category || e.category === category) &&
      (!decision || state(e) === decision) &&
      (!search ||
        e.title
          .toLocaleLowerCase("pl")
          .includes(search.toLocaleLowerCase("pl"))),
  );
  const monthly = events.filter((e) =>
    e.date
      ? Number(e.date.slice(5, 7)) === month + 1
      : e.rule.type === "manual" && e.rule.month === month + 1,
  );
  const selectedEvent = active?.occurrences.find((e) => e.id === selected);
  const move = (n: number) => {
    if (view === "year") {
      setYear(Math.min(2199, Math.max(2025, year + n)));
      return;
    }
    const d = new Date(year, month + n, 1);
    if (d.getFullYear() < 2025 || d.getFullYear() > 2199) return;
    setMonth(d.getMonth());
    setYear(d.getFullYear());
  };
  const openNotice = (n: Data["notices"][number]) => {
    setYear(n.year);
    setSelected(n.eventId);
    setDetailTab(
      n.kind === "plan" || n.kind.startsWith("task:") ? "plan" : "idea",
    );
    setQueue(false);
  };
  const start = (new Date(year, month, 1).getDay() + 6) % 7,
    days = new Date(year, month + 1, 0).getDate();
  const celebrate =
      active?.occurrences.filter((e) => state(e) === "CELEBRATE").length || 0,
    approved =
      active?.occurrences.filter(
        (e) => e.state?.plan_approved_at && state(e) === "CELEBRATE",
      ).length || 0;
  return (
    <main className="gastro">
      <AdminSectionHeader
        eyebrow="Marta Banaszek · atelier-café"
        title="Kalendarz gastronomiczny"
      />
      <section className="gc-hero">
        <div className="gc-hero-copy">
          <DailySlogan />
          <div className="gc-hero-actions">
            <button className="gc-light" onClick={() => setQueue(!queue)}>
              <Bell size={16} /> Centrum przygotowań{" "}
              <b>{active?.notices.length || 0}</b>
            </button>
            <button
              className="gc-text-light"
              onClick={() => setSources(!sources)}
            >
              <BookOpen size={16} /> Materiały i zasady{" "}
              <ArrowUpRight size={14} />
            </button>
          </div>
        </div>
        <div className="gc-hero-art" aria-hidden="true">
          <div className="gc-orbit" />
          <Flower2 size={180} strokeWidth={0.6} />
          <span>
            małe okazje
            <br />
            <i>piękne spotkania</i>
          </span>
          <small>ATELIER · CAFÉ · {year}</small>
        </div>
      </section>
      <div className="gc-rhythm">
        <span>
          <b>45 dni wcześniej</b> podejmujemy decyzję
        </span>
        <i>→</i>
        <span>
          <b>Miesiąc wcześniej</b> zatwierdzamy plan
        </span>
        <i>→</i>
        <span>
          <b>Każdego dnia</b> pilnujemy etapów
        </span>
      </div>
      {error && (
        <div className="gc-error" role="alert">
          {error} <button onClick={() => void load()}>Spróbuj ponownie</button>
        </div>
      )}
      {sources && (
        <section className="gc-paper gc-method">
          <div className="gc-section-title">
            <h3>Od inspiracji do dobrego planu</h3>
            <button
              aria-label="Zamknij materiały"
              onClick={() => setSources(false)}
            >
              <X size={20} />
            </button>
          </div>
          <p>
            Przeanalizowaliśmy wszystkie 7 materiałów z 2025 roku. Święta stałe
            wracają tego samego dnia, Wielkanoc i związane z nią daty są
            obliczane dla każdego roku, a okazje typu „pierwszy piątek sierpnia”
            podążają za dniem tygodnia. Terminy targów, wydarzeń organizatorów i
            astronomicznych pór roku wymagają corocznego potwierdzenia.
          </p>
          <p>
            Poprawiliśmy sprzeczne daty w materiałach, m.in. Tłustego Czwartku.
            Oddzielamy zwyczajowy Dzień Kawy (29 września) od Międzynarodowego
            Dnia Kawy ICO (1 października). Nie przenosimy dat targów ani tabel
            czasu pracy z 2025 na kolejne lata. Nieformalne dni kulinarne są
            inspiracją, a ich nazwy i zwyczaje mogą różnić się między krajami.
          </p>
          <div className="gc-source-grid">
            {active?.sources.map((s) => (
              <a key={s.id} href={s.url} target="_blank" rel="noreferrer">
                <BookOpen size={16} />
                <span>{s.title}</span>
                <ArrowUpRight size={14} />
              </a>
            ))}
          </div>
          <p>
            Decyzja dotyczy jednego roku. Każdy kolejny rok zaczyna od nowego
            pytania i pokazuje poprzedni wybór. Po „Odpowiem później” wrócimy w
            wybranym terminie. Przy etapie zapisujesz opis wykonania lub
            odnośnik do efektu; system pilnuje terminów i potwierdzeń w panelu
            administratora.
          </p>
          <small>
            Codzienny przegląd: 08:00, czas Warszawy.{" "}
            {active?.monitor
              ? `Ostatni przegląd: ${new Date(String(active.monitor.checked_at)).toLocaleString("pl-PL", { timeZone: "Europe/Warsaw" })}.`
              : "Pierwszy przegląd jeszcze przed nami."}{" "}
            Lista przypomnień odświeża się też przy otwarciu kalendarza.
          </small>
        </section>
      )}
      {queue && (
        <section className="gc-paper gc-queue">
          <div className="gc-section-title">
            <div>
              <span className="gc-eyebrow">TERAZ JEST DOBRY MOMENT</span>
              <h3>Centrum przygotowań</h3>
            </div>
            <button
              aria-label="Zamknij centrum"
              onClick={() => setQueue(false)}
            >
              <X size={20} />
            </button>
          </div>
          <p>
            Decyzje na najbliższe 45 dni, plany i etapy — także na przełomie
            roku.
          </p>
          {active?.notices.length ? (
            active.notices.map((n) => (
              <button
                className={"gc-notice " + n.level}
                key={n.key}
                onClick={() => openNotice(n)}
              >
                <span className="gc-notice-dot" />
                <span>
                  <strong>
                    {n.title} <small>{n.year}</small>
                  </strong>
                  <small>{n.message}</small>
                </span>
                <span>
                  {fmt(n.due)}
                  <ChevronRight size={16} />
                </span>
              </button>
            ))
          ) : (
            <div className="gc-empty">
              <CheckCircle2 /> Wszystko na bieżąco. Możesz zaplanować kolejne
              okazje.
            </div>
          )}
        </section>
      )}
      <section className="gc-stats">
        <div>
          <CalendarDays />
          <span>
            <b>{active?.occurrences.length || "—"}</b> inspiracji w roku
          </span>
        </div>
        <div>
          <Flower2 />
          <span>
            <b>{celebrate}</b> okazji obchodzimy
          </span>
        </div>
        <div>
          <CheckCircle2 />
          <span>
            <b>{approved}</b> zatwierdzonych planów
          </span>
        </div>
        <button onClick={() => setQueue(true)}>
          <Clock3 />
          <span>
            <b>
              {active?.notices.filter((n) => n.level === "urgent").length || 0}
            </b>{" "}
            spraw wymaga uwagi
          </span>
          <ArrowUpRight size={18} />
        </button>
      </section>
      <section className="gc-paper gc-calendar">
        <div className="gc-toolbar">
          <div className="gc-month-nav">
            <button aria-label="Poprzedni miesiąc" onClick={() => move(-1)}>
              <ChevronLeft size={20} />
            </button>
            <h3>{view === "year" ? "Rok pełen okazji" : months[month]}</h3>
            <button aria-label="Następny miesiąc" onClick={() => move(1)}>
              <ChevronRight size={20} />
            </button>
            <input
              aria-label="Rok"
              type="number"
              min="2025"
              max="2199"
              value={year}
              onChange={(e) => {
                const y = Number(e.target.value);
                if (y >= 2025 && y <= 2199) setYear(y);
              }}
            />
            <button
              className="gc-today"
              onClick={() => {
                setYear(Number(now.slice(0, 4)));
                setMonth(Number(now.slice(5, 7)) - 1);
              }}
            >
              Dzisiaj
            </button>
          </div>
          <div className="gc-segments" aria-label="Widok kalendarza">
            {[
              ["month", "Miesiąc"],
              ["year", "Rok"],
              ["list", "Lista"],
            ].map(([key, label]) => (
              <button
                key={key}
                aria-pressed={view === key}
                className={view === key ? "active" : ""}
                onClick={() => setView(key)}
              >
                {label}
              </button>
            ))}
          </div>
        </div>
        <div className="gc-filters">
          <input
            aria-label="Szukaj okazji"
            placeholder="Znajdź okazję…"
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
              if (e.target.value) setView("list");
            }}
          />
          <select
            aria-label="Kategoria"
            value={category}
            onChange={(e) => setCategory(e.target.value)}
          >
            <option value="">Wszystkie inspiracje</option>
            {Object.entries(categories).map(([v, l]) => (
              <option key={v} value={v}>
                {l}
              </option>
            ))}
          </select>
          <select
            aria-label="Decyzja"
            value={decision}
            onChange={(e) => setDecision(e.target.value)}
          >
            <option value="">Wszystkie decyzje</option>
            {Object.entries(decisions).map(([v, l]) => (
              <option key={v} value={v}>
                {l}
              </option>
            ))}
          </select>
          {loading && <span role="status">Wczytuję…</span>}
        </div>
        {view === "month" && (
          <>
            <div className="gc-weekdays">
              {["Pon", "Wt", "Śr", "Czw", "Pt", "Sob", "Niedz"].map((d) => (
                <span key={d}>{d}</span>
              ))}
            </div>
            <div className="gc-grid">
              {Array.from(
                { length: Math.ceil((start + days) / 7) * 7 },
                (_, i) => {
                  const day = i - start + 1,
                    valid = day > 0 && day <= days,
                    date = `${year}-${String(month + 1).padStart(2, "0")}-${String(day).padStart(2, "0")}`,
                    es = monthly.filter((e) => e.date === date);
                  return (
                    <div
                      key={i}
                      className={
                        "gc-day " +
                        (!valid ? "outside " : "") +
                        (date === now ? "today" : "")
                      }
                    >
                      {valid && (
                        <>
                          <span className="gc-day-number">
                            {day}
                            {date === now && <small>dzisiaj</small>}
                          </span>
                          {es.map((e) => (
                            <button
                              key={e.id}
                              className={`gc-event cat-${e.category} ${state(e) === "SKIP" ? "skipped" : ""}`}
                              onClick={() => {
                                setDetailTab("idea");
                                setSelected(e.id);
                              }}
                            >
                              <span className="gc-event-dot" />
                              <span>{e.title}</span>
                              {state(e) === "CELEBRATE" && <Check size={12} />}
                            </button>
                          ))}
                        </>
                      )}
                    </div>
                  );
                },
              )}
            </div>
            {monthly.some((e) => !e.date) && (
              <div className="gc-undated">
                <span className="gc-eyebrow">
                  TERMIN DO POTWIERDZENIA W TYM MIESIĄCU
                </span>
                <div>
                  {monthly
                    .filter((e) => !e.date)
                    .map((e) => (
                      <button
                        key={e.id}
                        onClick={() => {
                          setDetailTab("idea");
                          setSelected(e.id);
                        }}
                      >
                        <Clock3 size={14} />
                        {e.title}
                        <ChevronRight size={14} />
                      </button>
                    ))}
                </div>
              </div>
            )}
          </>
        )}
        {view === "year" && (
          <div className="gc-year-grid">
            {months.map((m, idx) => {
              const es = events.filter((e) =>
                e.date
                  ? Number(e.date.slice(5, 7)) === idx + 1
                  : e.rule.type === "manual" && e.rule.month === idx + 1,
              );
              return (
                <button
                  key={m}
                  className={
                    "gc-mini-month " + (idx === month ? "current" : "")
                  }
                  onClick={() => {
                    setMonth(idx);
                    setView("month");
                  }}
                >
                  <span>
                    <b>{m}</b>
                    <small>{es.length} okazji</small>
                  </span>
                  <div className="gc-mini-days">
                    {Array.from(
                      { length: (new Date(year, idx, 1).getDay() + 6) % 7 },
                      (_, i) => (
                        <i key={"x" + i} />
                      ),
                    )}
                    {Array.from(
                      { length: new Date(year, idx + 1, 0).getDate() },
                      (_, i) => {
                        const day = String(i + 1).padStart(2, "0");
                        return (
                          <i
                            key={i}
                            className={
                              es.some((e) => e.date?.endsWith("-" + day))
                                ? "has-event"
                                : ""
                            }
                          >
                            {i + 1}
                          </i>
                        );
                      },
                    )}
                  </div>
                  <small>
                    {es.filter((e) => state(e) === "CELEBRATE").length}{" "}
                    obchodzimy <ArrowUpRight size={13} />
                  </small>
                </button>
              );
            })}
          </div>
        )}
        {view === "list" && (
          <div className="gc-list">
            {(search ? events : monthly)
              .sort((a, b) =>
                (a.date || "9999").localeCompare(b.date || "9999"),
              )
              .map((e) => (
                <button
                  key={e.id}
                  onClick={() => {
                    setDetailTab("idea");
                    setSelected(e.id);
                  }}
                >
                  <span className="gc-list-date">
                    {e.date ? (
                      <>
                        <b>{Number(e.date.slice(8))}</b>
                        {months[Number(e.date.slice(5, 7)) - 1].slice(0, 3)}
                      </>
                    ) : (
                      <Clock3 />
                    )}
                  </span>
                  <span>
                    <strong>{e.title}</strong>
                    <small>
                      {categories[e.category]} ·{" "}
                      {e.date ? ruleLabel(e.rule) : "Ustal tegoroczny termin"}
                    </small>
                  </span>
                  <span className={"gc-status " + state(e)}>
                    {decisions[state(e)]}
                  </span>
                  <ChevronRight size={17} />
                </button>
              ))}
            {!(search ? events : monthly).length && (
              <p className="gc-empty">Brak okazji spełniających te kryteria.</p>
            )}
          </div>
        )}
        <div className="gc-legend">
          {Object.entries(categories).map(([key, label]) => (
            <span key={key} className={"cat-" + key}>
              <i />
              {label}
            </span>
          ))}
        </div>
      </section>
      <footer className="gc-footer">
        <Flower2 size={17} /> Zostawmy miejsce na dobre pomysły.{" "}
        <span>Decyzje i plany są dostępne tylko administratorom.</span>
      </footer>
      {selectedEvent && (
        <Detail
          key={
            selectedEvent.id +
            ":" +
            year +
            ":" +
            (selectedEvent.state?.version || 0)
          }
          event={selectedEvent}
          today={active!.today}
          admins={active!.admins}
          audit={active!.audit.filter((a) => a.event_id === selectedEvent.id)}
          close={() => setSelected(null)}
          tab={detailTab}
          setTab={setDetailTab}
          save={async (body) => {
            const r = await fetch("/api/admin/gastro-calendar", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                eventId: selectedEvent.id,
                year,
                version: selectedEvent.state?.version || 0,
                ...body,
              }),
            });
            const d = await r.json();
            if (!r.ok) throw Error(d.error);
            await load();
          }}
        />
      )}
    </main>
  );
}
function Detail({
  event: e,
  today,
  admins,
  audit,
  close,
  save,
  tab,
  setTab,
}: {
  event: Event;
  today: string;
  admins: string[];
  audit: Data["audit"];
  close: () => void;
  save: (body: Record<string, unknown>) => Promise<void>;
  tab: string;
  setTab: (value: string) => void;
}) {
  const [note, setNote] = useState(e.state?.note || ""),
    [snooze, setSnooze] = useState(e.state?.snooze_until || plusDays(today, 7)),
    [later, setLater] = useState(false),
    [date, setDate] = useState(e.date || ""),
    [dateNote, setDateNote] = useState("");
  const [plan, setPlan] = useState<Plan>({
    objective: "",
    offer: "",
    owner: "",
    budget: "",
    channels: "",
    notes: "",
    lateReason: "",
    ...e.state?.plan,
  } as Plan);
  const [tasks, setTasks] = useState<Stage[]>(
    e.tasks.length
      ? e.tasks
      : e.date
        ? milestones.map((m) => ({
            title: m.title,
            due_date: plusDays(e.date!, m.offset),
            owner: "",
          }))
        : [],
  );
  const [busy, setBusy] = useState(false),
    [error, setError] = useState(""),
    [completion, setCompletion] = useState<Record<number, string>>({}),
    [dirty, setDirty] = useState(false);
  const approved = !!e.state?.plan_approved_at,
    celebrate = state(e) === "CELEBRATE";
  useEffect(() => {
    const previous = document.activeElement as HTMLElement | null;
    const dialog = document.querySelector(".gc-detail") as HTMLElement | null;
    dialog
      ?.querySelector<HTMLButtonElement>(".gc-close")
      ?.focus({ preventScroll: true });
    const trap = (ev: KeyboardEvent) => {
      if (ev.key !== "Tab" || !dialog) return;
      const elements = Array.from(
        dialog.querySelectorAll<HTMLElement>(
          "button:not(:disabled),a[href],input:not(:disabled),textarea:not(:disabled),select:not(:disabled)",
        ),
      ).filter(
        (el) => el.getClientRects().length && !el.closest("fieldset:disabled"),
      );
      const first = elements[0],
        last = elements.at(-1);
      if (ev.shiftKey && document.activeElement === first) {
        ev.preventDefault();
        last?.focus();
      } else if (!ev.shiftKey && document.activeElement === last) {
        ev.preventDefault();
        first?.focus();
      }
    };
    document.addEventListener("keydown", trap);
    return () => {
      document.removeEventListener("keydown", trap);
      if (previous?.isConnected) previous.focus({ preventScroll: true });
    };
  }, []);
  useEffect(() => {
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const esc = (ev: KeyboardEvent) => {
      if (ev.key === "Escape" && !dirty && !busy) close();
    };
    document.addEventListener("keydown", esc);
    return () => {
      document.body.style.overflow = previous;
      document.removeEventListener("keydown", esc);
    };
  }, [close, dirty, busy]);
  async function act(body: Record<string, unknown>) {
    setBusy(true);
    setError("");
    try {
      await save(body);
    } catch (x) {
      setError(x instanceof Error ? x.message : "Nie udało się zapisać.");
    } finally {
      setBusy(false);
    }
  }
  function update(k: keyof Plan, v: string) {
    setPlan({ ...plan, [k]: v });
    setDirty(true);
  }
  const closeSafe = () => {
    if (
      !dirty ||
      window.confirm("Masz niezapisane zmiany. Zamknąć bez zapisywania?")
    )
      close();
  };
  return (
    <div
      className="gc-overlay"
      onMouseDown={(ev) => {
        if (ev.target === ev.currentTarget && !busy) closeSafe();
      }}
    >
      <section
        className="gc-detail"
        role="dialog"
        aria-modal="true"
        aria-labelledby="gc-event-title"
      >
        <header className={"gc-detail-hero cat-" + e.category}>
          <span className="gc-eyebrow">
            {categories[e.category]} · {e.year}
          </span>
          <button
            className="gc-close"
            onClick={closeSafe}
            aria-label="Zamknij wydarzenie"
            disabled={busy}
          >
            <X size={22} />
          </button>
          <h2 id="gc-event-title">{e.title}</h2>
          <span className="gc-detail-date">
            <CalendarDays size={17} />
            {fmt(e.date)}
          </span>
          <span className="gc-rule">{ruleLabel(e.rule)}</span>
        </header>
        <div className="gc-detail-body">
          {error && (
            <div className="gc-error" role="alert">
              {error}
            </div>
          )}
          <div className="gc-previous">
            <Clock3 size={17} />
            <div>
              <b>W poprzednim roku ({e.year - 1})</b>
              <span>
                {e.previous
                  ? decisions[e.previous.decision]
                  : "Brak zapisanej decyzji"}
                {e.previous?.note && ` · ${e.previous.note}`}
              </span>
            </div>
          </div>
          <section className="gc-decision-box">
            <span className="gc-eyebrow">NASZA DECYZJA NA {e.year}</span>
            <h3>Świętujemy w kawiarni?</h3>
            <div className="gc-decision-buttons">
              <button
                disabled={busy}
                className={celebrate ? "chosen yes" : ""}
                onClick={() =>
                  void act({ action: "DECIDE", decision: "CELEBRATE", note })
                }
              >
                <Flower2 size={18} /> Obchodzimy
              </button>
              <button
                disabled={busy}
                className={state(e) === "SKIP" ? "chosen" : ""}
                onClick={() =>
                  void act({ action: "DECIDE", decision: "SKIP", note })
                }
              >
                <X size={18} /> Pomijamy
              </button>
              <button
                disabled={busy}
                className={state(e) === "LATER" ? "chosen" : ""}
                onClick={() => setLater(!later)}
              >
                <Clock3 size={18} /> Odpowiem później
              </button>
            </div>
            <label className="gc-field">
              Notatka do decyzji
              <input
                value={note}
                placeholder="Dlaczego tak? Co warto pamiętać za rok?"
                onChange={(ev) => {
                  setNote(ev.target.value);
                  setDirty(true);
                }}
              />
            </label>
            {note !== (e.state?.note || "") && state(e) !== "UNDECIDED" && (
              <button
                className="gc-btn"
                disabled={busy}
                onClick={() =>
                  void act({
                    action: "DECIDE",
                    decision: state(e),
                    note,
                    snoozeUntil: snooze,
                  })
                }
              >
                Zapisz notatkę
              </button>
            )}
            {later && (
              <div className="gc-later">
                <label className="gc-field">
                  Zapytaj ponownie
                  <input
                    type="date"
                    value={snooze}
                    min={plusDays(today, 1)}
                    max={e.date || undefined}
                    onChange={(ev) => setSnooze(ev.target.value)}
                  />
                </label>
                <button
                  className="gc-btn primary"
                  disabled={busy}
                  onClick={() =>
                    void act({
                      action: "DECIDE",
                      decision: "LATER",
                      note,
                      snoozeUntil: snooze,
                    })
                  }
                >
                  Zapisz przypomnienie
                </button>
              </div>
            )}
            {state(e) === "LATER" && (
              <p>
                Wrócimy do pytania {fmt(e.state?.snooze_until || null)}. Plan
                nadal jest potrzebny do {fmt(e.planDue)}.
              </p>
            )}
          </section>
          {e.rule.type === "manual" && (
            <section className="gc-date-confirm">
              <h3>Potwierdź termin w {e.year}</h3>
              <p>
                {e.date
                  ? "Zmiana daty wymaga ponownego sprawdzenia etapów i zatwierdzenia planu."
                  : "Sprawdź aktualny komunikat organizatora lub kalendarz astronomiczny. Nie kopiujemy daty z poprzedniego roku."}
              </p>
              <label className="gc-field">
                Data
                <input
                  type="date"
                  value={date}
                  min={`${e.year}-01-01`}
                  max={`${e.year}-12-31`}
                  onChange={(ev) => setDate(ev.target.value)}
                />
              </label>
              <label className="gc-field">
                Źródło potwierdzenia
                <input
                  value={dateNote}
                  onChange={(ev) => setDateNote(ev.target.value)}
                  placeholder="Link lub opis źródła"
                />
              </label>
              <button
                className="gc-btn"
                disabled={busy}
                onClick={() => void act({ action: "DATE", date, dateNote })}
              >
                Zapisz termin
              </button>
            </section>
          )}
          <div className="gc-detail-tabs">
            {[
              ["idea", "Inspiracje"],
              ["plan", "Plan i realizacja"],
              ["history", "Historia"],
            ].map(([v, l]) => (
              <button
                key={v}
                className={tab === v ? "active" : ""}
                onClick={() => setTab(v)}
              >
                {l}
              </button>
            ))}
          </div>
          {tab === "idea" && (
            <>
              <div className="gc-tradition">
                <Sparkles size={22} />
                <div>
                  <span className="gc-eyebrow">
                    OPowieść, OD KTÓREJ ZACZYNAMY
                  </span>
                  <p>
                    {e.context ||
                      "Okazja do wspólnego spotkania wokół smaku. Wybierz pomysł pasujący do charakteru naszej kawiarni i zdecyduj, co zaproponujemy gościom."}
                  </p>
                </div>
              </div>
              <h3>Jak możemy to zrobić u nas?</h3>
              <div className="gc-ideas">
                {e.ideas?.map((idea, i) => (
                  <div key={i}>
                    <span>0{i + 1}</span>
                    <p>{idea}</p>
                  </div>
                ))}
              </div>
              <div className="gc-products">
                <span className="gc-eyebrow">
                  PUNKT WYJŚCIA: NASZA AKTUALNA KARTA
                </span>
                {e.products.length ? (
                  <div>
                    {e.products.map((p) => (
                      <div key={p.id}>
                        {p.image && <img src={String(p.image)} alt="" />}
                        <span>
                          <b>{p.name}</b>
                          <small>{Number(p.price).toFixed(2)} zł</small>
                        </span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p>
                    Nie znaleźliśmy oczywistego dopasowania w aktualnej karcie.
                    W planie wybierz produkt lub zdecyduj o przetestowaniu nowej
                    receptury.
                  </p>
                )}
                <small>
                  To propozycje do wyboru. Przed ogłoszeniem oferty potwierdź
                  dostępność, recepturę i kalkulację.
                </small>
              </div>
              <button
                className="gc-btn primary wide"
                onClick={() => setTab("plan")}
              >
                Przejdź od pomysłu do planu <ArrowUpRight size={16} />
              </button>
              <p className="gc-source-note">
                {e.certainty}.{" "}
                <a
                  href={`/api/admin/gastro-calendar/sources/${e.source}`}
                  target="_blank"
                  rel="noreferrer"
                >
                  Materiał źródłowy
                </a>
                {e.url && (
                  <>
                    {" "}
                    ·{" "}
                    <a href={e.url} target="_blank" rel="noreferrer">
                      Źródło daty
                    </a>
                  </>
                )}
              </p>
            </>
          )}
          {tab === "plan" && (
            <>
              {!celebrate || !e.date ? (
                <div className="gc-empty">
                  <CalendarDays />
                  Wybierz „Obchodzimy” i potwierdź datę, aby przygotować plan.
                </div>
              ) : (
                <>
                  <div
                    className={
                      "gc-plan-deadline " +
                      (e.planDue! < today && !approved ? "late" : "")
                    }
                  >
                    <CalendarDays size={22} />
                    <div>
                      <b>Plan gotowy do {fmt(e.planDue)}</b>
                      <span>
                        {approved
                          ? "Zatwierdzony — czas na realizację."
                          : "Miesiąc przed okazją ustalamy ofertę, odpowiedzialność i etapy."}
                      </span>
                    </div>
                    {approved && <CheckCircle2 size={21} />}
                  </div>
                  <fieldset
                    disabled={busy || approved}
                    className="gc-plan-fields"
                  >
                    <label className="gc-field">
                      Cel akcji
                      <textarea
                        value={plan.objective}
                        onChange={(ev) => update("objective", ev.target.value)}
                        placeholder="Co chcemy osiągnąć i jak ocenimy wynik?"
                      />
                    </label>
                    <label className="gc-field">
                      Oferta i sposób świętowania
                      <textarea
                        value={plan.offer}
                        onChange={(ev) => update("offer", ev.target.value)}
                        placeholder="Produkty, tradycja, forma spotkania, cena, liczba porcji…"
                      />
                    </label>
                    <div className="gc-form-row">
                      <label className="gc-field">
                        Osoba odpowiedzialna
                        <input
                          list="gc-admins"
                          value={plan.owner}
                          onChange={(ev) => {
                            update("owner", ev.target.value);
                            setTasks(
                              tasks.map((t) => ({
                                ...t,
                                owner:
                                  !t.owner || t.owner === plan.owner
                                    ? ev.target.value
                                    : t.owner,
                              })),
                            );
                          }}
                        />
                      </label>
                      <label className="gc-field">
                        Budżet / limit kosztów
                        <input
                          value={plan.budget}
                          onChange={(ev) => update("budget", ev.target.value)}
                          placeholder="np. 300 zł"
                        />
                      </label>
                    </div>
                    <datalist id="gc-admins">
                      {admins.map((a) => (
                        <option key={a} value={a} />
                      ))}
                    </datalist>
                    <label className="gc-field">
                      Gdzie opowiemy o akcji?
                      <input
                        value={plan.channels}
                        onChange={(ev) => update("channels", ev.target.value)}
                        placeholder="np. karta w lokalu, Instagram, tablica przed kawiarnią"
                      />
                    </label>
                    <label className="gc-field">
                      Ustalenia i potrzebne decyzje
                      <textarea
                        value={plan.notes}
                        onChange={(ev) => update("notes", ev.target.value)}
                        placeholder="Dostawcy, rezerwacje, pytania do zespołu…"
                      />
                    </label>
                    {e.planDue! < today && (
                      <label className="gc-field gc-late-reason">
                        Plan po terminie — jak nadrobimy przygotowania?
                        <textarea
                          value={plan.lateReason}
                          onChange={(ev) =>
                            update("lateReason", ev.target.value)
                          }
                          placeholder="Uzasadnij późne zatwierdzenie i opisz realny plan działania."
                        />
                      </label>
                    )}
                    <h3>Etapy przygotowań</h3>
                    <p className="gc-muted">
                      Proponujemy terminy. Dopasuj je do skali akcji i przypisz
                      osoby.
                    </p>
                    <div className="gc-stages-edit">
                      {tasks.map((t, i) => (
                        <div key={t.id || "new" + i}>
                          <span>{String(i + 1).padStart(2, "0")}</span>
                          <div>
                            <input
                              aria-label={`Nazwa etapu ${i + 1}`}
                              value={t.title}
                              disabled={t.status === "DONE"}
                              onChange={(ev) => {
                                setTasks(
                                  tasks.map((x, j) =>
                                    i === j
                                      ? { ...x, title: ev.target.value }
                                      : x,
                                  ),
                                );
                                setDirty(true);
                              }}
                            />
                            <div className="gc-form-row">
                              <input
                                aria-label={`Termin etapu ${i + 1}`}
                                type="date"
                                value={t.due_date}
                                disabled={t.status === "DONE"}
                                onChange={(ev) => {
                                  setTasks(
                                    tasks.map((x, j) =>
                                      i === j
                                        ? { ...x, due_date: ev.target.value }
                                        : x,
                                    ),
                                  );
                                  setDirty(true);
                                }}
                              />
                              <input
                                aria-label={`Odpowiedzialny za etap ${i + 1}`}
                                list="gc-admins"
                                placeholder="Osoba odpowiedzialna"
                                value={t.owner}
                                disabled={t.status === "DONE"}
                                onChange={(ev) => {
                                  setTasks(
                                    tasks.map((x, j) =>
                                      i === j
                                        ? { ...x, owner: ev.target.value }
                                        : x,
                                    ),
                                  );
                                  setDirty(true);
                                }}
                              />
                            </div>
                          </div>
                          {t.status !== "DONE" && (
                            <button
                              aria-label={`Usuń etap ${i + 1}`}
                              onClick={() => {
                                setTasks(tasks.filter((_, j) => j !== i));
                                setDirty(true);
                              }}
                            >
                              <X size={15} />
                            </button>
                          )}
                        </div>
                      ))}
                    </div>
                    <button
                      className="gc-btn"
                      onClick={() => {
                        setTasks([
                          ...tasks,
                          { title: "", due_date: e.date!, owner: plan.owner },
                        ]);
                        setDirty(true);
                      }}
                    >
                      <Plus size={15} /> Dodaj etap
                    </button>
                  </fieldset>
                  {!approved ? (
                    <div className="gc-plan-actions">
                      <button
                        className="gc-btn"
                        disabled={busy}
                        onClick={() =>
                          void act({ action: "SAVE_PLAN", plan, tasks })
                        }
                      >
                        Zapisz plan
                      </button>
                      <button
                        className="gc-btn primary"
                        disabled={busy || dirty || !e.tasks.length}
                        onClick={() => void act({ action: "APPROVE_PLAN" })}
                      >
                        Zatwierdź plan <Check size={16} />
                      </button>
                      {dirty && (
                        <small>
                          Najpierw zapisz zmiany, potem zatwierdź plan.
                        </small>
                      )}
                    </div>
                  ) : (
                    <>
                      <div className="gc-progress">
                        <b>
                          {e.tasks.filter((t) => t.status === "DONE").length} z{" "}
                          {e.tasks.length} etapów wykonanych
                        </b>
                        <progress
                          max={e.tasks.length}
                          value={
                            e.tasks.filter((t) => t.status === "DONE").length
                          }
                        />
                      </div>
                      <h3>Potwierdzenia wykonania</h3>
                      {e.tasks.map((t) => (
                        <div
                          className={
                            "gc-task " +
                            (t.status === "DONE"
                              ? "done"
                              : t.due_date < today
                                ? "overdue"
                                : "")
                          }
                          key={t.id}
                        >
                          <div>
                            <b>{t.title}</b>
                            <small>
                              {fmt(t.due_date)} · {t.owner}{" "}
                              {t.status !== "DONE" &&
                                t.due_date < today &&
                                "· Po terminie"}
                            </small>
                          </div>
                          {t.status === "DONE" ? (
                            <>
                              <p>
                                <CheckCircle2 size={16} />
                                {t.completion_note}
                              </p>
                              <button
                                className="gc-link"
                                disabled={busy}
                                onClick={() =>
                                  void act({
                                    action: "TASK",
                                    taskId: t.id,
                                    done: false,
                                  })
                                }
                              >
                                Oznacz jako niewykonane
                              </button>
                            </>
                          ) : (
                            <>
                              <textarea
                                aria-label={`Potwierdzenie: ${t.title}`}
                                placeholder="Co wykonano? Dodaj opis lub link do efektu."
                                value={completion[t.id] || ""}
                                onChange={(ev) =>
                                  setCompletion({
                                    ...completion,
                                    [t.id]: ev.target.value,
                                  })
                                }
                              />
                              <button
                                className="gc-btn"
                                disabled={busy || !completion[t.id]?.trim()}
                                onClick={() =>
                                  void act({
                                    action: "TASK",
                                    taskId: t.id,
                                    done: true,
                                    completionNote: completion[t.id],
                                  })
                                }
                              >
                                <Check size={16} /> Potwierdź wykonanie
                              </button>
                            </>
                          )}
                        </div>
                      ))}
                      <button
                        className="gc-link"
                        disabled={busy}
                        onClick={() => void act({ action: "REOPEN_PLAN" })}
                      >
                        Otwórz plan do ponownej edycji
                      </button>
                    </>
                  )}
                  <p className="gc-source-note">
                    Przypominamy 3 dni przed etapem i codziennie po terminie.
                    Zaległość znika po potwierdzeniu wykonania. Publikacje i
                    dostawy potwierdza administrator.
                  </p>
                </>
              )}
            </>
          )}
          {tab === "history" && (
            <div className="gc-history">
              <h3>Historia decyzji i realizacji</h3>
              {audit.length ? (
                audit.map((a, i) => (
                  <div key={i}>
                    <span>
                      {new Date(String(a.created_at)).toLocaleString("pl-PL", {
                        timeZone: "Europe/Warsaw",
                      })}
                    </span>
                    <b>
                      {(
                        {
                          DECIDE: "Zapisano decyzję",
                          DATE: "Potwierdzono termin",
                          SAVE_PLAN: "Zapisano plan",
                          APPROVE_PLAN: "Zatwierdzono plan",
                          REOPEN_PLAN: "Otwarto edycję planu",
                          TASK: "Zmieniono stan etapu",
                        } as Record<string, string>
                      )[String(a.action)] || String(a.action)}
                    </b>
                    <small>{String(a.actor)}</small>
                  </div>
                ))
              ) : (
                <p>Tu pojawią się zapisane decyzje, plany i potwierdzenia.</p>
              )}
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
