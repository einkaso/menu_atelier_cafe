import { isAdmin } from "../../../lib/admin-auth";
import AdminLogin from "../admin-login";
import GastroCalendar from "./gastro-calendar";
export const dynamic = "force-dynamic";
export default async function Page() {
  return (await isAdmin()) ? <GastroCalendar /> : <AdminLogin />;
}
