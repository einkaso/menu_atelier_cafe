"use client";
import { useEffect, useState } from "react";
import { CalendarDays, ArrowUpRight } from "lucide-react";
export default function GastroAttention() {
  const [summary, setSummary] = useState<{
    count: number;
    urgent: number;
    titles: string[];
  } | null>(null);
  useEffect(() => {
    let active = true;
    async function load() {
      try {
        const r = await fetch("/api/admin/gastro-calendar?summary=1", {
          cache: "no-store",
        });
        if (!r.ok) return;
        const d = await r.json();
        if (active)
          setSummary({
            count: d.notices.length,
            urgent: d.notices.filter(
              (n: { level: string }) => n.level === "urgent",
            ).length,
            titles: [
              ...new Set<string>(
                d.notices.map((n: { title: string }) => n.title),
              ),
            ].slice(0, 3),
          });
      } catch {}
    }
    void load();
    const timer = setInterval(() => void load(), 300000);
    return () => {
      active = false;
      clearInterval(timer);
    };
  }, []);
  if (!summary?.count) return null;
  return (
    <a
      href="/admin/gastro-calendar"
      style={{
        display: "flex",
        alignItems: "center",
        gap: 14,
        padding: "18px 22px",
        border: "1px solid #dacba8",
        borderRadius: 12,
        background: "#fbf6e8",
        color: "#586843",
        textDecoration: "none",
        margin: "18px 0",
      }}
    >
      <CalendarDays size={24} style={{ flexShrink: 0 }} />
      <span style={{ flex: 1 }}>
        <strong style={{ fontSize: 14 }}>
          Kalendarz gastronomiczny · {summary.count} spraw do przygotowania
          {summary.urgent > 0 ? ` · ${summary.urgent} pilnych` : ""}
        </strong>
        <small style={{ display: "block", marginTop: 5, fontSize: 12 }}>
          {summary.titles.join(" · ")}
        </small>
      </span>
      <ArrowUpRight size={19} />
    </a>
  );
}
