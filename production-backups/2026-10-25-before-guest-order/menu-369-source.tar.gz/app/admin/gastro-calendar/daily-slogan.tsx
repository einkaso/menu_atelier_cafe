'use client';
import {useCallback,useEffect,useRef,useState} from 'react';
import {Copy,RefreshCw,Sparkles} from 'lucide-react';
import type {DailySlogan as Slogan} from '../../../lib/gastro/slogan';
export default function DailySlogan(){
 const [data,setData]=useState<Slogan|null>(null),[busy,setBusy]=useState(false),[error,setError]=useState(''),[copied,setCopied]=useState(false);
 const inFlight=useRef(false);
 const load=useCallback(async(refresh=false)=>{
  if(inFlight.current)return;inFlight.current=true;setBusy(true);setError('');setCopied(false);
  try{const r=await fetch('/api/admin/gastro-calendar/slogan',{method:refresh?'POST':'GET',cache:'no-store'});const body=await r.json();if(!r.ok)throw Error(body.error);setData(body);}catch(e){setError(e instanceof Error?e.message:'Nie udało się pobrać hasła.');}finally{inFlight.current=false;setBusy(false);}
 },[]);
 useEffect(()=>{void load();const timer=setInterval(()=>void load(),60000);return()=>clearInterval(timer);},[load]);
 return <div className="gc-daily-slogan">
  <span className="gc-eyebrow"><Sparkles size={15}/> NA DZISIAJ · NA POTYKACZ</span>
  <h2 aria-live="polite">{data?.text||'Chwila na dobry pomysł…'}</h2>
  {data&&<><p className="gc-slogan-context">{new Date(data.date+'T12:00:00').toLocaleDateString('pl-PL',{day:'numeric',month:'long'})} · {data.context}</p><p className="gc-slogan-notice">{data.notice}</p></>}
  <div className="gc-hero-actions"><button className="gc-light" disabled={busy} onClick={()=>void load(true)}><RefreshCw size={15}/>{busy?'Przygotowuję…':'Inna propozycja'}</button><button className="gc-text-light" disabled={!data||busy} onClick={async()=>{try{await navigator.clipboard.writeText(data!.text);setCopied(true);}catch{setError('Nie udało się skopiować. Zaznacz hasło i skopiuj je ręcznie.');}}}><Copy size={15}/>{copied?'Skopiowano':'Kopiuj hasło'}</button></div>
  {error&&<p role="alert">{error}</p>}
 </div>;
}
