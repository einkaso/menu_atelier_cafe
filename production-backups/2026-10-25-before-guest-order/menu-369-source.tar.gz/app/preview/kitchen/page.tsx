import { notFound } from "next/navigation";
import PreparationCardView from "../../../components/kitchen/preparation-card";
import { preparationIssues, type PreparationCard, type RecipeVersion } from "../../../lib/kitchen-recipes";
import "../../../components/kitchen/kitchen.css";

export const dynamic = "force-dynamic";
export default function KitchenPreviewPage() {
  if (process.env.NODE_ENV !== "development") notFound();
  const recipe: RecipeVersion = {
    id: 1, recipeId: 1, version: 2, status: "PUBLISHED", editRevision: 1,
    updatedBy: "Podgląd demonstracyjny", updatedAt: "2026-10-05T12:00:00Z", publishedAt: "2026-10-05T12:00:00Z", media: [],
    content: { name: "Sos — przykład karty", category: "Sosy", yieldQuantity: "1000", yieldUnit: "g",
      ingredients: [{ name: "Składnik bazowy", quantity: "800", unit: "g" }, { name: "Dodatek", quantity: "200", unit: "g" }],
      steps: "1. Przygotuj i odważ składniki według zatwierdzonej receptury.\n2. Połącz je zgodnie z instrukcją kuchni.\n3. Oznacz pojemnik po przygotowaniu.",
      allergens: "Tutaj pojawi się sprawdzona lista alergenów.", storage: "Tutaj kuchnia określi warunki i czas przechowywania. Podgląd nie jest recepturą do zastosowania.", notes: "To demonstracja układu, nie rzeczywisty przepis." },
  };
  const card: PreparationCard = {
    productId: 0, productName: "Danie — podgląd demonstracyjny", revision: 1,
    instructions: "1. Przygotuj porcję według gramatur poniżej.\n2. Ułóż elementy zgodnie ze zdjęciem i instrukcją kuchni.\n3. Dodaj sos i wydaj gotowe danie.", media: [],
    components: [
      { name: "Sos", mode: "RECIPE", quantity: "30", unit: "g", notes: "Dodaj przy wydaniu.", recipeVersionId: 1, recipe },
      { name: "Dodatek kupowany", mode: "PURCHASED", quantity: "1", unit: "szt.", notes: "Produkt gotowy — bez własnego przepisu.", recipeVersionId: null, recipe: null },
    ], complete: false, issues: [],
  };
  card.issues = preparationIssues(card.instructions, card.media, card.components); card.complete = !card.issues.length;
  return <main style={{ maxWidth: 860, margin: "30px auto", padding: 24, background: "white", borderRadius: 16 }}><p className="kitchen-status is-incomplete">PODGLĄD LOKALNY · Dane demonstracyjne, nie instrukcja przygotowania rzeczywistego dania.</p><span className="kitchen-eyebrow">KARTA PRACOWNIKA</span><h1>{card.productName}</h1><PreparationCardView card={card}/></main>;
}
