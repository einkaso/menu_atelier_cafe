import { notFound } from "next/navigation";
import MenuClient from "../../../menu-client";
import { isWelcomeLayout } from "../../../../lib/menu-view";
import { readArtMediaConfig } from "../../../../lib/menu-art-server";

export const dynamic = "force-dynamic";

// Local visual QA only. Production guests cannot select a layout by URL.
export default async function WelcomePreview({ params }: { params: Promise<{ layout: string }> }) {
  if (process.env.NODE_ENV !== "development") notFound();
  const { layout } = await params;
  if (!isWelcomeLayout(layout)) notFound();
  return <MenuClient initialWelcomeLayout={layout} developmentPreview artMedia={await readArtMediaConfig()} />;
}
