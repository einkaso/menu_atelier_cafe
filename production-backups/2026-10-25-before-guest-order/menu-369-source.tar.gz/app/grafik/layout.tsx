import type { Metadata } from "next";
import "../kelner/grafik/workforce-employee.css";
import "./schedule-portal.css";

export const metadata: Metadata = {
  title: "Grafik pracownika — Atelier Café",
  description: "Prywatny dostęp pracownika do grafiku i dyspozycji.",
  robots: { index: false, follow: false },
};

export default function ScheduleLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return children;
}
