"use client";

import { FormEvent, useCallback, useEffect, useState } from "react";
import Image from "next/image";
import WorkforceEmployeeClient from "../kelner/grafik/workforce-employee-client";

type State = "LOADING" | "LOGIN" | "READY";

export default function SchedulePortalClient() {
  const [state, setState] = useState<State>("LOADING");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const sessionExpired = useCallback(() => { setState("LOGIN"); setError("Sesja wygasła. Zaloguj się ponownie."); }, []);

  useEffect(() => {
    let active = true;
    void fetch("/api/grafik/session", { cache: "no-store", credentials: "same-origin" }).then((response) => {
      if (active) setState(response.ok ? "READY" : "LOGIN");
    }).catch(() => { if (active) { setState("LOGIN"); setError("Nie udało się połączyć z serwerem."); } });
    return () => { active = false; };
  }, []);

  async function login(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setBusy(true); setError("");
    const form = new FormData(event.currentTarget);
    const response = await fetch("/api/grafik/session", {
      method: "POST",
      credentials: "same-origin",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ name: form.get("name"), pin: form.get("pin") }),
    }).catch(() => null);
    const body = await response?.json().catch(() => ({})) as { error?: string } | undefined;
    if (!response?.ok) setError(body?.error ?? "Nie udało się zalogować.");
    else setState("READY");
    setBusy(false);
  }

  async function logout() {
    setBusy(true);
    const response = await fetch("/api/grafik/session", { method: "DELETE", credentials: "same-origin" }).catch(() => null);
    if (!response?.ok) { setError("Nie udało się bezpiecznie wylogować."); setBusy(false); return; }
    setError(""); setState("LOGIN"); setBusy(false);
  }

  if (state === "LOADING") return <main className="schedule-portal-login is-loading"><Image src="/logo-cafe.png" width={360} height={160} priority alt="Marta Banaszek atelier-café"/><p>Sprawdzam dostęp do grafiku…</p></main>;
  if (state === "READY") return <WorkforceEmployeeClient standalone onStandaloneLogout={() => void logout()} onSessionExpired={sessionExpired}/>;
  return <main className="schedule-portal-login"><section><Image src="/logo-cafe.png" width={360} height={160} priority alt="Marta Banaszek atelier-café"/><span>PORTAL PRACOWNIKA</span><h1>Grafik i dyspozycje</h1><p>Zaloguj się imieniem zapisanym przy pracowniku i swoim PIN-em. Ten dostęp prowadzi wyłącznie do grafiku.</p><form onSubmit={login}><label>Imię pracownika<input name="name" autoComplete="username" maxLength={120} required autoFocus placeholder="Np. Marta"/></label><label>PIN<input name="pin" type="password" inputMode="numeric" pattern="[0-9]{4,8}" minLength={4} maxLength={8} autoComplete="current-password" required placeholder="••••"/></label>{error && <p role="alert">{error}</p>}<button disabled={busy}>{busy ? "Loguję…" : "Otwórz grafik"}</button></form><small>Nie udostępniaj swojego PIN-u innym osobom.</small></section></main>;
}
