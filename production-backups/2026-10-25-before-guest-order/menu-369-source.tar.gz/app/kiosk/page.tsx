import { headers } from "next/headers";
import { redirect } from "next/navigation";
import { currentAdmin } from "../../lib/admin-auth";
import { currentWorkforceKiosk } from "../../lib/workforce-kiosk-auth";
import KioskLogin from "./kiosk-login";
import "../admin/workforce/workforce.css";
import "./kiosk.css";
export const dynamic = "force-dynamic";
export const metadata = {title:"Obecność — skaner pracowników",robots:{index:false,follow:false}};
export default async function KioskPage({searchParams}:{searchParams:Promise<{error?:string;logged?:string}>}){
 const incoming=await headers();
 let scheme=incoming.get("x-forwarded-proto")?.split(",")[0]?.trim();
 try { const visitor=JSON.parse(incoming.get("cf-visitor")??"null");if(visitor?.scheme)scheme=visitor.scheme; } catch { /* Use the proxy protocol when no Cloudflare metadata is present. */ }
 const host=incoming.get("host")?.split(":")[0];
 if(host==="menu.martabanaszek.pl" && scheme==="http")redirect("https://menu.martabanaszek.pl/kiosk");
 const [admin,kiosk]=await Promise.all([currentAdmin(),currentWorkforceKiosk()]);
 const query=await searchParams;
 if(admin||kiosk)redirect("/skaner");
 return <KioskLogin error={query.logged?"session":query.error}/>;
}
