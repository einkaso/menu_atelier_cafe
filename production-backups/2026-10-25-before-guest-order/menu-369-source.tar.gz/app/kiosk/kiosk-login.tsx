const messages: Record<string,string> = {
 credentials:"Nieprawidłowy login lub hasło.",
 blocked:"Za dużo nieudanych prób. Spróbuj ponownie za 10 minut.",
 unavailable:"Dostęp do skanera nie został skonfigurowany.",
 session:"Tablet nie zapamiętał logowania. Otwórz stronę w zwykłym Chrome i zezwól na pliki cookie dla tej witryny.",
};
export default function KioskLogin({error}:{error?:string}){
 return <main className="kiosk-login"><section><img src="/logo-cafe.png" alt="Atelier Café"/><h1>Skaner obecności</h1><p>Zaloguj tablet do rejestrowania wejść i wyjść pracowników.</p><form method="post" action="/api/workforce/kiosk/session"><label>Login<input name="username" defaultValue="kiosk" autoComplete="username" required maxLength={50}/></label><label>Hasło<input name="password" type="password" autoComplete="current-password" required maxLength={128}/></label>{error&&messages[error]&&<p role="alert">{messages[error]}</p>}<button type="submit">Otwórz skaner</button></form></section></main>
}
