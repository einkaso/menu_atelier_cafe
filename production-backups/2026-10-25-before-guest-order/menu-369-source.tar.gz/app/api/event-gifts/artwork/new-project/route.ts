import {randomUUID} from 'node:crypto';
import {seal,unseal,validId} from '../../../../../lib/event-gift-artwork-core';

export const dynamic='force-dynamic';
const headers={'Cache-Control':'private, no-store','Referrer-Policy':'no-referrer'};
export async function POST(req:Request){
 if(req.headers.get('origin')!=='https://menu.martabanaszek.pl')return Response.json({error:'Otwórz kreator w menu Atelier.'},{status:403,headers});
 const secret=process.env.MENU_EVENT_OS_SECRET?.trim();
 if(!secret||secret.length<32)return Response.json({error:'Nie udało się rozpocząć nowego projektu. Spróbuj ponownie później.'},{status:503,headers});
 const cookieName='mb_gift_artwork';
 const raw=req.headers.get('cookie')?.split(';').map(part=>part.trim()).find(part=>part.startsWith(cookieName+'='))?.slice(cookieName.length+1)||'';
 const previous=unseal(raw,secret);
 if(previous?.kind!=='session'||!validId(previous.owner))return Response.json({error:'Sesja kreatora wygasła. Odśwież stronę i spróbuj ponownie.'},{status:409,headers});
 const token=seal({kind:'session',owner:randomUUID(),expires:Date.now()+30*86400000},secret);
 return Response.json({ready:true},{headers:{...headers,'Set-Cookie':`${cookieName}=${token}; Path=/api/event-gifts; HttpOnly; Secure; SameSite=Strict; Max-Age=2592000`}});
}
