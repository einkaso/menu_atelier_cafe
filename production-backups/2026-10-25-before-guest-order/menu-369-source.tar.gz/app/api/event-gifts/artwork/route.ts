import {sql} from 'drizzle-orm';
import {getDb} from '../../../../db';
import {artworkPrompt,artworkLimited,ARTWORK_LIMIT_START} from '../../../../lib/event-gift-artwork-policy';
import {recoverArtwork,artworkAllowance,reserveArtwork,acceptArtwork,ArtworkLimitError} from '../../../../lib/event-gift-artwork-limits';
import {brandGiftArtwork} from '../../../../lib/event-gift-artwork-brand';
import {createHmac,randomUUID} from 'node:crypto';
import {seal,unseal,validId,artworkInput,safeArtworkUrl} from '../../../../lib/event-gift-artwork-core';
import {readGiftIntegrationStatus} from '../../../../lib/event-gifts-integration';
export const dynamic='force-dynamic';
const cookieName='mb_gift_artwork',base='/api/integrations/menu/gifts/v1',states=['QUEUED','PROCESSING','SUCCEEDED','FAILED','REJECTED'];
const headers={'Cache-Control':'private, no-store','Referrer-Policy':'no-referrer'};
function config(){const secret=process.env.MENU_EVENT_OS_SECRET?.trim();const origin=new URL(process.env.EVENT_OS_APP_URL||'https://events.mbstudio.online');if(!secret||secret.length<32||origin.protocol!=='https:'||origin.username||origin.password||origin.pathname!=='/'||origin.search||origin.hash)throw Error();return {secret,origin:origin.origin};}
function session(req:Request,secret:string){const raw=req.headers.get('cookie')?.split(';').map(s=>s.trim()).find(s=>s.startsWith(cookieName+'='))?.slice(cookieName.length+1)||'';const v=unseal(raw,secret);return v?.kind==='session'&&validId(v.owner)?v:null;}
function json(v:unknown,status=200,extra:Record<string,string>={}){return Response.json(v,{status,headers:{...headers,...extra}});}
async function upstream(path:string,c:ReturnType<typeof config>,init:RequestInit={}){return fetch(c.origin+base+path,{...init,headers:{Authorization:`Bearer ${c.secret}`,Accept:'application/json',...init.headers},redirect:'error',cache:'no-store',signal:AbortSignal.timeout(15000)});}
function validJob(v:any,id?:string){return v&&validId(v.artworkId)&&(!id||v.artworkId===id)&&states.includes(v.status);}
function clientJob(v:any,receipt:string){return {artworkId:v.artworkId,status:v.status,createdAt:typeof v.createdAt==='string'?v.createdAt:null,receipt,imageUrl:v.status==='SUCCEEDED'?'/api/event-gifts/artwork?image=1&receipt='+encodeURIComponent(receipt):null,message:v.status==='REJECTED'?'Opis nie może zostać zrealizowany. Zmień pomysł i spróbuj ponownie.':v.status==='FAILED'?'Nie udało się wygenerować ilustracji. Możesz spróbować ponownie.':null};}
export async function POST(req:Request){
 const origin=req.headers.get('origin');if(!origin||!['https://menu.martabanaszek.pl',new URL(req.url).origin,`http://${req.headers.get('host')}`].includes(origin))return json({error:'Otwórz kreator w menu Atelier.'},403);
 let c:ReturnType<typeof config>;try{c=config();}catch{return json({error:'Połączenie z pracownią ilustracji jest niedostępne.'},503);}
 let input:ReturnType<typeof artworkInput>;let eventId:string|null=null;const key=req.headers.get('Idempotency-Key');try{if(!validId(key))throw Error();const raw=await req.text();if(raw.length>6000)throw Error();const parsed=JSON.parse(raw);input=artworkInput(parsed);if(input.brief.length>800)throw Error();if(parsed.eventId!=null){if(typeof parsed.eventId!=='string'||parsed.eventId.length>160)throw Error();eventId=parsed.eventId;}}catch{return json({error:'Opisz pomysł w 10–800 znakach.'},400);}
 const previous=session(req,c.secret);if(!previous)return json({error:'Odśwież sesję kreatora i spróbuj ponownie.'},409);const owner=previous.owner;const expires=Date.now()+30*86400000;
 const cookie=seal({kind:'session',owner,expires},c.secret);const extra={'Set-Cookie':`${cookieName}=${cookie}; Path=/api/event-gifts; HttpOnly; SameSite=Strict; Max-Age=2592000${origin.startsWith('https:')?'; Secure':''}`};
 try{const availability=await readGiftIntegrationStatus();if(!availability.compatible||!availability.capabilities?.artworkGeneration?.available)return json({error:'Generator jest chwilowo niedostępny.'},503,extra);
 let title:string|undefined;if(eventId){const events=await getDb().execute(sql`select title from event_os_events where external_id=${eventId} and starts_at>now() and status<>'CANCELLED'`);if(!events.length)return json({error:'Wybierz aktualne wydarzenie lub voucher otwarty.'},400,extra);title=String(events[0].title);}
 const payload={...input,brief:artworkPrompt(input.brief,title)};
 const network=req.headers.get('cf-connecting-ip')||req.headers.get('x-forwarded-for')?.split(',')[0]?.trim()||'unknown';
 let reservation:Awaited<ReturnType<typeof reserveArtwork>>;try{reservation=await reserveArtwork(String(owner),network,key!,JSON.stringify(payload),c.secret);}catch(e){return json({error:e instanceof ArtworkLimitError?e.message:'Nie udało się sprawdzić limitu ilustracji. Spróbuj ponownie.'},e instanceof ArtworkLimitError?429:503,extra);}
 if(reservation.jobId){const existing=await upstream('/artwork/'+reservation.jobId,c);if(!existing.ok)throw Error();const v=await existing.json();if(!validJob(v,reservation.jobId))throw Error();return json(clientJob(v,seal({kind:'job',owner,artworkId:v.artworkId,expires},c.secret)),202,extra);}
 const idempotency=createHmac('sha256',c.secret).update('artwork-request:'+owner+':'+reservation.key).digest('hex');
 const r=await upstream('/artwork',c,{method:'POST',headers:{'Content-Type':'application/json','Idempotency-Key':idempotency},body:JSON.stringify(payload)});
 if(!r.ok){console.warn('[gift-artwork] create rejected',r.status);return json({error:r.status===429?'Pracownia ilustracji jest zajęta. Spróbuj później.':r.status===409?'To zlecenie ma już inny opis. Odśwież kreator.':'Nie udało się przyjąć zlecenia. Spróbuj ponownie.'},[400,409,429,503].includes(r.status)?r.status:502,extra);}
 const v=await r.json();if(!validJob(v))throw Error();await acceptArtwork(reservation.key,v.artworkId);console.info('[gift-artwork] accepted',v.artworkId,v.status);const receipt=seal({kind:'job',owner,artworkId:v.artworkId,expires},c.secret);return json(clientJob(v,receipt),202,extra);
 }catch{console.warn('[gift-artwork] create could not be confirmed');return json({error:'Nie udało się potwierdzić zlecenia. Spróbuj ponownie — ten sam opis nie utworzy drugiego zadania.'},502,extra);}
}
export async function GET(req:Request){
 try{const c=config(),url=new URL(req.url);if(url.searchParams.get('session')==='1'){const existing=session(req,c.secret);const recovered=existing?await recoverArtwork(String(existing.owner),c.secret):null;const recoveredReceipt=recovered?seal({kind:'job',owner:existing!.owner,artworkId:recovered,expires:Date.now()+30*86400000},c.secret):null;const token=seal({kind:'session',owner:existing?.owner||randomUUID(),expires:Date.now()+30*86400000},c.secret);return json({ready:!!existing,recoveredReceipt,limited:artworkLimited(),limitStartsAt:ARTWORK_LIMIT_START,serverNow:Date.now(),generationAllowed:existing?await artworkAllowance(String(existing.owner),c.secret):true},200,{'Set-Cookie':`${cookieName}=${token}; Path=/api/event-gifts; HttpOnly; SameSite=Strict; Max-Age=2592000${(req.headers.get('host')||'').startsWith('127.0.0.1:')?'':'; Secure'}`});}const receipt=url.searchParams.get('receipt')||'',job=unseal(receipt,c.secret),s=session(req,c.secret);if(!s||!job||job.kind!=='job'||job.owner!==s.owner||!validId(job.artworkId))return json({error:'Dostęp do tej ilustracji wygasł lub należy do innej sesji.'},403);
 const r=await upstream('/artwork/'+job.artworkId,c);if(!r.ok)return json({error:'Nie udało się pobrać statusu ilustracji.'},r.status===404?404:502);const v=await r.json();if(!validJob(v,job.artworkId))throw Error();
 if(url.searchParams.get('image')!=='1')return json(clientJob(v,receipt));
 if(v.status!=='SUCCEEDED')return json({error:'Ilustracja nie jest jeszcze gotowa.'},409);
 // Fetch a fresh short-lived PNG link from Events for every image read.
 const png=await fetch(safeArtworkUrl(v.pngUrl,c.origin,job.artworkId),{redirect:'error',cache:'no-store',signal:AbortSignal.timeout(20000)});
 if(!png.ok||!png.headers.get('content-type')?.includes('image/png')||Number(png.headers.get('content-length')||0)>10000000)throw Error();
 const reader=png.body?.getReader();if(!reader)throw Error();const parts:Uint8Array[]=[];let size=0;for(;;){const {done,value}=await reader.read();if(done)break;size+=value.length;if(size>10000000){await reader.cancel();throw Error();}parts.push(value);}const data=Buffer.concat(parts);if(data.subarray(0,8).toString('hex')!=='89504e470d0a1a0a')throw Error();return new Response(new Uint8Array(await brandGiftArtwork(data)),{headers:{...headers,'Content-Type':'image/png','X-Content-Type-Options':'nosniff'}});
 }catch{return json({error:'Nie udało się pobrać ilustracji. Spróbuj ponownie.'},502);}
}
