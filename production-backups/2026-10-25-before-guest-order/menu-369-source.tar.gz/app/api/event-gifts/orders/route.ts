import {createHmac} from 'node:crypto';
import {seal,unseal,validId} from '../../../../lib/event-gift-artwork-core';
import {checkoutInput,testTicketAvailable,safeGiftCheckoutUrl,safeGiftOrderUrl} from '../../../../lib/event-gift-checkout';

export const dynamic='force-dynamic';
const base='/api/integrations/menu/gifts/v1';
const headers={'Cache-Control':'private, no-store','Referrer-Policy':'no-referrer'};
const states=['DRAFT','PENDING_PAYMENT','PAID','ISSUED','PAYMENT_FAILED','EXPIRED','CANCELLED','REFUND_PENDING','PARTIALLY_REFUNDED','REFUNDED'];
function json(value:unknown,status=200,extra:Record<string,string>={}){return Response.json(value,{status,headers:{...headers,...extra}});}
function config(){const secret=process.env.MENU_EVENT_OS_SECRET?.trim();const origin=new URL(process.env.EVENT_OS_APP_URL||'https://events.mbstudio.online');if(!secret||secret.length<32||origin.protocol!=='https:'||origin.username||origin.password||origin.pathname!=='/'||origin.search||origin.hash)throw Error();return {secret,origin:origin.origin};}
function cookie(req:Request,name:string,secret:string){return unseal(req.headers.get('cookie')?.split(';').map(part=>part.trim()).find(part=>part.startsWith(name+'='))?.slice(name.length+1)||'',secret);}
async function upstream(path:string,settings:ReturnType<typeof config>,init:RequestInit={}){return fetch(settings.origin+base+path,{...init,headers:{Authorization:`Bearer ${settings.secret}`,Accept:'application/json',...init.headers},cache:'no-store',redirect:'error',signal:AbortSignal.timeout(30000)});}
export async function POST(req:Request){
 if(req.headers.get('origin')!=='https://menu.martabanaszek.pl')return json({error:'Otwórz kreator w menu Atelier.'},403);
 let input:ReturnType<typeof checkoutInput>;
 let stage='configuration';
 try{const raw=await req.text();if(raw.length>12000)throw Error('Zbyt długie dane zamówienia.');input=checkoutInput(JSON.parse(raw));}catch(error){return json({error:error instanceof Error?error.message:'Sprawdź dane zamówienia.'},400);}
 try{
 const settings=config(),session=cookie(req,'mb_gift_artwork',settings.secret),job=unseal(input.receipt,settings.secret);
 if(session?.kind!=='session'||!validId(session.owner)||job?.kind!=='job'||job.owner!==session.owner||!validId(job.artworkId))return json({error:'Wróć do grafiki i zachowaj obraz w tej przeglądarce.'},403);
 stage='capabilities';
 const capabilityResponse=await upstream('/capabilities',settings);
 if(!capabilityResponse.ok||!testTicketAvailable(await capabilityResponse.json()))return json({error:'Zakup biletu testowego jest chwilowo niedostępny. Spróbuj ponownie później.'},503);
 const orderId=createHmac('sha256',settings.secret).update('gift-order:'+session.owner+':'+input.orderId).digest('hex');
 const id=orderId.slice(0,8)+'-'+orderId.slice(8,12)+'-4'+orderId.slice(13,16)+'-a'+orderId.slice(17,20)+'-'+orderId.slice(20,32);
 stage='artwork-approval';
 const approved=await upstream('/artwork/'+job.artworkId+'/approve',settings,{method:'POST',headers:{'Content-Type':'application/json','Idempotency-Key':'approve-'+id},body:JSON.stringify({orderId:id})});
 if(!approved.ok)return json({error:'Nie udało się zatwierdzić grafiki. Zachowaj gotowy obraz i spróbuj ponownie.'},approved.status===409?409:502);
 const {receipt,orderId:clientOrderId,...details}=input;
 void receipt;void clientOrderId;
 stage='order-request';
 const response=await upstream('/orders',settings,{method:'POST',headers:{'Content-Type':'application/json','Idempotency-Key':'order-'+id},body:JSON.stringify({...details,orderId:id,artworkId:job.artworkId,templateId:'atelier-menu-v1',returnUrl:'https://menu.martabanaszek.pl/voucher/zamowienie'})});
 if(!response.ok){const failure=await response.json().catch(()=>null);const candidate=failure?.code??failure?.error?.code;const code=typeof candidate==='string'&&/^[A-Z_]{1,80}$/.test(candidate)?candidate:'UPSTREAM_REJECTED';console.warn('[gift-checkout] order rejected',response.status,code);return json({error:response.status===409?'Dane zamówienia zmieniły się po rozpoczęciu zakupu. Przywróć wcześniejsze dane lub skontaktuj się z obsługą.':response.status===400?'Events odrzuciło dane zamówienia. Zachowaj ten ekran i zgłoś problem obsłudze.':'Nie udało się utworzyć płatności. Spróbuj ponownie — to samo zgłoszenie nie utworzy drugiego zamówienia.'},[400,409,429,503].includes(response.status)?response.status:502);}
 stage='order-response';
 const value=await response.json();if(value.orderId!==id)throw Error();
 stage='checkout-url';
 const checkoutUrl=safeGiftCheckoutUrl(value.checkoutUrl);
 stage='status-url';
 const statusUrl=safeGiftOrderUrl(value.statusUrl,settings.origin,id);
 const token=seal({kind:'order',orderId:id,statusUrl,checkoutUrl,expires:Date.now()+30*86400000},settings.secret);
 return json({orderId:id,checkoutUrl,statusPage:'/voucher/zamowienie'},201,{'Set-Cookie':`mb_gift_order=${token}; Path=/api/event-gifts; HttpOnly; Secure; SameSite=Lax; Max-Age=2592000`});
 }catch{console.warn('[gift-checkout] confirmation unavailable',stage);return json({error:'Nie udało się potwierdzić zamówienia. Ponów próbę z tymi samymi danymi.'},502);}
}
export async function GET(req:Request){
 try{
 const settings=config(),order=cookie(req,'mb_gift_order',settings.secret);
 if(order?.kind!=='order'||!validId(order.orderId))return json({error:'Brak zamówienia w tej przeglądarce. Otwórz status na urządzeniu użytym przy zakupie.'},404);
 const statusUrl=safeGiftOrderUrl(order.statusUrl,settings.origin,order.orderId);
 const response=await fetch(statusUrl,{cache:'no-store',redirect:'error',signal:AbortSignal.timeout(15000)});
 if(!response.ok)return json({error:'Nie udało się sprawdzić płatności. Spróbuj ponownie za chwilę.'},502);
 const value=await response.json();if(value.orderId!==order.orderId||!states.includes(value.status))throw Error();
 const pdfUrl=value.pdfUrl&&['PAID','ISSUED'].includes(value.status)?safeGiftOrderUrl(value.pdfUrl,settings.origin,order.orderId,'pdf'):null;
 return json({orderId:order.orderId,status:value.status,emailDelivery:['not_ready','queued','sent','failed'].includes(value.emailDelivery)?value.emailDelivery:'not_ready',pdfUrl,checkoutUrl:['PENDING_PAYMENT','PAYMENT_FAILED'].includes(value.status)&&value.checkoutUrl?safeGiftCheckoutUrl(value.checkoutUrl):null});
 }catch{return json({error:'Nie udało się sprawdzić zamówienia. Spróbuj ponownie za chwilę.'},502);}
}
