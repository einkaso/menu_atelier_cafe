import {randomUUID} from 'node:crypto';
import {sql} from 'drizzle-orm';
import {getDb} from '../../../db';
import {inventoryStages,inventoryStageItems,inventoryEvents,inventoryCountEntries} from '../../../db/schema';
import {currentAdmin} from '../../../lib/admin-auth';
import {currentWaiter} from '../../../lib/waiter-auth';
import {kegQuantity} from '../../../lib/inventory-special';
export const dynamic='force-dynamic';
async function identity(request:Request){const a=await currentAdmin();if(a)return {admin:true,id:a.username,name:a.employeeName||a.username};const w=await currentWaiter(request);return w?{admin:false,id:w.dotykackaId,name:w.name}:null;}
export async function GET(request:Request){
 const actor=await identity(request);if(!actor)return Response.json({error:'Zaloguj się.'},{status:401});if(!actor.admin)return Response.json({error:'Ten obszar jest dostępny wyłącznie w panelu administratora. Przydzielone zadania znajdziesz w swojej inwentaryzacji.'},{status:403});
 const products=await getDb().execute(sql`select k.*,p.name,p.unit,p.stock_quantity from inventory_keg_settings k join inventory_catalog_products p on p.dotykacka_id=k.product_id where not p.deleted order by p.name`);
 const history=await getDb().execute(sql`select c.*,p.name,s.status from inventory_keg_counts c join inventory_stages s on s.id=c.stage_id join inventory_catalog_products p on p.dotykacka_id=c.product_id order by c.counted_at desc limit 30`);
 return Response.json({admin:actor.admin,products,history});
}
export async function POST(request:Request){
 const actor=await identity(request);if(!actor)return Response.json({error:'Zaloguj się.'},{status:401});if(!actor.admin)return Response.json({error:'Ten obszar jest dostępny wyłącznie w panelu administratora. Przydzielone zadania znajdziesz w swojej inwentaryzacji.'},{status:403});
 const b=await request.json().catch(()=>null);if(!b||typeof b!=='object'||Array.isArray(b))return Response.json({error:'Nieprawidłowe dane.'},{status:400});
 if(b.action==='CAPACITY'){
 if(!actor.admin)return Response.json({error:'Tylko administrator może ustalić pojemność.'},{status:403});
 if(typeof b.capacity!=='number'||![20,30,50].includes(b.capacity))return Response.json({error:'Wybierz pojemność beczki.'},{status:400});
 const changed=await getDb().execute(sql`update inventory_keg_settings set capacity_liters=${b.capacity},updated_by=${actor.id},updated_at=now() where product_id=${String(b.productId)} returning product_id`);
 return changed.length?Response.json({ok:true}):Response.json({error:'Nie znaleziono kega.'},{status:404});
 }
 if(b.action!=='COUNT'||typeof b.requestId!=='string'||!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(b.requestId)||b.confirmedReplacement!==true)return Response.json({error:'Potwierdź liczenie bezpośrednio przy wymianie pustej beczki, przed nalaniem z nowej.'},{status:400});
 return getDb().transaction(async tx=>{
 await tx.execute(sql`select pg_advisory_xact_lock(hashtextextended(${b.requestId},0))`);
 const existing=await tx.execute(sql`select * from inventory_keg_counts where request_id=${b.requestId}::uuid`);
 if(existing.length){const e=existing[0];if(e.actor_id!==actor.id||e.product_id!==b.productId||Number(e.full_spare_kegs)!==b.fullSpareKegs||e.connected_full!==b.connectedFull)return Response.json({error:'Ten zapis został już wykonany z innymi danymi.'},{status:409});return Response.json({ok:true,stageId:e.stage_id});}
 const [p]=await tx.execute(sql`select k.*,p.name,p.unit,p.stock_quantity from inventory_keg_settings k join inventory_catalog_products p on p.dotykacka_id=k.product_id where k.product_id=${String(b.productId)} and not p.deleted for update of k`);
 if(!p||p.capacity_liters==null)return Response.json({error:'Administrator musi najpierw potwierdzić pojemność beczki.'},{status:409});
 if(p.stock_quantity==null)return Response.json({error:'Brak stanu magazynowego. Odśwież synchronizację.'},{status:409});
 let amount;try{amount=kegQuantity(b.fullSpareKegs,b.connectedFull,Number(p.capacity_liters),String(p.unit));}catch(e){return Response.json({error:(e as Error).message},{status:400});}
 const now=new Date();const note=`Wymiana pustej beczki. Pełne w zapasie: ${b.fullSpareKegs}; nowa podłączona: ${b.connectedFull?'tak':'nie'}; pojemność: ${p.capacity_liters} l; razem ${amount.liters} l. ${typeof b.note==='string'?b.note.trim().slice(0,300):''}`;
 const [stage]=await tx.insert(inventoryStages).values({externalId:randomUUID(),title:`Inwentaryzacja specjalna: ${p.name}`,categoryDotykackaId:'SPECIAL_KEGS',categoryName:'Inwentaryzacja specjalna',assignedEmployeeDotykackaId:actor.id,assignedEmployeeName:actor.name,locations:['Zapas i nowa beczka przy kranie'],expectedSnapshotAt:now,status:'SUBMITTED',startedAt:now,submittedAt:now,createdBy:actor.id,workerNote:note}).returning();
 const [item]=await tx.insert(inventoryStageItems).values({stageId:stage.id,productDotykackaId:String(p.product_id),productName:String(p.name),unit:String(p.unit),expectedQuantity:String(p.stock_quantity),countedQuantity:String(amount.quantity),countStatus:'COUNTED',countedAt:now,reasonCode:'INNE',workerNote:note}).returning();
 await tx.insert(inventoryCountEntries).values({itemId:item.id,location:'Zapas i nowa beczka przy kranie',quantity:String(amount.quantity),wholeContainers:amount.kegs,note,createdByName:actor.name});
 await tx.execute(sql`insert into inventory_keg_counts(request_id,product_id,capacity_liters,full_spare_kegs,connected_full,liters,stage_id,actor_id,actor_name,note,counted_at) values(${b.requestId}::uuid,${String(p.product_id)},${Number(p.capacity_liters)},${b.fullSpareKegs},${b.connectedFull},${amount.liters},${stage.id},${actor.id},${actor.name},${note},${now.toISOString()}::timestamptz)`);
 await tx.insert(inventoryEvents).values({stageId:stage.id,actorType:actor.admin?'ADMIN':'WORKER',actorId:actor.id,actorName:actor.name,action:'KEG_REPLACEMENT_COUNTED',details:{note,liters:amount.liters,fullSpareKegs:b.fullSpareKegs,connectedFull:b.connectedFull}});
 return Response.json({ok:true,stageId:stage.id},{status:201});
 });
}
