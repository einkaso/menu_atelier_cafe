import { eq } from "drizzle-orm";
import { z } from "zod";
import { getDb } from "../../../../../../db";
import { kitchenRecipes, kitchenRecipeVersions, type StaffManualMedia } from "../../../../../../db/schema";
import { currentAdmin } from "../../../../../../lib/admin-auth";
import { KitchenError, kitchenErrorResponse } from "../../../../../../lib/kitchen-recipes-server";
import { importStaffManualMedia } from "../../../../../../lib/staff-manual-media";

export const dynamic = "force-dynamic";
type Context = { params: Promise<{ id: string }> };
const revisionSchema = z.coerce.number().int().positive();
const deletionSchema = z.object({ expectedRevision: revisionSchema, mediaId: z.string().regex(/^[a-f0-9]{16}$/) }).strict();

export async function POST(request: Request, context: Context) {
  const admin = await currentAdmin();
  if (!admin) return Response.json({ error: "Unauthorized" }, { status: 401 });
  const id = Number((await context.params).id);
  if (!Number.isSafeInteger(id) || id < 1) return Response.json({ error: "Nieprawidłowa wersja." }, { status: 400 });
  const form = await request.formData().catch(() => null);
  const revision = revisionSchema.safeParse(form?.get("expectedRevision"));
  const files = (form?.getAll("media") ?? []).filter((item): item is File => item instanceof File && item.size > 0);
  if (!revision.success || !files.length || files.length > 8) return Response.json({ error: "Wybierz od 1 do 8 zdjęć lub filmów." }, { status: 400 });
  try {
    const [source] = await getDb().select().from(kitchenRecipeVersions).where(eq(kitchenRecipeVersions.id, id));
    if (!source) throw new KitchenError("Wersja nie istnieje.", 404);
    if (source.status !== "DRAFT" || source.editRevision !== revision.data) throw new KitchenError("Pliki można dodawać tylko do aktualnego szkicu.", 409);
    if (source.media.length + files.length > 8) throw new KitchenError("Przepis może mieć maksymalnie 8 plików.");
    const imported: StaffManualMedia[] = [];
    for (const file of files) imported.push(await importStaffManualMedia(id, file, "recipe"));
    await getDb().transaction(async (tx) => {
      const [recipe] = await tx.select().from(kitchenRecipes).where(eq(kitchenRecipes.id, source.recipeId)).for("update");
      const [version] = await tx.select().from(kitchenRecipeVersions).where(eq(kitchenRecipeVersions.id, id));
      if (!recipe || recipe.archived || !version || version.status !== "DRAFT" || version.editRevision !== revision.data) throw new KitchenError("Szkic został zmieniony. Odśwież przepis.", 409);
      const media = [...version.media, ...imported.filter((item) => !version.media.some((old) => old.id === item.id))];
      await tx.update(kitchenRecipeVersions).set({ media, editRevision: version.editRevision + 1, updatedBy: admin.username, updatedAt: new Date() }).where(eq(kitchenRecipeVersions.id, id));
    });
    return Response.json({ status: "ok" });
  } catch (error) { return kitchenErrorResponse(error); }
}

export async function DELETE(request: Request, context: Context) {
  const admin = await currentAdmin();
  if (!admin) return Response.json({ error: "Unauthorized" }, { status: 401 });
  const id = Number((await context.params).id);
  const parsed = deletionSchema.safeParse(await request.json().catch(() => null));
  if (!Number.isSafeInteger(id) || id < 1 || !parsed.success) return Response.json({ error: "Nieprawidłowy plik." }, { status: 400 });
  try {
    const [source] = await getDb().select().from(kitchenRecipeVersions).where(eq(kitchenRecipeVersions.id, id));
    if (!source) throw new KitchenError("Wersja nie istnieje.", 404);
    await getDb().transaction(async (tx) => {
      const [recipe] = await tx.select().from(kitchenRecipes).where(eq(kitchenRecipes.id, source.recipeId)).for("update");
      const [version] = await tx.select().from(kitchenRecipeVersions).where(eq(kitchenRecipeVersions.id, id));
      if (!recipe || recipe.archived || !version || version.status !== "DRAFT" || version.editRevision !== parsed.data.expectedRevision) throw new KitchenError("Pliki można zmieniać tylko w aktualnym szkicu.", 409);
      if (!version.media.some((item) => item.id === parsed.data.mediaId)) throw new KitchenError("Plik nie istnieje.", 404);
      await tx.update(kitchenRecipeVersions).set({ media: version.media.filter((item) => item.id !== parsed.data.mediaId), editRevision: version.editRevision + 1, updatedBy: admin.username, updatedAt: new Date() }).where(eq(kitchenRecipeVersions.id, id));
      // Never delete the file: earlier immutable versions may still reference it.
    });
    return Response.json({ status: "ok" });
  } catch (error) { return kitchenErrorResponse(error); }
}
