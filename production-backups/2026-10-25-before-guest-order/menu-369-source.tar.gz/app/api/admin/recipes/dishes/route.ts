import { asc, eq } from "drizzle-orm";
import { getDb } from "../../../../../db";
import { menuProducts, productContent, kitchenDishManualDrafts } from "../../../../../db/schema";
import { currentAdmin } from "../../../../../lib/admin-auth";
export const dynamic = "force-dynamic";
export async function GET() {
  if (!(await currentAdmin())) return Response.json({ error: "Unauthorized" }, { status: 401 });
  // Editing must not depend on price, menu visibility or employee publication.
  const rows = await getDb().select({ id: menuProducts.id, name: menuProducts.name,
    deleted: menuProducts.deleted, featured: productContent.featured,
    instructions: productContent.staffInstructions, draft: kitchenDishManualDrafts.instructions,
  }).from(menuProducts).leftJoin(productContent, eq(productContent.productId, menuProducts.id))
    .leftJoin(kitchenDishManualDrafts, eq(kitchenDishManualDrafts.productId, menuProducts.id)).orderBy(asc(menuProducts.name));
  return Response.json({ dishes: rows.map(({ instructions, draft, ...row }) => ({ ...row,
    hasPublished: !!instructions?.trim(), hasDraft: draft !== null,
  })) }, { headers: { "Cache-Control": "private, no-store" } });
}
