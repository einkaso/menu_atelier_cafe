import { asc, eq, sql } from "drizzle-orm";
import { z } from "zod";
import { getDb } from "../../../../db";
import { kitchenDishCards, kitchenDishComponents, kitchenRecipes, kitchenRecipeVersions, menuProducts } from "../../../../db/schema";
import { currentAdmin } from "../../../../lib/admin-auth";
import { recipeContentSchema, recipePublicationIssues } from "../../../../lib/kitchen-recipes";
import { KitchenError, kitchenErrorResponse } from "../../../../lib/kitchen-recipes-server";

export const dynamic = "force-dynamic";

export async function GET() {
  if (!(await currentAdmin())) return Response.json({ error: "Unauthorized" }, { status: 401 });
  const db = getDb();
  const [recipes, versions, usages, plannedUsages] = await Promise.all([
    db.select().from(kitchenRecipes).orderBy(asc(kitchenRecipes.id)),
    db.select().from(kitchenRecipeVersions).orderBy(asc(kitchenRecipeVersions.version)),
    db.select({ recipeId: kitchenRecipeVersions.recipeId, recipeVersionId: kitchenRecipeVersions.id, productId: menuProducts.id, productName: menuProducts.name })
      .from(kitchenDishComponents).innerJoin(kitchenRecipeVersions, eq(kitchenDishComponents.recipeVersionId, kitchenRecipeVersions.id))
      .innerJoin(menuProducts, eq(kitchenDishComponents.productId, menuProducts.id)),
    db.select({ recipeId: kitchenRecipes.id, productId: menuProducts.id, productName: menuProducts.name })
      .from(kitchenDishComponents).innerJoin(kitchenRecipes, eq(kitchenDishComponents.pendingRecipeId, kitchenRecipes.id))
      .innerJoin(menuProducts, eq(kitchenDishComponents.productId, menuProducts.id)),
  ]);
  return Response.json({ recipes: recipes.map((recipe) => ({
    ...recipe, versions: versions.filter((item) => item.recipeId === recipe.id), usages: [
      ...usages.filter((item) => item.recipeId === recipe.id),
      ...plannedUsages.filter((item) => item.recipeId === recipe.id).map((item) => ({ ...item, recipeVersionId: null, planned: true })),
    ],
  })) }, { headers: { "Cache-Control": "private, no-store" } });
}

export async function POST(request: Request) {
  const admin = await currentAdmin();
  if (!admin) return Response.json({ error: "Unauthorized" }, { status: 401 });
  const parsed = recipeContentSchema.safeParse(await request.json().catch(() => null));
  if (!parsed.success) return Response.json({ error: "Sprawdź nazwę i pola przepisu." }, { status: 400 });
  try {
    const recipe = await getDb().transaction(async (tx) => {
      await tx.execute(sql`SELECT pg_advisory_xact_lock(732710329)`);
      const [recipe] = await tx.insert(kitchenRecipes).values({ createdBy: admin.username }).returning();
      await tx.insert(kitchenRecipeVersions).values({ recipeId: recipe.id, version: 1, content: parsed.data, updatedBy: admin.username });
      return recipe;
    });
    return Response.json({ recipe }, { status: 201 });
  } catch (error) { return kitchenErrorResponse(error); }
}

const actionSchema = z.object({
  recipeId: z.number().int().positive(),
  action: z.enum(["SAVE", "PUBLISH", "NEW_VERSION", "ARCHIVE", "RESTORE"]),
  versionId: z.number().int().positive().optional(), expectedRevision: z.number().int().positive().optional(),
  content: recipeContentSchema.optional(),
}).strict();

export async function PATCH(request: Request) {
  const admin = await currentAdmin();
  if (!admin) return Response.json({ error: "Unauthorized" }, { status: 401 });
  const parsed = actionSchema.safeParse(await request.json().catch(() => null));
  if (!parsed.success) return Response.json({ error: "Nieprawidłowe dane przepisu." }, { status: 400 });
  const body = parsed.data;
  try {
    await getDb().transaction(async (tx) => {
      await tx.execute(sql`SELECT pg_advisory_xact_lock(732710329)`);
      const [recipe] = await tx.select().from(kitchenRecipes).where(eq(kitchenRecipes.id, body.recipeId)).for("update");
      if (!recipe) throw new KitchenError("Przepis nie istnieje.", 404);
      if (body.action === "ARCHIVE" || body.action === "RESTORE") {
        // Archiving prevents new assignments; previously approved dishes retain their recipes.
        await tx.update(kitchenRecipes).set({ archived: body.action === "ARCHIVE" }).where(eq(kitchenRecipes.id, recipe.id));
        return;
      }
      if (recipe.archived) throw new KitchenError("Najpierw przywróć przepis z archiwum.", 409);
      const versions = await tx.select().from(kitchenRecipeVersions).where(eq(kitchenRecipeVersions.recipeId, recipe.id)).orderBy(asc(kitchenRecipeVersions.version));
      if (body.action === "NEW_VERSION") {
        if (versions.some((item) => item.status === "DRAFT")) throw new KitchenError("Ten przepis ma już szkic. Otwórz go zamiast tworzyć kolejny.", 409);
        const source = versions.find((item) => item.id === body.versionId) ?? versions.at(-1);
        if (!source) throw new KitchenError("Brak wersji źródłowej.", 404);
        await tx.insert(kitchenRecipeVersions).values({ recipeId: recipe.id, version: (versions.at(-1)?.version ?? 0) + 1, content: source.content, media: source.media, updatedBy: admin.username });
        return;
      }
      const version = versions.find((item) => item.id === body.versionId);
      if (!version) throw new KitchenError("Wersja nie istnieje.", 404);
      if (version.status !== "DRAFT") throw new KitchenError("Zatwierdzona wersja jest niezmienna. Utwórz nową wersję.", 409);
      if (version.editRevision !== body.expectedRevision) throw new KitchenError("Ktoś zmienił szkic. Odśwież przepis przed zapisem.", 409);
      const content = body.content ?? version.content;
      if (body.action === "PUBLISH") {
        const issues = recipePublicationIssues(content);
        if (issues.length) throw new KitchenError(issues.join(" "));
      }
      await tx.update(kitchenRecipeVersions).set({
        content, editRevision: version.editRevision + 1, updatedBy: admin.username, updatedAt: new Date(),
        ...(body.action === "PUBLISH" ? { status: "PUBLISHED" as const, publishedAt: new Date() } : {}),
      }).where(eq(kitchenRecipeVersions.id, version.id));
      if (body.action === "PUBLISH") {
        // Resolve only planned links. Explicit version assignments stay pinned.
        const linked = await tx.update(kitchenDishComponents).set({recipeVersionId: version.id, pendingRecipeId: null})
          .where(eq(kitchenDishComponents.pendingRecipeId, recipe.id)).returning({productId: kitchenDishComponents.productId});
        for (const productId of [...new Set(linked.map(item => item.productId))].sort((a,b)=>a-b)) {
          await tx.update(kitchenDishCards).set({revision: sql`${kitchenDishCards.revision} + 1`, updatedBy: admin.username, updatedAt: new Date()}).where(eq(kitchenDishCards.productId, productId));
        }
      }
    });
    return Response.json({ status: "ok" });
  } catch (error) { return kitchenErrorResponse(error); }
}
