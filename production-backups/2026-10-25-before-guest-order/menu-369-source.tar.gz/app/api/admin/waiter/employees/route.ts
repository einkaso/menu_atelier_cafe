import { and, asc, eq, or, isNotNull } from "drizzle-orm";
import { getDb } from "../../../../../db";
import { adminUsers, waiterEmployees, waiterEmployeeThankYouMedia, waiterSurveyQuestions, waiterTables } from "../../../../../db/schema";
import { isAdmin } from "../../../../../lib/admin-auth";
import { employeeQrPayload } from "../../../../../lib/workforce-secrets";
import QRCode from "qrcode";

export const dynamic = "force-dynamic";

export async function GET() {
  if (!(await isAdmin())) return Response.json({ error: "Unauthorized" }, { status: 401 });
  const [employees, administrators, tables, surveyQuestions, thankYouMedia] = await Promise.all([
    getDb().select({
      dotykackaId: waiterEmployees.dotykackaId,
      name: waiterEmployees.name,
      barcode: waiterEmployees.barcode,
      enabled: waiterEmployees.enabled,
      deleted: waiterEmployees.deleted,
      accessLevel: waiterEmployees.accessLevel,
      canManageMenuVisibility: waiterEmployees.canManageMenuVisibility,
      canControlLighting: waiterEmployees.canControlLighting,
      canControlClimate: waiterEmployees.canControlClimate,
      canControlHeating: waiterEmployees.canControlHeating,
    canViewReports: waiterEmployees.canViewReports,
      canControlXr18: waiterEmployees.canControlXr18,
      xr18PinHash: waiterEmployees.xr18PinHash,
      canControlRooms: waiterEmployees.canControlRooms,
      thankYouMessage: waiterEmployees.thankYouMessage,
      includeInSchedule: waiterEmployees.includeInSchedule,
      hourlyRate: waiterEmployees.hourlyRate,
      contactPhone: waiterEmployees.contactPhone,
      contactEmail: waiterEmployees.contactEmail,
      terminationDate: waiterEmployees.terminationDate,
      pinHash: waiterEmployees.pinHash,
      syncedAt: waiterEmployees.syncedAt,
    }).from(waiterEmployees).where(or(and(eq(waiterEmployees.enabled, true), eq(waiterEmployees.deleted, false)), isNotNull(waiterEmployees.terminationDate))).orderBy(asc(waiterEmployees.name)),
    getDb().select({
      employeeDotykackaId: adminUsers.employeeDotykackaId,
      username: adminUsers.username,
      enabled: adminUsers.enabled,
      lastLoginAt: adminUsers.lastLoginAt,
    }).from(adminUsers),
    getDb().select({
      dotykackaId: waiterTables.dotykackaId,
      name: waiterTables.name,
      display: waiterTables.display,
      deleted: waiterTables.deleted,
      syncedAt: waiterTables.syncedAt,
    }).from(waiterTables).orderBy(asc(waiterTables.name)),
    getDb().select().from(waiterSurveyQuestions).orderBy(asc(waiterSurveyQuestions.sortOrder), asc(waiterSurveyQuestions.id)),
    getDb().select({
      id: waiterEmployeeThankYouMedia.id,
      employeeDotykackaId: waiterEmployeeThankYouMedia.employeeDotykackaId,
      mediaPath: waiterEmployeeThankYouMedia.mediaPath,
      mediaType: waiterEmployeeThankYouMedia.mediaType,
    }).from(waiterEmployeeThankYouMedia).orderBy(asc(waiterEmployeeThankYouMedia.id)),
  ]);
  const adminByEmployee = new Map(administrators.map((administrator) => [administrator.employeeDotykackaId, administrator]));
  const mediaByEmployee = new Map<string, typeof thankYouMedia>();
  for (const media of thankYouMedia) mediaByEmployee.set(media.employeeDotykackaId, [...(mediaByEmployee.get(media.employeeDotykackaId) ?? []), media]);
  const employeesWithQr = await Promise.all(employees.map(async ({ pinHash, xr18PinHash, ...employee }) => {
      const administrator = adminByEmployee.get(employee.dotykackaId);
      return {
        ...employee,
        qrDataUrl: employee.barcode ? await QRCode.toDataURL(
          employeeQrPayload(employee.dotykackaId, employee.barcode),
          { width: 420, margin: 2, color: { dark: "#082f3c", light: "#ffffff" } },
        ) : null,
        pinConfigured: Boolean(pinHash),
        xr18PinConfigured: Boolean(xr18PinHash),
        adminConfigured: Boolean(administrator?.enabled),
        adminUsername: administrator?.username ?? null,
        adminLastLoginAt: administrator?.lastLoginAt ?? null,
        thankYouMedia: mediaByEmployee.get(employee.dotykackaId) ?? [],
      };
    }));
  return Response.json({
    employees: employeesWithQr,
    tables,
    surveyQuestions,
    posActionsEnabled: process.env.WAITER_POS_ACTIONS_ENABLED === "true",
  });
}
