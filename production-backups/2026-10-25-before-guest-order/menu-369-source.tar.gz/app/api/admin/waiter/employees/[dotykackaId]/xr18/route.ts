import { and, eq } from "drizzle-orm";
import { getDb } from "../../../../../../../db";
import { waiterEmployees } from "../../../../../../../db/schema";
import { isAdmin } from "../../../../../../../lib/admin-auth";
import { hashWaiterPin, verifyWaiterPin } from "../../../../../../../lib/waiter-auth";
import { validXr18Pin } from "../../../../../../../lib/xr18-access";

export async function PUT(request: Request, context: { params: Promise<{ dotykackaId: string }> }) {
  if (!(await isAdmin())) return Response.json({ error: "Unauthorized" }, { status: 401 });
  const { dotykackaId } = await context.params;
  const body = await request.json().catch(() => ({})) as { enabled?: unknown; pin?: unknown };
  if (typeof body.enabled !== "boolean") return Response.json({ error: "Nieprawidłowe uprawnienie." }, { status: 400 });
  const pin = typeof body.pin === "string" ? body.pin : "";
  if (pin && !validXr18Pin(pin)) return Response.json({ error: "PIN XR18 musi mieć dokładnie 6 cyfr." }, { status: 400 });
  const [employee] = await getDb().select({
    id: waiterEmployees.id,
    pinHash: waiterEmployees.pinHash,
    xr18PinHash: waiterEmployees.xr18PinHash,
  }).from(waiterEmployees).where(and(
    eq(waiterEmployees.dotykackaId, dotykackaId),
    eq(waiterEmployees.enabled, true),
    eq(waiterEmployees.deleted, false),
  )).limit(1);
  if (!employee) return Response.json({ error: "Pracownik nie istnieje lub jest nieaktywny." }, { status: 404 });
  if (body.enabled && !pin && !employee.xr18PinHash) {
    return Response.json({ error: "Przy nadawaniu dostępu ustaw 6-cyfrowy PIN XR18." }, { status: 400 });
  }
  if (pin && employee.pinHash && await verifyWaiterPin(pin, employee.pinHash)) {
    return Response.json({ error: "Dodatkowy PIN XR18 musi różnić się od głównego PIN-u pracownika." }, { status: 409 });
  }
  await getDb().update(waiterEmployees).set({
    canControlXr18: body.enabled,
    ...(pin ? { xr18PinHash: await hashWaiterPin(pin) } : {}),
  }).where(eq(waiterEmployees.id, employee.id));
  return Response.json({ ok: true, canControlXr18: body.enabled, xr18PinConfigured: Boolean(pin || employee.xr18PinHash) });
}

export async function DELETE(_request: Request, context: { params: Promise<{ dotykackaId: string }> }) {
  if (!(await isAdmin())) return Response.json({ error: "Unauthorized" }, { status: 401 });
  const { dotykackaId } = await context.params;
  await getDb().update(waiterEmployees).set({ canControlXr18: false, xr18PinHash: null }).where(eq(waiterEmployees.dotykackaId, dotykackaId));
  return Response.json({ ok: true });
}
