import { readEventOsLifecycle } from "../../../../../lib/event-os-event-lifecycle";
import { asc } from "drizzle-orm";
import { getDb } from "../../../../../db";
import { eventOsEventProducts, eventOsEvents, eventOsOrders } from "../../../../../db/schema";
import { currentAdmin } from "../../../../../lib/admin-auth";

export const dynamic = "force-dynamic";

export async function GET() {
  if (!(await currentAdmin())) return Response.json({ error: "Unauthorized" }, { status: 401 });
  const db = getDb();
  const [events, orders, eventProducts, lifecycle] = await Promise.all([db.select().from(eventOsEvents).orderBy(asc(eventOsEvents.startsAt)), db.select().from(eventOsOrders), db.select().from(eventOsEventProducts), readEventOsLifecycle()]);
  return Response.json({ events: events.map((event) => {
    const rows = orders.filter((order) => order.eventExternalId === event.externalId);
    return {
      ...event,
      ...(lifecycle.events?.get(event.externalId) ? {
        cancelled: lifecycle.events.get(event.externalId)!.cancelled,
        status: lifecycle.events.get(event.externalId)!.cancelled ? "CANCELLED" : event.status === "CANCELLED" ? "COLLECTING" : event.status,
        finishedAt: lifecycle.events.get(event.externalId)!.finishedAt,
      } : {}),
      orderCount: rows.length,
      expectedGuests: new Set(rows.map((order) => order.ticketCode)).size,
      arrivedGuests: rows.filter((order) => ["ARRIVED", "SENT_TO_POS", "IN_SERVICE", "SETTLED"].includes(order.status)).length,
      forecastRevenue: rows.reduce((sum, order) => sum + Number(order.forecastTotal), 0),
      sentToPosRevenue: rows.filter((order) => ["SENT_TO_POS", "IN_SERVICE", "SETTLED"].includes(order.status)).reduce((sum, order) => sum + Number(order.forecastTotal), 0),
      selectedProductCount: eventProducts.filter((product) => product.eventExternalId === event.externalId && product.enabled).length,
    };
  }), lifecycleWarning: lifecycle.warning }, { headers: { "Cache-Control": "no-store" } });
}
