import { currentAdmin } from "../../../../../lib/admin-auth";
import { changeEventOsStatus, readEventOsOperations, EventOsOrderError } from "../../../../../lib/event-os-order-store";
import { ZodError } from "zod";
export const runtime = "nodejs";
export const dynamic = "force-dynamic";
const headers = { "Cache-Control": "no-store" };
export async function GET(request: Request) {
  if (!(await currentAdmin())) return Response.json({ error: "Unauthorized" }, { status: 401, headers });
  const eventId = new URL(request.url).searchParams.get("eventId") || "";
  if (!eventId || eventId.length > 160) return Response.json({ error: "Wybierz wydarzenie." }, { status: 400, headers });
  try { return Response.json({ orders: await readEventOsOperations(eventId) }, { headers }); } catch { return Response.json({ error: "Nie można odczytać zamówień." }, { status: 503, headers }); }
}
export async function POST(request: Request) {
  const admin = await currentAdmin(); if (!admin) return Response.json({ error: "Unauthorized" }, { status: 401, headers });
  if (request.headers.get("origin") !== (process.env.APP_ORIGIN || new URL(request.url).origin)) return Response.json({ error: "Niedozwolone źródło żądania." }, { status: 403, headers });
  if (Number(request.headers.get("content-length") || 0) > 10000) return Response.json({ error: "Za duże żądanie." }, { status: 413, headers });
  try {
    const text = await request.text(); if (Buffer.byteLength(text) > 10000) return Response.json({ error: "Za duże żądanie." }, { status: 413, headers });
    return Response.json({ order: await changeEventOsStatus(JSON.parse(text), admin.username) }, { headers });
  } catch (error) { return Response.json({ error: error instanceof EventOsOrderError ? error.message : "Sprawdź dane operacji." }, { status: error instanceof EventOsOrderError ? error.status : error instanceof ZodError || error instanceof SyntaxError ? 400 : 503, headers }); }
}
