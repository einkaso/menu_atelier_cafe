import { eq } from "drizzle-orm";
import { isAdmin } from "../../../../lib/admin-auth";
import { recoveredPhotos, storeReviewUpload } from "../../../../lib/recovered-photos";
import { getDb } from "../../../../db";
import { menuCategories, menuProducts, productContent, recoveredPhotoAssignments } from "../../../../db/schema";
export const dynamic = "force-dynamic";
export async function GET() {
  if (!await isAdmin()) return Response.json({ error: "Zaloguj się jako administrator." }, { status: 401 });
  const db = getDb();
  const [photos, assignments, products] = await Promise.all([
    recoveredPhotos(), db.select({ sha256: recoveredPhotoAssignments.sha256, imagePath: recoveredPhotoAssignments.imagePath, cover: productContent.imagePath, gallery: productContent.galleryPaths }).from(recoveredPhotoAssignments).leftJoin(productContent, eq(productContent.productId, recoveredPhotoAssignments.productId)),
    db.select({ id: menuProducts.id, name: menuProducts.name, category: menuCategories.name, imagePath: productContent.imagePath, gallery: productContent.galleryPaths }).from(menuProducts).leftJoin(menuCategories, eq(menuCategories.dotykackaId, menuProducts.dotykackaCategoryId)).leftJoin(productContent, eq(productContent.productId, menuProducts.id)).where(eq(menuProducts.deleted, false)),
  ]);
  const assigned = new Set(assignments.filter(a => a.cover === a.imagePath || a.gallery?.includes(a.imagePath)).map(a => a.sha256));
  return Response.json({ photos: photos.filter(p => !assigned.has(p.sha256)).map(p => ({ id: p.sha256, name: p.originalName, source: p.source, label: p.label, category: p.category, candidates: p.candidates ?? [] })), total: photos.length, products: products.map(p => ({ id: p.id, name: p.name, category: p.category || "Pozostałe", hasImage: Boolean(p.imagePath || p.gallery?.length) })) }, { headers: { "cache-control": "no-store" } });
}

export async function POST(request: Request) {
  if (!await isAdmin()) return Response.json({ error: "Zaloguj się jako administrator." }, { status: 401 });
  const origin = request.headers.get("origin");
  if (origin && origin !== new URL(request.url).origin && new URL(origin).host !== request.headers.get("host")) return Response.json({ error: "Nieprawidłowe źródło żądania." }, { status: 403 });
  if (Number(request.headers.get("content-length")) > 51 * 1024 * 1024) return Response.json({ error: "Plik jest za duży. Limit wynosi 50 MB." }, { status: 413 });
  try {
    const form = await request.formData();
    const file = form.get("image");
    if (!(file instanceof File)) return Response.json({ error: "Wybierz zdjęcie z urządzenia." }, { status: 400 });
    const result = await storeReviewUpload(file);
    return Response.json({ ok: true, id: result.photo.sha256, duplicate: result.duplicate });
  } catch(error) { return Response.json({ error: error instanceof Error ? error.message : "Nie udało się zapisać zdjęcia." }, { status: 422 }); }
}
