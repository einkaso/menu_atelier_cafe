import { createHash } from "node:crypto";
import { readFile } from "node:fs/promises";
import path from "node:path";
import { and, eq, sql } from "drizzle-orm";
import { currentAdmin } from "../../../../../lib/admin-auth";
import { recoveredPhotos, recoveredPath, recoveredRoot } from "../../../../../lib/recovered-photos";
import { importUploadedProductImage } from "../../../../../lib/image-import";
import { MAX_GALLERY_IMAGES, productGalleryImages } from "../../../../../lib/product-gallery";
import { getDb } from "../../../../../db";
import { menuProducts, productContent, recoveredPhotoAssignments } from "../../../../../db/schema";
export const dynamic = "force-dynamic";
type Context = { params: Promise<{ id: string }> };
export async function GET(_request: Request, context: Context) {
  if (!await currentAdmin()) return new Response(null, { status: 401 });
  const { id } = await context.params;
  if (!(await recoveredPhotos()).some(p => p.sha256 === id)) return new Response(null, { status: 404 });
  const image = await readFile(path.join(recoveredRoot, "thumbnails", id + ".webp"));
  return new Response(new Uint8Array(image), { headers: { "content-type": "image/webp", "cache-control": "private, no-store" } });
}
export async function POST(request: Request, context: Context) {
  const admin = await currentAdmin();
  if (!admin) return Response.json({ error: "Zaloguj się jako administrator." }, { status: 401 });
  const origin = request.headers.get("origin");
  if (origin && new URL(origin).host !== request.headers.get("host")) return Response.json({ error: "Nieprawidłowe źródło żądania." }, { status: 403 });
  const body = await request.json().catch(() => null);
  if (!Number.isSafeInteger(body?.productId) || body.productId < 1) return Response.json({ error: "Wybierz produkt." }, { status: 400 });
  const { id } = await context.params;
  const photo = (await recoveredPhotos()).find(p => p.sha256 === id);
  if (!photo) return Response.json({ error: "Nie znaleziono zdjęcia." }, { status: 404 });
  try {
    const result = await getDb().transaction(async tx => {
      await tx.execute(sql`select pg_advisory_xact_lock(hashtext(${'recovered-photo:' + id}))`);
      const [previous] = await tx.select().from(recoveredPhotoAssignments).where(eq(recoveredPhotoAssignments.sha256, id));
      if (previous) {
        const [old] = await tx.select().from(productContent).where(eq(productContent.productId, previous.productId));
        if (old && productGalleryImages(old.imagePath, old.galleryPaths).includes(previous.imagePath)) throw new Error("Zdjęcie jest już przypisane. Odśwież listę.");
      }
      const [product] = await tx.select().from(menuProducts).where(and(eq(menuProducts.id, body.productId), eq(menuProducts.deleted, false))).for("update");
      if (!product) throw new Error("Produkt nie istnieje.");
      await tx.insert(productContent).values({ productId: product.id }).onConflictDoNothing();
      const [content] = await tx.select().from(productContent).where(eq(productContent.productId, product.id)).for("update");
      const existing = productGalleryImages(content.imagePath, content.galleryPaths);
      if (existing.length >= MAX_GALLERY_IMAGES) throw new Error("Galeria produktu jest pełna.");
      const bytes = await readFile(recoveredPath(photo));
      if (createHash("sha256").update(bytes).digest("hex") !== id) throw new Error("Plik nie przeszedł kontroli integralności.");
      const imagePath = await importUploadedProductImage(product.id, new File([new Uint8Array(bytes)], photo.originalName));
      const combined = [...new Set([...existing, imagePath])];
      await tx.update(productContent).set({ imagePath: combined[0], galleryPaths: combined.slice(1), updatedAt: new Date() }).where(eq(productContent.productId, product.id));
      const values = { productId: product.id, imagePath, assignedBy: admin.username, assignedAt: new Date() };
      await tx.insert(recoveredPhotoAssignments).values({ sha256: id, ...values }).onConflictDoUpdate({ target: recoveredPhotoAssignments.sha256, set: values });
      return { product: product.name };
    });
    return Response.json({ ok: true, ...result });
  } catch (error) { return Response.json({ error: error instanceof Error ? error.message : "Nie udało się przypisać zdjęcia." }, { status: 409 }); }
}
