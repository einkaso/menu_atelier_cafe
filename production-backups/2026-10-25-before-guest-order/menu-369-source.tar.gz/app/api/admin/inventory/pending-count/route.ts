import { count, eq } from "drizzle-orm";
import { getDb } from "../../../../../db";
import { inventoryStages } from "../../../../../db/schema";
import { currentAdmin } from "../../../../../lib/admin-auth";
export const dynamic = "force-dynamic";
export async function GET() {
  if (!(await currentAdmin())) return Response.json({error:"Unauthorized"}, {status:401});
  const [result] = await getDb().select({count:count()}).from(inventoryStages).where(eq(inventoryStages.status,"SUBMITTED"));
  return Response.json({count:result.count}, {headers:{"cache-control":"private, no-store"}});
}
