import { isIngredientInventoryCategory } from "../../../../../lib/menu-tags";
import {historicalInventoryBatches,inventoryDateConflicts} from "../../../../../lib/inventory-history";
import type {InventoryBatchResult} from "../../../../../db/schema";
import { qualityInput } from "../../../../../lib/inventory-care";
import { createHash, randomUUID } from "node:crypto";
import { and, eq, inArray, sql } from "drizzle-orm";
import { getDb } from "../../../../../db";
import { inventoryCountEntries, inventoryEvents, inventoryExports, inventoryStageItems, inventoryStages } from "../../../../../db/schema";
import { inventoryManager } from "../../../../../lib/inventory-manager-auth";
import { inventoryStageDetail } from "../../../../../lib/inventory-data";
import { inventoryDifference, millisToQuantity, quantityToMillis, validInventoryReason } from "../../../../../lib/inventory";
import { DotykackaClient } from "../../../../../lib/dotykacka/client";
import { getDotykackaConfig } from "../../../../../lib/dotykacka/config";

export const dynamic = "force-dynamic";
const ADMIN_EDITABLE_STATUSES = ["ASSIGNED", "IN_PROGRESS", "CHANGES_REQUESTED", "SUBMITTED"];

function stageIdFrom(value: string) {
  const id = Number(value);
  return Number.isInteger(id) && id > 0 ? id : null;
}

export async function GET(request: Request, context: { params: Promise<{ id: string }> }) {
  if (!(await inventoryManager(request))) return Response.json({ error: "Unauthorized" }, { status: 401 });
  const stageId = stageIdFrom((await context.params).id);
  if (!stageId) return Response.json({ error: "Nieprawidłowy etap." }, { status: 400 });
  const detail = await inventoryStageDetail(stageId);
  return detail ? Response.json({ stage: detail, inventoryWriteEnabled: process.env.DOTYKACKA_INVENTORY_WRITE_ENABLED === "true" }) : Response.json({ error: "Etap nie istnieje." }, { status: 404 });
}

export async function PATCH(request: Request, context: { params: Promise<{ id: string }> }) {
 try{return await patch(request,context);}catch(error){if(error instanceof Error&&error.message==='INVENTORY_CONFLICT')return Response.json({error:'Zadanie zmieniło stan. Odśwież widok.'},{status:409});throw error;}
}
async function patch(request: Request, context: { params: Promise<{ id: string }> }) {
  const actor = await inventoryManager(request);
  if (!actor) return Response.json({ error: "Unauthorized" }, { status: 401 });
  const stageId = stageIdFrom((await context.params).id);
  if (!stageId) return Response.json({ error: "Nieprawidłowy etap." }, { status: 400 });
  const body = await request.json().catch(() => ({})) as { action?: unknown; itemId?: unknown; countedQuantity?: unknown; reasonCode?: unknown; note?: unknown };
  const action = typeof body.action === "string" ? body.action : "";
  const db = getDb();
  const [stage] = await db.select().from(inventoryStages).where(eq(inventoryStages.id, stageId)).limit(1);
  if (!stage) return Response.json({ error: "Etap nie istnieje." }, { status: 404 });
  const actorName = actor.employeeName ?? actor.username;
  const note = typeof body.note === "string" ? body.note.trim().slice(0, 1000) : "";

  const groupCounts=await db.execute(sql`select gc.resolved_at from inventory_group_counts gc join inventory_stage_items i on i.id=gc.item_id where i.stage_id=${stageId}`);
  if(groupCounts.length && action==='APPROVE' && groupCounts.some(g=>!g.resolved_at))return Response.json({error:'Najpierw rozdziel policzone ilości w Powiązaniach magazynu.'},{status:409});
  if(groupCounts.length && action==='ADJUST_ITEM')return Response.json({error:'Poproś pracownika o korektę liczenia przed podziałem; po podziale zleć nowe liczenie.'},{status:409});
  if(groupCounts.length && ['ADJUST_ITEM','REQUEST_CHANGES'].includes(action) && groupCounts.some(g=>g.resolved_at))return Response.json({error:'Podział został już zatwierdzony. Dalsza korekta wymaga nowego liczenia.'},{status:409});
  if (action === "ADJUST_ITEM") {
    if (!ADMIN_EDITABLE_STATUSES.includes(stage.status)) return Response.json({ error: "Ten etap jest już zamknięty do korekt administratora." }, { status: 409 });
    const itemId = Number(body.itemId);
    const countedMillis = quantityToMillis(body.countedQuantity);
    if (!Number.isInteger(itemId) || countedMillis == null) return Response.json({ error: "Podaj prawidłową ilość." }, { status: 400 });
    const [item] = await db.select().from(inventoryStageItems).where(and(eq(inventoryStageItems.id, itemId), eq(inventoryStageItems.stageId, stageId))).limit(1);
    if (item?.countStatus === "EXCLUDED") return Response.json({error:"Pozycja wyłączona z tego liczenia."},{status:409});
    if (!item) return Response.json({ error: "Pozycja nie należy do tego etapu." }, { status: 404 });
    const countedQuantity = millisToQuantity(countedMillis);
    const reasonCode = validInventoryReason(body.reasonCode) ? body.reasonCode : null;
    if (inventoryDifference(item.expectedQuantity, countedQuantity) && !reasonCode) return Response.json({ error: "Dla różnicy wybierz przyczynę." }, { status: 400 });
    if (!note) return Response.json({ error: "Korekta administratora wymaga notatki." }, { status: 400 });
    await db.transaction(async (tx) => {
      await tx.delete(inventoryCountEntries).where(eq(inventoryCountEntries.itemId, itemId));
      await tx.insert(inventoryCountEntries).values({ itemId, location: "Stan potwierdzony przez administratora", quantity: countedQuantity, note, createdByName: actorName });
      await tx.update(inventoryStageItems).set({ countedQuantity, countStatus: "COUNTED", reasonCode, adminNote: note, countedAt: new Date(), updatedAt: new Date() }).where(eq(inventoryStageItems.id, itemId));
      await tx.insert(inventoryEvents).values({ stageId, actorType: "ADMIN", actorId: actor.username, actorName, action: "ITEM_ADJUSTED", details: { itemId, product: item.productName, previousQuantity: item.countedQuantity, countedQuantity, reasonCode, note } });
    });
    return Response.json({ ok: true });
  }

  if (action === "REQUEST_CHANGES") {
    if (stage.status !== "SUBMITTED") return Response.json({ error: "Ten etap nie czeka na weryfikację." }, { status: 409 });
    if (!note) return Response.json({ error: "Podaj pracownikowi, co należy sprawdzić." }, { status: 400 });
    await db.transaction(async (tx) => {
      if(groupCounts.length){const locked=await tx.execute(sql`select status from inventory_stages where id=${stageId} for update`);const resolved=await tx.execute(sql`select 1 from inventory_group_counts gc join inventory_stage_items i on i.id=gc.item_id where i.stage_id=${stageId} and gc.resolved_at is not null`);if(locked[0]?.status!=='SUBMITTED'||resolved.length)throw Error('INVENTORY_CONFLICT');}
      await tx.update(inventoryStages).set({ status: "CHANGES_REQUESTED", adminNote: note, updatedAt: new Date() }).where(eq(inventoryStages.id, stageId));
      await tx.insert(inventoryEvents).values({ stageId, actorType: "ADMIN", actorId: actor.username, actorName, action: "CHANGES_REQUESTED", details: { note } });
    });
    return Response.json({ ok: true });
  }

  if (action === "APPROVE") {
    if (!ADMIN_EDITABLE_STATUSES.includes(stage.status)) return Response.json({ error: "Tego etapu nie można już zatwierdzić." }, { status: 409 });
    const items = (await db.select().from(inventoryStageItems).where(eq(inventoryStageItems.stageId, stageId))).filter(i=>i.countStatus!=="EXCLUDED");
    if (!items.length) return Response.json({ error: "Etap nie zawiera żadnych pozycji." }, { status: 409 });
    if(isIngredientInventoryCategory(stage.categoryName) && items.some(i=>!qualityInput(i.quality)||i.countStatus==='PENDING'))return Response.json({error:"Składniki wymagają fizycznego liczenia i kontroli dat oraz świeżości. Poproś pracownika o uzupełnienie."},{status:409});
    const pendingItems = items.filter((item) => item.countStatus === "PENDING" || item.countedQuantity == null);
    if (pendingItems.length && !note) return Response.json({ error: `Aby zatwierdzić trwający etap, wpisz notatkę. ${pendingItems.length} niepoliczonych pozycji zostanie przyjętych według stanu oczekiwanego z Dotykački.` }, { status: 400 });
    const missingReasons = items.filter((item) => item.countStatus !== "PENDING" && inventoryDifference(item.expectedQuantity, item.countedQuantity) && !item.reasonCode);
    if (missingReasons.length) return Response.json({ error: `Uzupełnij przyczynę różnicy dla: ${missingReasons.slice(0, 3).map((item) => item.productName).join(", ")}.` }, { status: 409 });
    const localOnly=items.every(item=>item.inventorySource==="OWN");
    const now = new Date();
    await db.transaction(async (tx) => {
      if(groupCounts.length){const locked=await tx.execute(sql`select status from inventory_stages where id=${stageId} for update`);if(locked[0]?.status!=='SUBMITTED')throw Error('INVENTORY_CONFLICT');}
      if (pendingItems.length) {
        const pendingIds = pendingItems.map((item) => item.id);
        await tx.delete(inventoryCountEntries).where(inArray(inventoryCountEntries.itemId, pendingIds));
        await tx.insert(inventoryCountEntries).values(pendingItems.map((item) => ({
          itemId: item.id,
          location: "Stan oczekiwany zaakceptowany przez administratora",
          quantity: item.expectedQuantity,
          note,
          createdByName: actorName,
          createdAt: now,
          updatedAt: now,
        })));
        await tx.update(inventoryStageItems).set({
          countedQuantity: sql`${inventoryStageItems.expectedQuantity}`,
          countStatus: "COUNTED",
          reasonCode: null,
          adminNote: note,
          countedAt: now,
          updatedAt: now,
        }).where(inArray(inventoryStageItems.id, pendingIds));
      }
      await tx.update(inventoryStages).set({ status: localOnly ? "FINISHED" : "APPROVED", finishedAt:localOnly?now:null, approvedAt: now, approvedBy: actor.username, adminNote: note || stage.adminNote, updatedAt: now }).where(eq(inventoryStages.id, stageId));
      await tx.insert(inventoryEvents).values({ stageId, actorType: "ADMIN", actorId: actor.username, actorName, action: "APPROVED", details: { note, previousStatus: stage.status, acceptedExpectedCount: pendingItems.length, differences: items.filter((item) => item.countStatus !== "PENDING" && inventoryDifference(item.expectedQuantity, item.countedQuantity)).length } });
    });
    return Response.json({ ok: true, status:localOnly?"FINISHED":"APPROVED", acceptedExpectedCount: pendingItems.length });
  }

  if (action === "SEND") {
    if (process.env.DOTYKACKA_INVENTORY_WRITE_ENABLED !== "true") return Response.json({ error: "Wysyłanie stanów do Dotykački pozostaje zablokowane do kontrolowanego testu." }, { status: 409 });
    if (stage.status !== "APPROVED") return Response.json({ error: "Najpierw zatwierdź etap." }, { status: 409 });
    const [existingExport] = await db.select().from(inventoryExports).where(eq(inventoryExports.stageId, stageId)).limit(1);
    if (existingExport) return Response.json({ error: "Ten etap ma już utworzoną operację wysyłki. Nie można wysłać go ponownie." }, { status: 409 });
    const items = (await db.select().from(inventoryStageItems).where(eq(inventoryStageItems.stageId, stageId))).filter(i=>i.countStatus!=="EXCLUDED");
    const externalId = randomUUID();
    let batches;
    try{batches=historicalInventoryBatches(items).map((batch,index)=>({...batch,note:`inventory_stage=${stage.externalId}; export=${externalId}; batch=${index}`}));}
    catch(error){return Response.json({error:error instanceof Error?error.message:"Błędne pozycje"},{status:409});}
    if(!batches.length)return Response.json({error:"Brak policzonych pozycji do wysłania do Dotykački."},{status:409});
    const payload={note:`inventory_stage=${stage.externalId}; export=${externalId}`,stockTakingDate:batches[0].stockTakingDate,items:batches.flatMap(b=>b.items),batches};
    const payloadHash = createHash("sha256").update(JSON.stringify(payload)).digest("hex");
    let client: DotykackaClient;
    try {
      const config = await getDotykackaConfig();
      if (!config.warehouseId) return Response.json({ error: "Nie wybrano magazynu Dotykački." }, { status: 409 });
      client = new DotykackaClient(config);
      const latestDates = await client.stockTakingDates(payload.items.map((item) => item._productId));
      const conflicts = inventoryDateConflicts(latestDates,batches);
      if (conflicts.length) return Response.json({ error: "Co najmniej jeden produkt ma nowszą inwentaryzację niż zapisany czas jego liczenia. Utwórz nowy etap dla konfliktowych pozycji." }, { status: 409 });
    } catch (error) {
      return Response.json({ error: error instanceof Error ? error.message : "Nie udało się wykonać kontroli przed wysyłką." }, { status: 502 });
    }
    const [createdExport] = await db.transaction(async (tx) => {
      await tx.execute(sql`select pg_advisory_xact_lock(${stageId})`);
      const [locked]=await tx.select().from(inventoryStages).where(eq(inventoryStages.id,stageId)).for("update");
      if(locked.status!=="APPROVED")return [];
      const [already]=await tx.select().from(inventoryExports).where(eq(inventoryExports.stageId,stageId));
      if(already)return [];

      const [created] = await tx.insert(inventoryExports).values({ stageId, externalId, payload, payloadHash, status: "READY", createdBy: actor.username }).returning();
      await tx.update(inventoryStages).set({ status: "SENDING", updatedAt: new Date() }).where(and(eq(inventoryStages.id, stageId), eq(inventoryStages.status, "APPROVED")));
      await tx.update(inventoryExports).set({ status: "SENDING", updatedAt: new Date() }).where(eq(inventoryExports.id, created.id));
      await tx.insert(inventoryEvents).values({ stageId, actorType: "ADMIN", actorId: actor.username, actorName, action: "SEND_STARTED", details: { externalId, payloadHash } });
      return [created];
    });
    if(!createdExport)return Response.json({error:"Wysyłka została już rozpoczęta."},{status:409});
    const results:InventoryBatchResult[]=[];
    try {
      for(const [index,batch] of batches.entries()){
        results.push({index,status:"SENDING"});
        await db.update(inventoryExports).set({batchResults:[...results],updatedAt:new Date()}).where(eq(inventoryExports.id,createdExport.id));
        const result=await client.createStockTaking(batch);
        results[index]={index,status:"PROCESSING",stockTransactionId:String(result._stockTransactionId),statusWebhookUrl:result.statusWebhookUrl};
        await db.update(inventoryExports).set({batchResults:[...results],sentAt:new Date(),updatedAt:new Date()}).where(eq(inventoryExports.id,createdExport.id));
      }
      await db.transaction(async tx=>{
        await tx.update(inventoryExports).set({status:"PROCESSING",updatedAt:new Date()}).where(eq(inventoryExports.id,createdExport.id));
        await tx.update(inventoryStages).set({status:"PROCESSING",updatedAt:new Date()}).where(eq(inventoryStages.id,stageId));
        await tx.insert(inventoryEvents).values({stageId,actorType:"SYSTEM",actorId:"dotykacka",actorName:"Dotykačka",action:"SEND_ACCEPTED",details:{batches:results,history:true}});
      });
      return Response.json({ok:true,status:"PROCESSING"});
    } catch(error){
      const message=error instanceof Error?error.message:"Nieznany błąd wysyłki.";
      if(results.length&&results.at(-1)?.status==="SENDING")results[results.length-1]={...results[results.length-1],status:"UNKNOWN",error:message};
      await db.transaction(async tx=>{
        await tx.update(inventoryExports).set({status:"UNKNOWN",batchResults:results,error:message,updatedAt:new Date()}).where(eq(inventoryExports.id,createdExport.id));
        await tx.update(inventoryStages).set({status:"UNKNOWN",updatedAt:new Date()}).where(eq(inventoryStages.id,stageId));
        await tx.insert(inventoryEvents).values({stageId,actorType:"SYSTEM",actorId:"dotykacka",actorName:"Dotykačka",action:"SEND_UNCERTAIN",details:{error:message,batches:results}});
      });
      return Response.json({error:`${message} Wysyłka częściowa lub niepewna. Nie ponawiaj jej automatycznie.`},{status:502});
    }
  }

  if (action === "POLL_STATUS") {
    const [inventoryExport] = await db.select().from(inventoryExports).where(eq(inventoryExports.stageId, stageId)).limit(1);
    if (!inventoryExport || !["PROCESSING","UNKNOWN"].includes(inventoryExport.status)) return Response.json({error:"Brak operacji do sprawdzenia."},{status:409});
    try {
      const client = new DotykackaClient(await getDotykackaConfig());
      let result:{status:string;error?:string|null;errors?:unknown[]};
      if(inventoryExport.payload.batches){
        const results=[...inventoryExport.batchResults];
        for(const [index,batch] of results.entries()){
          if(batch.statusWebhookUrl&&batch.status!=="FINISHED"&&batch.status!=="FAILED"){
            const response=await client.stockTakingStatus(batch.statusWebhookUrl,batch.stockTransactionId);
            results[index]={...batch,status:response.status,error:response.error??(response.errors?.length?JSON.stringify(response.errors):undefined)};
            await db.update(inventoryExports).set({batchResults:[...results],updatedAt:new Date()}).where(eq(inventoryExports.id,inventoryExport.id));
          }
        }
        const allPresent=results.length===inventoryExport.payload.batches.length;
        result={status:allPresent&&results.every(b=>b.status==="FINISHED")?"FINISHED":results.some(b=>b.status==="FAILED")?"FAILED":!allPresent||results.some(b=>["UNKNOWN","SENDING"].includes(b.status))?"UNKNOWN":"PROCESSING",errors:results.filter(b=>b.error).map(b=>b.error)};
      }else{
        if(!inventoryExport.statusWebhookUrl)throw Error("Brak adresu sprawdzania statusu.");
        result=await client.stockTakingStatus(inventoryExport.statusWebhookUrl,inventoryExport.stockTransactionId??undefined);
      }
      const status=result.status;
      const finished=status==="FINISHED"?new Date():null;
      await db.transaction(async (tx) => {
        await tx.update(inventoryExports).set({ status, error: result.error ?? (result.errors?.length ? JSON.stringify(result.errors) : null), finishedAt: finished, updatedAt: new Date() }).where(eq(inventoryExports.id, inventoryExport.id));
        await tx.update(inventoryStages).set({ status, finishedAt: finished, updatedAt: new Date() }).where(eq(inventoryStages.id, stageId));
        await tx.insert(inventoryEvents).values({ stageId, actorType: "SYSTEM", actorId: "dotykacka", actorName: "Dotykačka", action: `STATUS_${status}`, details: { error: result.error, errors: result.errors } });
      });
      return Response.json({ ok: true, status });
    } catch (error) {
      return Response.json({ error: error instanceof Error ? error.message : "Nie udało się sprawdzić statusu." }, { status: 502 });
    }
  }

  return Response.json({ error: "Nieznana akcja." }, { status: 400 });
}
