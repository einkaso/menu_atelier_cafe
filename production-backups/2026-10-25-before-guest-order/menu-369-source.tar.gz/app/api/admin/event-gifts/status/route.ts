import {currentAdmin} from '../../../../../lib/admin-auth';
import {readGiftIntegrationStatus} from '../../../../../lib/event-gifts-integration';
export const dynamic='force-dynamic';
export async function GET(){
 if(!await currentAdmin())return Response.json({error:'Zaloguj się jako administrator.'},{status:401,headers:{'Cache-Control':'private, no-store'}});
 return Response.json(await readGiftIntegrationStatus(),{headers:{'Cache-Control':'private, no-store'}});
}
