import { eq } from "drizzle-orm";
import { getDb } from "../../../../../../db";
import { staffInstructions } from "../../../../../../db/schema";
import { currentAdmin } from "../../../../../../lib/admin-auth";
import { importStaffInstructionAttachment } from "../../../../../../lib/staff-instruction-attachments";
export const dynamic = "force-dynamic";
type Context = { params: Promise<{ id: string }> };
async function change(request: Request, context: Context, remove: boolean) {
  const admin = await currentAdmin();
  if (!admin) return Response.json({ error: "Unauthorized" }, { status: 401 });
  const id = Number((await context.params).id);
  if (!Number.isSafeInteger(id) || id < 1) return Response.json({ error: "Nieprawidłowa instrukcja." }, { status: 400 });
  const form = remove ? null : await request.formData().catch(() => null);
  const body = remove ? await request.json().catch(() => ({})) : {};
  const renotify = remove ? body.renotify : form?.get("renotify") === "true" ? true : form?.get("renotify") === "false" ? false : undefined;
  const expected = remove ? body.expectedUpdatedAt : form?.get("expectedUpdatedAt");
  const files = form?.getAll("attachments").filter((item): item is File => item instanceof File && item.size > 0) ?? [];
  if (!remove && (!files.length || files.length > 10)) return Response.json({ error: "Wybierz od 1 do 10 plików." }, { status: 400 });
  try {
    return await getDb().transaction(async tx => {
      const [instruction] = await tx.select().from(staffInstructions).where(eq(staffInstructions.id, id)).for("update");
      if (!instruction) return Response.json({ error: "Instrukcja nie istnieje." }, { status: 404 });
      if (instruction.status === "ARCHIVED") return Response.json({ error: "Najpierw przywróć instrukcję z archiwum." }, { status: 409 });
      if ((expected && expected !== instruction.updatedAt.toISOString()) || (instruction.status === "PUBLISHED" && (!expected || typeof renotify !== "boolean"))) return Response.json({ error: "Odśwież instrukcję i wybierz, czy zmiana wymaga ponownego przeczytania." }, { status: 409 });
      let attachments = [...instruction.attachments];
      if (remove) {
        if (!attachments.some(item => item.id === body.attachmentId)) return Response.json({ error: "Załącznik nie istnieje." }, { status: 404 });
        attachments = attachments.filter(item => item.id !== body.attachmentId);
      } else {
        for (const file of files) {
          const item = await importStaffInstructionAttachment(id, file);
          if (!attachments.some(old => old.id === item.id)) attachments.push(item);
        }
        if (attachments.length > 10) throw new Error("Instrukcja może mieć maksymalnie 10 załączników.");
        if (attachments.length === instruction.attachments.length) return Response.json({ duplicate: true });
      }
      const republished = instruction.status === "PUBLISHED" && renotify === true;
      const now = new Date();
      await tx.update(staffInstructions).set({ attachments, updatedAt: now, updatedBy: admin.username,
        ...(republished ? { revision: instruction.revision + 1, publishedAt: now } : {}),
      }).where(eq(staffInstructions.id, id));
      return Response.json({ attachments, republished });
    });
  } catch (error) { return Response.json({ error: error instanceof Error ? error.message : "Nie udało się zapisać załączników." }, { status: 400 }); }
}
export async function POST(request: Request, context: Context) { return change(request, context, false); }
export async function DELETE(request: Request, context: Context) { return change(request, context, true); }
