import { getDb } from "../../../../db";
import { menuOfferSettings } from "../../../../db/schema";
import { isAdmin } from "../../../../lib/admin-auth";
import { isWelcomeLayout } from "../../../../lib/menu-view";
import { readWelcomeLayout } from "../../../../lib/menu-view-server";

export const dynamic = "force-dynamic";

export async function GET() {
  if (!(await isAdmin())) return Response.json({ error: "Unauthorized" }, { status: 401 });
  try {
    return Response.json({ welcomeLayout: await readWelcomeLayout() }, { headers: { "cache-control": "no-store" } });
  } catch {
    return Response.json({ error: "Nie udało się odczytać ustawień widoku." }, { status: 503 });
  }
}

export async function PUT(request: Request) {
  if (!(await isAdmin())) return Response.json({ error: "Unauthorized" }, { status: 401 });
  const body = await request.json().catch(() => null);
  if (!isWelcomeLayout(body?.welcomeLayout)) {
    return Response.json({ error: "Wybierz prawidłowy układ strony startowej." }, { status: 400 });
  }
  try {
    const now = new Date();
    await getDb().insert(menuOfferSettings).values({ key: "main", welcomeLayout: body.welcomeLayout, updatedAt: now })
      .onConflictDoUpdate({ target: menuOfferSettings.key, set: { welcomeLayout: body.welcomeLayout, updatedAt: now } });
    return Response.json({ welcomeLayout: body.welcomeLayout }, { headers: { "cache-control": "no-store" } });
  } catch {
    return Response.json({ error: "Nie udało się zapisać ustawień widoku." }, { status: 503 });
  }
}
