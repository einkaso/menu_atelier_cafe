import { eq, inArray, sql, desc } from "drizzle-orm";
import { getDb } from "../../../../../../db";
import { kitchenDishCards, kitchenDishComponents, kitchenRecipes, kitchenRecipeVersions, menuProducts } from "../../../../../../db/schema";
import { currentAdmin } from "../../../../../../lib/admin-auth";
import { dishCardSchema } from "../../../../../../lib/kitchen-recipes";
import { KitchenError, kitchenErrorResponse, readPreparationCard } from "../../../../../../lib/kitchen-recipes-server";

export const dynamic = "force-dynamic";
type Context = { params: Promise<{ id: string }> };

export async function GET(_request: Request, context: Context) {
  if (!(await currentAdmin())) return Response.json({ error: "Unauthorized" }, { status: 401 });
  const id = Number((await context.params).id);
  if (!Number.isSafeInteger(id) || id < 1) return Response.json({ error: "Nieprawidłowe danie." }, { status: 400 });
  const card = await readPreparationCard(id);
  return card ? Response.json({ card }, { headers: { "Cache-Control": "private, no-store" } }) : Response.json({ error: "Danie nie istnieje." }, { status: 404 });
}

export async function PUT(request: Request, context: Context) {
  const admin = await currentAdmin();
  if (!admin) return Response.json({ error: "Unauthorized" }, { status: 401 });
  const id = Number((await context.params).id);
  if (!Number.isSafeInteger(id) || id < 1) return Response.json({ error: "Nieprawidłowe danie." }, { status: 400 });
  const parsed = dishCardSchema.safeParse(await request.json().catch(() => null));
  if (!parsed.success) return Response.json({ error: "Sprawdź elementy dania." }, { status: 400 });
  try {
    await getDb().transaction(async (tx) => {
      await tx.execute(sql`SELECT pg_advisory_xact_lock(732710329)`);
      const components = parsed.data.components.map(part => ({...part}));
      // The product lock serializes first-time card creation as well as replacements.
      const [product] = await tx.select({ id: menuProducts.id }).from(menuProducts).where(eq(menuProducts.id, id)).for("update");
      if (!product) throw new KitchenError("Danie nie istnieje.", 404);
      const [card] = await tx.select().from(kitchenDishCards).where(eq(kitchenDishCards.productId, id));
      if ((card?.revision ?? 0) !== parsed.data.expectedRevision) throw new KitchenError("Karta dania została zmieniona. Odśwież ją przed zapisem.", 409);
      const previous = await tx.select().from(kitchenDishComponents).where(eq(kitchenDishComponents.productId, id));
      const pendingIds = [...new Set(components.flatMap((part) => part.pendingRecipeId ? [part.pendingRecipeId] : []))];
      if (pendingIds.length) {
        const pending = await tx.select().from(kitchenRecipes).where(inArray(kitchenRecipes.id, pendingIds)).for("share");
        for (const pendingId of pendingIds) {
          const recipe = pending.find((item) => item.id === pendingId);
          if (!recipe || recipe.archived && !previous.some((part) => part.pendingRecipeId === pendingId)) throw new KitchenError("Roboczy przepis nie istnieje lub jest archiwalny.");
        }
      }
      if (pendingIds.length) {
        const published = await tx.select().from(kitchenRecipeVersions).where(inArray(kitchenRecipeVersions.recipeId, pendingIds)).orderBy(desc(kitchenRecipeVersions.version));
        for (const part of components) {
          const version = published.find(item => item.recipeId === part.pendingRecipeId && item.status === "PUBLISHED");
          if (version) { part.recipeVersionId = version.id; part.pendingRecipeId = null; }
        }
      }
      const versionIds = [...new Set(components.flatMap((part) => part.recipeVersionId ? [part.recipeVersionId] : []))];
      if (versionIds.length) {
        const versions = await tx.select({ id: kitchenRecipeVersions.id, status: kitchenRecipeVersions.status, archived: kitchenRecipes.archived })
          .from(kitchenRecipeVersions).innerJoin(kitchenRecipes, eq(kitchenRecipeVersions.recipeId, kitchenRecipes.id))
          .where(inArray(kitchenRecipeVersions.id, versionIds)).for("share");
        for (const versionId of versionIds) {
          const version = versions.find((item) => item.id === versionId);
          if (!version || version.status !== "PUBLISHED") throw new KitchenError("Możesz podpinać tylko zatwierdzone wersje przepisów.");
          if (version.archived && !previous.some((part) => part.recipeVersionId === versionId)) throw new KitchenError("Archiwalnego przepisu nie można podpiąć do nowego dania.");
        }
      }
      await tx.insert(kitchenDishCards).values({ productId: id, updatedBy: admin.username }).onConflictDoUpdate({
        target: kitchenDishCards.productId, set: { revision: (card?.revision ?? 0) + 1, updatedBy: admin.username, updatedAt: new Date() },
      });
      await tx.delete(kitchenDishComponents).where(eq(kitchenDishComponents.productId, id));
      if (components.length) await tx.insert(kitchenDishComponents).values(components.map((part, index) => ({ ...part, pendingRecipeId: part.pendingRecipeId ?? null, productId: id, sortOrder: index })));
    });
    return Response.json({ status: "ok", card: await readPreparationCard(id) });
  } catch (error) { return kitchenErrorResponse(error); }
}
