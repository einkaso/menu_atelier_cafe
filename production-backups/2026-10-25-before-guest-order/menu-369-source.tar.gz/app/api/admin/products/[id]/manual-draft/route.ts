import { eq } from "drizzle-orm";
import { z } from "zod";
import { getDb } from "../../../../../../db";
import { menuProducts, productContent, kitchenDishManualDrafts } from "../../../../../../db/schema";
import { currentAdmin } from "../../../../../../lib/admin-auth";
import { KitchenError, kitchenErrorResponse } from "../../../../../../lib/kitchen-recipes-server";
export const dynamic = "force-dynamic";
type Context = { params: Promise<{ id: string }> };
const schema = z.object({ action: z.enum(["SAVE", "PUBLISH"]), instructions: z.string().max(12000), expectedRevision: z.number().int().nonnegative(), expectedPublished: z.string().max(12000) }).strict();
export async function GET(_request: Request, context: Context) {
  if (!(await currentAdmin())) return Response.json({ error: "Unauthorized" }, { status: 401 });
  const id = Number((await context.params).id);
  if (!Number.isSafeInteger(id) || id < 1) return Response.json({ error: "Nieprawidłowe danie." }, { status: 400 });
  const [row] = await getDb().select({ published: productContent.staffInstructions, draft: kitchenDishManualDrafts.instructions, revision: kitchenDishManualDrafts.revision })
    .from(menuProducts).leftJoin(productContent, eq(productContent.productId, menuProducts.id))
    .leftJoin(kitchenDishManualDrafts, eq(kitchenDishManualDrafts.productId, menuProducts.id)).where(eq(menuProducts.id, id));
  return row ? Response.json({ published: row.published ?? "", draft: row.draft, revision: row.revision ?? 0 }, { headers: { "Cache-Control": "private, no-store" } }) : Response.json({ error: "Danie nie istnieje." }, { status: 404 });
}
export async function PUT(request: Request, context: Context) {
  const admin = await currentAdmin();
  if (!admin) return Response.json({ error: "Unauthorized" }, { status: 401 });
  const id = Number((await context.params).id);
  const parsed = schema.safeParse(await request.json().catch(() => null));
  if (!Number.isSafeInteger(id) || id < 1 || !parsed.success) return Response.json({ error: "Sprawdź dane receptury." }, { status: 400 });
  const body = parsed.data;
  if (body.action === "PUBLISH" && !body.instructions.trim()) return Response.json({ error: "Uzupełnij recepturę przed publikacją." }, { status: 400 });
  try {
    const state = await getDb().transaction(async (tx) => {
      const [product] = await tx.select({ id: menuProducts.id }).from(menuProducts).where(eq(menuProducts.id, id)).for("update");
      if (!product) throw new KitchenError("Danie nie istnieje.", 404);
      const [content] = await tx.select().from(productContent).where(eq(productContent.productId, id)).for("update");
      const [draft] = await tx.select().from(kitchenDishManualDrafts).where(eq(kitchenDishManualDrafts.productId, id));
      if ((draft?.revision ?? 0) !== body.expectedRevision || (content?.staffInstructions ?? "") !== body.expectedPublished) throw new KitchenError("Receptura została zmieniona w innym oknie. Odśwież stronę przed zapisem.", 409);
      const revision = (draft?.revision ?? 0) + 1;
      const instructions = body.action === "SAVE" ? body.instructions : null;
      await tx.insert(kitchenDishManualDrafts).values({ productId: id, instructions, revision, updatedBy: admin.username }).onConflictDoUpdate({ target: kitchenDishManualDrafts.productId, set: { instructions, revision, updatedBy: admin.username, updatedAt: new Date() } });
      if (body.action === "PUBLISH") await tx.insert(productContent).values({ productId: id, staffInstructions: body.instructions }).onConflictDoUpdate({ target: productContent.productId, set: { staffInstructions: body.instructions, updatedAt: new Date() } });
      return { revision, draft: instructions, published: body.action === "PUBLISH" ? body.instructions : content?.staffInstructions ?? "" };
    });
    return Response.json(state);
  } catch (error) { return kitchenErrorResponse(error); }
}
