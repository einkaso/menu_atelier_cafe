import { NextRequest, NextResponse } from "next/server";
import { readFile, writeFile, rename } from "node:fs/promises";
import { randomUUID } from "node:crypto";
import { currentAdmin } from "../../../../lib/admin-auth";
import { todayWarsaw, plusDays } from "../../../../lib/gastro/core";
export const dynamic = "force-dynamic";
const reviewPath = () =>
  process.env.ADMIN_DESIGN_REVIEW_FILE ||
  "/var/lib/banaszek-menu/admin-design-review.json";
export async function GET() {
  if (!(await currentAdmin()))
    return NextResponse.json(
      { error: "Wymagane konto administratora." },
      { status: 401 },
    );
  let review = { due: "2026-10-22", created: "2026-10-12" };
  try {
    review = { ...review, ...JSON.parse(await readFile(reviewPath(), "utf8")) };
  } catch {}
  return NextResponse.json(
    { due: review.due, today: todayWarsaw(), backupRetained: true },
    { headers: { "Cache-Control": "no-store" } },
  );
}
export async function POST(req: NextRequest) {
  const admin = await currentAdmin();
  if (!admin)
    return NextResponse.json(
      { error: "Wymagane konto administratora." },
      { status: 401 },
    );
  if (
    req.headers.get("origin") &&
    new URL(req.headers.get("origin")!).host !== req.headers.get("host")
  )
    return NextResponse.json(
      { error: "Nieprawidłowe źródło żądania." },
      { status: 403 },
    );
  const b = await req.json().catch(() => null);
  if (b?.action === "DEFER_REVIEW") {
    const review = {
      due: plusDays(todayWarsaw(), 7),
      created: "2026-10-12",
      deferredBy: admin.username,
      deferredAt: new Date().toISOString(),
    };
    const path = reviewPath(),
      temp = path + "." + randomUUID() + ".tmp";
    await writeFile(temp, JSON.stringify(review, null, 2), { mode: 0o600 });
    await rename(temp, path);
    return NextResponse.json({ ok: true, due: review.due });
  }
  if (!["atelier", "legacy"].includes(b?.appearance))
    return NextResponse.json(
      { error: "Wybierz wygląd panelu." },
      { status: 400 },
    );
  const result = NextResponse.json({ ok: true });
  result.cookies.set("mb_admin_appearance", b.appearance, {
    httpOnly: true,
    sameSite: "lax",
    secure: req.nextUrl.protocol === "https:",
    path: "/",
    maxAge: 86400 * 365,
  });
  return result;
}
