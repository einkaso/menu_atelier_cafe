import { NextRequest, NextResponse } from "next/server";
import { sql } from "drizzle-orm";
import { currentAdmin } from "../../../../lib/admin-auth";
import { getDb } from "../../../../db";
import { calendarData } from "../../../../lib/gastro/service";
import { gastroEvents } from "../../../../lib/gastro/catalog";
import {
  eventDate,
  validDate,
  todayWarsaw,
  monthBefore,
} from "../../../../lib/gastro/core";
export const dynamic = "force-dynamic";
const fail = (message: string, status = 400) =>
  NextResponse.json({ error: message }, { status });
const str = (v: unknown, max = 4000) =>
  typeof v === "string" ? v.trim().slice(0, max) : "";
export async function GET(req: NextRequest) {
  if (!(await currentAdmin()))
    return fail("Wymagane konto administratora.", 401);
  const year = Number(
    req.nextUrl.searchParams.get("year") || todayWarsaw().slice(0, 4),
  );
  if (!Number.isInteger(year) || year < 2025 || year > 2199)
    return fail("Nieprawidłowy rok.");
  const data = await calendarData(year);
  return NextResponse.json(
    req.nextUrl.searchParams.has("summary")
      ? { notices: data.notices, monitor: data.monitor }
      : data,
    { headers: { "Cache-Control": "no-store" } },
  );
}
export async function POST(req: NextRequest) {
  const admin = await currentAdmin();
  if (!admin) return fail("Wymagane konto administratora.", 401);
  if (
    req.headers.get("origin") &&
    new URL(req.headers.get("origin")!).host !== req.headers.get("host")
  )
    return fail("Nieprawidłowe źródło żądania.", 403);
  let b: Record<string, any>;
  try {
    b = await req.json();
  } catch {
    return fail("Nieprawidłowe dane.");
  }
  if (!b || typeof b !== "object" || Array.isArray(b))
    return fail("Nieprawidłowe dane.");
  const event = gastroEvents.find((e) => e.id === b.eventId),
    year = Number(b.year),
    today = todayWarsaw();
  if (
    !event ||
    !Number.isInteger(year) ||
    year < 2025 ||
    year > 2199 ||
    !Number.isInteger(b.version)
  )
    return fail("Nieprawidłowe wydarzenie lub wersja.");
  try {
    await getDb().transaction(async (tx) => {
      await tx.execute(
        sql`select pg_advisory_xact_lock(hashtext(${event.id + ":" + year}))`,
      );
      await tx.execute(
        sql`insert into gastro_occurrences(event_id,year,updated_by) values(${event.id},${year},${admin.username}) on conflict do nothing`,
      );
      const [s] = await tx.execute(
        sql`select * from gastro_occurrences where event_id=${event.id} and year=${year} for update`,
      );
      if (Number(s.version) !== b.version)
        throw Error(
          "409:Ktoś zmienił to wydarzenie. Odśwież dane przed zapisaniem.",
        );
      const date = String(s.date_override || eventDate(event.rule, year) || "");
      const tasks = await tx.execute(
        sql`select * from gastro_tasks where event_id=${event.id} and year=${year}`,
      );
      let details: Record<string, unknown> = {};
      if (b.action === "DECIDE") {
        if (!["CELEBRATE", "SKIP", "LATER"].includes(b.decision))
          throw Error("Wybierz decyzję.");
        let snooze: string | null = null;
        if (b.decision === "LATER") {
          if (
            !validDate(b.snoozeUntil) ||
            b.snoozeUntil <= today ||
            (date && b.snoozeUntil > date)
          )
            throw Error(
              "Wybierz przyszłą datę powrotu do decyzji, najpóźniej w dniu wydarzenia.",
            );
          snooze = b.snoozeUntil;
        }
        await tx.execute(
          sql`update gastro_occurrences set decision=${b.decision},snooze_until=${snooze},note=${str(b.note)},plan_approved_at=case when decision=${b.decision} then plan_approved_at else null end,plan_approved_by=case when decision=${b.decision} then plan_approved_by else null end where event_id=${event.id} and year=${year}`,
        );
        details = {
          before: s.decision,
          after: b.decision,
          note: str(b.note),
          snooze,
        };
      } else if (b.action === "DATE") {
        if (event.rule.type !== "manual")
          throw Error("To święto ma datę wyznaczaną automatycznie.");
        if (
          !validDate(b.date) ||
          Number(b.date.slice(0, 4)) !== year ||
          !str(b.dateNote)
        )
          throw Error("Podaj datę w wybranym roku i źródło jej potwierdzenia.");
        await tx.execute(
          sql`update gastro_occurrences set date_override=${b.date},date_note=${str(b.dateNote)},plan_approved_at=null,plan_approved_by=null where event_id=${event.id} and year=${year}`,
        );
        details = {
          before: s.date_override,
          after: b.date,
          source: str(b.dateNote),
          message: "Zmiana daty wymaga ponownego zatwierdzenia terminów planu.",
        };
      } else if (b.action === "SAVE_PLAN") {
        if (s.decision !== "CELEBRATE" || !date)
          throw Error("Najpierw wybierz „Obchodzimy” i potwierdź termin.");
        if (s.plan_approved_at)
          throw Error("Najpierw otwórz plan do ponownej edycji.");
        const p = b.plan || {};
        const plan = {
          objective: str(p.objective),
          offer: str(p.offer),
          owner: str(p.owner, 150),
          budget: str(p.budget, 150),
          channels: str(p.channels, 1000),
          notes: str(p.notes),
          lateReason: str(p.lateReason, 1000),
        };
        if (!Array.isArray(b.tasks) || b.tasks.length > 30)
          throw Error("Plan może mieć do 30 etapów.");
        const ids = new Set<number>();
        for (const t of b.tasks) {
          if (
            !str(t.title, 250) ||
            !validDate(t.due_date) ||
            !str(t.owner, 150)
          )
            throw Error(
              "Każdy etap wymaga nazwy, terminu i osoby odpowiedzialnej.",
            );
          if (
            t.due_date < `${year - 1}-01-01` ||
            t.due_date > `${year + 1}-12-31`
          )
            throw Error("Termin etapu jest zbyt odległy od wydarzenia.");
          if (t.id) {
            const old = tasks.find((x) => Number(x.id) === Number(t.id));
            if (!old || ids.has(Number(t.id)))
              throw Error("Nieprawidłowy etap.");
            ids.add(Number(t.id));
            if (
              old.status === "DONE" &&
              (old.title !== str(t.title, 250) ||
                old.due_date !== t.due_date ||
                old.owner !== str(t.owner, 150))
            )
              throw Error(
                "Wykonany etap zachowuje swoją treść. Najpierw oznacz go jako niewykonany.",
              );
            await tx.execute(
              sql`update gastro_tasks set title=${str(t.title, 250)},due_date=${t.due_date},owner=${str(t.owner, 150)} where id=${Number(t.id)}`,
            );
          } else
            await tx.execute(
              sql`insert into gastro_tasks(event_id,year,title,due_date,owner) values(${event.id},${year},${str(t.title, 250)},${t.due_date},${str(t.owner, 150)})`,
            );
        }
        for (const old of tasks)
          if (!ids.has(Number(old.id))) {
            if (old.status === "DONE")
              throw Error("Nie można usunąć wykonanego etapu.");
            await tx.execute(
              sql`delete from gastro_tasks where id=${Number(old.id)}`,
            );
          }
        await tx.execute(
          sql`update gastro_occurrences set plan=${JSON.stringify(plan)}::jsonb where event_id=${event.id} and year=${year}`,
        );
        details = { before: s.plan, after: plan, tasks: b.tasks };
      } else if (b.action === "APPROVE_PLAN") {
        const p = s.plan as Record<string, unknown>;
        if (
          s.decision !== "CELEBRATE" ||
          !date ||
          !str(p.objective) ||
          !str(p.offer) ||
          !str(p.owner) ||
          !tasks.length
        )
          throw Error(
            "Uzupełnij i zapisz cel, ofertę, osobę odpowiedzialną oraz etapy.",
          );
        if (today > monthBefore(date) && !str(p.lateReason))
          throw Error(
            "Termin planu minął. Zapisz uzasadnienie i sposób nadrobienia opóźnienia.",
          );
        await tx.execute(
          sql`update gastro_occurrences set plan_approved_at=now(),plan_approved_by=${admin.username} where event_id=${event.id} and year=${year}`,
        );
        details = {
          plan: p,
          tasks,
          deadline: monthBefore(date),
          late: today > monthBefore(date),
        };
      } else if (b.action === "REOPEN_PLAN") {
        await tx.execute(
          sql`update gastro_occurrences set plan_approved_at=null,plan_approved_by=null where event_id=${event.id} and year=${year}`,
        );
        details = { reason: "Ponowna edycja planu", before: s.plan };
      } else if (b.action === "TASK") {
        const task = tasks.find((t) => Number(t.id) === Number(b.taskId));
        if (
          !task ||
          s.decision !== "CELEBRATE" ||
          (!s.plan_approved_at && b.done !== false)
        )
          throw Error("Potwierdzanie wykonania wymaga zatwierdzonego planu.");
        if (typeof b.done !== "boolean" || (b.done && !str(b.completionNote)))
          throw Error("Opisz wykonanie etapu lub wklej odnośnik do rezultatu.");
        await tx.execute(
          sql`update gastro_tasks set status=${b.done ? "DONE" : "TODO"},completion_note=${str(b.completionNote)},completed_at=${b.done ? new Date().toISOString() : null},completed_by=${b.done ? admin.username : null} where id=${Number(task.id)}`,
        );
        details = {
          taskId: task.id,
          title: task.title,
          done: b.done,
          note: str(b.completionNote),
        };
      } else throw Error("Nieznana operacja.");
      await tx.execute(
        sql`update gastro_occurrences set version=version+1,updated_by=${admin.username},updated_at=now() where event_id=${event.id} and year=${year}`,
      );
      await tx.execute(
        sql`insert into gastro_audit(event_id,year,actor,action,details) values(${event.id},${year},${admin.username},${b.action},${JSON.stringify(details)}::jsonb)`,
      );
    });
    return NextResponse.json({ ok: true });
  } catch (e) {
    const message = e instanceof Error ? e.message : "Nie udało się zapisać.";
    if (message.startsWith("409:")) return fail(message.slice(4), 409);
    console.error("gastro mutation", e);
    return fail(
      message.includes("query")
        ? "Nie udało się zapisać danych. Spróbuj ponownie."
        : message,
    );
  }
}
