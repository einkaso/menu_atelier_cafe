import { readFile } from "node:fs/promises";
import { NextResponse } from "next/server";
import { currentAdmin } from "../../../../../../lib/admin-auth";
export const dynamic = "force-dynamic";
export async function GET(
  _req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  if (!(await currentAdmin()))
    return NextResponse.json(
      { error: "Wymagane konto administratora." },
      { status: 401 },
    );
  const { id } = await params;
  if (!/^[0-6]$/.test(id)) return new NextResponse(null, { status: 404 });
  try {
    return new NextResponse(
      await readFile(`/var/lib/banaszek-menu/gastro-sources/${id}.pdf`),
      {
        headers: {
          "Content-Type": "application/pdf",
          "Content-Disposition": `inline; filename="gastro-source-${id}.pdf"`,
          "Cache-Control": "private, no-store",
          "X-Content-Type-Options": "nosniff",
        },
      },
    );
  } catch {
    return new NextResponse(null, { status: 404 });
  }
}
