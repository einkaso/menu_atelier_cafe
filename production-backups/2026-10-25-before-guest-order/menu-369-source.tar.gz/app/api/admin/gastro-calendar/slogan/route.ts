import {currentAdmin} from '../../../../../lib/admin-auth';
import {dailySlogan} from '../../../../../lib/gastro/slogan';
export const dynamic='force-dynamic';
export async function GET(){
 if(!await currentAdmin())return Response.json({error:'Zaloguj się jako administrator.'},{status:401});
 try{return Response.json(await dailySlogan(),{headers:{'Cache-Control':'no-store'}});}catch{return Response.json({error:'Nie udało się przygotować hasła. Spróbuj ponownie.'},{status:503});}
}
export async function POST(request:Request){
 if(!await currentAdmin())return Response.json({error:'Zaloguj się jako administrator.'},{status:401});
 const origin=request.headers.get('origin');
 if(!origin||new URL(origin).host!==request.headers.get('host'))return Response.json({error:'Nieprawidłowe źródło żądania.'},{status:403});
 try{return Response.json(await dailySlogan(true),{headers:{'Cache-Control':'no-store'}});}catch{return Response.json({error:'Nie udało się przygotować hasła. Spróbuj ponownie.'},{status:503});}
}
