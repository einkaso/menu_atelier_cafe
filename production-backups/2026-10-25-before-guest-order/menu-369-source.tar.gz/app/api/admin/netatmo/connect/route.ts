import { currentAdmin } from "../../../../../lib/admin-auth";
import { createNetatmoOAuthState, netatmoAuthorizationUrl, netatmoCredentialsConfigured, netatmoSiteUrl } from "../../../../../lib/netatmo";

export async function GET(request: Request) {
  const admin = await currentAdmin();
  if (!admin) return Response.json({ error: "Unauthorized" }, { status: 401 });
  if (!netatmoCredentialsConfigured()) return Response.redirect(new URL("/admin/ogrzewanie?error=config", netatmoSiteUrl(request.url)));
  return Response.redirect(netatmoAuthorizationUrl(createNetatmoOAuthState(admin.username)));
}
