import { currentAdmin } from "../../../../../lib/admin-auth";
import { connectNetatmo, netatmoSiteUrl, verifyNetatmoOAuthState } from "../../../../../lib/netatmo";

function destination(request: Request, result: "connected" | "denied" | "invalid" | "failed") {
  const url = new URL("/admin/ogrzewanie", netatmoSiteUrl(request.url));
  url.searchParams.set(result === "connected" ? "connected" : "error", result);
  return url;
}

export async function GET(request: Request) {
  const admin = await currentAdmin();
  if (!admin) return Response.redirect(destination(request, "invalid"));
  const url = new URL(request.url);
  if (url.searchParams.get("error")) return Response.redirect(destination(request, "denied"));
  const code = url.searchParams.get("code")?.trim() ?? "";
  const state = url.searchParams.get("state")?.trim() ?? "";
  if (!code || !verifyNetatmoOAuthState(state, admin.username)) return Response.redirect(destination(request, "invalid"));
  try {
    await connectNetatmo(code, admin.username);
    return Response.redirect(destination(request, "connected"));
  } catch (error) {
    console.error("Netatmo OAuth callback failed", error);
    return Response.redirect(destination(request, "failed"));
  }
}
