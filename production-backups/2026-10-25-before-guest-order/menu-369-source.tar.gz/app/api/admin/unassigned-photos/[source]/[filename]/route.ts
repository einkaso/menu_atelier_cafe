import { readFile } from "node:fs/promises";
import path from "node:path";
import sharp from "sharp";

import { isAdmin } from "../../../../../../lib/admin-auth";
import { unassignedPhotoPath } from "../../../../../../lib/unassigned-photo-review";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

const contentTypes: Record<string, string> = {
  ".avif": "image/avif",
  ".heic": "image/heic",
  ".heif": "image/heif",
  ".jpeg": "image/jpeg",
  ".jpg": "image/jpeg",
  ".png": "image/png",
  ".webp": "image/webp",
};

export async function GET(request: Request, context: { params: Promise<{ source: string; filename: string }> }) {
  if (!(await isAdmin())) return new Response("Not found", { status: 404 });
  const { source, filename } = await context.params;
  const storedPath = unassignedPhotoPath(source, filename);
  if (!storedPath) return new Response("Not found", { status: 404 });

  try {
    const bytes = await readFile(storedPath);
    const url = new URL(request.url);
    if (url.searchParams.get("preview") === "1") {
      const preview = await sharp(bytes)
        .rotate()
        .resize({ width: 720, height: 720, fit: "inside", withoutEnlargement: true })
        .webp({ quality: 78 })
        .toBuffer();
      return new Response(new Uint8Array(preview), {
        headers: {
          "Content-Type": "image/webp",
          "Cache-Control": "private, max-age=86400",
          "X-Content-Type-Options": "nosniff",
        },
      });
    }

    const headers: Record<string, string> = {
      "Content-Type": contentTypes[path.extname(filename).toLowerCase()] ?? "application/octet-stream",
      "Cache-Control": "private, max-age=3600",
      "X-Content-Type-Options": "nosniff",
    };
    if (url.searchParams.get("download") === "1") {
      headers["Content-Disposition"] = `attachment; filename="${filename}"`;
    }
    return new Response(new Uint8Array(bytes), { headers });
  } catch {
    return new Response("Not found", { status: 404 });
  }
}
