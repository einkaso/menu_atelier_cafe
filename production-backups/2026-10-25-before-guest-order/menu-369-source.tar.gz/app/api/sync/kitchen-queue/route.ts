import { timingSafeEqual, randomUUID } from 'node:crypto';
import { sql } from 'drizzle-orm';
import { getDb } from '../../../../db';
import { DotykackaClient } from '../../../../lib/dotykacka/client';
import { getDotykackaConfig } from '../../../../lib/dotykacka/config';
import { advanceQueue, normalizeQueueOrders, preparationMinutes, type QueueState } from '../../../../lib/kitchen-queue';
export const dynamic = 'force-dynamic';
export async function POST(request: Request) {
 const expected=Buffer.from(process.env.SYNC_SECRET ?? ''); const provided=Buffer.from(request.headers.get('authorization')?.replace(/^Bearer\s+/i,'') ?? '');
 if (!expected.length || expected.length!==provided.length || !timingSafeEqual(expected,provided)) return Response.json({error:'Unauthorized'},{status:401});
 try {
  const result = await getDb().transaction(async tx => {
   const [lock]=await tx.execute(sql`SELECT pg_try_advisory_xact_lock(732710327) AS acquired`);
   if (!lock.acquired) return {status:'busy'};
   const [row]=await tx.execute(sql`SELECT state,excluded_table_ids FROM kitchen_queue_state WHERE id=1 FOR UPDATE`);
   if(!row) throw new Error('Queue not configured');
   const client=new DotykackaClient(await getDotykackaConfig());
   const response=await client.posAction({action:'order/list','idempotency-key':randomUUID()});
   if(response.code!==0) throw new Error('POS order list unavailable');
   const orders=normalizeQueueOrders(response.orders);
   const now=Date.now();
   const state=advanceQueue(row.state as QueueState,orders,new Set(row.excluded_table_ids as string[]),now);
   await tx.execute(sql`UPDATE kitchen_queue_state SET state=${JSON.stringify(state)}::jsonb,last_success_at=${new Date(now).toISOString()}::timestamptz WHERE id=1`);
   return {status:'ok',activeBatches:state.batches.length,minutes:preparationMinutes(state.batches.length)};
  });
  return Response.json(result);
 } catch { return Response.json({error:'Kitchen queue synchronization unavailable'},{status:502}); }
}
