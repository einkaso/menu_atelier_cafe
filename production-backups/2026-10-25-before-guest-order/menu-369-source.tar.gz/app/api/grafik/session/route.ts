import { and, eq, isNotNull } from "drizzle-orm";
import { getDb } from "../../../../db";
import { waiterEmployees } from "../../../../db/schema";
import { createScheduleToken, currentScheduleEmployee, normalizedEmployeeName, scheduleCookie } from "../../../../lib/schedule-auth";
import { validWaiterPin, verifyWaiterPin } from "../../../../lib/waiter-auth";
import { clearWaiterLoginFailures, noteWaiterLoginFailure, waiterLoginBlocked, waiterLoginKey } from "../../../../lib/waiter-rate-limit";

export const dynamic = "force-dynamic";

function cookie(value: string, maxAge: number) {
  return `${scheduleCookie.name}=${value}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${maxAge}${process.env.NODE_ENV === "production" ? "; Secure" : ""}`;
}

export async function GET() {
  const employee = await currentScheduleEmployee();
  const headers = { "cache-control": "private, no-cache, no-store, max-age=0, must-revalidate" };
  return employee ? Response.json({ employee }, { headers }) : Response.json({ error: "Sesja grafiku wygasła." }, { status: 401, headers });
}

export async function POST(request: Request) {
  const key = waiterLoginKey(request);
  if (waiterLoginBlocked(key)) return Response.json({ error: "Za dużo nieudanych prób. Spróbuj ponownie za 10 minut." }, { status: 429 });
  const body = await request.json().catch(() => ({})) as { name?: unknown; pin?: unknown };
  const name = typeof body.name === "string" ? normalizedEmployeeName(body.name) : "";
  const pin = typeof body.pin === "string" ? body.pin : "";
  if (!name || name.length > 120 || !validWaiterPin(pin)) return Response.json({ error: "Podaj imię oraz PIN składający się z 4–8 cyfr." }, { status: 400 });
  const employees = await getDb().select({ dotykackaId: waiterEmployees.dotykackaId, name: waiterEmployees.name, pinHash: waiterEmployees.pinHash }).from(waiterEmployees).where(and(
    eq(waiterEmployees.enabled, true),
    eq(waiterEmployees.deleted, false),
    isNotNull(waiterEmployees.pinHash),
  ));
  let match: (typeof employees)[number] | undefined;
  for (const employee of employees) {
    if (normalizedEmployeeName(employee.name) === name && employee.pinHash && await verifyWaiterPin(pin, employee.pinHash)) { match = employee; break; }
  }
  if (!match) {
    noteWaiterLoginFailure(key);
    return Response.json({ error: "Nieprawidłowe imię lub PIN." }, { status: 401 });
  }
  clearWaiterLoginFailures(key);
  const token = createScheduleToken(match.dotykackaId);
  const response = Response.json({ employee: { dotykackaId: match.dotykackaId, name: match.name } });
  response.headers.append("Set-Cookie", cookie(token, scheduleCookie.maxAge));
  return response;
}

export async function DELETE() {
  const response = Response.json({ status: "ok" });
  response.headers.append("Set-Cookie", cookie("", 0));
  return response;
}
