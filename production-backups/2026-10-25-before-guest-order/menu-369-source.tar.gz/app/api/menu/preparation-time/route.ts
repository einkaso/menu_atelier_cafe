import { sql } from 'drizzle-orm';
import { getDb } from '../../../../db';
import { preparationMinutes, type QueueState } from '../../../../lib/kitchen-queue';
export const dynamic = 'force-dynamic';
export async function GET() {
 const headers={'Cache-Control':'no-store'};
 try {
  const [row]=await getDb().execute(sql`SELECT state,last_success_at FROM kitchen_queue_state WHERE id=1`);
  const now=Date.now(); const updated=row?.last_success_at ? new Date(String(row.last_success_at)).getTime() : 0;
  if(!updated || now-updated>120_000 || updated>now+5000) return Response.json({minutes:15,live:false},{headers});
  const count=(row.state as QueueState).batches.filter(b=>b.expiresAt>now).length;
  return Response.json({minutes:preparationMinutes(count),live:true},{headers});
 } catch { return Response.json({minutes:15,live:false},{headers}); }
}
