import { lt } from "drizzle-orm";
import { getDb } from "../../../../db";
import { menuAnalyticsEvents } from "../../../../db/schema";
import { menuAnalyticsBatch } from "../../../../lib/menu-analytics";
export const dynamic = "force-dynamic";
const limits = new Map<string, { count: number; until: number }>();
let lastCleanup = 0;
export async function POST(request: Request) {
  const origin = request.headers.get("origin");
  try { if (!origin || new URL(origin).host !== new URL(request.url).host || request.headers.get("sec-fetch-site") === "cross-site") return new Response(null, { status: 403 }); }
  catch { return new Response(null, { status: 403 }); }
  if (Number(request.headers.get("content-length") ?? 0) > 48000) return new Response(null, { status: 413 });
  const reader = request.body?.getReader();
  if (!reader) return new Response(null, { status: 400 });
  let text = "", bytes = 0; const decoder = new TextDecoder();
  for (;;) { const chunk = await reader.read(); if (chunk.done) break; bytes += chunk.value.length; if (bytes > 48000) { await reader.cancel(); return new Response(null, { status: 413 }); } text += decoder.decode(chunk.value, { stream: true }); }
  text += decoder.decode();
  let value: unknown; try { value = JSON.parse(text); } catch { return new Response(null, { status: 400 }); }
  const parsed = menuAnalyticsBatch.safeParse(value);
  const now = Date.now();
  if (!parsed.success || parsed.data.events.some(event => Date.parse(event.at) < now - 86400000 || Date.parse(event.at) > now + 300000)) return new Response(null, { status: 400 });
  for (const [key, entry] of limits) if (entry.until <= now) limits.delete(key);
  const counts = new Map<string, number>();
  for (const event of parsed.data.events) counts.set(event.sessionId, (counts.get(event.sessionId) ?? 0) + 1);
  if (limits.size > 10000 || [...counts].some(([id, count]) => (limits.get(id)?.count ?? 0) + count > 180)) return new Response(null, { status: 429 });
  for (const [id, count] of counts) { const entry = limits.get(id) ?? { count: 0, until: now + 60000 }; entry.count += count; limits.set(id, entry); }
  try {
    await getDb().insert(menuAnalyticsEvents).values(parsed.data.events.map(({ at, ...event }) => ({ ...event, occurredAt: new Date(at) }))).onConflictDoNothing();
    if (now - lastCleanup > 3600000) {
      await getDb().delete(menuAnalyticsEvents).where(lt(menuAnalyticsEvents.occurredAt, new Date(now - 180 * 86400000)));
      lastCleanup = now;
    }
    return new Response(null, { status: 204 });
  } catch { return new Response(null, { status: 503 }); }
}
