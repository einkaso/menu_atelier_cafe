import { and, desc, eq, gte, inArray, isNotNull, isNull, lt, or } from "drizzle-orm";
import { getDb } from "../../../../../db";
import { waiterEmployees, workSchedules, workShifts, workTimeEntries, workTimeEvents } from "../../../../../db/schema";
import { currentAdmin } from "../../../../../lib/admin-auth";
import { workedMinutes } from "../../../../../lib/workforce";
import { parseWorkforceScan } from "../../../../../lib/workforce-scan";
import { currentWorkforceKiosk } from "../../../../../lib/workforce-kiosk-auth";

import { kioskContext } from "../../../../../lib/kiosk-context";

import { validWaiterPin, verifyWaiterPin } from "../../../../../lib/waiter-auth";
import { clearWaiterLoginFailures, noteWaiterLoginFailure, waiterLoginBlocked, waiterLoginKey } from "../../../../../lib/waiter-rate-limit";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const [administrator, kiosk] = await Promise.all([currentAdmin(), currentWorkforceKiosk()]);
  if (!administrator && !kiosk) return Response.json({ error: "Tablet ewidencji nie został aktywowany przez administratora." }, { status: 401 });
  const body = await request.json().catch(() => ({})) as { payload?: unknown; pin?: unknown; kioskName?: unknown };
  const db = getDb(); const now = new Date();
  let resolvedEmployee: { dotykackaId: string; name: string } | null = null;
  if (Object.prototype.hasOwnProperty.call(body, "pin")) {
    const key = `kiosk-pin:${waiterLoginKey(request)}`;
    if (waiterLoginBlocked(key)) return Response.json({ error: "Za dużo nieudanych prób PIN-u. Spróbuj ponownie za 10 minut lub użyj karty." }, { status: 429 });
    const pin = typeof body.pin === "string" ? body.pin.trim() : "";
    if (!validWaiterPin(pin)) {
      noteWaiterLoginFailure(key);
      return Response.json({ error: "PIN musi mieć od 4 do 8 cyfr." }, { status: 400 });
    }
    const employees = await db.select({ dotykackaId: waiterEmployees.dotykackaId, name: waiterEmployees.name, pinHash: waiterEmployees.pinHash }).from(waiterEmployees).where(and(eq(waiterEmployees.enabled, true), eq(waiterEmployees.deleted, false), isNotNull(waiterEmployees.pinHash)));
    const matches = [];
    for (const candidate of employees) {
      if (candidate.pinHash && await verifyWaiterPin(pin, candidate.pinHash)) matches.push(candidate);
    }
    if (matches.length !== 1) {
      noteWaiterLoginFailure(key);
      return Response.json({ error: matches.length > 1 ? "PIN jest przypisany do więcej niż jednej osoby. Użyj karty i zgłoś to administratorowi." : "Nieprawidłowy PIN." }, { status: 400 });
    }
    clearWaiterLoginFailures(key);
    resolvedEmployee = { dotykackaId: matches[0].dotykackaId, name: matches[0].name };
  } else {
    const payload = parseWorkforceScan(body.payload);
    if (!payload) return Response.json({ error: "To nie jest prawidłowy kod pracownika Atelier Café." }, { status: 400 });
    const matches = await db.select({ dotykackaId: waiterEmployees.dotykackaId, name: waiterEmployees.name }).from(waiterEmployees).where(and(or(eq(waiterEmployees.barcode, payload.barcode), payload.registoQrHash ? eq(waiterEmployees.registoQrHash, payload.registoQrHash) : undefined), payload.employeeDotykackaId ? eq(waiterEmployees.dotykackaId, payload.employeeDotykackaId) : undefined, eq(waiterEmployees.enabled, true), eq(waiterEmployees.deleted, false))).limit(2);
    resolvedEmployee = matches.length === 1 ? matches[0] : null;
    if (!resolvedEmployee) return Response.json({ error: "Kod odczytano, ale nie jest jednoznacznie przypisany do aktywnego pracownika. Sprawdź kartę w panelu pracowników i synchronizację z Registo." }, { status: 409 });
  }
  const employee = resolvedEmployee;
  const [lastEvent] = await db.select().from(workTimeEvents).where(eq(workTimeEvents.employeeDotykackaId, employee.dotykackaId)).orderBy(desc(workTimeEvents.occurredAt)).limit(1);
  if (lastEvent && now.getTime() - lastEvent.occurredAt.getTime() < 20_000) return Response.json({ error: "Kod został już odczytany. Odczekaj chwilę przed kolejnym odbiciem." }, { status: 429 });
  const [open] = await db.select().from(workTimeEntries).where(and(eq(workTimeEntries.employeeDotykackaId, employee.dotykackaId), isNull(workTimeEntries.endedAt), eq(workTimeEntries.status, "OPEN"))).orderBy(desc(workTimeEntries.startedAt)).limit(1);
  const kioskName = kiosk?.name ?? (typeof body.kioskName === "string" ? body.kioskName.trim().slice(0, 100) || "Tablet wejściowy" : "Tablet wejściowy");
  if (open) {
    if (now.getTime() - open.startedAt.getTime() < 60_000) return Response.json({ error: "Wejście zapisano przed chwilą. Wyjście będzie możliwe po minucie." }, { status: 409 });
    const minutes = workedMinutes(open.startedAt, now);
    const closed = await db.transaction(async (tx) => { const updated = await tx.update(workTimeEntries).set({ endedAt: now, workedMinutes: minutes, status: "CLOSED", updatedAt: now }).where(and(eq(workTimeEntries.id, open.id), eq(workTimeEntries.status, "OPEN"), isNull(workTimeEntries.endedAt))).returning({ id: workTimeEntries.id }); if (!updated.length) return false; await tx.insert(workTimeEvents).values({ entryId: open.id, employeeDotykackaId: employee.dotykackaId, employeeName: employee.name, action: "CLOCK_OUT", kioskName, occurredAt: now }); return true; });
    if (!closed) return Response.json({ error: "Poprzednia zmiana została już zamknięta automatycznie. Zeskanuj kod ponownie, aby zapisać nowe wejście." }, { status: 409 });
    return Response.json({ action: "CLOCK_OUT", employee: employee.name, occurredAt: now, workedMinutes: minutes, ...await kioskContext("CLOCK_OUT", employee, now, open.shiftId) });
  }
  const windowStart = new Date(now.getTime() - 6 * 60 * 60 * 1000); const windowEnd = new Date(now.getTime() + 6 * 60 * 60 * 1000);
  const published = await db.select({ id: workSchedules.id }).from(workSchedules).where(eq(workSchedules.status, "PUBLISHED"));
  const [shift] = published.length ? await db.select().from(workShifts).where(and(inArray(workShifts.scheduleId, published.map((schedule) => schedule.id)), eq(workShifts.employeeDotykackaId, employee.dotykackaId), gte(workShifts.startsAt, windowStart), lt(workShifts.startsAt, windowEnd))).orderBy(workShifts.startsAt).limit(1) : [];
  const [entry] = await db.transaction(async (tx) => { const [created] = await tx.insert(workTimeEntries).values({ employeeDotykackaId: employee.dotykackaId, employeeName: employee.name, shiftId: shift?.id ?? null, startedAt: now, source: "QR_KIOSK", status: "OPEN" }).returning(); await tx.insert(workTimeEvents).values({ entryId: created.id, employeeDotykackaId: employee.dotykackaId, employeeName: employee.name, action: "CLOCK_IN", kioskName, occurredAt: now }); return [created]; });
  return Response.json({ action: "CLOCK_IN", employee: employee.name, occurredAt: now, entryId: entry.id, ...await kioskContext("CLOCK_IN", employee, now) });
}
