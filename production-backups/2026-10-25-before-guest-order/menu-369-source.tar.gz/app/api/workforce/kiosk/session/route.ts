import { constantTimeMatch } from "../../../../../lib/admin-auth";
import { createKioskToken, currentWorkforceKiosk, workforceKioskCookie } from "../../../../../lib/workforce-kiosk-auth";
import { clearWaiterLoginFailures, noteWaiterLoginFailure, waiterLoginBlocked, waiterLoginKey } from "../../../../../lib/waiter-rate-limit";
export const dynamic = "force-dynamic";
const headers = { "cache-control": "private, no-store" };
function cookie(value: string, maxAge: number) { return `${workforceKioskCookie.name}=${value}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${maxAge}${process.env.NODE_ENV === "production" ? "; Secure" : ""}`; }
export async function GET() { return await currentWorkforceKiosk() ? Response.json({ok:true},{headers}) : Response.json({error:"Zaloguj tablet do skanera."},{status:401,headers}); }
export async function POST(request: Request) {
  const formRequest = request.headers.get("content-type")?.includes("application/x-www-form-urlencoded") ?? false;
  const origin = request.headers.get("origin");
  if (formRequest && (request.headers.get("sec-fetch-site") === "cross-site" || (origin && new URL(origin).host !== request.headers.get("host")))) return Response.json({error:"Nieprawidłowe źródło logowania."},{status:403,headers});
  const failure = (error:string,message:string,status:number) => formRequest ? new Response(null,{status:303,headers:{...headers,location:`/kiosk?error=${error}`}}) : Response.json({error:message},{status,headers});
  const key = `kiosk:${waiterLoginKey(request)}`;
  if (waiterLoginBlocked(key)) return failure("blocked","Za dużo nieudanych prób. Spróbuj ponownie za 10 minut.",429);
  const configured = process.env.WORKFORCE_KIOSK_PASSWORD;
  if (!configured) return failure("unavailable","Dostęp do skanera nie został skonfigurowany.",503);
  const body = (formRequest ? await request.formData().then(form=>({username:form.get("username"),password:form.get("password")})).catch(()=>null) : await request.json().catch(()=>null)) as {username?:unknown;password?:unknown}|null;
  if (typeof body?.username !== "string" || typeof body?.password !== "string" || body.password.length > 128 || body.username.trim() !== "kiosk" || !constantTimeMatch(body.password, configured)) {
    noteWaiterLoginFailure(key);
    return failure("credentials","Nieprawidłowy login lub hasło.",401);
  }
  clearWaiterLoginFailures(key);
  const response = formRequest ? new Response(null,{status:303,headers:{...headers,location:"/kiosk?logged=1"}}) : Response.json({ok:true},{headers});
  response.headers.append("Set-Cookie",cookie(createKioskToken(),workforceKioskCookie.maxAge));
  return response;
}
export async function DELETE() { const response=Response.json({ok:true},{headers});response.headers.append("Set-Cookie",cookie("",0));return response; }
