import {sql,eq} from 'drizzle-orm';
import {getDb} from '../../../db';
import {inventoryEvents,inventoryStages,inventoryStageItems} from '../../../db/schema';
import {inventoryManager} from '../../../lib/inventory-manager-auth';
import {allocationTotal,type CountMember} from '../../../lib/inventory-group-math';
import {ensureMappedMorning} from '../../../lib/inventory-mapping';
import {isSpecialInventoryProduct} from '../../../lib/inventory-special';
export const dynamic='force-dynamic';
const reply=(data:unknown,status=200)=>Response.json(data,{status,headers:{'Cache-Control':'private, no-store'}});
export async function GET(request:Request){
 if(!await inventoryManager(request))return reply({error:'Dostęp dla administratora i managerki Oli.'},403);
 const db=getDb();
 const products=await db.execute(sql`select p.dotykacka_id as id,p.name,p.unit,p.stock_quantity,p.synced_at,c.name as category,m.group_id,m.factor,m.ignored,m.reason from inventory_catalog_products p left join inventory_catalog_categories c on c.dotykacka_id=p.category_dotykacka_id left join inventory_product_mapping m on m.product_id=p.dotykacka_id where not p.deleted order by p.name`);
 const groups=await db.execute(sql`select g.*, (select max(i.counted_at) from inventory_group_counts gc join inventory_stage_items i on i.id=gc.item_id join inventory_stages s on s.id=i.stage_id where gc.group_id=g.id and s.status='FINISHED') as last_counted_at from inventory_count_groups g where exists(select 1 from inventory_product_mapping m where m.group_id=g.id) order by g.name`);
 const counts=await db.execute(sql`select gc.*,i.product_name,i.unit,i.counted_quantity,i.counted_at,i.expected_quantity,s.id as stage_id,s.status,s.title,s.assigned_employee_name,(select jsonb_object_agg(ci.product_dotykacka_id,ci.counted_quantity) from inventory_stage_items ci where ci.stage_id=s.id and ci.inventory_source='DOTYKACKA') as allocated from inventory_group_counts gc join inventory_stage_items i on i.id=gc.item_id join inventory_stages s on s.id=i.stage_id where s.status<>'CANCELLED' order by s.id desc,i.id limit 300`);
 const version=await db.execute(sql`select coalesce(max(id),0)::text as version from inventory_mapping_audit`);
 return reply({products:products.map(p=>({...p,special:isSpecialInventoryProduct(String(p.id))})),groups,counts,version:version[0].version});
}
export async function POST(request:Request){
 const actor=await inventoryManager(request);if(!actor)return reply({error:'Dostęp dla administratora i managerki Oli.'},403);
 const b=await request.json().catch(()=>null);if(!b||typeof b!=='object'||Array.isArray(b))return reply({error:'Nieprawidłowe dane.'},400);
 if(b.action==='SCHEDULE'){await ensureMappedMorning();return reply({ok:true});}
 return getDb().transaction(async tx=>{
 await tx.execute(sql`select pg_advisory_xact_lock(hashtextextended('inventory-mapping',0))`);
 if(b.action==='CANCEL'){
 const stageId=Number(b.stageId);if(!Number.isSafeInteger(stageId)||stageId<1)return reply({error:'Nieprawidłowy etap.'},400);
 const stages=await tx.execute(sql`select * from inventory_stages where id=${stageId} for update`);
 const rows=await tx.execute(sql`select gc.* from inventory_group_counts gc join inventory_stage_items i on i.id=gc.item_id where i.stage_id=${stageId}`);
 if(!rows.length||!['ASSIGNED','IN_PROGRESS','CHANGES_REQUESTED','SUBMITTED'].includes(String(stages[0]?.status))||rows.some(r=>r.resolved_at))return reply({error:'Tego etapu nie można już anulować.'},409);
 if(typeof b.note!=='string'||!b.note.trim())return reply({error:'Podaj powód anulowania.'},400);
 await tx.update(inventoryStages).set({status:'CANCELLED',adminNote:b.note.trim().slice(0,1000),updatedAt:new Date()}).where(eq(inventoryStages.id,stageId));
 await tx.insert(inventoryEvents).values({stageId,actorType:'ADMIN',actorId:actor.username,actorName:actor.employeeName,action:'CANCELLED',details:{note:b.note.trim().slice(0,1000)}});return reply({ok:true});
 }
 if(b.action==='RESOLVE'){
 const stageId=Number(b.stageId);if(!Number.isSafeInteger(stageId)||stageId<1)return reply({error:'Nieprawidłowy etap.'},400);
 const stages=await tx.execute(sql`select * from inventory_stages where id=${stageId} for update`);
 if(stages[0]?.status!=='SUBMITTED')return reply({error:'Najpierw pracownik musi zakończyć liczenie.'},409);
 const rows=await tx.execute(sql`select gc.*,i.* from inventory_group_counts gc join inventory_stage_items i on i.id=gc.item_id where i.stage_id=${stageId} order by i.id for update of gc,i`);
 if(!rows.length||rows.some(r=>r.resolved_at||r.counted_quantity==null||r.count_status==='PENDING'))return reply({error:'Etap nie jest gotowy do rozdzielenia albo został już rozdzielony.'},409);
 if(typeof b.note!=='string'||!b.note.trim())return reply({error:'Opisz podstawę podziału, np. sprawdzenie opakowań lub dokumentów dostawy.'},400);
 const allocations=b.allocations;
 if(!allocations||typeof allocations!=='object')return reply({error:'Podaj podział.'},400);
 for(const r of rows){try{if(Math.abs(allocationTotal(r.members as CountMember[],allocations[String(r.item_id)]||{})-Number(r.counted_quantity))>0.0005)return reply({error:`Podział „${r.product_name}” musi odpowiadać policzonej ilości ${r.counted_quantity} ${r.unit}.`},400);}catch(e){return reply({error:(e as Error).message},400);}}
 for(const r of rows){
 const members=r.members as CountMember[];const values=allocations[String(r.item_id)];
 for(const m of members){const q=String(values[m.id]).replace(',','.');await tx.insert(inventoryStageItems).values({stageId,inventorySource:'DOTYKACKA',productDotykackaId:m.id,productName:m.name,unit:m.unit,expectedQuantity:m.expected,countedQuantity:q,countStatus:'COUNTED',reasonCode:Number(q)!==Number(m.expected)?String(r.reason_code||'BLAD_EWIDENCJI'):null,adminNote:b.note.trim().slice(0,1000),countedAt:new Date(String(r.counted_at))});}
 await tx.update(inventoryStageItems).set({countStatus:'EXCLUDED'}).where(eq(inventoryStageItems.id,Number(r.item_id)));
 await tx.execute(sql`update inventory_group_counts set resolved_at=now(),resolved_by=${actor.username} where item_id=${Number(r.item_id)}`);
 }
 await tx.insert(inventoryEvents).values({stageId,actorType:'ADMIN',actorId:actor.username,actorName:actor.employeeName,action:'GROUPS_ALLOCATED',details:{allocations,note:b.note.trim().slice(0,1000)}});
 return reply({ok:true});
 }
 if(!['SAVE','IGNORE'].includes(b.action))return reply({error:'Nieznana operacja.'},400);
 const v=await tx.execute(sql`select coalesce(max(id),0)::text as version from inventory_mapping_audit`);
 if(String(b.version)!==v[0].version)return reply({error:'Lista została zmieniona. Odśwież ją przed zapisem.'},409);
 const ids=Array.isArray(b.productIds)?[...new Set(b.productIds.filter((id:unknown):id is string=>typeof id==='string'))] as string[]:[];
 if(!ids.length||ids.length>300||ids.some(id=>!/^\d+$/.test(id)))return reply({error:'Wybierz od 1 do 300 towarów.'},400);
 if(ids.some(isSpecialInventoryProduct))return reply({error:'Kegi pozostają w inwentaryzacji specjalnej.'},409);
 const products=await tx.execute(sql`select dotykacka_id from inventory_catalog_products where dotykacka_id in (${sql.join(ids.map(id=>sql`${id}`),sql`,`)}) and not deleted`);
 if(products.length!==ids.length)return reply({error:'Odśwież katalog produktów.'},409);
 const groupId=b.groupId==null?null:Number(b.groupId);
 if(groupId!==null&&(!Number.isSafeInteger(groupId)||groupId<1))return reply({error:'Nieprawidłowa grupa.'},400);
 const old=await tx.execute(sql`select * from inventory_product_mapping where product_id in (${sql.join(ids.map(id=>sql`${id}`),sql`,`)}) or group_id=${groupId}`);
 const affected=[...new Set(old.map(m=>Number(m.group_id)).filter(Boolean))];
 if(affected.length){const active=await tx.execute(sql`select 1 from inventory_group_counts gc join inventory_stage_items i on i.id=gc.item_id join inventory_stages s on s.id=i.stage_id where gc.group_id in (${sql.join(affected.map(id=>sql`${id}`),sql`,`)}) and s.status not in ('FINISHED','CANCELLED') limit 1`);if(active.length)return reply({error:'Najpierw zakończ aktywne liczenie tych pozycji. Powiązania użyte w liczeniu pozostają stałe.'},409);}
 if(b.action==='IGNORE'){
 if(typeof b.reason!=='string'||!b.reason.trim())return reply({error:'Wpisz powód pominięcia.'},400);
 for(const id of ids)await tx.execute(sql`insert into inventory_product_mapping(product_id,ignored,reason,updated_by) values(${id},true,${b.reason.trim().slice(0,500)},${actor.username}) on conflict(product_id) do update set group_id=null,ignored=true,reason=excluded.reason,updated_by=excluded.updated_by,updated_at=now()`);
 }else{
 if(typeof b.name!=='string'||!b.name.trim()||b.name.length>160||!['kg','g','l','ml','szt.','porcja'].includes(b.unit)||!Number.isInteger(b.intervalDays)||b.intervalDays<1||b.intervalDays>366||typeof b.enabled!=='boolean')return reply({error:'Podaj nazwę, jednostkę i częstotliwość 1–366 dni.'},400);
 for(const id of ids){const f=String(b.factors?.[id]??'').replace(',','.');if(!/^\d+(\.\d{1,3})?$/.test(f)||Number(f)<=0||Number(f)>1e6)return reply({error:'Podaj dodatni przelicznik każdego towaru (do 3 miejsc po przecinku).'},400);}
 if(old.some(m=>m.group_id!=null&&Number(m.group_id)!==groupId))return reply({error:'Towar należy już do innej grupy. Najpierw usuń go z niej przez edycję tej grupy lub oznacz jako pomijany.'},409);
 const duplicate=await tx.execute(sql`select id from inventory_count_groups where lower(trim(name))=lower(${b.name.trim()}) and (${groupId}::integer is null or id<>${groupId}) and exists(select 1 from inventory_product_mapping m where m.group_id=inventory_count_groups.id)`);if(duplicate.length)return reply({error:'Taka nazwa już istnieje — wybierz edycję grupy.'},409);
 const group=groupId===null?await tx.execute(sql`insert into inventory_count_groups(name,unit,interval_days,enabled,updated_by) values(${b.name.trim()},${b.unit},${b.intervalDays},${b.enabled},${actor.username}) returning id`):await tx.execute(sql`update inventory_count_groups set name=${b.name.trim()},unit=${b.unit},interval_days=${b.intervalDays},enabled=${b.enabled},revision=revision+1,updated_by=${actor.username},updated_at=now() where id=${groupId} returning id`);
 if(!group.length)return reply({error:'Grupa nie istnieje.'},404);
 const id=Number(group[0].id);
 await tx.execute(sql`delete from inventory_product_mapping where group_id=${id}`);
 for(const productId of ids)await tx.execute(sql`insert into inventory_product_mapping(product_id,group_id,factor,updated_by) values(${productId},${id},${String(b.factors[productId]).replace(',','.')},${actor.username}) on conflict(product_id) do update set group_id=excluded.group_id,factor=excluded.factor,ignored=false,reason='',updated_by=excluded.updated_by,updated_at=now()`);
 }
 await tx.execute(sql`insert into inventory_mapping_audit(actor,details) values(${actor.username},${JSON.stringify({before:old,request:b})}::jsonb)`);
 return reply({ok:true});
 });
}
