import {isSpecialInventoryProduct} from '../../../lib/inventory-special';
import {ownProducts,saveOwnProduct,assignMorning} from '../../../lib/inventory-own';
import {sql} from 'drizzle-orm';
import {getDb} from '../../../db';
import {currentAdmin} from '../../../lib/admin-auth';
import {currentWaiter} from '../../../lib/waiter-auth';
import {quantityToMillis} from '../../../lib/inventory';
import {inventoryDue} from '../../../lib/inventory-care';
export const dynamic='force-dynamic';
async function identity(request:Request){const admin=await currentAdmin();if(admin)return {admin:true,id:admin.username,name:admin.employeeName||admin.username};const w=await currentWaiter(request);return w?{admin:false,id:w.dotykackaId,name:w.name}:null;}
export async function GET(request:Request){
 const actor=await identity(request);if(!actor)return Response.json({error:'Zaloguj się.'},{status:401});if(!actor.admin)return Response.json({error:'Ten obszar jest dostępny wyłącznie w panelu administratora. Przydzielone zadania znajdziesz w swojej inwentaryzacji.'},{status:403});
 const db=getDb();
 const ingredientProducts=await db.execute(sql`select p.dotykacka_id as id,p.name,p.unit,p.stock_quantity,p.synced_at,p.category_dotykacka_id as category_id,c.name as category_name,pol.interval_days,pol.minimum_quantity,pol.lead_days,
 last_count.counted_quantity,last_count.counted_at,last_count.quality,last_count.item_id,
 exists(select 1 from inventory_stage_items i join inventory_stages s on s.id=i.stage_id where i.product_dotykacka_id=p.dotykacka_id and s.status in ('ASSIGNED','IN_PROGRESS','CHANGES_REQUESTED','SUBMITTED')) as assigned
 from inventory_catalog_products p join inventory_catalog_categories c on c.dotykacka_id=p.category_dotykacka_id
 left join inventory_product_policies pol on pol.product_id=p.dotykacka_id
 left join lateral(select i.id as item_id,i.counted_quantity,i.counted_at,i.quality from inventory_stage_items i join inventory_stages s on s.id=i.stage_id where i.product_dotykacka_id=p.dotykacka_id and s.approved_at is not null and s.status<>'CANCELLED' and i.counted_at is not null order by i.counted_at desc,i.id desc limit 1) last_count on true
 where not p.deleted and not c.deleted and lower(trim(c.name)) in ('składniki','skladniki') order by p.name`);
 const products:Record<string,unknown>[]=[...ingredientProducts.filter(p=>!isSpecialInventoryProduct(String(p.id))).map(p=>({...p,source:'DOTYKACKA'})),...await ownProducts()];
 const lossProducts=await db.execute(sql`select p.dotykacka_id as id,p.name,p.unit,c.name as category_name from inventory_catalog_products p left join inventory_catalog_categories c on c.dotykacka_id=p.category_dotykacka_id where not p.deleted order by p.name`);
 const losses=await db.execute(sql`select l.*,p.name,p.unit from inventory_losses l join inventory_catalog_products p on p.dotykacka_id=l.product_id order by l.created_at desc limit 200`);
 const openLosses=await db.execute(sql`select l.*,p.name,p.unit from inventory_losses l join inventory_catalog_products p on p.dotykacka_id=l.product_id where l.status<>'VOID' and not exists(select 1 from inventory_reminder_resolutions r where r.origin='loss:'||l.id::text) order by l.created_at desc`);
 const resolved=await db.execute(sql`select origin from inventory_reminder_resolutions`);const done=new Set(resolved.map(r=>r.origin));
 const reminders:Array<{origin:string;name:string;text:string}>=[];
 for(const l of openLosses)if(l.status!=='VOID'&&!done.has('loss:'+l.id))reminders.push({origin:'loss:'+l.id,name:String(l.name),text:`Strata ${l.quantity} ${l.unit||'szt.'}; pozostało ${l.remaining_quantity}. Sprawdź potrzebę uzupełnienia.`});
 for(const p of products){
 const quality=p.quality as {lossQuantity?:string;expiry?:string;freshness?:string}|null;
 const urgent=quality?.freshness==='USE_FIRST'||quality?.freshness==='DISPOSE'||Boolean(quality?.expiry && quality.expiry<=new Date(Date.now()+Number(p.lead_days??1)*86400000).toISOString().slice(0,10));
 if(p.item_id && (Number(p.counted_quantity)<=Number(p.minimum_quantity??0)||Number(quality?.lossQuantity)>0||urgent)) {
 const origin='count:'+p.item_id+':'+new Date(String(p.counted_at)).toISOString();
 if(!done.has(origin))reminders.push({origin,name:String(p.name),text:`${p.source==='OWN'?'Do przygotowania na kolejny poranek — ostatni pomiar':'Po zatwierdzonym liczeniu'}: ${p.counted_quantity} ${p.unit||'szt.'}. ${urgent?`Sprawdź świeżość i termin ${quality?.expiry||'niepodany'}; zużyj w pierwszej kolejności lub uzupełnij.`:'Sprawdź uzupełnienie.'}`});
 }}
 return Response.json({admin:actor.admin,lossProducts,products:products.map(p=>({...p,due:inventoryDue(p.counted_at?String(p.counted_at):null,p.interval_days?Number(p.interval_days):null)})),losses,reminders});
}
export async function POST(request:Request){
 const actor=await identity(request);if(!actor)return Response.json({error:'Zaloguj się.'},{status:401});if(!actor.admin)return Response.json({error:'Ten obszar jest dostępny wyłącznie w panelu administratora. Przydzielone zadania znajdziesz w swojej inwentaryzacji.'},{status:403});const b=await request.json().catch(()=>({}));if(!b||typeof b!=='object'||Array.isArray(b))return Response.json({error:'Nieprawidłowe dane.'},{status:400});const db=getDb();
 if(b.action==='OWN_SAVE'||b.action==='ASSIGN_MORNING'){
 if(!actor.admin)return Response.json({error:'Tylko administrator.'},{status:403});
 return b.action==='OWN_SAVE'?saveOwnProduct(b,actor.id):assignMorning(b,actor);
 }
 if(b.action==='POLICY'){
 if(!actor.admin)return Response.json({error:'Tylko administrator.'},{status:403});
 if(![1,5,6,7,14,30].includes(b.intervalDays)||quantityToMillis(b.minimum)==null||!Number.isInteger(b.leadDays)||b.leadDays<0||b.leadDays>60)return Response.json({error:'Sprawdź częstotliwość, minimum i czas dostawy.'},{status:400});
 const p=await db.execute(sql`select dotykacka_id from inventory_catalog_products where dotykacka_id=${String(b.productId)} and not deleted`);if(!p.length)return Response.json({error:'Brak produktu.'},{status:404});
 await db.execute(sql`insert into inventory_product_policies(product_id,interval_days,minimum_quantity,lead_days,updated_by) values(${String(b.productId)},${b.intervalDays},${String(b.minimum).replace(',','.')},${b.leadDays},${actor.id}) on conflict(product_id) do update set interval_days=excluded.interval_days,minimum_quantity=excluded.minimum_quantity,lead_days=excluded.lead_days,updated_by=excluded.updated_by,updated_at=now()`);
 }else if(b.action==='LOSS'){
 if(!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(String(b.requestId))||!['ZEPSUCIE','PRZETERMINOWANIE','ZNISZCZENIE','ZAGUBIENIE','INNE'].includes(b.reason)||!quantityToMillis(b.quantity)||quantityToMillis(b.remaining)==null||typeof b.note!=='string'||!b.note.trim())return Response.json({error:'Podaj produkt, ilość straty, pozostały stan, przyczynę i opis.'},{status:400});
 return db.transaction(async db=>{
 await db.execute(sql`select pg_advisory_xact_lock(hashtextextended(${String(b.requestId)},0))`);
 const p=await db.execute(sql`select dotykacka_id from inventory_catalog_products where dotykacka_id=${String(b.productId)} and not deleted`);if(!p.length)return Response.json({error:'Brak produktu.'},{status:404});
 const existing=await db.execute(sql`select * from inventory_losses where request_id=${String(b.requestId)}::uuid`);
 if(existing.length){const old=existing[0];if(old.actor_id!==actor.id||old.product_id!==String(b.productId)||Number(old.quantity)!==Number(String(b.quantity).replace(',','.'))||Number(old.remaining_quantity)!==Number(String(b.remaining).replace(',','.'))||old.reason!==b.reason||old.note!==b.note.trim().slice(0,1000))return Response.json({error:"To zgłoszenie zostało już zapisane z innymi danymi. Odśwież stronę przed nowym zgłoszeniem."},{status:409});return Response.json({ok:true});}
 await db.execute(sql`insert into inventory_losses(request_id,product_id,quantity,remaining_quantity,reason,note,actor_id,actor_name) values(${String(b.requestId)}::uuid,${String(b.productId)},${String(b.quantity).replace(',','.')},${String(b.remaining).replace(',','.')},${b.reason},${b.note.trim().slice(0,1000)},${actor.id},${actor.name}) on conflict(request_id) do nothing`);
 return Response.json({ok:true});
 });
 }else if(b.action==='REVIEW'){
 if(!actor.admin)return Response.json({error:'Tylko administrator.'},{status:403});if(!Number.isSafeInteger(b.id)||!['REVIEWED','VOID'].includes(b.status)||typeof b.note!=='string'||!b.note.trim())return Response.json({error:'Podaj decyzję i komentarz.'},{status:400});
 const updated=await db.execute(sql`update inventory_losses set status=${b.status},review_note=${b.note.trim().slice(0,1000)},reviewed_by=${actor.id},reviewed_at=now() where id=${b.id} and status='REPORTED' returning id`);if(!updated.length)return Response.json({error:'Zgłoszenie już rozpatrzono. Odśwież listę.'},{status:409});
 }else if(b.action==='RESOLVE'){
 if(!actor.admin)return Response.json({error:'Tylko administrator.'},{status:403});if(typeof b.origin!=='string'||!/^(loss:\d+|count:\d+:.+)$/.test(b.origin)||b.origin.length>100)return Response.json({error:'Nieprawidłowe przypomnienie.'},{status:400});await db.execute(sql`insert into inventory_reminder_resolutions(origin,resolved_by) values(${b.origin},${actor.id}) on conflict(origin) do nothing`);
 }else return Response.json({error:'Nieznana operacja.'},{status:400});
 return Response.json({ok:true});
}
