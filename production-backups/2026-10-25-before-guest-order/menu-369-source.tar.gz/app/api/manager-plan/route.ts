import { sql } from "drizzle-orm";
import { getDb } from "../../../db";
import { currentAdmin } from "../../../lib/admin-auth";
import { currentWorkforceEmployee } from "../../../lib/workforce-employee-auth";
import { isPlanManager, parsePlanDay, planToday, validPlanDate, type PlanDay } from "../../../lib/manager-plan";
export const dynamic = "force-dynamic";
const headers = { "Cache-Control":"private, no-store" };
const reply = (body: unknown, status=200) => Response.json(body,{status,headers});
async function identity(request: Request) {
  const admin = await currentAdmin();
  if (admin) return { admin:true, actor:`Administrator: ${admin.username}` };
  const employee = await currentWorkforceEmployee(request);
  return employee && isPlanManager(employee.dotykackaId) ? {admin:false,actor:`${employee.name} (${employee.dotykackaId})`} : null;
}
function rowDay(row: Record<string,unknown>): PlanDay {
  return { date:String(row.date), kind:row.kind as PlanDay["kind"], intervals:row.intervals as PlanDay["intervals"], note:String(row.note), revision:Number(row.revision) };
}
export async function GET(request: Request) {
  const who = await identity(request);
  if (!who) return reply({error:"Brak dostępu do planu managerki. Zaloguj się jako Aleksandra lub administrator."},403);
  const url = new URL(request.url), from = url.searchParams.get("from"), to = url.searchParams.get("to");
  if (!validPlanDate(from) || !validPlanDate(to) || to < from || Date.parse(to)-Date.parse(from)>62*86400000) return reply({error:"Wybierz okres do 63 dni."},400);
  const db = getDb();
  const rows = await db.execute(sql`SELECT work_date::text AS date, kind, intervals, note, revision FROM manager_plan_days WHERE work_date BETWEEN ${from}::date AND ${to}::date ORDER BY work_date`);
  const auditDate = url.searchParams.get("history");
  let history: unknown[] = [];
  if (auditDate) {
    if (!who.admin) return reply({error:"Historia zmian jest dostępna tylko administratorowi."},403);
    if (!validPlanDate(auditDate) || auditDate<from || auditDate>to) return reply({error:"Nieprawidłowa data historii."},400);
    history = Array.from(await db.execute(sql`SELECT id, actor, before_entry AS "before", after_entry AS "after", changed_at AS "changedAt" FROM manager_plan_audit WHERE work_date=${auditDate}::date ORDER BY id DESC`));
  }
  return reply({days:Array.from(rows).map(rowDay), today:planToday(), admin:who.admin, history});
}
export async function PUT(request: Request) {
  const who = await identity(request);
  if (!who) return reply({error:"Brak dostępu. Zaloguj się ponownie jako Aleksandra lub administrator."},403);
  let day: PlanDay;
  try {day=parsePlanDay(await request.json());} catch(error) {return reply({error:error instanceof Error?error.message:"Nieprawidłowy wpis."},400);}
  try {
    const saved = await getDb().transaction(async tx=>{
      await tx.execute(sql`SELECT pg_advisory_xact_lock(hashtext(${'manager-plan:'+day.date}))`);
      const rows = await tx.execute(sql`SELECT work_date::text AS date, kind, intervals, note, revision FROM manager_plan_days WHERE work_date=${day.date}::date FOR UPDATE`);
      const previous = rows[0] ? rowDay(rows[0]) : null;
      if ((previous?.revision ?? 0)!==day.revision) throw Error("CONFLICT");
      const next = {...day,revision:day.revision+1};
      await tx.execute(sql`INSERT INTO manager_plan_days (work_date,kind,intervals,note,revision) VALUES (${day.date}::date,${day.kind},${JSON.stringify(day.intervals)}::jsonb,${day.note},${next.revision}) ON CONFLICT (work_date) DO UPDATE SET kind=EXCLUDED.kind, intervals=EXCLUDED.intervals, note=EXCLUDED.note, revision=EXCLUDED.revision, updated_at=now()`);
      await tx.execute(sql`INSERT INTO manager_plan_audit (work_date,actor,before_entry,after_entry) VALUES (${day.date}::date,${who.actor},${previous?JSON.stringify(previous):null}::jsonb,${JSON.stringify(next)}::jsonb)`);
      return next;
    });
    return reply({day:saved});
  } catch(error) {
    if (error instanceof Error && error.message==="CONFLICT") return reply({error:"Ten dzień został zmieniony w innym oknie. Zamknij edycję i odśwież plan przed ponowną zmianą."},409);
    console.error("manager plan save failed",error);
    return reply({error:"Nie udało się zapisać planu. Spróbuj ponownie."},500);
  }
}
