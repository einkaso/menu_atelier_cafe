import {eq} from "drizzle-orm";
import {getDb} from "../../../../db";
import {menuCategories,menuProducts,productContent} from "../../../../db/schema";
import {photoReviewCatalog,photoReviewCorsOrigin} from "../../../../lib/photo-review-catalog";
import {GET as publicMenu} from "../../menu/route";
export const dynamic="force-dynamic";
export async function GET(request:Request){
 const origin=request.headers.get("origin"),allowed=photoReviewCorsOrigin(origin);
 const headers:Record<string,string>={"cache-control":"no-store","vary":"Origin"};
 if(origin&&!allowed)return Response.json({error:"Origin not allowed"},{status:403,headers});
 if(allowed)headers["access-control-allow-origin"]=allowed;
 try{
  const db=getDb();const[rows,response]=await Promise.all([
   db.select({id:menuProducts.id,name:menuProducts.name,category:menuCategories.name,imagePath:productContent.imagePath}).from(menuProducts).innerJoin(menuCategories,eq(menuProducts.dotykackaCategoryId,menuCategories.dotykackaId)).leftJoin(productContent,eq(menuProducts.id,productContent.productId)).where(eq(menuProducts.deleted,false)),
   publicMenu()
  ]);
  if(!response.ok)throw Error("Public menu unavailable");
  const menu=await response.json();
  return Response.json({products:photoReviewCatalog(rows,menu.products),updatedAt:new Date().toISOString(),source:"dotykacka"},{headers});
 }catch{return Response.json({error:"Nie udało się odświeżyć listy produktów."},{status:503,headers});}
}
