import { and, desc, eq, inArray } from "drizzle-orm";
import { getDb } from "../../../../db";
import { staffInstructionReceipts, staffInstructions, staffInstructionVersions } from "../../../../db/schema";
import { instructionDiff } from "../../../../lib/instruction-diff";
import { currentWaiter } from "../../../../lib/waiter-auth";

export const dynamic = "force-dynamic";
const DEFER_MILLISECONDS = 2 * 60 * 60 * 1000;

export async function GET(request: Request) {
  const employee = await currentWaiter(request);
  if (!employee) return Response.json({ error: "Sesja pracownika wygasła." }, { status: 401 });
  const db = getDb();
  const instructions = await db.select().from(staffInstructions)
    .where(inArray(staffInstructions.status, ["PUBLISHED", "ARCHIVED"]))
    .orderBy(desc(staffInstructions.publishedAt), desc(staffInstructions.id));
  const receipts = instructions.length ? await db.select().from(staffInstructionReceipts).where(and(
    eq(staffInstructionReceipts.employeeDotykackaId, employee.dotykackaId),
    inArray(staffInstructionReceipts.instructionId, instructions.map((instruction) => instruction.id)),
  )) : [];
  const versions = instructions.length ? await db.select().from(staffInstructionVersions).where(inArray(staffInstructionVersions.instructionId, instructions.map(item => item.id))) : [];
  const receiptByVersion = new Map(receipts.map((receipt) => [`${receipt.instructionId}:${receipt.instructionRevision}`, receipt]));
  const now = Date.now();
  const result = instructions.map((instruction) => {
    const receipt = receiptByVersion.get(`${instruction.id}:${instruction.revision}`);
    const acknowledged = Boolean(receipt?.acknowledgedAt);
    const deferred = !acknowledged && Boolean(receipt?.deferredUntil && receipt.deferredUntil.getTime() > now);
    const due = instruction.status === "PUBLISHED" && !acknowledged && !deferred;
    const previous = receipts.filter(item => item.instructionId === instruction.id && item.acknowledgedAt && item.instructionRevision < instruction.revision).sort((a,b) => b.instructionRevision - a.instructionRevision)[0];
    const baseline = previous?.contentVersion ? versions.find(item => item.instructionId === instruction.id && item.contentVersion === previous.contentVersion) : null;
    const changes = !acknowledged && previous ? baseline ? {
      ...instructionDiff(baseline.content, instruction.content),
      previousTitle: baseline.title !== instruction.title ? baseline.title : null,
      addedAttachments: instruction.attachments.filter(item => !baseline.attachments.some(old => old.id === item.id)).map(item => item.name),
      removedAttachments: baseline.attachments.filter(item => !instruction.attachments.some(current => current.id === item.id)).map(item => item.name),
    } : { unavailable: true } : null;
    return {
      changes,
      contentVersion: instruction.contentVersion,
      id: instruction.id,
      title: instruction.title,
      content: instruction.content,
      attachments: instruction.attachments,
      status: instruction.status,
      revision: instruction.revision,
      publishedAt: instruction.publishedAt,
      archivedAt: instruction.archivedAt,
      acknowledgedAt: receipt?.acknowledgedAt ?? null,
      deferredUntil: receipt?.deferredUntil ?? null,
      canDefer: instruction.status === "PUBLISHED" && !acknowledged && !receipt?.deferredAt,
      due,
    };
  });
  return Response.json({
    employee,
    instructions: result,
    pendingCount: result.filter((instruction) => instruction.status === "PUBLISHED" && !instruction.acknowledgedAt).length,
    dueCount: result.filter((instruction) => instruction.due).length,
  });
}

export async function POST(request: Request) {
  const employee = await currentWaiter(request);
  if (!employee) return Response.json({ error: "Sesja pracownika wygasła." }, { status: 401 });
  const body = await request.json().catch(() => ({})) as { instructionId?: unknown; action?: unknown; declaration?: unknown; contentVersion?: unknown; revision?: unknown };
  const instructionId = Number(body.instructionId);
  const action = typeof body.action === "string" ? body.action : "";
  if (!Number.isInteger(instructionId) || instructionId < 1) return Response.json({ error: "Nieprawidłowa instrukcja." }, { status: 400 });
  const db = getDb();
  return db.transaction(async tx => {
  const [instruction] = await tx.select().from(staffInstructions).where(eq(staffInstructions.id, instructionId)).for("update");
  if (!instruction || instruction.status !== "PUBLISHED") return Response.json({ error: "Ta instrukcja nie jest już aktywna." }, { status: 409 });
  if (action === "ACKNOWLEDGE" && (body.contentVersion !== instruction.contentVersion || body.revision !== instruction.revision)) return Response.json({ error: "Instrukcja zmieniła się podczas czytania. Otwórz aktualną wersję i przeczytaj ją przed potwierdzeniem." }, { status: 409 });
  const [receipt] = await tx.select().from(staffInstructionReceipts).where(and(
    eq(staffInstructionReceipts.instructionId, instruction.id),
    eq(staffInstructionReceipts.instructionRevision, instruction.revision),
    eq(staffInstructionReceipts.employeeDotykackaId, employee.dotykackaId),
  )).limit(1);
  if (receipt?.acknowledgedAt) return Response.json({ ok: true, acknowledgedAt: receipt.acknowledgedAt });
  const now = new Date();
  if (action === "DEFER") {
    if (receipt?.deferredAt) return Response.json({ error: "Tę instrukcję można odłożyć tylko jeden raz." }, { status: 409 });
    const deferredUntil = new Date(now.getTime() + DEFER_MILLISECONDS);
    await tx.insert(staffInstructionReceipts).values({
      instructionId: instruction.id,
      instructionRevision: instruction.revision,
      employeeDotykackaId: employee.dotykackaId,
      employeeName: employee.name,
      firstPresentedAt: now,
      deferredAt: now,
      deferredUntil,
    }).onConflictDoUpdate({
      target: [staffInstructionReceipts.instructionId, staffInstructionReceipts.employeeDotykackaId, staffInstructionReceipts.instructionRevision],
      set: { employeeName: employee.name, firstPresentedAt: receipt?.firstPresentedAt ?? now, deferredAt: now, deferredUntil, updatedAt: now },
    });
    return Response.json({ ok: true, deferredUntil });
  }
  if (action === "ACKNOWLEDGE") {
    if (body.declaration !== "I_HAVE_READ") return Response.json({ error: "Potwierdź oświadczenie o zapoznaniu się z instrukcją." }, { status: 400 });
    await tx.insert(staffInstructionReceipts).values({
      instructionId: instruction.id,
      instructionRevision: instruction.revision,
      employeeDotykackaId: employee.dotykackaId,
      employeeName: employee.name,
      firstPresentedAt: receipt?.firstPresentedAt ?? now,
      deferredAt: receipt?.deferredAt ?? null,
      deferredUntil: receipt?.deferredUntil ?? null,
      acknowledgedAt: now,
      contentVersion: instruction.contentVersion,
    }).onConflictDoUpdate({
      target: [staffInstructionReceipts.instructionId, staffInstructionReceipts.employeeDotykackaId, staffInstructionReceipts.instructionRevision],
      set: { employeeName: employee.name, firstPresentedAt: receipt?.firstPresentedAt ?? now, acknowledgedAt: now, contentVersion: instruction.contentVersion, updatedAt: now },
    });
    return Response.json({ ok: true, acknowledgedAt: now });
  }
  return Response.json({ error: "Nieznana operacja." }, { status: 400 });
  });
}
