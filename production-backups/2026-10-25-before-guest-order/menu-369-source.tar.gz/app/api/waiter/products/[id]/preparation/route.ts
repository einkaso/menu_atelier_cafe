import { currentWaiter } from "../../../../../../lib/waiter-auth";
import { readPreparationCard } from "../../../../../../lib/kitchen-recipes-server";

export const dynamic = "force-dynamic";
export async function GET(request: Request, context: { params: Promise<{ id: string }> }) {
  if (!(await currentWaiter(request))) return Response.json({ error: "Zaloguj się ponownie do strefy pracownika." }, { status: 401 });
  const id = Number((await context.params).id);
  if (!Number.isSafeInteger(id) || id < 1) return Response.json({ error: "Nieprawidłowe danie." }, { status: 400 });
  const card = await readPreparationCard(id);
  return card ? Response.json({ card }, { headers: { "Cache-Control": "private, no-store" } }) : Response.json({ error: "Danie nie istnieje." }, { status: 404 });
}
