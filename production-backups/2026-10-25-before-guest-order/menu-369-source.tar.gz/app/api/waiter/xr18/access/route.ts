import { and, eq } from "drizzle-orm";
import { getDb } from "../../../../../db";
import { waiterEmployees } from "../../../../../db/schema";
import { httpOnlyCookie, requestUsesHttps } from "../../../../../lib/guest-receipt-auth";
import { currentWaiter, verifyWaiterPin } from "../../../../../lib/waiter-auth";
import { clearWaiterLoginFailures, noteWaiterLoginFailure, waiterLoginBlocked, waiterLoginKey } from "../../../../../lib/waiter-rate-limit";
import { createXr18AccessToken, validXr18Pin, xr18AccessCookie } from "../../../../../lib/xr18-access";

export async function POST(request: Request) {
  const employee = await currentWaiter(request);
  if (!employee) return Response.json({ error: "Sesja pracownika wygasła." }, { status: 401 });
  if (!employee.canControlXr18) return Response.json({ error: "Nie masz uprawnienia eksperta XR18." }, { status: 403 });
  const rateKey = `xr18:${employee.dotykackaId}:${waiterLoginKey(request)}`;
  if (waiterLoginBlocked(rateKey)) return Response.json({ error: "Za dużo nieudanych prób. Dostęp XR18 zablokowano na 10 minut." }, { status: 429 });
  const body = await request.json().catch(() => ({})) as { pin?: unknown };
  const pin = typeof body.pin === "string" ? body.pin : "";
  if (!validXr18Pin(pin)) return Response.json({ error: "PIN XR18 musi mieć dokładnie 6 cyfr." }, { status: 400 });
  const [record] = await getDb().select({ xr18PinHash: waiterEmployees.xr18PinHash }).from(waiterEmployees).where(and(
    eq(waiterEmployees.dotykackaId, employee.dotykackaId),
    eq(waiterEmployees.enabled, true),
    eq(waiterEmployees.deleted, false),
  )).limit(1);
  if (!record?.xr18PinHash) return Response.json({ error: "Administrator nie ustawił jeszcze dodatkowego PIN-u XR18." }, { status: 409 });
  if (!(await verifyWaiterPin(pin, record.xr18PinHash))) {
    noteWaiterLoginFailure(rateKey);
    return Response.json({ error: "Nieprawidłowy PIN XR18." }, { status: 401 });
  }
  clearWaiterLoginFailures(rateKey);
  const token = createXr18AccessToken(employee.dotykackaId);
  const response = Response.json({ ok: true, token });
  response.headers.append("Set-Cookie", httpOnlyCookie(xr18AccessCookie.name, token, xr18AccessCookie.maxAge, requestUsesHttps(request)));
  return response;
}

export async function DELETE(request: Request) {
  const response = Response.json({ ok: true });
  response.headers.append("Set-Cookie", httpOnlyCookie(xr18AccessCookie.name, "", 0, requestUsesHttps(request)));
  return response;
}
