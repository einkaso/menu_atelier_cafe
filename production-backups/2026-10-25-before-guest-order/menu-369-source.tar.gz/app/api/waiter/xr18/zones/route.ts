import { currentWaiter } from "../../../../../lib/waiter-auth";
import { changeXr18Setting, readXr18Zones } from "../../../../../lib/xr18";
import { validXr18ZoneChange } from "../../../../../lib/xr18-zones";
import { getDb } from "../../../../../db";
import { xr18ControlEvents } from "../../../../../db/schema";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const employee = await currentWaiter(request);
  if (!employee) return Response.json({ error: "Sesja pracownika wygasła." }, { status: 401 });
  try {
    return Response.json({ employeeName: employee.name, zones: await readXr18Zones() });
  } catch {
    return Response.json({ error: "Nie można odczytać głośności stref. Sprawdź połączenie z mikserem." }, { status: 502 });
  }
}

export async function PATCH(request: Request) {
  const employee = await currentWaiter(request);
  if (!employee) return Response.json({ error: "Sesja pracownika wygasła." }, { status: 401 });
  const body = await request.json().catch(() => null);
  if (!body || !validXr18ZoneChange(body)) return Response.json({ error: "Dozwolona jest tylko zmiana głośności trzech stref." }, { status: 400 });
  const targetId = body.targetId as string, requestedValue = body.value as number;
  const actor = { actorDotykackaId: employee.dotykackaId, actorName: employee.name, targetId, property: "fader", requestedValue };
  try {
    const change = await changeXr18Setting(targetId, "fader", requestedValue);
    await getDb().insert(xr18ControlEvents).values({ ...actor, previousValue: change.previousValue, observedValue: change.value, status: "SUCCEEDED" }).catch(() => undefined);
    return Response.json({ ok: true, change });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Mikser nie potwierdził zmiany głośności.";
    await getDb().insert(xr18ControlEvents).values({ ...actor, status: "FAILED", error: message.slice(0, 1000) }).catch(() => undefined);
    return Response.json({ error: message }, { status: 502 });
  }
}
