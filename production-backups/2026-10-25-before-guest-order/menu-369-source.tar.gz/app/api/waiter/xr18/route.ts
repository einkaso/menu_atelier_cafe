import { getDb } from "../../../../db";
import { xr18ControlEvents } from "../../../../db/schema";
import { currentWaiter } from "../../../../lib/waiter-auth";
import { hasXr18Access } from "../../../../lib/xr18-access";
import { changeXr18Setting, readXr18State, setXr18SettingFast, xr18Configured, type Xr18Property } from "../../../../lib/xr18";

export const dynamic = "force-dynamic";

function errorMessage(error: unknown) {
  return error instanceof Error ? error.message : "Nie udało się połączyć z XR18.";
}

async function authorized(request: Request) {
  const employee = await currentWaiter(request);
  if (!employee) return { response: Response.json({ error: "Sesja pracownika wygasła." }, { status: 401 }) };
  if (!employee.canControlXr18) return { response: Response.json({ error: "Nie masz uprawnienia eksperta XR18." }, { status: 403 }) };
  if (!(await hasXr18Access(request, employee.dotykackaId))) {
    return { response: Response.json({ locked: true, error: "Podaj dodatkowy 6-cyfrowy PIN XR18." }, { status: 423 }) };
  }
  return { employee };
}

export async function GET(request: Request) {
  const auth = await authorized(request);
  if ("response" in auth) return auth.response;
  if (!xr18Configured()) return Response.json({ configured: false, error: "Adres XR18 nie jest skonfigurowany na serwerze." }, { status: 503 });
  try {
    return Response.json({ configured: true, employeeName: auth.employee.name, mixer: await readXr18State() });
  } catch (error) {
    return Response.json({ configured: true, error: errorMessage(error) }, { status: 502 });
  }
}

export async function PATCH(request: Request) {
  const auth = await authorized(request);
  if ("response" in auth) return auth.response;
  if (!xr18Configured()) return Response.json({ error: "Adres XR18 nie jest skonfigurowany na serwerze." }, { status: 503 });
  const body = await request.json().catch(() => ({})) as {
    targetId?: unknown;
    property?: unknown;
    value?: unknown;
    live?: unknown;
  };
  const targetId = typeof body.targetId === "string" ? body.targetId : "";
  const property = body.property === "on" || body.property === "fader" || body.property === "pan" ? body.property as Xr18Property : null;
  if (!/^(ch-(0[1-9]|1[0-6])|aux|fx-[1-4]|bus-[1-6]|dca-[1-4]|lr)$/.test(targetId) || !property) {
    return Response.json({ error: "Nieprawidłowy kanał lub ustawienie XR18." }, { status: 400 });
  }
  if (property === "on" && typeof body.value !== "boolean") return Response.json({ error: "Nieprawidłowy stan wyciszenia." }, { status: 400 });
  if ((property === "fader" || property === "pan") && (typeof body.value !== "number" || !Number.isFinite(body.value) || body.value < 0 || body.value > 1)) {
    return Response.json({ error: property === "pan" ? "Panorama musi mieścić się w zakresie L–R." : "Poziom kanału musi mieścić się w zakresie 0–100%." }, { status: 400 });
  }
  const requestedValue = body.value as boolean | number;
  try {
    if (body.live === true && property !== "on") {
      return Response.json({ ok: true, change: await setXr18SettingFast(targetId, property, requestedValue), live: true });
    }
    const result = await changeXr18Setting(targetId, property, requestedValue);
    await getDb().insert(xr18ControlEvents).values({
      actorDotykackaId: auth.employee.dotykackaId,
      actorName: auth.employee.name,
      targetId,
      property,
      previousValue: result.previousValue,
      requestedValue,
      observedValue: result.value,
      status: "SUCCEEDED",
    }).catch(() => undefined);
    return Response.json({ ok: true, change: result });
  } catch (error) {
    const message = errorMessage(error);
    await getDb().insert(xr18ControlEvents).values({
      actorDotykackaId: auth.employee.dotykackaId,
      actorName: auth.employee.name,
      targetId,
      property,
      requestedValue,
      status: "FAILED",
      error: message.slice(0, 1000),
    }).catch(() => undefined);
    return Response.json({ error: message }, { status: 502 });
  }
}
