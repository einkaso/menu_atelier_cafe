import { getDb } from "../../../../db";
import { heatingControlEvents } from "../../../../db/schema";
import { listHeatingHomes, netatmoConnectionStatus, netatmoCredentialsConfigured, setHomeThermMode, setRoomThermpoint } from "../../../../lib/netatmo";
import { currentWaiter } from "../../../../lib/waiter-auth";

export const dynamic = "force-dynamic";

function errorMessage(error: unknown) {
  return error instanceof Error ? error.message : "Nie udało się połączyć z Netatmo.";
}

async function allowed(request: Request) {
  const employee = await currentWaiter(request);
  if (!employee) return { response: Response.json({ error: "Sesja pracownika wygasła." }, { status: 401 }) } as const;
  if (!employee.canControlHeating) return { response: Response.json({ error: "Nie masz uprawnienia do sterowania ogrzewaniem." }, { status: 403 }) } as const;
  return { employee } as const;
}

export async function GET(request: Request) {
  const access = await allowed(request);
  if ("response" in access) return access.response;
  if (!netatmoCredentialsConfigured()) return Response.json({ configured: false, connected: false, homes: [], employeeName: access.employee.name });
  const connection = await netatmoConnectionStatus();
  if (!connection.connected) return Response.json({ configured: true, connected: false, homes: [], employeeName: access.employee.name });
  try {
    return Response.json({ configured: true, connected: true, homes: await listHeatingHomes(), employeeName: access.employee.name });
  } catch (error) {
    return Response.json({ error: errorMessage(error) }, { status: 502 });
  }
}

function duration(value: unknown) {
  return typeof value === "number" && Number.isInteger(value) && value >= 15 && value <= 7 * 24 * 60 ? value : null;
}

export async function PATCH(request: Request) {
  const access = await allowed(request);
  if ("response" in access) return access.response;
  if (!netatmoCredentialsConfigured()) return Response.json({ error: "Połączenie Netatmo nie zostało jeszcze skonfigurowane." }, { status: 503 });
  const connection = await netatmoConnectionStatus();
  if (!connection.connected) return Response.json({ error: "Administrator musi najpierw połączyć konto Netatmo." }, { status: 503 });
  const body = await request.json().catch(() => ({})) as { homeId?: unknown; roomId?: unknown; action?: unknown; mode?: unknown; temperature?: unknown; durationMinutes?: unknown };
  let homes: Awaited<ReturnType<typeof listHeatingHomes>>;
  try { homes = await listHeatingHomes(); } catch (error) { return Response.json({ error: errorMessage(error) }, { status: 502 }); }
  const home = homes.find((item) => item.id === body.homeId);
  if (!home) return Response.json({ error: "Nie znaleziono tego lokalu w Netatmo." }, { status: 404 });

  const requested = { action: body.action, mode: body.mode, temperature: body.temperature, durationMinutes: body.durationMinutes };
  let room: typeof home.rooms[number] | undefined;
  let execute: (() => Promise<void>) | null = null;
  if (body.action === "home" && (body.mode === "schedule" || body.mode === "away" || body.mode === "hg")) {
    const requestedDuration = body.mode === "schedule" ? undefined : duration(body.durationMinutes) ?? undefined;
    execute = () => setHomeThermMode(home.id, body.mode as "schedule" | "away" | "hg", requestedDuration);
  }
  if (body.action === "room" && typeof body.roomId === "string") {
    room = home.rooms.find((item) => item.id === body.roomId);
    const requestedDuration = duration(body.durationMinutes);
    if (room && body.mode === "home") execute = () => setRoomThermpoint(home.id, room!.id, "home");
    if (room && body.mode === "max" && requestedDuration) execute = () => setRoomThermpoint(home.id, room!.id, "max", { durationMinutes: requestedDuration });
    if (room && body.mode === "manual" && requestedDuration && typeof body.temperature === "number" && Number.isFinite(body.temperature) && body.temperature >= 7 && body.temperature <= 30 && Math.round(body.temperature * 2) === body.temperature * 2) {
      execute = () => setRoomThermpoint(home.id, room!.id, "manual", { temperature: body.temperature as number, durationMinutes: requestedDuration });
    }
  }
  if (!execute) return Response.json({ error: "Nieprawidłowe ustawienie ogrzewania." }, { status: 400 });

  try {
    await execute();
    await getDb().insert(heatingControlEvents).values({
      actorDotykackaId: access.employee.dotykackaId,
      actorName: access.employee.name,
      homeId: home.id,
      homeName: home.name,
      roomId: room?.id ?? null,
      roomName: room?.name ?? null,
      action: body.action === "home" ? "HOME_MODE" : "ROOM_SETPOINT",
      requestedValue: requested,
      status: "SUCCEEDED",
    }).catch(() => undefined);
    const updatedHomes = await listHeatingHomes({ fresh: true }).catch(() => homes);
    return Response.json({ ok: true, home: updatedHomes.find((item) => item.id === home.id) ?? home });
  } catch (error) {
    const message = errorMessage(error);
    await getDb().insert(heatingControlEvents).values({
      actorDotykackaId: access.employee.dotykackaId,
      actorName: access.employee.name,
      homeId: home.id,
      homeName: home.name,
      roomId: room?.id ?? null,
      roomName: room?.name ?? null,
      action: body.action === "home" ? "HOME_MODE" : "ROOM_SETPOINT",
      requestedValue: requested,
      status: "FAILED",
      error: message.slice(0, 1000),
    }).catch(() => undefined);
    return Response.json({ error: message }, { status: 502 });
  }
}
