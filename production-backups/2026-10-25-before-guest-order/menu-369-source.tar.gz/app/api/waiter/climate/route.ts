import { getDb } from "../../../../db";
import { climateControlEvents } from "../../../../db/schema";
import { changeClimateProperty, listClimateRooms, sensiboConfigured, type ClimateProperty } from "../../../../lib/sensibo";
import { currentWaiter } from "../../../../lib/waiter-auth";

export const dynamic = "force-dynamic";

function errorMessage(error: unknown) {
  return error instanceof Error ? error.message : "Nie udało się połączyć z Sensibo.";
}

export async function GET(request: Request) {
  const employee = await currentWaiter(request);
  if (!employee) return Response.json({ error: "Sesja pracownika wygasła." }, { status: 401 });
  if (!employee.canControlClimate) return Response.json({ error: "Nie masz uprawnienia do sterowania klimatyzacją." }, { status: 403 });
  if (!sensiboConfigured()) return Response.json({ configured: false, rooms: [], employeeName: employee.name });
  try {
    return Response.json({ configured: true, rooms: await listClimateRooms(), employeeName: employee.name });
  } catch (error) {
    return Response.json({ error: errorMessage(error) }, { status: 502 });
  }
}

function validCommand(room: Awaited<ReturnType<typeof listClimateRooms>>[number], property: unknown, value: unknown): { property: ClimateProperty; value: boolean | number | string } | null {
  if (property === "on" && typeof value === "boolean") return { property, value };
  if (property === "mode" && typeof value === "string" && Object.hasOwn(room.modeCapabilities, value)) return { property, value };
  if (property === "fanLevel" && typeof value === "string") {
    const levels = room.modeCapabilities[room.mode]?.fanLevels ?? [];
    if (levels.includes(value)) return { property, value };
  }
  if (property === "targetTemperature" && typeof value === "number" && Number.isInteger(value)) {
    const capability = room.modeCapabilities[room.mode];
    if (capability?.temperatureSupported && value >= capability.minTemperature && value <= capability.maxTemperature) return { property, value };
  }
  return null;
}

export async function PATCH(request: Request) {
  const employee = await currentWaiter(request);
  if (!employee) return Response.json({ error: "Sesja pracownika wygasła." }, { status: 401 });
  if (!employee.canControlClimate) return Response.json({ error: "Nie masz uprawnienia do sterowania klimatyzacją." }, { status: 403 });
  if (!sensiboConfigured()) return Response.json({ error: "Połączenie Sensibo nie zostało jeszcze skonfigurowane." }, { status: 503 });
  const body = await request.json().catch(() => ({})) as { room?: unknown; property?: unknown; value?: unknown };
  let rooms: Awaited<ReturnType<typeof listClimateRooms>>;
  try {
    rooms = await listClimateRooms();
  } catch (error) {
    return Response.json({ error: errorMessage(error) }, { status: 502 });
  }
  const room = rooms.find((item) => item.key === body.room);
  if (!room) return Response.json({ error: "Nie znaleziono tego urządzenia Sensibo." }, { status: 404 });
  const command = validCommand(room, body.property, body.value);
  if (!command) return Response.json({ error: "To ustawienie nie jest obsługiwane przez klimatyzator." }, { status: 400 });
  try {
    await changeClimateProperty(room.deviceId, command.property, command.value);
    await getDb().insert(climateControlEvents).values({
      actorDotykackaId: employee.dotykackaId,
      actorName: employee.name,
      roomKey: room.key,
      roomName: room.name,
      deviceId: room.deviceId,
      property: command.property,
      requestedValue: command.value,
      status: "SUCCEEDED",
    }).catch(() => undefined);
    const updatedRoom = (await listClimateRooms({ fresh: true })).find((item) => item.key === room.key) ?? room;
    return Response.json({ ok: true, room: updatedRoom });
  } catch (error) {
    const message = errorMessage(error);
    await getDb().insert(climateControlEvents).values({
      actorDotykackaId: employee.dotykackaId,
      actorName: employee.name,
      roomKey: room.key,
      roomName: room.name,
      deviceId: room.deviceId,
      property: command.property,
      requestedValue: command.value,
      status: "FAILED",
      error: message.slice(0, 1000),
    }).catch(() => undefined);
    return Response.json({ error: message }, { status: 502 });
  }
}
