import {eventOsAuthorized} from "../../../../../lib/event-os-auth";
import {readTicketProductSettings,writeTicketProduct,hideTicketProduct,TicketProductError} from "../../../../../lib/event-os-ticket-products";
import {ZodError} from "zod";
export const runtime="nodejs";
export const dynamic="force-dynamic";
const headers={"Cache-Control":"no-store"};
function failure(error:unknown){return Response.json({error:error instanceof TicketProductError?error.message:error instanceof ZodError?"Dozwolone są wyłącznie bilety, bez własnej kategorii i pól produktu.":"MENU nie potwierdziło operacji w Dotykačce. Sprawdź połączenie i produkt w kategorii BILETY."},{status:error instanceof TicketProductError?error.status:error instanceof ZodError||error instanceof SyntaxError?400:503,headers});}
export async function GET(request:Request){
  if(!eventOsAuthorized(request))return Response.json({error:"Unauthorized"},{status:401,headers});
  try{return Response.json(await readTicketProductSettings(),{headers});}catch(error){return failure(error);}
}
async function change(request:Request,hide=false){
  if(!eventOsAuthorized(request))return Response.json({error:"Unauthorized"},{status:401,headers});
  try{
    if(!request.headers.get("content-type")?.startsWith("application/json"))return Response.json({error:"Wymagany JSON."},{status:415,headers});
    const reader=request.body?.getReader();if(!reader)throw new SyntaxError();let size=0;const chunks:Uint8Array[]=[];
    while(true){const {done,value}=await reader.read();if(done)break;size+=value.length;if(size>12000){await reader.cancel();return Response.json({error:"Za duże żądanie."},{status:413,headers});}chunks.push(value);}
    return Response.json(await (hide?hideTicketProduct:writeTicketProduct)(JSON.parse(Buffer.concat(chunks).toString("utf8"))),{headers});
  }catch(error){return failure(error);}
}

export async function POST(request:Request){return change(request);}
export async function PATCH(request:Request){return change(request,true);}
