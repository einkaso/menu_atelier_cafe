import { eq } from "drizzle-orm";
import { getDb } from "../../../../../db";
import { eventOsEvents, eventOsEventProducts } from "../../../../../db/schema";
import { eventOsAuthorized } from "../../../../../lib/event-os-auth";
import { eventOsCatalog } from "../../../../../lib/event-os-catalog";
export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export async function GET(request: Request) {
  const headers = { "Cache-Control": "no-store" };
  if (!eventOsAuthorized(request)) return Response.json({ error: "Unauthorized" }, { status: 401, headers });
  const eventId = new URL(request.url).searchParams.get("eventId") || "";
  if (!eventId || eventId.length > 160) return Response.json({ error: "Wybierz wydarzenie." }, { status: 400, headers });
  const db = getDb();
  const [event] = await db.select().from(eventOsEvents).where(eq(eventOsEvents.externalId, eventId)).limit(1);
  if (!event) return Response.json({ error: "Nie znaleziono wydarzenia." }, { status: 404, headers });
  const selected = await db.select().from(eventOsEventProducts).where(eq(eventOsEventProducts.eventExternalId, eventId));
  const enabled = selected.filter((item) => item.enabled);
  // The existing MENU selection is the offer publication decision. No second catalogue or approval process.
  return Response.json({ eventId, status: enabled.length ? "READY" : "REQUESTED", revision: Math.max(0, ...selected.map((item) => item.updatedAt.getTime())),
    discountPercent: Number(event.discountPercent), orderCutoffAt: event.orderCutoffAt?.toISOString() || null,
    preparedAt: enabled.length ? new Date(Math.max(...enabled.map((item) => item.updatedAt.getTime()))).toISOString() : null,
    products: await eventOsCatalog(eventId) }, { headers });
}
