import { eventOsAuthorized } from "../../../../../lib/event-os-auth";
import { receiveEventOsOrder, readEventOsState, EventOsOrderError } from "../../../../../lib/event-os-order-store";
import { ZodError } from "zod";
export const runtime = "nodejs";
export const dynamic = "force-dynamic";
const headers = { "Cache-Control": "no-store" };
function failure(error: unknown) { return Response.json({ error: error instanceof EventOsOrderError ? error.message : "Nie udało się potwierdzić zamówienia." }, { status: error instanceof EventOsOrderError ? error.status : error instanceof ZodError || error instanceof SyntaxError ? 400 : 503, headers }); }
export async function POST(request: Request) {
  if (!eventOsAuthorized(request)) return Response.json({ error: "Unauthorized" }, { status: 401, headers });
  try {
    if (!request.headers.get("content-type")?.startsWith("application/json")) return Response.json({ error: "Wymagany JSON." }, { status: 415, headers });
    const reader = request.body?.getReader(); if (!reader) throw new SyntaxError();
    const chunks: Uint8Array[] = []; let size = 0;
    while (true) { const { value, done } = await reader.read(); if (done) break; size += value.length; if (size > 100000) { await reader.cancel(); return Response.json({ error: "Za duże żądanie." }, { status: 413, headers }); } chunks.push(value); }
    return Response.json({ protocolVersion: 2, order: await receiveEventOsOrder(JSON.parse(Buffer.concat(chunks).toString("utf8"))) }, { headers });
  } catch (error) { return failure(error); }
}
export async function GET(request: Request) {
  if (!eventOsAuthorized(request)) return Response.json({ error: "Unauthorized" }, { status: 401, headers });
  const params = new URL(request.url).searchParams; const eventId = params.get("eventId") || ""; const orderId = params.get("orderId") || "";
  if (!eventId || !orderId || eventId.length > 160 || orderId.length > 160) return Response.json({ error: "Podaj wydarzenie i zamówienie." }, { status: 400, headers });
  try { return Response.json({ protocolVersion: 2, order: await readEventOsState(eventId, orderId) }, { headers }); } catch (error) { return failure(error); }
}
