import { eventOsAuthorized } from "../../../../../lib/event-os-auth";
import { eventOsCatalog } from "../../../../../lib/event-os-catalog";
export const dynamic = "force-dynamic";
export async function GET(request: Request) {
  const headers = { "Cache-Control": "no-store" };
  if (!eventOsAuthorized(request)) return Response.json({ error: "Unauthorized" }, { status: 401, headers });
  const eventId = new URL(request.url).searchParams.get("eventId")?.trim() || null;
  return Response.json({ products: await eventOsCatalog(eventId), eventId, generatedAt: new Date().toISOString() }, { headers });
}
