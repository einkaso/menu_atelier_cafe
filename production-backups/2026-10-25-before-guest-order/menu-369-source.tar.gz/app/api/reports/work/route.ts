import { reportActor } from "../../../../lib/work-report-auth";
import { readWorkReport, payReportTips, ReportConflict } from "../../../../lib/work-report-store";
import { reportCsv, reportRange } from "../../../../lib/work-report";
export const dynamic = "force-dynamic";
const headers = { "cache-control": "private, no-store" };
export async function GET(request: Request) {
  const access = await reportActor(request); if (access.response) return access.response;
  const query = new URL(request.url).searchParams;
  let range;
  try { range = reportRange(query.get("from"), query.get("to")); } catch { return Response.json({ error: "Wybierz prawidłowe daty od i do." }, { status: 400, headers }); }
  try {
    const result = await readWorkReport(range.from, range.to);
    if (query.get("format") === "csv") return new Response(reportCsv(query.get("hideWithoutHours") === "false" ? result.rows : result.rows.filter(row => row.minutes > 0), query.get("showRate") === "true"), { headers: { ...headers, "content-type": "text/csv; charset=utf-8", "content-disposition": `attachment; filename="raport-pracy-${range.from}-${range.to}.csv"` } });
    return Response.json(result, { headers });
  } catch (error) { console.error("[work-report] read failed", error instanceof Error ? error.message : "unknown"); return Response.json({ error: "Nie udało się wygenerować raportu. Spróbuj ponownie." }, { status: 500, headers }); }
}
export async function POST(request: Request) {
  const access = await reportActor(request); if (access.response) return access.response;
  const body = await request.json().catch(() => null);
  if (!body || body.action !== "MARK_TIPS_PAID" || typeof body.employeeId !== "string" || !body.employeeId || body.employeeId.length > 160 || typeof body.snapshot !== "string" || !/^[a-f0-9]{64}$/.test(body.snapshot)) return Response.json({ error: "Nieprawidłowe dane wypłaty." }, { status: 400, headers });
  try { reportRange(body.from, body.to); } catch { return Response.json({ error: "Nieprawidłowy okres raportu." }, { status: 400, headers }); }
  try { return Response.json({ ok: true, ...await payReportTips(body, access.actor!) }, { headers }); }
  catch (error) { if (error instanceof ReportConflict) return Response.json({ error: error.message }, { status: 409, headers }); console.error("[work-report] payout failed", error instanceof Error ? error.message : "unknown"); return Response.json({ error: "Nie udało się zapisać wypłaty. Odśwież raport przed kolejną próbą." }, { status: 500, headers }); }
}
