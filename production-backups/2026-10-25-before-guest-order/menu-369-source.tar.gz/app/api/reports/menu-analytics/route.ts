import { sql } from "drizzle-orm";
import { getDb } from "../../../../db";
import { reportActor } from "../../../../lib/work-report-auth";
import { reportRange } from "../../../../lib/work-report";
export const dynamic = "force-dynamic";
const headers = { "cache-control": "private, no-store" };
export async function GET(request: Request) {
  const access = await reportActor(request); if (access.response) return access.response;
  const query = new URL(request.url).searchParams, device = query.get("device") ?? "all";
  let range;
  try { range = reportRange(query.get("from"), query.get("to")); if (!["all", "tablet", "phone", "desktop"].includes(device) || range.end.getTime() - range.start.getTime() > 181 * 86400000) throw Error(); }
  catch { return Response.json({ error: "Wybierz prawidłowy okres (maksymalnie 180 dni) i typ urządzenia." }, { status: 400, headers }); }
  const filter = sql`occurred_at >= ${range.start.toISOString()} AND occurred_at < ${range.end.toISOString()} ${device === "all" ? sql`` : sql`AND device = ${device}`}`;
  try {
    const data = await getDb().transaction(async tx => {
      const summary = await tx.execute(sql`SELECT count(DISTINCT session_id)::int AS sessions, count(*) FILTER (WHERE kind='category_view')::int AS categories, count(*) FILTER (WHERE kind='product_open')::int AS opens, count(*) FILTER (WHERE kind='allergen_open')::int AS allergens, coalesce(sum(duration_ms),0)::float AS "durationMs", count(DISTINCT session_id) FILTER (WHERE kind='product_open')::int AS "productSessions" FROM menu_analytics_events WHERE ${filter}`);
      const categories = await tx.execute(sql`SELECT category AS id, max(category_name) AS name, count(*)::int AS opens, count(DISTINCT session_id)::int AS sessions FROM menu_analytics_events WHERE ${filter} AND kind='category_view' GROUP BY category ORDER BY opens DESC, category LIMIT 100`);
      const products = await tx.execute(sql`WITH views AS (SELECT product_id, max(product_name) AS name, view_id, sum(duration_ms) AS duration FROM menu_analytics_events WHERE ${filter} AND kind IN ('product_open','product_time') GROUP BY product_id,view_id), engaged AS (SELECT product_id, count(*) FILTER (WHERE duration>=10000)::int AS engaged, count(*)::int AS views FROM views GROUP BY product_id) SELECT e.product_id AS id, max(e.product_name) AS name, count(*) FILTER (WHERE e.kind='product_open')::int AS opens, count(DISTINCT e.session_id) FILTER (WHERE e.kind='product_open')::int AS sessions, count(*) FILTER (WHERE e.kind='allergen_open')::int AS allergens, coalesce(sum(e.duration_ms),0)::float AS "durationMs", coalesce(max(engaged.engaged),0)::int AS engaged, coalesce(max(engaged.views),0)::int AS views FROM menu_analytics_events e LEFT JOIN engaged ON e.product_id=engaged.product_id WHERE ${filter} AND e.product_id IS NOT NULL GROUP BY e.product_id ORDER BY opens DESC, e.product_id LIMIT 100`);
      const hourly = await tx.execute(sql`SELECT extract(hour FROM occurred_at AT TIME ZONE 'Europe/Warsaw')::int AS hour, count(*) FILTER (WHERE kind='product_open')::int AS opens, count(*) FILTER (WHERE kind='category_view')::int AS categories FROM menu_analytics_events WHERE ${filter} GROUP BY hour ORDER BY hour`);
      const coverage = await tx.execute(sql`SELECT min(occurred_at) AS "firstEvent", max(occurred_at) AS "lastEvent" FROM menu_analytics_events`);
      return { summary: summary[0], categories: Array.from(categories), products: Array.from(products), hourly: Array.from(hourly), coverage: coverage[0] };
    }, { isolationLevel: "repeatable read", accessMode: "read only" });
    return Response.json({ from: range.from, to: range.to, device, ...data }, { headers });
  } catch { return Response.json({ error: "Pomiar menu nie jest jeszcze uruchomiony lub baza raportu jest niedostępna. Raport wymaga wdrożenia migracji 0094." }, { status: 503, headers }); }
}
