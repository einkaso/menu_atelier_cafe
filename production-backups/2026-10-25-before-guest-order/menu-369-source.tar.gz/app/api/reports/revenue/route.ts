import { and, eq, gt, inArray, isNull, lt, or } from "drizzle-orm";
import { getDb } from "../../../../db";
import { workSchedules, workShifts, workTimeEntries } from "../../../../db/schema";
import { reportActor } from "../../../../lib/work-report-auth";
import { reportRange } from "../../../../lib/work-report";
import { aggregateRevenue, revenueSales, type RevenueInterval } from "../../../../lib/revenue-report";
import { DotykackaClient } from "../../../../lib/dotykacka/client";
import { getDotykackaConfig } from "../../../../lib/dotykacka/config";
export const dynamic = "force-dynamic";
const headers = { "cache-control": "private, no-store" };
export async function GET(request: Request) {
  const access = await reportActor(request); if (access.response) return access.response;
  const query = new URL(request.url).searchParams;
  const source = query.get("source") ?? "schedule";
  let range;
  try {
    range = reportRange(query.get("from"), query.get("to"));
    if (!["schedule", "actual"].includes(source) || range.end.getTime() - range.start.getTime() > 367 * 86400000 || range.start.getTime() >= Date.now()) throw Error();
  } catch { return Response.json({ error: "Wybierz prawidłowy okres (maksymalnie rok) i źródło godzin. Początek nie może być w przyszłości." }, { status: 400, headers }); }
  const now = new Date(), end = new Date(Math.min(range.end.getTime(), now.getTime()));
  try {
    const config = await getDotykackaConfig();
    if (!config.branchId) return Response.json({ error: "Wybierz oddział w połączeniu z Dotykačką." }, { status: 409, headers });
    const db = getDb();
    let intervals: RevenueInterval[] = [], openEntries = 0;
    if (source === "schedule") {
      const shifts = await db.select({ employeeId: workShifts.employeeDotykackaId, employeeName: workShifts.employeeName, start: workShifts.startsAt, end: workShifts.endsAt }).from(workShifts).innerJoin(workSchedules, eq(workShifts.scheduleId, workSchedules.id)).where(and(eq(workSchedules.status, "PUBLISHED"), lt(workShifts.startsAt, end), gt(workShifts.endsAt, range.start)));
      intervals = shifts.map(shift => ({ ...shift, start: shift.start.getTime(), end: shift.end.getTime() }));
    } else {
      const entries = await db.select().from(workTimeEntries).where(and(inArray(workTimeEntries.status, ["OPEN", "CLOSED", "CORRECTED"]), lt(workTimeEntries.startedAt, end), or(isNull(workTimeEntries.endedAt), gt(workTimeEntries.endedAt, range.start))));
      openEntries = entries.filter(entry => !entry.endedAt || entry.status === "OPEN").length;
      intervals = entries.filter(entry => entry.endedAt && ["CLOSED", "CORRECTED"].includes(entry.status)).map(entry => ({ employeeId: entry.employeeDotykackaId, employeeName: entry.employeeName, start: entry.startedAt.getTime(), end: entry.endedAt!.getTime() }));
    }
    const orders = await new DotykackaClient(config).closedOrdersRange(range.start, end);
    const { sales, skipped } = revenueSales(orders, config.branchId, range.start.getTime(), end.getTime());
    return Response.json({ from: range.from, to: range.to, source, generatedAt: now.toISOString(), effectiveEnd: end.toISOString(), openEntries, skipped, ...aggregateRevenue(sales, intervals, range.start.getTime(), end.getTime()) }, { headers });
  } catch (error) {
    console.error("[revenue-report] read failed", error instanceof Error ? error.message : "unknown");
    return Response.json({ error: "Nie udało się pobrać kompletnego raportu. Spróbuj ponownie lub wybierz krótszy okres." }, { status: 502, headers });
  }
}
