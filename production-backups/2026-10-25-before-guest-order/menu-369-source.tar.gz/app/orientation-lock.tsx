"use client";

import { useEffect } from "react";
import { usePathname } from "next/navigation";
import { lockAppLandscapeOrientation } from "./kelner/guest-orientation";

export default function OrientationLock() {
  const pathname = usePathname();
  useEffect(() => {
    if (pathname === "/grafik") return;
    void lockAppLandscapeOrientation();
    const reapply = () => { void lockAppLandscapeOrientation(); };
    const onVisibilityChange = () => { if (document.visibilityState === "visible") reapply(); };
    window.addEventListener("orientationchange", reapply);
    window.addEventListener("pageshow", reapply);
    window.addEventListener("pointerup", reapply, { capture: true });
    document.addEventListener("visibilitychange", onVisibilityChange);
    return () => {
      window.removeEventListener("orientationchange", reapply);
      window.removeEventListener("pageshow", reapply);
      window.removeEventListener("pointerup", reapply, { capture: true });
      document.removeEventListener("visibilitychange", onVisibilityChange);
    };
  }, [pathname]);

  if (pathname === "/grafik") return null;
  return <aside className="app-landscape-required" role="status" aria-live="polite"><b>Obróć tablet poziomo</b><span>Menu i strefa obsługi działają w układzie poziomym.</span></aside>;
}
