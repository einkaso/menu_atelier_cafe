"use client";
import { useEffect, useRef } from "react";
import { MenuAnalyticsTracker, type MenuAnalyticsContext, type MenuAnalyticsEvent } from "../lib/menu-analytics";
export function useMenuAnalytics(context: MenuAnalyticsContext, enabled: boolean) {
  const tracker = useRef<MenuAnalyticsTracker | null>(null);
  const latest = useRef(context); latest.current = context;
  useEffect(() => {
    if (!enabled || new URLSearchParams(window.location.search).get("analytics") === "off") return;
    if (!globalThis.crypto?.getRandomValues) return;
    const uuid = () => {
      if (crypto.randomUUID) return crypto.randomUUID();
      const bytes = crypto.getRandomValues(new Uint8Array(16)); bytes[6] = (bytes[6] & 15) | 64; bytes[8] = (bytes[8] & 63) | 128;
      const hex = Array.from(bytes, byte => byte.toString(16).padStart(2, "0")).join("");
      return `${hex.slice(0,8)}-${hex.slice(8,12)}-${hex.slice(12,16)}-${hex.slice(16,20)}-${hex.slice(20)}`;
    };
    const touch = navigator.maxTouchPoints > 0;
    const device = touch ? Math.min(screen.width, screen.height) >= 600 ? "tablet" : "phone" : "desktop";
    let queue: MenuAnalyticsEvent[] = [], sending = false;
    const analytics = new MenuAnalyticsTracker(event => { queue.push(event); if (queue.length > 200) queue.shift(); }, uuid, device, Date.now());
    tracker.current = analytics; analytics.setContext(latest.current, Date.now()); analytics.setVisible(document.visibilityState === "visible", Date.now());
    const flush = async () => {
      if (sending || !queue.length) return;
      const batch = queue.splice(0, 30); sending = true;
      try { const response = await fetch("/api/menu/analytics", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ events: batch }), keepalive: true }); if (!response.ok && response.status !== 400) queue = [...batch, ...queue].slice(-200); }
      catch { queue = [...batch, ...queue].slice(-200); }
      finally { sending = false; }
    };
    const beacon = () => { analytics.tick(Date.now()); const batch = queue.slice(0, 30); if (batch.length && navigator.sendBeacon?.("/api/menu/analytics", new Blob([JSON.stringify({ events: batch })], { type: "application/json" }))) queue.splice(0, batch.length); };
    const activity = () => analytics.interact(Date.now());
    const visibility = () => { analytics.setVisible(document.visibilityState === "visible", Date.now()); if (document.visibilityState !== "visible") beacon(); };
    const timer = window.setInterval(() => { analytics.tick(Date.now()); void flush(); }, 5000);
    window.addEventListener("pointerdown", activity, { passive: true }); window.addEventListener("keydown", activity); window.addEventListener("wheel", activity, { passive: true });
    document.addEventListener("visibilitychange", visibility); window.addEventListener("pagehide", beacon);
    return () => { beacon(); window.clearInterval(timer); tracker.current = null; window.removeEventListener("pointerdown", activity); window.removeEventListener("keydown", activity); window.removeEventListener("wheel", activity); document.removeEventListener("visibilitychange", visibility); window.removeEventListener("pagehide", beacon); };
  }, [enabled]);
  useEffect(() => { tracker.current?.setContext(context, Date.now()); }, [context.category, context.categoryName, context.product?.id, context.product?.name, context.allergen?.id]);
}
