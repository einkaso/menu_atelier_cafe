"use client";
import { useEffect } from "react";
import { saveWaiterSessionToken, waiterSessionHeaders, waiterSessionToken } from "./waiter-session-client";

// Mounted only while a staff preparation card is open. Reading does not require
// touch activity; closing the card stops this renewal and releases update deferral.
export function useRecipeSession() {
  useEffect(() => {
    document.documentElement.dataset.staffRecipeOpen = "true";
    let disposed = false;
    let controller: AbortController | null = null;
    const renew = async () => {
      if (disposed || controller) return;
      const request = new AbortController();
      controller = request;
      const token = waiterSessionToken();
      const timeout = window.setTimeout(() => request.abort(), 15000);
      try {
        const response = await fetch("/api/waiter/session", { method: "PUT", credentials: "same-origin", cache: "no-store", headers: waiterSessionHeaders(), signal: request.signal });
        if (!response.ok) return;
        const body = await response.json() as { token?: string };
        // An explicit logout or a new login must win over a pending renewal.
        if (!disposed && waiterSessionToken() === token) saveWaiterSessionToken(body.token, false);
      } catch { /* Keep the recipe visible during transient network failures; retry. */ }
      finally { window.clearTimeout(timeout); if (controller === request) controller = null; }
    };
    const refresh = () => { void renew(); };
    const visible = () => { if (document.visibilityState === "visible") refresh(); };
    refresh();
    const timer = window.setInterval(refresh, 60000);
    window.addEventListener("focus", refresh);
    window.addEventListener("online", refresh);
    document.addEventListener("visibilitychange", visible);
    return () => {
      disposed = true;
      controller?.abort();
      window.clearInterval(timer);
      window.removeEventListener("focus", refresh);
      window.removeEventListener("online", refresh);
      document.removeEventListener("visibilitychange", visible);
      delete document.documentElement.dataset.staffRecipeOpen;
    };
  }, []);
}
