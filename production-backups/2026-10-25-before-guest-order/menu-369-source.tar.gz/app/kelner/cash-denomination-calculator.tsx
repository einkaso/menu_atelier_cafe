"use client";

import { useState } from "react";

const denominations = [50000, 20000, 10000, 5000, 2000, 1000, 500, 200, 100, 50, 20, 10, 5, 2, 1];
const money = (cents: number) => (cents / 100).toLocaleString("pl-PL", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const label = (cents: number) => cents >= 100 ? `${cents / 100} zł` : `${cents} gr`;

export default function CashDenominationCalculator({ title = "Policz banknoty i monety", instruction, onUse }: {
  title?: string;
  instruction?: string;
  onUse?: (amount: string) => void;
}) {
  const [counts, setCounts] = useState<Record<number, string>>({});
  const [applied, setApplied] = useState(false);
  const valid = Object.values(counts).every(value => /^\d{0,6}$/.test(value));
  const hasEntries = Object.values(counts).some(value => value !== "");
  const total = valid ? denominations.reduce((sum, value) => sum + value * Number(counts[value] || 0), 0) : 0;
  return <details className="cash-denomination-calculator">
    <summary>Kalkulator gotówki — {title}</summary>
    <p>Wpisz liczbę sztuk każdego nominału. Puste pola oznaczają 0 sztuk.</p>
    <div className="cash-denomination-groups">
      {[denominations.slice(0, 6), denominations.slice(6)].map((group, index) => <fieldset key={index}>
        <legend>{index === 0 ? "Banknoty" : "Monety"}</legend>
        {group.map(value => <label key={value}>
          <span>{label(value)}</span>
          <input type="text" inputMode="numeric" pattern="[0-9]*" maxLength={6} placeholder="0" aria-label={`Liczba sztuk ${label(value)}`} aria-invalid={!/^\d{0,6}$/.test(counts[value] || "")} value={counts[value] || ""} onChange={event => { setCounts(previous => ({ ...previous, [value]: event.target.value })); setApplied(false); }}/>
          <small>szt.</small>
          <output>{/^\d{0,6}$/.test(counts[value] || "") ? money(value * Number(counts[value] || 0)) : "—"} zł</output>
        </label>)}
      </fieldset>)}
    </div>
    {!valid && <p role="alert">Podaj liczbę całych sztuk od 0 do 999999 — bez przecinków, kropek ani znaku minus.</p>}
    <p className="cash-denomination-total" role="status">Razem: <strong>{valid ? money(total) : "—"} zł</strong></p>
    {instruction && <p>{instruction}</p>}
    <div className="cash-denomination-actions">
      {onUse && <button type="button" disabled={!valid || !hasEntries} onClick={() => { onUse((total / 100).toFixed(2)); setApplied(true); }}>Wpisz wyliczoną kwotę</button>}
      <button type="button" onClick={() => { setCounts({}); setApplied(false); }}>Wyczyść kalkulator</button>
    </div>
    {applied && <p role="status">Kwota przeniesiona do formularza. Sprawdź ją przed zapisaniem.</p>}
  </details>;
}
