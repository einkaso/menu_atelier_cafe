"use client";
import { useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { waiterSessionHeaders } from "../waiter-session-client";

type Attachment = { id: string; path: string; type: "IMAGE" | "PDF"; name: string; size: number };
export default function InstructionAttachment({ attachment, onLoaded }: { attachment: Attachment; onLoaded: () => void }) {
  const [attempt, setAttempt] = useState(0), [url, setUrl] = useState(""), [error, setError] = useState(""), [ready, setReady] = useState(false), [expanded, setExpanded] = useState(false);
  const closeRef = useRef<HTMLButtonElement>(null), openRef = useRef<HTMLButtonElement>(null);
  const loadedRef = useRef(onLoaded);
  loadedRef.current = onLoaded;
  useEffect(() => {
    const refresh = () => setAttempt(n => n + 1);
    window.addEventListener("waiter-session-changed", refresh);
    return () => window.removeEventListener("waiter-session-changed", refresh);
  }, []);
  useEffect(() => {
    const controller = new AbortController(); let objectUrl = ""; let disposed = false;
    setUrl(""); setError(""); setReady(false); setExpanded(false);
    const timer = window.setTimeout(() => controller.abort(), 15_000);
    void (async () => {
      try {
        const response = await fetch(attachment.path, { credentials: "same-origin", cache: "no-store", headers: waiterSessionHeaders(), signal: controller.signal });
        if (!response.ok) throw Error(response.status === 401 || response.status === 404 ? "Plik jest niedostępny lub sesja wygasła. Spróbuj ponownie; w razie potrzeby zaloguj się ponownie." : "Nie udało się pobrać załącznika. Spróbuj ponownie.");
        const blob = await response.blob();
        if (!blob.size || blob.size > 25 * 1024 * 1024 || !(attachment.type === "IMAGE" ? blob.type.startsWith("image/") : blob.type === "application/pdf")) throw Error("Załącznik ma nieprawidłowy format.");
        if (disposed) return;
        objectUrl = URL.createObjectURL(blob); setUrl(objectUrl);
        if (attachment.type === "PDF") { setReady(true); loadedRef.current(); }
      } catch (e) {
        if (!disposed) { setError(controller.signal.aborted ? "Przekroczono czas ładowania. Sprawdź połączenie i spróbuj ponownie." : e instanceof Error ? e.message : "Nie udało się odczytać załącznika."); loadedRef.current(); }
      } finally { window.clearTimeout(timer); }
    })();
    return () => { disposed = true; controller.abort(); window.clearTimeout(timer); if (objectUrl) URL.revokeObjectURL(objectUrl); };
  }, [attachment.path, attachment.type, attempt]);
  useEffect(() => {
    if (!url || ready || error || attachment.type !== "IMAGE") return;
    const timer = window.setTimeout(() => { setError("Nie udało się wyświetlić zdjęcia. Spróbuj ponownie."); loadedRef.current(); }, 10_000);
    return () => window.clearTimeout(timer);
  }, [url, ready, error, attachment.type]);
  useEffect(() => {
    if (!expanded) return;
    closeRef.current?.focus();
    const escape = (e: KeyboardEvent) => { if (e.key === "Escape") setExpanded(false); };
    window.addEventListener("keydown", escape);
    return () => { window.removeEventListener("keydown", escape); openRef.current?.focus(); };
  }, [expanded]);
  function failed() { setReady(false); setExpanded(false); setError("Nie udało się wyświetlić zdjęcia. Spróbuj ponownie."); loadedRef.current(); }
  return <div className="instruction-attachment">
    {error ? <div className="instruction-attachment-error" role="alert"><strong>Załącznik nie został wyświetlony</strong><p>{error}</p><button type="button" onClick={() => setAttempt(n => n + 1)}>Spróbuj ponownie</button></div> : <>
      {!ready && <p role="status">Wczytywanie załącznika…</p>}
      {url && (attachment.type === "IMAGE" ? <button ref={openRef} className="instruction-image-button" type="button" disabled={!ready} onClick={() => setExpanded(true)} aria-label={`Powiększ: ${attachment.name}`}><img src={url} alt={attachment.name} style={{ display: ready ? "block" : "none" }} onLoad={() => { setReady(true); loadedRef.current(); }} onError={failed}/></button> : <a href={url} target="_blank" rel="noreferrer" className="is-pdf"><b>PDF</b><span><strong>{attachment.name}</strong><small>Otwórz dokument</small></span></a>)}
    </>}
    <span className="instruction-attachment-name">{attachment.name}</span>
    {expanded && ready && createPortal(<div className="instruction-image-overlay" role="presentation" onClick={() => setExpanded(false)}><section role="dialog" aria-modal="true" aria-label={attachment.name} onClick={e => e.stopPropagation()}><header><span>{attachment.name}</span><button ref={closeRef} type="button" onClick={() => setExpanded(false)} onKeyDown={e => { if(e.key === "Tab") { e.preventDefault(); closeRef.current?.focus(); } }}>Zamknij zdjęcie ×</button></header><img src={url} alt={attachment.name} onError={failed}/></section></div>, document.body)}
  </div>;
}
