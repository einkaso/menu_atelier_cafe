import type { Metadata } from "next";
import "./waiter.css";
import "./instrukcje/instruction-attachments.css";
import "./tablet-fixes.css";
import "./cash-day.css";
import "./grafik/workforce-employee.css";
import "./rezerwacje/reservations-employee.css";
import "./staff-navigation.css";
import "./unified-header.css";
import "./rezerwacje/reservations-full-width.css";
import "./grafik/workforce-header.css";
import "./login-redesign.css";
import "./oswietlenie/lighting-preparation.css";
import "./chlodnie/cold-storage.css";
import "./klimatyzacja/climate.css";
import "./ogrzewanie/heating.css";
import "./ogrzewanie/heating-enhanced.css";
import "./xr18/xr18.css";
import "./pomieszczenia/rooms.css";
import "../../components/kitchen/kitchen.css";
import WaiterStaffDock from "./staff-navigation";

export const metadata: Metadata = { title: "Strefa pracownika — Atelier Café", robots: { index: false, follow: false } };

export default function WaiterLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <>{children}<WaiterStaffDock/></>;
}
