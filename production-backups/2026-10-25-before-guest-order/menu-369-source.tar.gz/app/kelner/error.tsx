"use client";
export default function StaffError({reset}:{error:Error & {digest?:string};reset:()=>void}) {
  return <main style={{maxWidth:560,margin:"48px auto",padding:24,fontFamily:"system-ui",lineHeight:1.6}}>
    <h1>Nie udało się otworzyć ekranu</h1>
    <p>Wystąpił błąd wyświetlania. Spróbuj ponownie lub wczytaj aktualną wersję aplikacji. Zapisane wyniki inwentaryzacji pozostają w systemie.</p>
    <button onClick={reset} style={{padding:14,marginRight:12}}>Spróbuj ponownie</button>
    <button onClick={()=>window.location.reload()} style={{padding:14}}>Wczytaj aktualną wersję</button>
    <p><a href="/kelner">Wróć do panelu pracownika</a></p>
  </main>;
}
