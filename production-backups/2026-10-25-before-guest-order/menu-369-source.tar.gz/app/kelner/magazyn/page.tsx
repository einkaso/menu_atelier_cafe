import InventoryMappingPanel from '../../../components/inventory/inventory-mapping-panel';
export const dynamic='force-dynamic';
export default function Page(){return <main><a href="/kelner">← Strefa pracownika</a><InventoryMappingPanel/></main>;}
