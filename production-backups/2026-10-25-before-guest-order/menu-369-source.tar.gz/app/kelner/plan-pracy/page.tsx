import ManagerPlanClient from "../../../components/manager-plan/manager-plan-client";
export const dynamic = "force-dynamic";
export default function ManagerPlanPage(){return <ManagerPlanClient/>;}
