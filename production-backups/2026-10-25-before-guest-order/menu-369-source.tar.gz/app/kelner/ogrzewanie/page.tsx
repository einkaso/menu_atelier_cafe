import HeatingControlClient from "./heating-control-client";

export const dynamic = "force-dynamic";

export default function HeatingPage() {
  return <HeatingControlClient/>;
}
