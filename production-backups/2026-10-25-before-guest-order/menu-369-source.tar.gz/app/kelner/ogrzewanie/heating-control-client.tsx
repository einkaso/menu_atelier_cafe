"use client";

import { useCallback, useEffect, useState } from "react";
import { WaiterSectionHeader } from "../staff-navigation";
import { clearWaiterSessionToken, waiterSessionHeaders } from "../waiter-session-client";

type HeatingModule = { id: string; name: string; type: string; reachable: boolean; batteryState: string | null; signal: number | null };
type HeatingRoom = { id: string; name: string; type: string | null; reachable: boolean; temperature: number | null; targetTemperature: number | null; mode: string; heatingPower: number | null; openWindow: boolean; anticipating: boolean; setpointEndsAt: string | null; modules: HeatingModule[] };
type HeatingHome = { id: string; name: string; timezone: string | null; mode: "schedule" | "away" | "hg"; boilerOn: boolean; defaultSetpointMinutes: number; defaultBoostMinutes: number; rooms: HeatingRoom[]; observedAt: string };
type HeatingResponse = { configured?: boolean; connected?: boolean; homes?: HeatingHome[]; employeeName?: string; error?: string };

const modeLabels: Record<string, string> = { schedule: "Harmonogram", home: "Tryb lokalu", manual: "Ręczny", max: "Boost", away: "Poza lokalem", hg: "Przeciwzamrożeniowy", off: "Wyłączone" };
const batteryLabels: Record<string, string> = { full: "pełna", high: "wysoka", medium: "średnia", low: "niska", very_low: "bardzo niska" };
const durationOptions = [30, 60, 120, 240, 480, 720, 1440] as const;

function temperature(value: number | null) {
  return value === null ? "—" : `${value.toLocaleString("pl-PL", { minimumFractionDigits: 1, maximumFractionDigits: 1 })}°C`;
}

function endTime(value: string | null) {
  if (!value) return null;
  return new Intl.DateTimeFormat("pl-PL", { hour: "2-digit", minute: "2-digit" }).format(new Date(value));
}

function durationLabel(minutes: number) {
  if (minutes < 60) return `${minutes} min`;
  if (minutes === 1440) return "24 godziny";
  return `${minutes / 60} godz.`;
}

function moduleLabel(type: string) {
  if (type === "NRV") return "Głowica grzejnikowa";
  if (type === "NATherm1") return "Termostat";
  if (type === "NAPlug") return "Przekaźnik kotła";
  return type || "Urządzenie Netatmo";
}

function roomKey(home: HeatingHome, room: HeatingRoom) {
  return `${home.id}:${room.id}`;
}

export default function HeatingControlClient() {
  const [data, setData] = useState<HeatingResponse | null>(null);
  const [drafts, setDrafts] = useState<Record<string, number>>({});
  const [durations, setDurations] = useState<Record<string, number>>({});
  const [busy, setBusy] = useState("");
  const [error, setError] = useState("");
  const [forbidden, setForbidden] = useState(false);

  const load = useCallback(async () => {
    const response = await fetch("/api/waiter/heating", { cache: "no-store", credentials: "same-origin", headers: waiterSessionHeaders() }).catch(() => null);
    const body = await response?.json().catch(() => ({})) as HeatingResponse | undefined;
    if (response?.status === 401) { clearWaiterSessionToken(); window.location.replace("/kelner"); return; }
    if (response?.status === 403) { setForbidden(true); setError(body?.error ?? "Brak uprawnienia do ogrzewania."); return; }
    if (!response?.ok) { setError(body?.error ?? "Nie udało się pobrać stanu ogrzewania."); return; }
    setForbidden(false); setError(""); setData(body ?? null);
  }, []);

  useEffect(() => {
    const refresh = () => { if (document.visibilityState === "visible") void load(); };
    const initial = window.setTimeout(refresh, 0);
    const timer = window.setInterval(refresh, 30_000);
    window.addEventListener("focus", refresh);
    document.addEventListener("visibilitychange", refresh);
    return () => { window.clearTimeout(initial); window.clearInterval(timer); window.removeEventListener("focus", refresh); document.removeEventListener("visibilitychange", refresh); };
  }, [load]);

  async function command(home: HeatingHome, payload: Record<string, unknown>, key: string) {
    setBusy(key); setError("");
    const response = await fetch("/api/waiter/heating", {
      method: "PATCH",
      credentials: "same-origin",
      headers: waiterSessionHeaders({ "content-type": "application/json" }),
      body: JSON.stringify({ homeId: home.id, ...payload }),
    }).catch(() => null);
    const body = await response?.json().catch(() => ({})) as { home?: HeatingHome; error?: string } | undefined;
    if (response?.status === 401) { clearWaiterSessionToken(); window.location.replace("/kelner"); return; }
    if (!response?.ok) setError(body?.error ?? "Nie udało się wysłać ustawienia do Netatmo.");
    else if (body?.home) setData((current) => current ? { ...current, homes: current.homes?.map((item) => item.id === body.home?.id ? body.home : item) } : current);
    setBusy("");
  }

  function draft(home: HeatingHome, room: HeatingRoom) {
    return drafts[roomKey(home, room)] ?? room.targetTemperature ?? 20;
  }

  function changeDraft(home: HeatingHome, room: HeatingRoom, delta: number) {
    const key = roomKey(home, room);
    setDrafts((current) => ({ ...current, [key]: Math.max(7, Math.min(30, Math.round((draft(home, room) + delta) * 2) / 2)) }));
  }

  function selectedDuration(home: HeatingHome, room: HeatingRoom) {
    return durations[roomKey(home, room)] ?? home.defaultSetpointMinutes ?? 120;
  }

  return <main className="waiter-heating-page">
    <WaiterSectionHeader eyebrow="Komfort lokalu" title="OGRZEWANIE" employeeName={data?.employeeName}/>
    <section className="waiter-heating-intro"><div><span>NETATMO · TERMOSTAT I GŁOWICE</span><h1>OGRZEWANIE</h1><p>Temperatury, tryb kotła i nazwy pomieszczeń są odczytywane na żywo z Netatmo.</p></div><button type="button" onClick={() => void load()}>Odśwież</button></section>
    {error && <div className="waiter-heating-message is-error" role="alert">{error}</div>}
    {forbidden && <section className="waiter-heating-empty"><strong>Brak uprawnienia</strong><p>Administrator musi nadać Ci osobne uprawnienie „Sterowanie ogrzewaniem”.</p></section>}
    {!forbidden && data?.configured === false && <section className="waiter-heating-empty"><strong>Netatmo nie jest jeszcze skonfigurowane</strong><p>Administrator musi zapisać dane aplikacji Netatmo na serwerze.</p></section>}
    {!forbidden && data?.configured && data.connected === false && <section className="waiter-heating-empty"><strong>Konto Netatmo nie jest połączone</strong><p>Administrator musi jednorazowo zaakceptować połączenie w sekcji „OGRZEWANIE”.</p></section>}
    {data?.connected && data.homes?.length === 0 && <section className="waiter-heating-empty"><strong>Nie znaleziono termostatu</strong><p>Sprawdź, czy połączone konto ma dostęp do Smart Thermostat.</p></section>}
    {data?.homes?.map((home) => <section className="waiter-heating-home" key={home.id}>
      <header><div><span>{home.boilerOn ? "KOCIOŁ PRACUJE" : "KOCIOŁ W GOTOWOŚCI"}</span><h2>{home.name}</h2><p>Tryb całego lokalu: <b>{modeLabels[home.mode] ?? home.mode}</b></p></div><nav aria-label="Tryb ogrzewania lokalu"><button className={home.mode === "schedule" ? "is-active" : ""} disabled={busy === `${home.id}:home`} onClick={() => void command(home, { action: "home", mode: "schedule" }, `${home.id}:home`)}>Harmonogram</button><button className={home.mode === "away" ? "is-active" : ""} disabled={busy === `${home.id}:home`} onClick={() => void command(home, { action: "home", mode: "away", durationMinutes: 1440 }, `${home.id}:home`)}>Poza lokalem · 24 h</button><button className={home.mode === "hg" ? "is-active" : ""} disabled={busy === `${home.id}:home`} onClick={() => void command(home, { action: "home", mode: "hg", durationMinutes: 1440 }, `${home.id}:home`)}>Przeciwzamrożeniowy · 24 h</button></nav></header>
      <div className="waiter-heating-grid">{home.rooms.map((room) => {
        const key = roomKey(home, room);
        const roomBusy = busy === key;
        const target = draft(home, room);
        const minutes = selectedDuration(home, room);
        const setpointEnd = endTime(room.setpointEndsAt);
        const battery = room.modules.map((module) => module.batteryState).find((state) => state === "very_low") ?? room.modules.map((module) => module.batteryState).find((state) => state === "low") ?? room.modules.map((module) => module.batteryState).find(Boolean) ?? null;
        return <article className={`waiter-heating-card${room.heatingPower && room.heatingPower > 0 ? " is-heating" : ""}${room.reachable ? "" : " is-offline"}`} key={room.id}>
          <header><div><span>{room.reachable ? room.heatingPower && room.heatingPower > 0 ? `GRZANIE ${room.heatingPower}%` : "ONLINE" : "OFFLINE"}</span><h3>{room.name}</h3></div><i>{room.modules.length} {room.modules.length === 1 ? "urządzenie" : "urządzenia"}</i></header>
          {room.openWindow && <p className="waiter-heating-window">Wykryto otwarte okno — ogrzewanie może być chwilowo wstrzymane.</p>}
          <div className="waiter-heating-readings"><div><span>Temperatura</span><strong>{temperature(room.temperature)}</strong></div><div><span>Zadana</span><strong>{temperature(room.targetTemperature)}</strong></div></div>
          <section className="waiter-heating-devices"><span>Przypisane do pomieszczenia</span>{room.modules.length ? room.modules.map((module) => <div key={module.id}><i className={module.reachable ? "is-online" : ""}/><p><b>{module.name}</b><small>{moduleLabel(module.type)} · {module.reachable ? "online" : "offline"}{module.batteryState ? ` · bateria ${batteryLabels[module.batteryState] ?? module.batteryState}` : ""}</small></p></div>) : <p>Brak przypisanych urządzeń.</p>}</section>
          <div className="waiter-heating-target"><span>Ustaw temperaturę na określony czas</span><div><button type="button" aria-label="Zmniejsz temperaturę" disabled={!room.reachable || roomBusy || target <= 7} onClick={() => changeDraft(home, room, -0.5)}>−</button><strong>{temperature(target)}</strong><button type="button" aria-label="Zwiększ temperaturę" disabled={!room.reachable || roomBusy || target >= 30} onClick={() => changeDraft(home, room, 0.5)}>+</button></div><select aria-label="Czas ustawienia temperatury" value={minutes} disabled={roomBusy} onChange={(event) => setDurations((current) => ({ ...current, [key]: Number(event.target.value) }))}>{durationOptions.map((value) => <option value={value} key={value}>{durationLabel(value)}</option>)}</select><button type="button" className="is-apply" disabled={!room.reachable || roomBusy} onClick={() => void command(home, { action: "room", roomId: room.id, mode: "manual", temperature: target, durationMinutes: minutes }, key)}>Ustaw {temperature(target)} na {durationLabel(minutes)}</button></div>
          <div className="waiter-heating-actions"><button type="button" disabled={!room.reachable || roomBusy} onClick={() => void command(home, { action: "room", roomId: room.id, mode: "home" }, key)}>Wróć do harmonogramu</button><button type="button" className="is-boost" disabled={!room.reachable || roomBusy} onClick={() => void command(home, { action: "room", roomId: room.id, mode: "max", durationMinutes: minutes }, key)}>Boost na {durationLabel(minutes)}</button></div>
          <footer><span>Tryb: <b>{modeLabels[room.mode] ?? room.mode}</b>{setpointEnd ? ` do ${setpointEnd}` : ""}</span><span>Bateria: <b>{battery ? batteryLabels[battery] ?? battery : "—"}</b></span>{room.anticipating && <span>Rozgrzewanie wyprzedzające</span>}{roomBusy && <span>Wysyłam ustawienie…</span>}</footer>
        </article>;
      })}</div>
    </section>)}
    {!data && !forbidden && !error && <section className="waiter-heating-empty"><strong>Łączę z Netatmo…</strong></section>}
  </main>;
}
