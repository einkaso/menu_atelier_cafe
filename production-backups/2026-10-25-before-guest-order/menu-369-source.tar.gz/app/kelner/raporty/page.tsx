import WorkReportsClient from "../../admin/reports/work-reports-client";
export const dynamic = "force-dynamic";
export default function EmployeeReportsPage() { return <WorkReportsClient employeeMode/>; }
