"use client";

import { useEffect, useRef, useState } from "react";
import type { PreparationCard } from "../../lib/kitchen-recipes";
import PreparationCardView from "../../components/kitchen/preparation-card";
import { useRecipeSession } from "./use-recipe-session";
import { waiterSessionHeaders } from "./waiter-session-client";

export default function StaffPreparationDialog({ product, onClose }: { product: { id: number; name: string }; onClose: () => void }) {
  useRecipeSession();
  const [card, setCard] = useState<PreparationCard | null>(null);
  const [error, setError] = useState("");
  const [retry, setRetry] = useState(0);
  const dialog = useRef<HTMLElement>(null);
  useEffect(() => {
    const controller = new AbortController();
    void fetch(`/api/waiter/products/${product.id}/preparation`, { headers: waiterSessionHeaders(), cache: "no-store", signal: controller.signal })
      .then(async (response) => { const body = await response.json(); if (!response.ok) throw new Error(body.error ?? "Nie udało się pobrać karty przygotowania."); return body.card as PreparationCard; })
      .then((card) => { if (!controller.signal.aborted) { setCard(card); setError(""); } })
      .catch((error) => { if (!controller.signal.aborted) setError(error instanceof Error ? error.message : "Błąd połączenia."); });
    return () => controller.abort();
  }, [product.id, retry]);
  useEffect(() => {
    const previous = document.activeElement as HTMLElement | null;
    const originalOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    dialog.current?.focus();
    const handler = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
      if (event.key === "Tab") {
        const nodes = dialog.current?.querySelectorAll<HTMLElement>('button:not(:disabled), input:not(:disabled), select:not(:disabled), textarea:not(:disabled), a[href], summary, video[controls], [tabindex="0"]');
        const focusable = [...(nodes ?? [])].filter((node) => node.getClientRects().length > 0);
        const first = focusable[0], last = focusable.at(-1);
        if (event.shiftKey && (document.activeElement === first || document.activeElement === dialog.current)) { event.preventDefault(); last?.focus(); }
        else if (!event.shiftKey && (document.activeElement === last || document.activeElement === dialog.current)) { event.preventDefault(); first?.focus(); }
      }
    };
    document.addEventListener("keydown", handler);
    return () => { document.body.style.overflow = originalOverflow; document.removeEventListener("keydown", handler); previous?.focus(); };
  }, [onClose]);
  return <div className="waiter-manual-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose(); }}>
    <section className="waiter-manual kitchen-preparation-dialog" ref={dialog} tabIndex={-1} role="dialog" aria-modal="true" aria-labelledby="waiter-manual-title">
      <header><div><span>KARTA PRZYGOTOWANIA · TYLKO DLA PERSONELU</span><h2 id="waiter-manual-title">{product.name}</h2></div><button type="button" onClick={onClose} aria-label="Zamknij instrukcję"><svg className="waiter-manual-close-icon" viewBox="0 0 20 20" aria-hidden="true"><path d="M4 4l12 12M16 4L4 16"/></svg></button></header>
      {error ? <p role="alert" className="kitchen-error">{error} <button type="button" onClick={() => setRetry((value) => value + 1)}>Spróbuj ponownie</button></p> : card ? <PreparationCardView card={card}/> : <p role="status">Wczytuję manual i przepisy…</p>}
      <footer><span>Składanie i przepisy elementów w jednym miejscu.</span><button type="button" onClick={onClose}>Zamknij</button></footer>
    </section>
  </div>;
}
