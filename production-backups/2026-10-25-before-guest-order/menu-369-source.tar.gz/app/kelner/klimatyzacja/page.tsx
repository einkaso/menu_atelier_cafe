import ClimateControlClient from "./climate-control-client";

export const dynamic = "force-dynamic";

export default function ClimatePage() {
  return <ClimateControlClient/>;
}
