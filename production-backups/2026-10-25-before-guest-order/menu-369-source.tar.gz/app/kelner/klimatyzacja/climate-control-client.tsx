"use client";

import { useCallback, useEffect, useState } from "react";
import { WaiterSectionHeader } from "../staff-navigation";
import { clearWaiterSessionToken, waiterSessionHeaders } from "../waiter-session-client";

type ModeCapability = { fanLevels: string[]; temperatureSupported: boolean; minTemperature: number; maxTemperature: number };
type ClimateRoom = {
  key: "kawiarnia" | "atelier";
  name: string;
  productModel: string | null;
  online: boolean;
  on: boolean;
  mode: string;
  targetTemperature: number | null;
  fanLevel: string | null;
  temperature: number | null;
  humidity: number | null;
  measuredAt: string | null;
  modeCapabilities: Record<string, ModeCapability>;
};
type ClimateResponse = { configured?: boolean; rooms?: ClimateRoom[]; employeeName?: string; error?: string };
type ClimateProperty = "on" | "targetTemperature" | "mode" | "fanLevel";

const modeLabels: Record<string, string> = { cool: "Chłodzenie", heat: "Grzanie", auto: "Auto", fan: "Nawiew", dry: "Osuszanie" };
const fanLabels: Record<string, string> = { auto: "Auto", low: "Cichy", medium: "Średni", high: "Mocny", quiet: "Cichy", strong: "Mocny" };

function formatMeasurement(value: number | null, suffix: string) {
  return value === null ? "—" : `${value.toLocaleString("pl-PL", { maximumFractionDigits: 1 })}${suffix}`;
}

function formatTime(value: string | null) {
  if (!value) return "Brak odczytu";
  return new Intl.DateTimeFormat("pl-PL", { hour: "2-digit", minute: "2-digit", day: "2-digit", month: "2-digit" }).format(new Date(value));
}

export default function ClimateControlClient() {
  const [data, setData] = useState<ClimateResponse | null>(null);
  const [error, setError] = useState("");
  const [forbidden, setForbidden] = useState(false);
  const [busy, setBusy] = useState("");

  const load = useCallback(async () => {
    const response = await fetch("/api/waiter/climate", { cache: "no-store", credentials: "same-origin", headers: waiterSessionHeaders() }).catch(() => null);
    const body = await response?.json().catch(() => ({})) as ClimateResponse | undefined;
    if (response?.status === 401) { clearWaiterSessionToken(); window.location.replace("/kelner"); return; }
    if (response?.status === 403) { setForbidden(true); setError(body?.error ?? "Brak uprawnienia do klimatyzacji."); return; }
    if (!response?.ok) { setError(body?.error ?? "Nie udało się pobrać stanu klimatyzacji."); return; }
    setForbidden(false); setError(""); setData(body ?? null);
  }, []);

  useEffect(() => {
    const refresh = () => { if (document.visibilityState === "visible") void load(); };
    const initialTimer = window.setTimeout(refresh, 0);
    const timer = window.setInterval(refresh, 15_000);
    window.addEventListener("focus", refresh);
    document.addEventListener("visibilitychange", refresh);
    return () => { window.clearTimeout(initialTimer); window.clearInterval(timer); window.removeEventListener("focus", refresh); document.removeEventListener("visibilitychange", refresh); };
  }, [load]);

  async function change(room: ClimateRoom, property: ClimateProperty, value: boolean | number | string) {
    setBusy(`${room.key}:${property}`); setError("");
    const response = await fetch("/api/waiter/climate", {
      method: "PATCH",
      credentials: "same-origin",
      headers: waiterSessionHeaders({ "content-type": "application/json" }),
      body: JSON.stringify({ room: room.key, property, value }),
    }).catch(() => null);
    const body = await response?.json().catch(() => ({})) as { room?: ClimateRoom; error?: string } | undefined;
    if (response?.status === 401) { clearWaiterSessionToken(); window.location.replace("/kelner"); return; }
    if (!response?.ok) setError(body?.error ?? "Nie udało się wysłać ustawienia do Sensibo.");
    else if (body?.room) setData((current) => current ? { ...current, rooms: current.rooms?.map((item) => item.key === body.room?.key ? body.room : item) } : current);
    setBusy("");
  }

  return <main className="waiter-climate-page">
    <WaiterSectionHeader eyebrow="Sterowanie komfortem" title="Klimatyzacja" employeeName={data?.employeeName}/>
    <section className="waiter-climate-intro"><div><span>SENSIBO · STEROWANIE ONLINE</span><h1>Kawiarnia i Atelier</h1><p>Temperatura oraz stan urządzeń odświeżają się automatycznie.</p></div><button type="button" onClick={() => void load()}>Odśwież</button></section>
    {error && <div className="waiter-climate-message is-error" role="alert">{error}</div>}
    {forbidden && <section className="waiter-climate-empty"><strong>Brak uprawnienia</strong><p>Administrator musi nadać Ci osobne uprawnienie „Klimatyzacja”.</p></section>}
    {!forbidden && data?.configured === false && <section className="waiter-climate-empty"><strong>Sensibo nie jest jeszcze skonfigurowane</strong><p>Administrator musi zapisać klucz API na serwerze.</p></section>}
    {!forbidden && data?.configured && data.rooms?.length === 0 && <section className="waiter-climate-empty"><strong>Nie znaleziono urządzeń</strong><p>Nazwij urządzenia w Sensibo „Kawiarnia” i „Atelier” albo ustaw ich identyfikatory na serwerze.</p></section>}
    <section className="waiter-climate-grid">{data?.rooms?.map((room) => {
      const capability = room.modeCapabilities[room.mode] ?? { fanLevels: [], temperatureSupported: false, minTemperature: 16, maxTemperature: 30 };
      const target = room.targetTemperature ?? Math.max(capability.minTemperature, Math.min(22, capability.maxTemperature));
      const roomBusy = busy.startsWith(`${room.key}:`);
      return <article className={`waiter-climate-card${room.on ? " is-on" : ""}${room.online ? "" : " is-offline"}`} key={room.key}>
        <header><div><span>{room.online ? "ONLINE" : "OFFLINE"}</span><h2>{room.name}</h2></div><i>{room.productModel ?? "Sensibo"}</i></header>
        <div className="waiter-climate-readings"><div><span>Temperatura</span><strong>{formatMeasurement(room.temperature, "°C")}</strong></div><div><span>Wilgotność</span><strong>{formatMeasurement(room.humidity, "%")}</strong></div><small>Pomiar: {formatTime(room.measuredAt)}</small></div>
        <div className="waiter-climate-power"><span>Klimatyzator</span><div><button type="button" className={room.on ? "is-active" : ""} disabled={!room.online || roomBusy || room.on} onClick={() => void change(room, "on", true)}>Włącz</button><button type="button" className={!room.on ? "is-active" : ""} disabled={!room.online || roomBusy || !room.on} onClick={() => void change(room, "on", false)}>Wyłącz</button></div></div>
        {capability.temperatureSupported && <div className="waiter-climate-temperature"><span>Temperatura zadana</span><div><button type="button" aria-label="Zmniejsz temperaturę" disabled={!room.online || roomBusy || target <= capability.minTemperature} onClick={() => void change(room, "targetTemperature", target - 1)}>−</button><strong>{target}°C</strong><button type="button" aria-label="Zwiększ temperaturę" disabled={!room.online || roomBusy || target >= capability.maxTemperature} onClick={() => void change(room, "targetTemperature", target + 1)}>+</button></div></div>}
        <label>Tryb<select value={room.mode} disabled={!room.online || roomBusy} onChange={(event) => void change(room, "mode", event.target.value)}>{Object.keys(room.modeCapabilities).map((mode) => <option value={mode} key={mode}>{modeLabels[mode] ?? mode}</option>)}</select></label>
        {capability.fanLevels.length > 0 && <label>Nawiew<select value={room.fanLevel ?? capability.fanLevels[0]} disabled={!room.online || roomBusy} onChange={(event) => void change(room, "fanLevel", event.target.value)}>{capability.fanLevels.map((level) => <option value={level} key={level}>{fanLabels[level] ?? level}</option>)}</select></label>}
        <footer>{roomBusy ? "Wysyłam ustawienie…" : room.on ? `${modeLabels[room.mode] ?? room.mode}${capability.temperatureSupported ? ` · ${target}°C` : ""}` : "Klimatyzator wyłączony"}</footer>
      </article>;
    })}</section>
    {!data && !forbidden && !error && <section className="waiter-climate-empty"><strong>Łączę z Sensibo…</strong></section>}
  </main>;
}
