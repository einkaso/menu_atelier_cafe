"use client";

import { FormEvent, useCallback, useEffect, useRef, useState } from "react";
import { WaiterSectionHeader } from "../staff-navigation";
import { clearWaiterSessionToken, waiterSessionHeaders } from "../waiter-session-client";

type Xr18Strip = { id: string; index: number; group: "input" | "effect" | "bus" | "dca" | "main"; name: string; on: boolean; fader: number; pan: number | null };
type Xr18Mixer = { online: boolean; host: string; name: string; model: string; firmware: string; observedAt: string; main: Xr18Strip; channels: Xr18Strip[]; effects: Xr18Strip[]; buses: Xr18Strip[]; dcas: Xr18Strip[] };
type Xr18Response = { configured?: boolean; employeeName?: string; mixer?: Xr18Mixer; locked?: boolean; error?: string };
type ContinuousProperty = "fader" | "pan";
type Bank = "inputs" | "effects" | "buses" | "dcas";
type PendingLive = { strip: Xr18Strip; property: ContinuousProperty; value: number };

const XR18_TOKEN_KEY = "mb_xr18_access";
function accessToken() { try { return window.sessionStorage.getItem(XR18_TOKEN_KEY) ?? ""; } catch { return ""; } }
function saveAccessToken(token: string) { try { window.sessionStorage.setItem(XR18_TOKEN_KEY, token); } catch { /* The HttpOnly cookie remains available. */ } }
function clearAccessToken() { try { window.sessionStorage.removeItem(XR18_TOKEN_KEY); } catch { /* No client token to clear. */ } }
function xr18Headers(initial?: HeadersInit) { const headers = waiterSessionHeaders(initial); const token = accessToken(); if (token) headers.set("x-xr18-access", token); return headers; }
function faderDb(value: number) { if (value <= 0.0001) return "−∞ dB"; const db = value >= 0.5 ? value * 40 - 30 : value >= 0.25 ? value * 80 - 50 : value >= 0.0625 ? value * 160 - 70 : value * 480 - 90; return `${db > 0 ? "+" : ""}${db.toFixed(1)} dB`; }
function panLabel(value: number) { if (Math.abs(value - 0.5) < 0.015) return "C"; const amount = Math.round(Math.abs(value - 0.5) * 200); return `${value < 0.5 ? "L" : "R"} ${amount}`; }
function observedTime(value?: string) { return value ? new Intl.DateTimeFormat("pl-PL", { hour: "2-digit", minute: "2-digit", second: "2-digit" }).format(new Date(value)) : "—"; }

export default function Xr18ControlClient() {
  const [data, setData] = useState<Xr18Response | null>(null);
  const [locked, setLocked] = useState(true);
  const [forbidden, setForbidden] = useState(false);
  const [pin, setPin] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState("");
  const [drafts, setDrafts] = useState<Record<string, number>>({});
  const [bank, setBank] = useState<Bank>("inputs");
  const pendingLive = useRef(new Map<string, PendingLive>());
  const liveTimers = useRef(new Map<string, number>());
  const liveChains = useRef(new Map<string, Promise<void>>());

  useEffect(() => () => {
    for (const timer of liveTimers.current.values()) window.clearTimeout(timer);
    liveTimers.current.clear(); pendingLive.current.clear();
  }, []);

  const load = useCallback(async () => {
    const response = await fetch("/api/waiter/xr18", { cache: "no-store", credentials: "same-origin", headers: xr18Headers() }).catch(() => null);
    const body = await response?.json().catch(() => ({})) as Xr18Response | undefined;
    if (response?.status === 401) { clearWaiterSessionToken(); clearAccessToken(); window.location.replace("/kelner"); return; }
    if (response?.status === 403) { setForbidden(true); setLocked(false); setError(body?.error ?? "Brak uprawnienia eksperta XR18."); return; }
    if (response?.status === 423) { setLocked(true); setError(""); return; }
    if (!response?.ok) { setError(body?.error ?? "Nie udało się pobrać stanu XR18."); return; }
    setForbidden(false); setLocked(false); setError(""); setData(body ?? null);
  }, []);

  useEffect(() => {
    const refresh = () => { if (document.visibilityState === "visible" && !locked) void load(); };
    const initial = window.setTimeout(() => void load(), 0); const timer = window.setInterval(refresh, 3_000);
    window.addEventListener("focus", refresh); document.addEventListener("visibilitychange", refresh);
    return () => { window.clearTimeout(initial); window.clearInterval(timer); window.removeEventListener("focus", refresh); document.removeEventListener("visibilitychange", refresh); };
  }, [load, locked]);

  async function unlock(event: FormEvent) {
    event.preventDefault(); if (!/^\d{6}$/.test(pin)) return; setBusy("unlock"); setError("");
    const response = await fetch("/api/waiter/xr18/access", { method: "POST", credentials: "same-origin", headers: waiterSessionHeaders({ "content-type": "application/json" }), body: JSON.stringify({ pin }) }).catch(() => null);
    const body = await response?.json().catch(() => ({})) as { token?: string; error?: string } | undefined;
    if (!response?.ok || !body?.token) setError(body?.error ?? "Nie udało się odblokować XR18.");
    else { saveAccessToken(body.token); setPin(""); setLocked(false); await load(); }
    setBusy("");
  }

  async function lock() {
    clearAccessToken(); setLocked(true); setData(null); setPin(""); setError("");
    await fetch("/api/waiter/xr18/access", { method: "DELETE", credentials: "same-origin", headers: waiterSessionHeaders() }).catch(() => null);
  }

  async function liveRequest(item: PendingLive) {
    const response = await fetch("/api/waiter/xr18", { method: "PATCH", credentials: "same-origin", headers: xr18Headers({ "content-type": "application/json" }), body: JSON.stringify({ targetId: item.strip.id, property: item.property, value: item.value, live: true }) }).catch(() => null);
    if (response?.status === 423) { clearAccessToken(); setLocked(true); setData(null); setError("Podaj ponownie PIN XR18."); }
    else if (response?.status === 401) { clearWaiterSessionToken(); clearAccessToken(); window.location.replace("/kelner"); }
  }

  function queueLive(strip: Xr18Strip, property: ContinuousProperty, value: number) {
    const key = `${strip.id}:${property}`; pendingLive.current.set(key, { strip, property, value });
    if (liveTimers.current.has(key)) return;
    const timer = window.setTimeout(() => {
      liveTimers.current.delete(key); const item = pendingLive.current.get(key); pendingLive.current.delete(key); if (!item) return;
      const chain = (liveChains.current.get(key) ?? Promise.resolve()).then(() => liveRequest(item));
      liveChains.current.set(key, chain.finally(() => { if (liveChains.current.get(key) === chain) liveChains.current.delete(key); }));
    }, 65);
    liveTimers.current.set(key, timer);
  }

  async function change(strip: Xr18Strip, property: "on" | ContinuousProperty, value: boolean | number) {
    const key = `${strip.id}:${property}`;
    if (property !== "on") {
      const timer = liveTimers.current.get(key); if (timer) window.clearTimeout(timer); liveTimers.current.delete(key); pendingLive.current.delete(key);
      await liveChains.current.get(key)?.catch(() => undefined);
    }
    setBusy(key); setError("");
    const response = await fetch("/api/waiter/xr18", { method: "PATCH", credentials: "same-origin", headers: xr18Headers({ "content-type": "application/json" }), body: JSON.stringify({ targetId: strip.id, property, value }) }).catch(() => null);
    const body = await response?.json().catch(() => ({})) as { error?: string } | undefined;
    if (response?.status === 423) { clearAccessToken(); setLocked(true); setData(null); setError("Podaj ponownie PIN XR18."); }
    else if (response?.status === 401) { clearWaiterSessionToken(); clearAccessToken(); window.location.replace("/kelner"); return; }
    else if (!response?.ok) setError(body?.error ?? "XR18 nie potwierdził ustawienia.");
    else { setDrafts((current) => { const next = { ...current }; delete next[key]; return next; }); await load(); }
    setBusy("");
  }

  function slider(strip: Xr18Strip, property: ContinuousProperty) {
    const key = `${strip.id}:${property}`; const source = property === "fader" ? strip.fader : strip.pan ?? 0.5; const value = drafts[key] ?? source;
    return <label className={`xr18-slider is-${property}`}><span>{property === "fader" ? "Poziom" : "Panorama"}<b>{property === "fader" ? faderDb(value) : panLabel(value)}</b></span><input type="range" min="0" max="1" step="0.001" value={value} disabled={busy === key} onChange={(event) => { const next = Number(event.target.value); setDrafts((current) => ({ ...current, [key]: next })); queueLive(strip, property, next); }} onPointerUp={() => void change(strip, property, value)} onKeyUp={(event) => { if (["ArrowLeft", "ArrowRight", "ArrowUp", "ArrowDown", "Home", "End"].includes(event.key)) void change(strip, property, value); }}/></label>;
  }

  function stripCard(strip: Xr18Strip, main = false) {
    const onBusy = busy === `${strip.id}:on`;
    const label = strip.group === "input" ? strip.id === "aux" ? "AUX 17/18" : `CH ${String(strip.index).padStart(2, "0")}` : strip.group === "effect" ? `FX ${strip.index}` : strip.group === "bus" ? `BUS ${strip.index}` : strip.group === "dca" ? `DCA ${strip.index}` : "SUMA";
    return <article className={`xr18-strip${main ? " is-main" : ""}${strip.on ? " is-live" : " is-muted"}`} key={strip.id}><header><span>{label}</span><i>{strip.on ? "AKTYWNY" : "MUTE"}</i></header><h2>{strip.name}</h2>{slider(strip, "fader")}{strip.pan !== null && slider(strip, "pan")}<button type="button" className={strip.on ? "is-on" : ""} disabled={onBusy} onClick={() => void change(strip, "on", !strip.on)}>{onBusy ? "Wysyłam…" : strip.on ? "Wycisz" : "Włącz kanał"}</button></article>;
  }

  const bankStrips = data?.mixer ? bank === "inputs" ? data.mixer.channels : bank === "effects" ? data.mixer.effects : bank === "buses" ? data.mixer.buses : data.mixer.dcas : [];
  const bankTitle = bank === "inputs" ? "Wejścia" : bank === "effects" ? "Powroty efektów" : bank === "buses" ? "Szyny BUS" : "Grupy DCA";

  return <main className="xr18-page"><WaiterSectionHeader eyebrow="Sterowanie dźwiękiem" title="NAGŁOŚNIENIE" employeeName={data?.employeeName}/>
    <section className="xr18-hero"><div><span className="xr18-device-mark">XR18</span><span>BEHRINGER X AIR · TYLKO EKSPERCI</span><h1>NAGŁOŚNIENIE</h1><p>Nazwy i ustawienia są stale odczytywane z aktualnie załadowanego programu miksera.</p></div>{!locked && !forbidden && <div className="xr18-hero-actions"><button type="button" onClick={() => void load()}>Odśwież</button><button type="button" className="is-lock" onClick={() => void lock()}>Zablokuj</button></div>}</section>
    {error && <div className="xr18-message is-error" role="alert">{error}</div>}
    {forbidden && <section className="xr18-empty"><strong>Brak uprawnienia eksperta XR18</strong><p>Administrator musi nadać osobne uprawnienie i ustawić dodatkowy 6-cyfrowy PIN.</p></section>}
    {locked && !forbidden && <section className="xr18-lock" aria-labelledby="xr18-lock-title"><div><span>DRUGI STOPIEŃ OCHRONY</span><h2 id="xr18-lock-title">Podaj PIN XR18</h2><p>Po odblokowaniu dostęp pozostaje aktywny do ręcznego zablokowania albo wylogowania.</p></div><form onSubmit={unlock}><input value={pin} onChange={(event) => setPin(event.target.value.replace(/\D/g, "").slice(0, 6))} type="password" inputMode="numeric" pattern="[0-9]{6}" autoComplete="off" aria-label="Dodatkowy PIN XR18" autoFocus/><div className="xr18-keypad">{[1,2,3,4,5,6,7,8,9].map((digit) => <button type="button" key={digit} onClick={() => setPin((value) => `${value}${digit}`.slice(0, 6))}>{digit}</button>)}<button type="button" onClick={() => setPin("")}>C</button><button type="button" onClick={() => setPin((value) => `${value}0`.slice(0, 6))}>0</button><button type="button" onClick={() => setPin((value) => value.slice(0, -1))}>⌫</button></div><button className="xr18-unlock" disabled={!/^\d{6}$/.test(pin) || busy === "unlock"}>{busy === "unlock" ? "Sprawdzam…" : "Odblokuj mikser"}</button></form></section>}
    {!locked && data?.mixer && <><section className="xr18-status"><div><span>ONLINE</span><strong>{data.mixer.name}</strong></div><dl><div><dt>Model</dt><dd>{data.mixer.model}</dd></div><div><dt>Firmware</dt><dd>{data.mixer.firmware}</dd></div><div><dt>Adres LAN</dt><dd>{data.mixer.host}</dd></div><div><dt>Odczyt</dt><dd>{observedTime(data.mixer.observedAt)}</dd></div></dl></section><section className="xr18-main"><div><span>WYJŚCIE GŁÓWNE</span><h2>MAIN LR</h2><p>Poziom, panorama i wyciszenie sumy głównej.</p></div>{stripCard(data.mixer.main, true)}</section><section className="xr18-channel-section"><nav className="xr18-banks" aria-label="Sekcje miksera">{([['inputs','Wejścia'],['effects','FX'],['buses','BUS'],['dcas','DCA']] as const).map(([id,label]) => <button type="button" className={bank === id ? "is-active" : ""} key={id} onClick={() => setBank(id)}>{label}</button>)}</nav><header><span>AKTUALNY PROGRAM XR18</span><h2>{bankTitle}</h2><p>Suwaki sterują płynnie podczas ruchu; nazwy odświeżają się automatycznie po zmianie show lub snapshotu.</p></header><div className="xr18-grid">{bankStrips.map((strip) => stripCard(strip))}</div></section></>}
    {!locked && !forbidden && !data && !error && <section className="xr18-empty"><strong>Łączę z XR18…</strong></section>}
  </main>;
}
