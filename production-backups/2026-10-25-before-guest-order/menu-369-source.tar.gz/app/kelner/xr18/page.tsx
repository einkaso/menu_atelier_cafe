import Xr18ZonesClient from "./xr18-zones-client";

export const dynamic = "force-dynamic";

export default function Xr18Page() {
  return <Xr18ZonesClient/>;
}
