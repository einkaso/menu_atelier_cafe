"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { WaiterSectionHeader } from "../staff-navigation";
import { clearWaiterSessionToken, waiterSessionHeaders } from "../waiter-session-client";
import { XR18_ZONES } from "../../../lib/xr18-zones";
import Xr18ControlClient from "./xr18-control-client";

type Zone = { id: string; name: string; fader: number | null; on: boolean | null };
export default function Xr18ZonesClient() {
  const [zones, setZones] = useState<Zone[]>(XR18_ZONES.map(zone => ({ ...zone, fader: null, on: null })));
  const [employeeName, setEmployeeName] = useState<string>();
  const [error, setError] = useState("");
  const [drafts, setDrafts] = useState<Record<string, number>>({});
  const [busy, setBusy] = useState<Record<string, boolean>>({});
  const [expert, setExpert] = useState(false);
  const [opening, setOpening] = useState(false);
  const saving = useRef(new Set<string>());
  const expired = (response: Response) => {
    if (response.status !== 401) return false;
    clearWaiterSessionToken(); window.location.replace("/kelner"); return true;
  };
  const load = useCallback(async () => {
    try {
      const response = await fetch("/api/waiter/xr18/zones", { cache: "no-store", headers: waiterSessionHeaders() });
      if (expired(response)) return;
      const body = await response.json();
      if (!response.ok) throw Error(body.error);
      setZones(body.zones); setEmployeeName(body.employeeName);
    } catch {
      setZones(current => current.map(zone => ({ ...zone, fader: null, on: null })));
      setError("Nie można odczytać głośności stref. Odśwież lub sprawdź połączenie z mikserem.");
    }
  }, []);
  useEffect(() => {
    void load();
    const timer = window.setInterval(() => { if (document.visibilityState === "visible" && saving.current.size === 0) void load(); }, 3000);
    return () => window.clearInterval(timer);
  }, [load]);

  async function change(zone: Zone, value: number) {
    if (saving.current.has(zone.id) || zone.fader === null) return;
    saving.current.add(zone.id); setBusy(current => ({ ...current, [zone.id]: true })); setError("");
    try {
      const response = await fetch("/api/waiter/xr18/zones", { method: "PATCH", headers: waiterSessionHeaders({ "content-type": "application/json" }), body: JSON.stringify({ targetId: zone.id, property: "fader", value }) });
      if (expired(response)) return;
      const body = await response.json();
      if (!response.ok) throw Error(body.error || "Mikser nie potwierdził zmiany.");
      setZones(current => current.map(item => item.id === zone.id ? { ...item, fader: body.change.value } : item));
    } catch (error) {
      setError(error instanceof Error ? error.message : "Nie udało się zmienić głośności.");
      await load();
    } finally {
      setDrafts(current => { const next = { ...current }; delete next[zone.id]; return next; });
      saving.current.delete(zone.id); setBusy(current => ({ ...current, [zone.id]: false }));
    }
  }

  async function toggleExpert() {
    setOpening(true); setError("");
    try {
      const response = await fetch("/api/waiter/xr18/access", { method: "DELETE", headers: waiterSessionHeaders() });
      if (!response.ok) throw Error("Nie udało się zamknąć sesji eksperta. Spróbuj ponownie.");
      try { sessionStorage.removeItem("mb_xr18_access"); } catch { /* Cookie cleared by server. */ }
      setExpert(value => !value);
    } catch (error) { setError(error instanceof Error ? error.message : "Sprawdź połączenie."); }
    finally { setOpening(false); }
  }

  return <div className="xr18-page">
    <WaiterSectionHeader eyebrow="Głośność w lokalu" title="MIKSER XR18" employeeName={employeeName}/>
    <section className="xr18-hero"><div><span>GŁOŚNOŚĆ STREF</span><h1>Ustaw głośność</h1><p>Przesuń suwak wybranej strefy. Głośność zmieni się po puszczeniu suwaka.</p></div><button type="button" onClick={() => { setError(""); void load(); }}>Odśwież</button></section>
    {error && <div className="xr18-message is-error" role="alert">{error}</div>}
    <section className="xr18-zones" aria-label="Głośność stref">
      {zones.map(zone => <article className="xr18-zone" key={zone.id}>
        <h2>{zone.name}</h2>
        <strong>{zone.fader === null ? "Brak odczytu" : `${Math.round((drafts[zone.id] ?? zone.fader) * 100)}%`}</strong>
        <label><span>Głośność — {zone.name}</span><input type="range" min="0" max="1" step="0.01" value={drafts[zone.id] ?? zone.fader ?? 0} disabled={zone.fader === null || busy[zone.id]} onChange={event => setDrafts(current => ({ ...current, [zone.id]: Number(event.target.value) }))} onPointerUp={event => void change(zone, Number(event.currentTarget.value))} onKeyUp={event => { if (["ArrowLeft", "ArrowRight", "ArrowUp", "ArrowDown", "Home", "End", "PageUp", "PageDown"].includes(event.key)) void change(zone, Number(event.currentTarget.value)); }} onPointerCancel={() => setDrafts(current => { const next = { ...current }; delete next[zone.id]; return next; })}/></label>
        <p>{busy[zone.id] ? "Zapisuję…" : zone.on === false ? "Strefa jest wyciszona w pełnym mikserze." : "Ciszej ← → Głośniej"}</p>
      </article>)}
    </section>
    <section className="xr18-expert-entry"><div><h2>Pełny mikser</h2><p>Dostęp dla eksperta po podaniu dodatkowego PIN-u XR18.</p></div><button type="button" disabled={opening} onClick={() => void toggleExpert()}>{opening ? "Proszę czekać…" : expert ? "Zamknij i zablokuj pełny mikser" : "Otwórz pełny mikser"}</button></section>
    {expert && <Xr18ControlClient/>}
  </div>;
}
