import MenuClient from "./menu-client";
import { readWelcomeLayout } from "../lib/menu-view-server";
import QRCode from "qrcode";
import { readArtMediaConfig } from "../lib/menu-art-server";

export const dynamic = "force-dynamic";
export const revalidate = 0;

export default async function Page() {
  const welcomeLayout = await readWelcomeLayout().catch(() => "portrait" as const);
  const configuredReviewUrl = process.env.GOOGLE_REVIEW_URL?.trim();
  const reviewUrl = configuredReviewUrl && /^https:\/\//i.test(configuredReviewUrl) ? configuredReviewUrl : undefined;
  const reviewQr = reviewUrl ? await QRCode.toDataURL(reviewUrl, { width:184, margin:1, color:{dark:"#111a37",light:"#ffffff"} }).catch(() => undefined) : undefined;
  return <MenuClient initialWelcomeLayout={welcomeLayout} reviewUrl={reviewUrl} reviewQr={reviewQr} artMedia={await readArtMediaConfig()} />;
}
