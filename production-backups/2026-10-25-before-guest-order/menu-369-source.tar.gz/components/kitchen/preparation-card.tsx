import type { PreparationCard } from "../../lib/kitchen-recipes";
import RecipeDetails from "./recipe-details";

export default function PreparationCardView({ card }: { card: PreparationCard }) {
  return <div className="kitchen-preparation-card">
    <div className={`kitchen-status ${card.complete ? "is-complete" : "is-incomplete"}`}>
      <b>{card.complete ? "Komplet przygotowania" : "Karta wymaga uzupełnienia"}</b>
      {!card.complete && <ul>{card.issues.map((issue) => <li key={issue}>{issue}</li>)}</ul>}
    </div>
    <section><span className="kitchen-eyebrow">PRZY ZAMÓWIENIU</span><h3>Składanie i wydanie</h3>
      {card.instructions && <p className="kitchen-multiline">{card.instructions}</p>}
      {!!card.media.length && <div className="kitchen-media">{card.media.map((item) => <figure key={item.id}>{item.type === "IMAGE" ? <img src={item.path} alt={item.name}/> : <video src={item.path} controls playsInline preload="metadata"/>}<figcaption>{item.name}</figcaption></figure>)}</div>}
      {!card.instructions && !card.media.length && <p>Nie dodano instrukcji składania.</p>}
    </section>
    <section><span className="kitchen-eyebrow">PRZED SERWISEM</span><h3>Elementy dania i przepisy</h3><p>Ilości poniżej dotyczą jednej porcji dania. Przepisy opisują przygotowanie partii bazowej.</p>
      {card.components.map((part, index) => part.mode === "PURCHASED" ? <article className="kitchen-purchased" key={index}><b>{part.name}</b><span>{part.quantity} {part.unit} / porcja · produkt gotowy</span>{part.notes && <p>{part.notes}</p>}</article> :
        <details className="kitchen-component" key={`${index}-${part.recipeVersionId}`}><summary><span><b>{part.name}</b><small>{part.quantity} {part.unit} / porcja{part.recipe ? ` · przepis v${part.recipe.version}` : " · brak zatwierdzonego przepisu"}</small></span><span>{part.recipe ? "Otwórz przepis" : "Brak przepisu"}</span></summary>
          {part.notes && <p className="kitchen-part-note">Do tego dania: {part.notes}</p>}
          {part.recipe ? <RecipeDetails recipe={part.recipe}/> : <p className="kitchen-part-note">Administrator musi podpiąć zatwierdzony przepis tego elementu.</p>}
        </details>)}
      {!card.components.length && <p>Nie określono jeszcze elementów dania.</p>}
    </section>
  </div>;
}
