import RecipeIngredients from "./recipe-ingredients";
import type { RecipeVersion } from "../../lib/kitchen-recipes";

export default function RecipeDetails({ recipe }: { recipe: RecipeVersion }) {
  const content = recipe.content;
  return <section className="kitchen-recipe-details">
    <header><span>{content.category} · wersja {recipe.version}</span><h3>{content.name}</h3></header>
    <RecipeIngredients key={`${recipe.id}-${recipe.editRevision}`} content={content}/>
    <h4>Przygotowanie krok po kroku</h4><p className="kitchen-multiline">{content.steps}</p>
    <div className="kitchen-recipe-facts"><section><h4>Alergeny</h4><p className="kitchen-multiline">{content.allergens}</p></section><section><h4>Przechowywanie</h4><p className="kitchen-multiline">{content.storage}</p></section></div>
    {content.notes && <><h4>Wskazówki</h4><p className="kitchen-multiline">{content.notes}</p></>}
    {!!recipe.media.length && <div className="kitchen-media">{recipe.media.map((item) => <figure key={item.id}>{item.type === "IMAGE" ? <img src={item.path} alt={item.name}/> : <video src={item.path} controls playsInline preload="metadata"/>}<figcaption>{item.name}</figcaption></figure>)}</div>}
    <small>Zatwierdzono: {recipe.publishedAt ? new Date(recipe.publishedAt).toLocaleDateString("pl-PL") : "szkic"} · {recipe.updatedBy}</small>
  </section>;
}
