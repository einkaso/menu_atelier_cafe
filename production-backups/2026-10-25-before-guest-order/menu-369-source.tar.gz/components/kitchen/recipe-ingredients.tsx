"use client";
import { useState } from "react";
import type { RecipeContent } from "../../lib/kitchen-recipes";
import { formatRecipeQuantity, recipeQuantity, scaleRecipe } from "../../lib/recipe-scaling";

export default function RecipeIngredients({ content }: { content: RecipeContent }) {
  return <Calculator key={JSON.stringify(content)} content={content}/>;
}
function Calculator({ content }: { content: RecipeContent }) {
  const [multiplier, setMultiplier] = useState(1);
  const [active, setActive] = useState<{ index: number; text: string } | null>(null);
  const [invalid, setInvalid] = useState(false);
  function reset() { setMultiplier(1); setActive(null); setInvalid(false); }
  function change(index: number, text: string) {
    setActive({ index, text });
    const result = scaleRecipe(content, index, text, content.ingredients[index].unit);
    setInvalid(!result);
    if (result) setMultiplier(result.multiplier);
  }
  const baseYield = recipeQuantity(content.yieldQuantity);
  return <section aria-label={`Przeliczanie składników: ${content.name}`}>
    <h4>Składniki — przelicz proporcje</h4>
    <p>Wpisz posiadaną ilość przy dowolnym składniku. Pozostałe ilości przeliczą się automatycznie. Przepis bazowy pozostaje bez zmian.</p>
    <p>Partia bazowa: <b>{content.yieldQuantity || "nie określono"} {content.yieldUnit}</b>{baseYield !== null && <span> · Po przeliczeniu: <b>{formatRecipeQuantity(baseYield * multiplier)} {content.yieldUnit}</b></span>}</p>
    <div aria-live="polite" role="status">{invalid ? "Wpisz liczbę większą od zera (np. 0,5). Pozostałe pola pokazują ostatnie prawidłowe przeliczenie." : `Proporcja partii: ×${formatRecipeQuantity(multiplier)}${active ? ` · według składnika: ${content.ingredients[active.index].name}` : " · ilości bazowe"}`}</div>
    <table><thead><tr><th>Składnik</th><th>Ilość na Twoją partię</th></tr></thead><tbody>{content.ingredients.map((item, index) => {
      const base = recipeQuantity(item.quantity);
      const editable = base !== null && !!item.unit.trim();
      const value = editable ? formatRecipeQuantity(base * multiplier) : item.quantity;
      return <tr key={index}><td>{item.name}{editable && <small style={{ display: "block" }}>Bazowo: {item.quantity} {item.unit}</small>}</td><td>{editable ? <><input style={{ width: "100%", maxWidth: 150, boxSizing: "border-box", minHeight: 44, padding: 8, border: "1px solid #aab8b0", borderRadius: 6, background: "white", color: "#162b25" }} type="text" inputMode="decimal" maxLength={40} aria-label={`Ilość: ${item.name} (${item.unit})`} aria-invalid={active?.index === index && invalid} value={active?.index === index ? active.text : value} onChange={event => change(index, event.target.value)}/><span> {item.unit}</span></> : <>{item.quantity || "Do ustalenia"} {item.unit}</>}</td></tr>;
    })}</tbody></table>
    <button type="button" onClick={reset}>Przywróć ilości bazowe</button>
    <p><small>Ułamkowe sztuki pozostają ułamkowe. Ilości opisowe i liczby w treści instrukcji nie są przeliczane. Podana wydajność skaluje się proporcjonalnie; czas przygotowania pozostaje zgodny z instrukcją.</small></p>
  </section>;
}
