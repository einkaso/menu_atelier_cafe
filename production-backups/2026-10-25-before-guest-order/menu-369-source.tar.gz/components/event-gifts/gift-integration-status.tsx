'use client';
import {useState} from 'react';
import type {GiftIntegrationStatus} from '../../lib/event-gifts-capabilities';
export default function GiftConnectionStatus({initial}:{initial:GiftIntegrationStatus}){
 const [status,setStatus]=useState(initial),[busy,setBusy]=useState(false),[error,setError]=useState('');
 async function refresh(){setBusy(true);setError('');try{const r=await fetch('/api/admin/event-gifts/status',{cache:'no-store'});if(!r.ok)throw Error('Nie udało się odświeżyć statusu. Sprawdź sesję administratora.');setStatus(await r.json());}catch(e){setError(e instanceof Error?e.message:'Błąd odczytu.');}finally{setBusy(false);}}
 return <section className="gift-connection" aria-label="Stan integracji prezentów"><b>{status.connected?'Events: połączenie potwierdzone':'Events: brak potwierdzenia połączenia'}</b><p>{status.message}</p>{status.capabilities&&<p>Wersja: {status.capabilities.apiVersion} · tryb: {status.capabilities.mode} · sprzedaż w Events: {status.capabilities.salesEnabled?'włączona':'wyłączona'} · <strong>sprzedaż w Menu: wyłączona</strong></p>}<small>Sprawdzono: {new Date(status.checkedAt).toLocaleString('pl-PL',{timeZone:'Europe/Warsaw'})}</small> <button type="button" disabled={busy} onClick={()=>void refresh()}>{busy?'Sprawdzam…':'Sprawdź połączenie'}</button>{error&&<p role="alert">{error}</p>}</section>;
}
