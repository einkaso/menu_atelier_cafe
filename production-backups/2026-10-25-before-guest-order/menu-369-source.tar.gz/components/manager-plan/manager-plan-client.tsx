"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import { Dialog, DialogContent, DialogTitle, DialogDescription } from "../ui/dialog";
import { waiterSessionHeaders } from "../../app/kelner/waiter-session-client";
import { dayOffset, hoursLabel, kindNames, planMinutes, planMonday, planSummary, planToday, type PlanDay, type PlanKind } from "../../lib/manager-plan";
import "./manager-plan.css";
type Audit = { id:number; actor:string; before:PlanDay|null; after:PlanDay; changedAt:string };
const dateLabel = (date:string) => new Intl.DateTimeFormat("pl-PL",{weekday:"short",day:"numeric",month:"long",year:"numeric",timeZone:"Europe/Warsaw"}).format(new Date(date+"T12:00:00Z"));
const describe = (day:PlanDay|null) => !day?.kind ? "Brak wpisu" : `${kindNames[day.kind]}${day.kind==="WORK"?": "+day.intervals.map(i=>`${i.from}–${i.to}`).join(", "):""}${day.note?" · "+day.note:""}`;
export default function ManagerPlanClient() {
  const [anchor,setAnchor] = useState(planToday), [mode,setMode] = useState<"week"|"month">("week");
  const [days,setDays] = useState<PlanDay[]>([]), [today,setToday] = useState(planToday), [admin,setAdmin] = useState(false);
  const [ready,setReady] = useState(false), [loading,setLoading] = useState(true), [error,setError] = useState(""), [message,setMessage] = useState("");
  const [editing,setEditing] = useState<PlanDay|null>(null), [saving,setSaving] = useState(false), [editError,setEditError] = useState("");
  const [history,setHistory] = useState<{date:string;rows:Audit[]}|null>(null);
  const requestId = useRef(0);
  const weekStart=planMonday(anchor), weekEnd=dayOffset(weekStart,6), monthStart=anchor.slice(0,7)+"-01";
  const monthEnd=new Date(Date.UTC(Number(anchor.slice(0,4)),Number(anchor.slice(5,7)),0,12)).toISOString().slice(0,10);
  const from=weekStart<monthStart?weekStart:monthStart, to=weekEnd>monthEnd?weekEnd:monthEnd;
  const load = useCallback(async()=>{
    const id=++requestId.current;setLoading(true);setError("");setHistory(null);
    try {
      const response=await fetch(`/api/manager-plan?from=${from}&to=${to}`,{cache:"no-store",headers:waiterSessionHeaders()});
      const body=await response.json();if(id!==requestId.current)return;
      if(!response.ok){setReady(false);setDays([]);throw Error(body.error||"Nie udało się pobrać planu.");}
      setDays(body.days);setToday(body.today);setAdmin(body.admin);setReady(true);
    } catch(e){if(id===requestId.current){setReady(false);setError(e instanceof Error?e.message:"Brak połączenia.");}}
    finally{if(id===requestId.current)setLoading(false);}
  },[from,to]);
  useEffect(()=>{void load();return()=>{requestId.current++};},[load]);
  function move(direction:number){
    setMessage("");
    if(mode==="week")setAnchor(dayOffset(anchor,7*direction));
    else setAnchor(new Date(Date.UTC(Number(anchor.slice(0,4)),Number(anchor.slice(5,7))-1+direction,1,12)).toISOString().slice(0,10));
  }
  async function save(remove=false){
    if(!editing||saving)return;setSaving(true);setEditError("");
    try{
      const entry=remove?{...editing,kind:null,intervals:[],note:""}:editing;
      const response=await fetch("/api/manager-plan",{method:"PUT",headers:waiterSessionHeaders({"Content-Type":"application/json"}),body:JSON.stringify(entry)});
      const body=await response.json();if(!response.ok)throw Error(body.error||"Nie udało się zapisać.");
      setDays(previous=>[...previous.filter(d=>d.date!==body.day.date),body.day]);setHistory(null);setEditing(null);setMessage(remove?"Wpis usunięty. Historia zmiany została zachowana.":"Zapisano dzień i przeliczono podsumowania.");
    }catch(e){setEditError(e instanceof Error?e.message:"Brak połączenia.");}finally{setSaving(false);}
  }
  async function showHistory(date:string){
    setError("");try{const r=await fetch(`/api/manager-plan?from=${from}&to=${to}&history=${date}`,{cache:"no-store",headers:waiterSessionHeaders()});const b=await r.json();if(!r.ok)throw Error(b.error);setHistory({date,rows:b.history});}catch(e){setError(e instanceof Error?e.message:"Brak połączenia.");}
  }
  const first=mode==="week"?weekStart:monthStart,last=mode==="week"?weekEnd:monthEnd;
  const dates:string[]=[];for(let d=first;d<=last;d=dayOffset(d,1))dates.push(d);
  return <main className="manager-plan">
    <header><div><p>PRYWATNY PLAN PRACY</p><h1>Aleksandra — plan pracy managerki</h1><p>Wpisz planowane godziny, a po zmianie planu lub wykonaniu pracy popraw ten sam wpis.</p></div><a href={admin?"/admin":"/kelner"}>← Wróć do panelu</a></header>
    <nav aria-label="Okres planu"><button onClick={()=>move(-1)} disabled={loading}>← Poprzedni</button><label>Dzień odniesienia<input type="date" value={anchor} min="2000-01-01" max="2099-12-31" onChange={e=>{if(e.target.value)setAnchor(e.target.value)}}/></label><button onClick={()=>move(1)} disabled={loading}>Następny →</button><button onClick={()=>setAnchor(planToday())}>Dzisiaj</button><button aria-pressed={mode==="week"} onClick={()=>setMode("week")}>Tydzień</button><button aria-pressed={mode==="month"} onClick={()=>setMode("month")}>Miesiąc</button><button onClick={()=>void load()} disabled={loading}>Odśwież</button></nav>
    {loading&&<p role="status">Pobieram plan…</p>}{error&&<p role="alert">{error} {!ready&&<a href="/kelner">Zaloguj się swoim PIN-em</a>}</p>}{message&&<p role="status">{message}</p>}
    {ready&&<>
      <section className="manager-plan-summaries" aria-label="Podsumowania">{[{title:"Tydzień",start:weekStart,end:weekEnd},{title:"Miesiąc",start:monthStart,end:monthEnd}].map(period=>{const sum=planSummary(days,period.start,period.end,today);return <article key={period.title}><h2>{period.title}</h2><p>{period.start} – {period.end}</p><dl><dt>Zapisane godziny do dziś włącznie</dt><dd>{hoursLabel(sum.throughToday)}</dd><dt>Łącznie z przyszłymi wpisami</dt><dd>{hoursLabel(sum.minutes)}</dd><dt>Urlop</dt><dd>{sum.leave} dni</dd><dt>Zwolnienie lekarskie</dt><dd>{sum.sick} dni</dd></dl></article>})}</section>
      <p>Sumy wynikają z aktualnie zapisanych godzin. Wpisy do dziś mogą wymagać korekty po wykonaniu pracy. Urlop i zwolnienie nie zwiększają sumy godzin; liczba dni oznacza dni oznaczone w tym planie.</p>
      <div className="manager-plan-table"><table><caption>{dateLabel(first)} – {dateLabel(last)}</caption><thead><tr><th>Dzień</th><th>Rodzaj</th><th>Godziny</th><th>Suma</th><th>Notatka</th><th>Akcje</th></tr></thead><tbody>{dates.map(date=>{const day=days.find(d=>d.date===date)||{date,kind:null,intervals:[],note:"",revision:0};return <tr key={date} className={date===today?"is-today":""}><th scope="row">{dateLabel(date)}</th><td>{day.kind?kindNames[day.kind]:"—"}</td><td>{day.intervals.map(i=>`${i.from}–${i.to}`).join(", ")||"—"}</td><td>{day.kind==="WORK"?hoursLabel(planMinutes(day)):"—"}</td><td>{day.note||"—"}</td><td><button disabled={loading} onClick={()=>{setEditError("");setEditing({...day,kind:day.kind||"WORK",intervals:day.kind?day.intervals:[{from:"09:00",to:"17:00"}]});}} aria-label={`Edytuj ${date}`}>{day.kind?"Edytuj":"Dodaj"}</button>{admin&&<button onClick={()=>void showHistory(date)} aria-label={`Historia ${date}`}>Historia</button>}</td></tr>})}</tbody></table></div>
      {history&&<section className="manager-plan-history"><h2>Historia — {dateLabel(history.date)}</h2><button onClick={()=>setHistory(null)}>Zamknij historię</button>{!history.rows.length&&<p>Brak zmian.</p>}{history.rows.map(row=><article key={row.id}><b>{row.actor} · {new Date(row.changedAt).toLocaleString("pl-PL",{timeZone:"Europe/Warsaw"})}</b><p>Przed: {describe(row.before)}</p><p>Po: {describe(row.after)}</p></article>)}</section>}
    </>}
    <Dialog open={!!editing} onOpenChange={open=>{if(!open&&!saving)setEditing(null)}}><DialogContent className="manager-plan-editor" showCloseButton={!saving}><DialogTitle>{editing?dateLabel(editing.date):"Dzień pracy"}</DialogTitle><DialogDescription>Jeden aktualny wpis na dzień. Zapis nie zmienia grafiku zespołu ani odbić kartą.</DialogDescription>{editing&&<form onSubmit={e=>{e.preventDefault();void save()}}><fieldset disabled={saving}><label>Rodzaj dnia<select value={editing.kind||"WORK"} onChange={e=>{const kind=e.target.value as PlanKind;setEditing({...editing,kind,intervals:kind==="WORK"?[{from:"09:00",to:"17:00"}]:[]})}}>{Object.entries(kindNames).map(([value,name])=><option key={value} value={value}>{name}</option>)}</select></label>
      {editing.kind==="WORK"&&<><p>Przerwę pomiń, wpisując osobne przedziały. Godziny po północy zapisz w kolejnym dniu; koniec dnia możesz oznaczyć jako 24:00.</p>{editing.intervals.map((interval,index)=><div className="manager-plan-interval" key={index}><label>Od<input aria-label={`Od ${index+1}`} placeholder="09:00" inputMode="text" pattern="([01][0-9]|2[0-3]):[0-5][0-9]" required value={interval.from} onChange={e=>setEditing({...editing,intervals:editing.intervals.map((i,n)=>n===index?{...i,from:e.target.value}:i)})}/></label><label>Do<input aria-label={`Do ${index+1}`} placeholder="17:00" inputMode="text" pattern="(([01][0-9]|2[0-3]):[0-5][0-9]|24:00)" required value={interval.to} onChange={e=>setEditing({...editing,intervals:editing.intervals.map((i,n)=>n===index?{...i,to:e.target.value}:i)})}/></label><button type="button" disabled={editing.intervals.length===1} onClick={()=>setEditing({...editing,intervals:editing.intervals.filter((_,n)=>n!==index)})}>Usuń przedział</button></div>)}<button type="button" disabled={editing.intervals.length>=4} onClick={()=>setEditing({...editing,intervals:[...editing.intervals,{from:"",to:""}]})}>+ Drugi / kolejny przedział</button></>}
      <label>Notatka (opcjonalnie)<textarea maxLength={1000} value={editing.note} onChange={e=>setEditing({...editing,note:e.target.value})}/></label>{editError&&<p role="alert">{editError}</p>}<footer><button type="submit">{saving?"Zapisuję…":"Zapisz dzień"}</button><button type="button" onClick={()=>setEditing(null)}>Anuluj</button>{editing.revision>0&&<button type="button" onClick={()=>{if(window.confirm("Usunąć wpis tego dnia? Historia zmiany pozostanie dostępna administratorowi."))void save(true)}}>Usuń wpis</button>}</footer></fieldset></form>}</DialogContent></Dialog>
  </main>;
}
