import { allergenNames } from "../../lib/product-order";
export const dishAttributeKeys = ["dishIngredients", "dishAllergens", "dishAllergenNote"];
export default function SavoryComposition({ attributes, allergens, lang, contentOnly = false }: { attributes?: Record<string,string>; allergens?: number[]; lang: "pl" | "en"; contentOnly?: boolean }) {
  const pl = lang === "pl";
  const ingredients = attributes?.dishIngredients;
  const names = [...new Set([...(attributes?.dishAllergens?.split("|").map(name => name.trim()).filter(Boolean) ?? []), ...(allergens ?? []).map(id => allergenNames[id]?.[lang]).filter(Boolean)])];
  const content = <div className="savory-composition-content">
    <h4>{pl ? "Składniki" : "Ingredients"}</h4>
    <p>{ingredients || (pl ? "O aktualny skład tego dania zapytaj obsługę." : "Ask our team about the current ingredients of this dish.")}</p>
    <h4>{pl ? "Alergeny" : "Allergens"}</h4>
    {names.length ? <ul>{names.map(name => <li key={name}>{name}</li>)}</ul> : <p>{pl ? "Informację o alergenach uzyskasz u obsługi." : "Please ask our team for allergen information."}</p>}
    {(attributes?.dishAllergenNote || ingredients && !names.length) && <small>{attributes?.dishAllergenNote || (pl ? "Brak oznaczeń nie oznacza braku alergenów. Zapytaj obsługę." : "Missing labels do not mean allergen-free. Please ask our team.")}</small>}
  </div>;
  return contentOnly ? content : <details className="savory-composition" aria-label={pl ? "Skład i alergeny" : "Ingredients and allergens"}><summary>{pl ? "Skład i alergeny" : "Ingredients and allergens"}<span aria-hidden="true" className="savory-composition-toggle" /></summary>{content}</details>;
}
