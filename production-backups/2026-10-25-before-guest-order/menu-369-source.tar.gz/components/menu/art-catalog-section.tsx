"use client";

import { PromoLaunchNotice } from "./promo-launch-notice";
import { cocktailViewFor } from "../../lib/alcohol-view";
import { isMulledWine } from "../../lib/wine-serving";
import { wineImageStyle } from "../../lib/wine-framing";
import { bottleImageStyle } from "../../lib/bottle-framing";
import { type CSSProperties, type ReactNode, useEffect, useMemo, useRef, useState } from "react";
import { hasGuestPrice, menuArtAsset, type ArtLoopMedia, type MenuArtSection } from "../../lib/menu-art";
import { artWhiskyPresentation, artWhiskySectionIntro, artWhiskySectionTitle } from "../../lib/art-whisky";
import ArtLoopVideo from "./art-loop-video";
import { Dialog, DialogContent, DialogDescription, DialogTitle } from "../ui/dialog";

type Lang = "pl" | "en";
type CatalogKind = Exclude<MenuArtSection, "coffee" | "food">;
type Offer = { kind: "glass" | "serving" | "bottle"; price: string };
type BurstStyle = CSSProperties & Record<`--${string}`, string | number>;

export type ArtCatalogProduct = {
  id?: number;
  pl: string;
  en: string;
  descPl: string;
  descEn: string;
  price: string;
  image?: string;
  visualKind?: string;
  sourceCategory?: string | null;
  sourceCategoryEn?: string | null;
  groupPl?: string;
  groupEn?: string;
  zeroGroupPl?: string;
  zeroGroupEn?: string;
  cakePartner?: "capuccino-cafe";
  featured?: boolean;
  promo?: boolean;
  guestChoice?: boolean;
  productCode?: string;
  country?: string;
  countryEn?: string;
  region?: string;
  regionEn?: string;
  wineColor?: string;
  taste?: string;
  tasteEn?: string;
  wineStyle?: string;
  wineStyleEn?: string;
  sweetness?: string;
  tastingNotes?: string;
  tastingNotesEn?: string;
  sparklingType?: string;
  vegan?: boolean;
  alcoholFree?: boolean;
  wine?: boolean;
  whisky?: boolean;
  offers?: Offer[];
  allergens?: number[];
  attributes?: Record<string, string>;
  attributesEn?: Record<string, string>;
  temperatures?: Array<"warm" | "cold">;
  drinkVessel?: { capacityMl: number };
  beerVariantGroup?: string;
  beerVariants?: Array<{ productId: number; capacity: string; price: string; available: boolean; image?: string }>;
};

export type ArtCatalogGroup<T extends ArtCatalogProduct> = { id: string; title: string; products: T[] };

const FLOURISHES = ["fala", "kreska", "kropka", "listek", "pierscien", "spirala", "trojkat"];
const BURST_COLORS = ["#FC0AB9", "#FB5925", "#0145BD", "#01AEE8", "#A5E0E1", "#FE0505", "#8E1C86"];

function normalized(value: string) {
  return value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLocaleLowerCase("pl").replace(/ł/g, "l");
}

function sectionId(value: string) {
  return `art-section-${normalized(value).replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "")}`;
}


function shotFamily(product: ArtCatalogProduct, lang: Lang) {
  const value = normalized(`${product.attributes?.cocktailBase ?? ""} ${product.attributesEn?.cocktailBase ?? ""} ${product.pl}`);
  if (/wodk|vodka|absolut|ciroc|finlandia/.test(value)) return lang === "pl" ? "Wódka" : "Vodka";
  if (/gin|hendri|tanqueray|bombay/.test(value)) return "Gin";
  if (/rum|bacardi|captain|kraken|havana|planteray/.test(value)) return "Rum";
  if (/tequil|olmeca|1800/.test(value)) return "Tequila";
  return lang === "pl" ? "Likiery i bittery" : "Liqueurs and bitters";
}

const SHOT_FAMILY_ORDER_PL = ["Wódka", "Gin", "Rum", "Tequila", "Likiery i bittery"];
const SHOT_FAMILY_ORDER_EN = ["Vodka", "Gin", "Rum", "Tequila", "Liqueurs and bitters"];

function sentenceCase(value: string, lang: Lang) {
  const trimmed = value.trim();
  if (!trimmed || trimmed !== trimmed.toLocaleUpperCase(lang === "pl" ? "pl" : "en")) return trimmed;
  const lower = trimmed.toLocaleLowerCase(lang === "pl" ? "pl" : "en");
  return lower.charAt(0).toLocaleUpperCase(lang === "pl" ? "pl" : "en") + lower.slice(1);
}

function firstSentence(value: string) {
  const trimmed = value.trim();
  return trimmed.match(/^.*?[.!?](?=\s|$)/)?.[0] ?? trimmed;
}

export function isArtDraughtBeer(product: ArtCatalogProduct) {
  const serving = normalized(`${product.attributes?.servingStyle ?? ""} ${product.attributesEn?.servingStyle ?? ""}`);
  if (/nalew|kran|on tap|draught|draft/.test(serving)) return true;
  if (/butelk|bottle|puszk|\bcan\b/.test(serving)) return false;
  const name = normalized(`${product.pl} ${product.en}`);
  if (product.alcoholFree || /(?:^|\s)0\s*%|\bzero\b/.test(name)) return false;
  return /\b(?:bosman|guinness)\b/.test(name);
}

export function artCatalogPresentation(value: string, lang: Lang) {
  const parameters: string[] = [];
  const parenthetical = [...value.matchAll(/\(([^)]+)\)/g)].map(match => match[1]?.trim()).filter(Boolean) as string[];
  parameters.push(...parenthetical.filter(item => /\d|ml|cl|l\b|g\b|%/i.test(item)));
  for (const match of value.matchAll(/(?:^|\s)(\d+(?:[,.]\d+)?)\s*(ml|cl|l|g|kg)\b/gi)) parameters.push(`${match[1]} ${match[2].toLocaleLowerCase("pl")}`);
  const name = sentenceCase(value
    .replace(/\s*\([^)]+\)\s*/g, " ")
    .replace(/(?:^|\s)\d+(?:[,.]\d+)?\s*(?:ml|cl|l|g|kg)\b/gi, " ")
    .replace(/\s+/g, " ").trim(), lang);
  return { name, parameters: Array.from(new Set(parameters)) };
}

function groupTitle(product: ArtCatalogProduct, kind: CatalogKind, lang: Lang) {
  const L = (pl: string, en: string) => lang === "pl" ? pl : en;
  const name = normalized(product.pl).trim();
  const group = lang === "pl" ? product.groupPl : product.groupEn || product.groupPl;
  if (kind === "cakes") return product.cakePartner === "capuccino-cafe" ? L("Dzisiaj w naszej witrynie", "Today in our display") : L("Desery Atelier", "Atelier desserts");
  if (kind === "matcha") return product.temperatures?.includes("warm") && !product.temperatures?.includes("cold") ? L("Na ciepło", "Warm") : L("Na zimno", "Cold");
  if (kind === "tea") {
    const knownGroup = /^(paris|hot cinnamon spice)$/.test(name) ? L("Czarne", "Black tea")
      : name === "jasmine" ? L("Zielone", "Green tea")
      : /^mango (fruit|friut) tea$/.test(name) ? L("Owocowe", "Fruit tea")
      : name === "rooibos chai" ? L("Ziołowe", "Herbal tea") : null;
    return group || (lang === "pl" ? product.attributes?.teaType : product.attributesEn?.teaType) || knownGroup || L("Pozostałe herbaty", "Other teas");
  }
  if (kind === "cold") {
    if (/wod[ay]|water/.test(name)) return L("Wody", "Water");
    if (/lemoniad|sok|napar|lemonade|juice|infusion/.test(name)) return L("Robione u nas", "Made in house");
    return L("Gazowane", "Sparkling drinks");
  }
  if (kind === "wine") {
    if (isMulledWine(product)) return L("Wina grzane", "Mulled wines");
    const color = normalized(product.wineColor || "");
    if (/roz|pomar|rose|orange/.test(color)) return L("Różowe i pomarańczowe", "Rosé and orange");
    if (/czerw|red/.test(color)) return L("Czerwone", "Red");
    return L("Białe", "White");
  }
  if (kind === "beer") {
    if (product.alcoholFree) return L("Bezalkoholowe", "Alcohol-free");
    return group || (lang === "pl" ? product.attributes?.beerStyle : product.attributesEn?.beerStyle) || L("Piwa", "Beer");
  }
  if (kind === "whisky") {
    return artWhiskySectionTitle(artWhiskyPresentation(product).section, lang);
  }
  if (kind === "zero") {
    if (product.visualKind === "cocktails") return L("Drinki 0%", "0% cocktails");
    if (product.visualKind === "beer") return L("Piwa", "Beer");
    if (product.visualKind === "wine") return L("Wina", "Wine");
    return L("Aperitify i gin", "Aperitifs and gin");
  }
  if (kind === "shelf") return (lang === "pl" ? product.sourceCategory : product.sourceCategoryEn || product.sourceCategory) || L("Z półki", "From the shelf");
  return group || L("Koktajle", "Cocktails");
}

const groupOrder: Record<CatalogKind, string[]> = {
  cakes: ["dzisiaj", "today in our display", "desery", "atelier desserts"], matcha: ["cieplo", "zimno"], tea: ["czarne", "zielone", "ziolowe", "owocowe"], cold: ["robione", "gazowane", "wody"],
  cocktails: ["spritze", "koktajle", "drinki 0", "shoty", "wodka na butelki", "pozostale"], wine: ["biale", "white", "rozowe", "rose", "czerwone", "red", "wina grzane", "mulled wines"], beer: ["lager", "pszen", "ipa", "stout", "ale", "bezalkohol"],
  whisky: ["lagodne", "waniliowo", "dymne", "koniaki"], zero: ["drinki", "piwa", "wina", "aperitify"], shelf: ["kawa", "tlocznia", "pasty", "miody", "oleje", "syropy"],
};

export function buildArtCatalogGroups<T extends ArtCatalogProduct>(products: T[], kind: CatalogKind, lang: Lang) {
  const groups = new Map<string, T[]>();
  for (const product of products) {
    const title = groupTitle(product, kind, lang);
    groups.set(title, [...(groups.get(title) ?? []), product]);
  }
  const order = groupOrder[kind];
  return [...groups.entries()].sort(([a], [b]) => {
    const rank = (value: string) => { const key = normalized(value); const index = order.findIndex(item => key.includes(item)); return index < 0 ? 999 : index; };
    return rank(a) - rank(b);
  }).map(([title, group]) => ({ id: sectionId(title), title, products: group }));
}

function beerCapacityNumber(value: string) {
  const match = value.match(/(\d+(?:[,.]\d+)?)\s*(ml|cl|l)\b/i);
  if (!match) return 0;
  const amount = Number(match[1].replace(",", "."));
  return match[2].toLocaleLowerCase("pl") === "l" ? amount * 1000 : match[2].toLocaleLowerCase("pl") === "cl" ? amount * 10 : amount;
}

function combineBeerCards<T extends ArtCatalogProduct>(products: T[]) {
  const cards = new Map<string, T[]>();
  for (const product of products) cards.set(product.beerVariantGroup || `product-${product.id ?? product.pl}`, [...(cards.get(product.beerVariantGroup || `product-${product.id ?? product.pl}`) ?? []), product]);
  return [...cards.values()].map(group => {
    const variants = [...(group[0].beerVariants ?? [])].sort((a, b) => beerCapacityNumber(a.capacity) - beerCapacityNumber(b.capacity));
    const preferredId = [...variants].reverse().find(variant => variant.available)?.productId;
    const primary = group.find(product => product.id === preferredId) ?? group[0];
    const largestImage = variants.at(-1)?.image;
    return { ...primary, image: largestImage || primary.image, beerVariants: variants } as T;
  });
}

function InfoBadge({ wave, order }: { wave: number; order: number }) {
  const ref = useRef<HTMLSpanElement>(null);
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const element = ref.current;
    if (!element || typeof IntersectionObserver === "undefined") { setVisible(true); return; }
    const observer = new IntersectionObserver(([entry]) => setVisible(entry.isIntersecting), { threshold: .55 });
    observer.observe(element);
    return () => observer.disconnect();
  }, []);
  return <span ref={ref} className="art-menu-info" style={visible && wave >= 0 ? { animationName: wave % 2 ? "art-info-pulse-a" : "art-info-pulse-b", animationDelay: `${(order % 10) * 110}ms` } : undefined} aria-hidden="true">i</span>;
}

function Burst({ token }: { token: number }) {
  if (!token) return null;
  return <span className="art-menu-burst" aria-hidden="true">{Array.from({ length: 16 }, (_, index) => {
    const angle = ((index * 137.5 + token * 17) % 360) * Math.PI / 180;
    const distance = 150 + (index % 5) * 19;
    const style: BurstStyle = { "--burst-x": `${Math.cos(angle) * distance}px`, "--burst-y": `${Math.sin(angle) * distance}px`, "--burst-r": `${140 + (index % 6) * 32}deg`, "--burst-size": `${20 + (index % 5) * 3}px`, "--burst-delay": `${(index % 4) * 18}ms`, "--burst-color": BURST_COLORS[index % BURST_COLORS.length], "--burst-mask": `url("/menu-art/flourishes/${FLOURISHES[index % FLOURISHES.length]}.svg")` };
    return <i key={`${token}-${index}`} style={style}/>;
  })}</span>;
}

function priceParts(product: ArtCatalogProduct) {
  const offers = product.offers ?? [];
  const main = offers.find(offer => offer.kind === "bottle") ?? offers.find(offer => offer.kind === "serving");
  const secondary = offers.find(offer => offer.kind === "glass") ?? (offers.length > 1 ? offers[0] : undefined);
  if (main || secondary) return { main: main?.price, secondary: secondary && secondary !== main ? secondary.price : undefined, secondaryLabel: offers.find(offer => offer.kind === "glass") === secondary ? "kieliszek" : undefined };
  const values = product.price.split(/\s*\/\s*/).filter(hasGuestPrice);
  return { main: values.length > 1 ? values.at(-1) : values[0], secondary: values.length > 1 ? values[0] : undefined, secondaryLabel: undefined };
}

function parameters(product: ArtCatalogProduct, kind: CatalogKind, lang: Lang, fromName: string[]) {
  const attributes = lang === "pl" ? product.attributes : product.attributesEn || product.attributes;
  const country = lang === "pl" ? product.country : product.countryEn || product.country;
  const taste = lang === "pl" ? product.sweetness || product.taste : product.tasteEn || product.taste;
  const draught = kind === "beer" && isArtDraughtBeer(product);
  const list = [...fromName];
  if (product.drinkVessel?.capacityMl) list.push(`${product.drinkVessel.capacityMl} ml`);
  if (attributes?.volume && !(draught && /butelk|bottle/i.test(attributes.volume))) list.push(attributes.volume);
  if (["wine", "whisky"].includes(kind) && country) list.push(country);
  if (kind === "wine" && taste) list.push(taste);
  if (kind === "beer") {
    const inferredBeerStyle = /guinness/i.test(product.pl) ? "Stout" : /bosman/i.test(product.pl) ? "Lager" : undefined;
    if (attributes?.beerStyle || inferredBeerStyle) list.push(attributes?.beerStyle || inferredBeerStyle as string);
  }
  if (draught) list.push(lang === "pl" ? "Z nalewaka" : "Draught");
  if (kind === "whisky" && attributes?.spiritType) list.push(attributes.spiritType);
  if (product.alcoholFree) list.push("0%");
  return Array.from(new Set(list.filter(item => Boolean(item) && !(draught && /butelk|bottle/i.test(item))))).slice(0, 4);
}

function cardShape(product: ArtCatalogProduct, kind: CatalogKind) {
  if (["cakes", "matcha", "cold"].includes(kind)) return kind === "cold" && !/lemoniad|sok|napar/i.test(product.pl) ? "is-circle is-small" : "is-circle";
  if (kind === "zero" && product.visualKind === "cocktails") return "is-rectangle is-cocktail";
  return `is-rectangle${kind === "cocktails" ? " is-cocktail" : ""}`;
}

function ArtCatalogCard<T extends ArtCatalogProduct>({ product, kind, lang, order, wave, onOpen, onAllergens, featured = false }: { product: T; kind: CatalogKind; lang: Lang; order: number; wave: number; onOpen: (product: T) => void; onAllergens?: (product: T) => void; featured?: boolean }) {
  const [failed, setFailed] = useState(false);
  const [burst, setBurst] = useState(0);
  useEffect(() => { if (!burst) return; const timer = window.setTimeout(() => setBurst(0), 760); return () => window.clearTimeout(timer); }, [burst]);
  const whisky = kind === "whisky" ? artWhiskyPresentation(product) : null;
  const genericPresentation = artCatalogPresentation(product[lang], lang);
  const presentation = whisky ? { name: lang === "pl" ? whisky.namePl : whisky.nameEn, parameters: [] } : genericPresentation;
  const mulledWine = kind === "wine" && isMulledWine(product);
  const productDescription = lang === "pl" ? product.descPl : product.descEn || product.descPl;
  const description = whisky ? (lang === "pl" ? whisky.notesPl : whisky.notesEn) : mulledWine ? productDescription : firstSentence(productDescription);
  const beerVariants = kind === "beer" ? product.beerVariants?.filter(variant => variant.capacity && hasGuestPrice(variant.price)) ?? [] : [];
  const params = (whisky ? [lang === "pl" ? whisky.origin : whisky.originEn, lang === "pl" ? whisky.type : whisky.typeEn] : parameters(product, kind, lang, presentation.parameters)).filter(parameter => !beerVariants.length || !/^\d+(?:[,.]\d+)?\s*(?:ml|cl|l)$/i.test(parameter)).filter(parameter => !(featured && kind === "beer" && /nalew|draught/i.test(parameter)));
  const wineStyle = kind === "wine" && !failed ? wineImageStyle(product.image) : undefined;
  const bottle = kind === "cocktails" && cocktailViewFor(product) === "shots";
  const prices = priceParts(product);
  const activate = () => { setBurst(value => value + 1); onOpen(product); };
  return <article className={`art-catalog-card ${cardShape(product, kind)}${mulledWine ? " is-mulled-wine" : ""}${bottle ? " is-bottle" : ""}${wineStyle ? " is-wine-bottle" : ""}${featured ? " is-featured" : ""}${kind === "beer" && /franziskaner|franciszkaner/i.test(product.pl) && !failed ? " is-franziskaner" : ""}`}>
    <button type="button" className="art-catalog-card-main" onClick={activate} aria-label={`${lang === "pl" ? "Zobacz szczegóły" : "View details"}: ${presentation.name}`}>
      <span className="art-catalog-visual">
        {kind === "beer" && String(product.id) === "261" && !failed && product.image ? <span className="art-beer-can-photo"><img src={product.image} alt={presentation.name} onError={() => setFailed(true)}/></span> : wineStyle ? <span className="art-wine-photo"><img src={product.image} style={wineStyle} alt={presentation.name} onError={() => setFailed(true)}/></span> : bottle ? <span className="art-bottle-photo"><img src={!failed && product.image ? product.image : menuArtAsset(product.visualKind || kind)} style={!failed && product.image ? bottleImageStyle(product.image) : undefined} alt={presentation.name} onError={() => setFailed(true)}/></span> : <img src={!failed && product.image ? product.image : menuArtAsset(product.visualKind || kind)} alt={presentation.name} onError={() => setFailed(true)}/>}
        <InfoBadge wave={wave} order={order}/>
        {product.alcoholFree ? <span className="art-price-bubble is-zero">0%</span> : null}
        {!beerVariants.length && prices.secondary && hasGuestPrice(prices.secondary) ? <span className="art-price-bubble is-secondary"><small>{prices.secondaryLabel}</small>{prices.secondary} zł</span> : null}
        {!beerVariants.length && prices.main && hasGuestPrice(prices.main) ? <span className="art-price-bubble is-primary">{prices.main} zł</span> : null}
        {beerVariants.length ? <span className="art-beer-variant-prices">{beerVariants.map((variant, index) => <span className={`${index === beerVariants.length - 1 ? "is-large" : "is-small"}${variant.available ? "" : " is-unavailable"}`} key={variant.productId}><small>{variant.capacity}</small><b>{variant.price} zł</b></span>)}</span> : null}
        <Burst token={burst}/>
      </span>
      <span className="art-catalog-copy">
        {featured && kind === "beer" ? <small>{lang === "pl" ? "Z nalewaka" : "Draught"}</small> : product.featured ? <small>{lang === "pl" ? "Polecamy" : "Featured"}</small> : product.guestChoice ? <small>{lang === "pl" ? "Wybór gości" : "Guests’ choice"}</small> : null}
        {product.productCode && kind !== "whisky" ? <b>{product.productCode}</b> : null}
        <strong>{presentation.name}</strong>
      <PromoLaunchNotice product={product} lang={lang}/>
        {params.length ? <span className="art-catalog-params">{params.join(" · ")}</span> : null}
        {whisky?.classLabel ? <span className="art-whisky-age">{whisky.classLabel}</span> : null}
        {description && kind !== "shelf" ? <em>{description}</em> : null}
      </span>
    </button>
    {kind === "cakes" && product.allergens?.length && onAllergens ? <button type="button" className="art-catalog-allergens" onClick={() => onAllergens(product)}>{lang === "pl" ? "Alergeny" : "Allergens"}</button> : null}
  </article>;
}

function Arrow({ back = false }: { back?: boolean }) {
  return <svg width="22" height="22" viewBox="0 0 22 22" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{back ? <path d="M17 11H5m5-5-5 5 5 5"/> : <path d="M5 17 17 5M8 5h9v9"/>}</svg>;
}

export default function ArtCatalogSection<T extends ArtCatalogProduct>({ kind, lang, title, lead, products, media, featuredProducts = [], featuredTitle, beforeSections, onOpenCakeStory, openWineCount = 0, finder, emptyState, alcoMode = "cocktails", onAlcoModeChange, afterSections, onOpen, onAllergens, onHome, onNext, nextLabel }: {
  kind: CatalogKind;
  lang: Lang;
  title: string;
  lead: string;
  products: T[];
  media?: ArtLoopMedia;
  featuredProducts?: T[];
  featuredTitle?: string;
  beforeSections?: ReactNode;
  onOpenCakeStory?: () => void;
  openWineCount?: number;
  finder?: ReactNode;
  alcoMode?: "cocktails" | "shots";
  onAlcoModeChange?: (mode: "cocktails" | "shots") => void;
  emptyState?: ReactNode;
  afterSections?: ReactNode;
  onOpen: (product: T) => void;
  onAllergens?: (product: T) => void;
  onHome: () => void;
  onNext?: () => void;
  nextLabel?: string;
}) {
  const L = (pl: string, en: string) => lang === "pl" ? pl : en;
  const [wave, setWave] = useState(-1);
  const [teaStoryOpen, setTeaStoryOpen] = useState(false);
  useEffect(() => { const first = window.setTimeout(() => setWave(0), 120); const timer = window.setInterval(() => setWave(value => value + 1), 15000); return () => { window.clearTimeout(first); window.clearInterval(timer); }; }, []);
  const visibleProducts = useMemo(() => kind !== "cocktails" ? products : products.filter(product => cocktailViewFor(product) === alcoMode), [alcoMode, kind, products]);
  const groups = useMemo(() => buildArtCatalogGroups(visibleProducts, kind, lang).map(group => kind === "beer" ? { ...group, products: combineBeerCards(group.products) } : group), [kind, lang, visibleProducts]);
  const visibleFeaturedProducts = useMemo(() => kind === "beer" ? combineBeerCards(featuredProducts) : featuredProducts, [featuredProducts, kind]);
  const shotFamilies = useMemo(() => {
    if (kind !== "cocktails" || alcoMode !== "shots") return [];
    const shotProducts = visibleProducts.filter(product => normalized(product.groupPl || product.groupEn || "").includes("shoty"));
    const order = lang === "pl" ? SHOT_FAMILY_ORDER_PL : SHOT_FAMILY_ORDER_EN;
    return order.map(title => ({ id: sectionId(`shot-${title}`), title, products: shotProducts.filter(product => shotFamily(product, lang) === title) })).filter(group => group.products.length);
  }, [alcoMode, kind, lang, visibleProducts]);
  const coldAddonGroupId = kind === "cold" ? groups.find(group => group.title === L("Robione u nas", "Made in house"))?.id : undefined;
  const offsets = useMemo(() => groups.map((_, index) => groups.slice(0, index).reduce((sum, group) => sum + group.products.length, 0)), [groups]);
  const scrollTo = (id: string) => document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
  return <section className={`art-section-page art-catalog-page art-compact-heading is-${kind}`}>
    <header className="art-section-hero"><div className="art-section-hero-copy"><small>Atelier café · {L("karta", "menu")}</small><div className="art-section-heading-row"><h1>{title}</h1><div className="art-section-hero-circle"><img src={menuArtAsset(kind)} alt=""/>{media ? <span><ArtLoopVideo media={media}/></span> : null}</div></div><p>{lead}</p>{kind === "cocktails" ? <div className="art-alco-mode" role="group" aria-label={L("Wybór alkoholi", "Alcoholic drinks view")}><button type="button" className={alcoMode === "cocktails" ? "is-active" : ""} aria-pressed={alcoMode === "cocktails"} onClick={() => onAlcoModeChange?.("cocktails")}>{L("Koktajle", "Cocktails")}</button><button type="button" className={alcoMode === "shots" ? "is-active" : ""} aria-pressed={alcoMode === "shots"} onClick={() => onAlcoModeChange?.("shots")}>{L("Shoty i butelki", "Shots and bottles")}</button></div> : null}{kind === "tea" && beforeSections ? <button type="button" className="art-tea-story-trigger" onClick={() => setTeaStoryOpen(true)}><span>{L("O naszych herbatach", "About our teas")}</span><img src="/menu-art/harney-sons-logo.png" alt="Harney & Sons"/></button> : null}{kind !== "cocktails" && kind !== "wine" ? <nav aria-label={L("Skróty do sekcji", "Section shortcuts")}>{visibleFeaturedProducts.length ? <button type="button" onClick={() => scrollTo("art-section-featured")}>{featuredTitle || L("Wybór Atelier", "Atelier selection")}</button> : null}{groups.map(group => <button type="button" key={group.id} onClick={() => scrollTo(group.id)}>{group.title}</button>)}</nav> : null}</div></header>
    {kind === "beer" ? finder : null}
    {visibleFeaturedProducts.length ? <section className="art-menu-featured art-catalog-featured" id="art-section-featured"><h2 className="art-menu-section-title">{featuredTitle || L("Wybór Atelier", "Atelier selection")}</h2><div>{visibleFeaturedProducts.map((product, index) => <ArtCatalogCard key={product.id ?? product.pl} product={product} kind={kind} lang={lang} order={index} wave={wave} onOpen={onOpen} onAllergens={onAllergens} featured/>)}</div></section> : null}
    {kind === "cakes" && beforeSections && onOpenCakeStory ? <button type="button" className="art-tea-story-trigger art-cake-story-trigger" onClick={onOpenCakeStory}><span>{L("Poznaj pracownię, z której przywozimy nasze wspaniałe ciasta", "Meet the bakery that makes our wonderful cakes")}</span><img src="/menu-art/capuccino-cafe-logo-na-jasne-tlo.png" alt="Capuccino Cafe"/></button> : null}
    {beforeSections && kind !== "tea" && kind !== "cakes" && kind !== "wine" ? <details className="art-category-options" key={`${kind}-intro`}><summary>{L("Poznaj naszą pracownię", "Meet our makers")}</summary>{beforeSections}</details> : null}
    {kind === "tea" && beforeSections ? <Dialog open={teaStoryOpen} onOpenChange={setTeaStoryOpen}><DialogContent className="art-tea-story-dialog" showCloseButton={false}><button type="button" className="art-event-dialog-close" onClick={() => setTeaStoryOpen(false)} aria-label={L("Zamknij", "Close")}>×</button><DialogTitle>{L("O naszych herbatach", "About our teas")}</DialogTitle><DialogDescription className="sr-only">{L("Poznaj markę Harney & Sons", "Meet Harney & Sons")}</DialogDescription>{beforeSections}</DialogContent></Dialog> : null}
    {kind !== "beer" ? finder : null}
    {kind === "wine" && beforeSections ? <details className="art-category-options art-open-wines" key="wine-intro"><summary className="art-wine-launch"><span className="art-wine-launch-copy"><small>{L("Wina na kieliszki", "Wines by the glass")}</small><span className="art-wine-launch-title">{L("Zobacz aktualnie otwarte butelki – wina dostępne na kieliszki", "Explore currently open bottles – wines available by the glass")}</span></span><span className="art-wine-launch-action"><span className="when-closed">{L("Zobacz wina", "View wines")}</span><span className="when-open">{L("Zwiń listę", "Hide wines")}</span><b>{openWineCount}</b></span></summary>{beforeSections}</details> : null}
    {!visibleFeaturedProducts.length && !groups.length ? emptyState : null}
    {groups.map((group, groupIndex) => <section className={`art-menu-product-section art-catalog-group is-${kind}`} id={group.id} key={group.id} aria-labelledby={`${group.id}-title`}><header className="art-catalog-group-title"><div><h2 className="art-menu-section-title" id={`${group.id}-title`}>{group.title}</h2>{kind === "whisky" && group.products[0] ? <p>{artWhiskySectionIntro(artWhiskyPresentation(group.products[0]).section, lang)}</p> : null}</div>{kind === "cakes" && group.products.some(product => product.cakePartner === "capuccino-cafe") ? <span>{L("z pracowni", "from the atelier")}<img src="/menu-art/capuccino-cafe-logo-na-jasne-tlo.png" alt="Capuccino Cafe"/></span> : null}</header>{kind === "cocktails" && alcoMode === "shots" && normalized(group.title).includes("shoty") ? <div className="art-shot-families">{shotFamilies.map((family, familyIndex) => <section id={family.id} key={family.id} aria-labelledby={`${family.id}-title`}><h3 id={`${family.id}-title`}>{family.title}</h3><div className="art-catalog-grid">{family.products.map((product, index) => <ArtCatalogCard key={product.id ?? product.pl} product={product} kind={kind} lang={lang} order={offsets[groupIndex] + familyIndex * 20 + index} wave={wave} onOpen={onOpen} onAllergens={onAllergens}/>)}</div></section>)}</div> : <div className="art-catalog-grid">{group.products.map((product, index) => <ArtCatalogCard key={product.id ?? product.pl} product={product} kind={kind} lang={lang} order={offsets[groupIndex] + index} wave={wave} onOpen={onOpen} onAllergens={onAllergens}/>)}</div>}{coldAddonGroupId === group.id ? afterSections : null}</section>)}
    {!coldAddonGroupId ? afterSections : null}
    <footer className="art-section-footer"><button type="button" onClick={onHome}><Arrow back/>{L("Start", "Home")}</button>{onNext && nextLabel ? <button type="button" onClick={onNext}><span><small>{L("Dalej", "Next")}</small><strong>{nextLabel}</strong></span><img src={menuArtAsset(kind === "cakes" ? "cocktails" : kind === "matcha" ? "tea" : kind === "tea" ? "cold" : kind === "cold" ? "food" : kind === "cocktails" ? "wine" : kind === "wine" ? "beer" : kind === "beer" ? "whisky" : kind === "whisky" ? "zero" : "shelf")} alt=""/></button> : null}</footer>
  </section>;
}
