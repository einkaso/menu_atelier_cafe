"use client";
import { useEffect, useRef, useState } from "react";
import type { ArtLoopMedia } from "../../lib/menu-art";

export const MAX_PLAYING_CATEGORY_LOOPS = 11;
type Loop = { visible: boolean; allowed: boolean; loaded: boolean; blocked: boolean; request: number; show: (value: boolean) => void };
const loops = new Map<HTMLVideoElement, Loop>();
let frame = 0;
function updatePlayback() {
  const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const distance = (video: HTMLVideoElement) => { const r = video.getBoundingClientRect(); return Math.abs(r.top + r.height / 2 - innerHeight / 2); };
  const selected = new Set([...loops].filter(([, e]) => e.visible && !e.blocked).sort(([a], [b]) => distance(a) - distance(b)).slice(0, MAX_PLAYING_CATEGORY_LOOPS).map(([v]) => v));
  for (const [video, entry] of loops) {
    const allowed = !reduced && !document.hidden && selected.has(video);
    if (!allowed) {
      if (entry.allowed) entry.request++; entry.allowed = false; if (!video.paused) video.pause();
      if (reduced && entry.loaded) { entry.show(false); video.querySelectorAll("source").forEach(s => s.removeAttribute("src")); video.load(); entry.loaded = false; }
      continue;
    }
    if (entry.allowed) continue;
    entry.allowed = true; video.muted = true; video.defaultMuted = true; video.setAttribute("muted", "");
    if (!entry.loaded) { video.querySelectorAll("source").forEach(s => { if(s.dataset.src)s.src = s.dataset.src; }); video.load(); entry.loaded = true; }
    const request = ++entry.request;
    const play = video.play();
    if (play) void play.catch(() => { if (entry.allowed && entry.request === request && loops.has(video)) { entry.blocked = true; entry.allowed = false; video.pause(); schedulePlayback(); } });
  }
}
function schedulePlayback() { if (!frame) frame = requestAnimationFrame(() => { frame = 0; updatePlayback(); }); }
export default function ArtLoopVideo({ media, alpha = false }: { media: ArtLoopMedia; alpha?: boolean }) {
  const video = useRef<HTMLVideoElement>(null);
  const [playing, setPlaying] = useState(false);
  useEffect(() => {
    const node = video.current; if (!node) return;
    const entry: Loop = { visible: typeof IntersectionObserver === "undefined", allowed: false, loaded: false, blocked: false, request: 0, show: setPlaying };
    loops.set(node, entry);
    const observer = typeof IntersectionObserver === "undefined" ? null : new IntersectionObserver(([intersection]) => { entry.visible = intersection.isIntersecting && intersection.intersectionRatio > 0; schedulePlayback(); }, { threshold: 0 });
    observer?.observe(node);
    // Safari may reject autoplay temporarily or suspend videos in its back/forward cache.
    // Retry only after a user gesture or when returning to the page, never in a rejection loop.
    const resume = () => {
      if(document.hidden)return;
      entry.blocked=false;
      if(node.error)return;
      if(node.paused)entry.allowed=false;
      updatePlayback();
    };
    document.addEventListener("pointerdown",resume);
    document.addEventListener("keydown",resume);
    document.addEventListener("visibilitychange",resume);
    window.addEventListener("pageshow",resume);
    schedulePlayback();
    const started = () => { if(entry.allowed) entry.show(true); else node.pause(); };
    const failed = () => { entry.blocked = true; entry.allowed = false; entry.show(false); node.pause(); schedulePlayback(); };
    node.addEventListener("playing", started); node.addEventListener("error", failed);
    const motion = window.matchMedia("(prefers-reduced-motion: reduce)");
    if (motion.addEventListener) motion.addEventListener("change", schedulePlayback); else motion.addListener(schedulePlayback);
    document.addEventListener("visibilitychange", schedulePlayback); window.addEventListener("scroll", schedulePlayback, { passive: true }); window.addEventListener("resize", schedulePlayback);
    return () => {
      document.removeEventListener("pointerdown",resume);document.removeEventListener("keydown",resume);document.removeEventListener("visibilitychange",resume);window.removeEventListener("pageshow",resume);
      observer?.disconnect(); loops.delete(node); node.pause(); node.querySelectorAll("source").forEach(s => s.removeAttribute("src")); node.load();
      node.removeEventListener("playing", started); node.removeEventListener("error", failed);
      if (motion.removeEventListener) motion.removeEventListener("change", schedulePlayback); else motion.removeListener(schedulePlayback);
      document.removeEventListener("visibilitychange", schedulePlayback); window.removeEventListener("scroll", schedulePlayback); window.removeEventListener("resize", schedulePlayback); schedulePlayback();
    };
  }, [media.mp4, media.webm, media.mov, alpha]);
  return <span className={`art-loop${alpha ? " is-alpha" : ""}${playing ? " is-playing" : ""}`}><video ref={video} muted loop playsInline preload="none" poster={media.poster} aria-hidden="true" tabIndex={-1} disablePictureInPicture>
    {alpha && (media.mov || media.mp4) && <source data-src={media.mov ?? media.mp4} type='video/mp4; codecs="hvc1"'/>}{alpha && media.webm && <source data-src={media.webm} type="video/webm"/>}{!alpha && media.mp4 && <source data-src={media.mp4} type="video/mp4"/>}{!alpha && media.webm && <source data-src={media.webm} type="video/webm"/>}
  </video><img className="art-loop-poster" src={media.poster} alt="" aria-hidden="true"/></span>;
}
