"use client";

import { useEffect, useMemo, useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogTitle } from "../ui/dialog";

import EventTicketAction from "./event-ticket-action";

type Lang = "pl" | "en";
export type ArtEvent = { id: string; title: string; titleEn: string; kind: string; kindEn: string; day: string; month: string; time: string; ticketUrl?: string };
type EventDetail = { descriptionPl: string; descriptionEn: string; image: string | null };
type ViewMode = "calendar" | "list";
type EventKind = "concert" | "theatre" | "meeting";

const MONTHS: Record<string, number> = { STY: 0, LUT: 1, MAR: 2, KWI: 3, MAJ: 4, CZE: 5, LIP: 6, SIE: 7, WRZ: 8, PAZ: 9, LIS: 10, GRU: 11 };
const KIND_ART: Record<EventKind, string> = { concert: "/menu-art/typ-koncert.jpg", theatre: "/menu-art/typ-spektakl.jpg", meeting: "/menu-art/typ-spotkanie.jpg" };

function normalizedToken(value: string) { return value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^A-Z]/gi, "").toUpperCase().slice(0, 3); }
function kindOf(value: string): EventKind { const key = value.toLocaleLowerCase("pl"); return key.includes("spektak") || key.includes("teatr") ? "theatre" : key.includes("koncert") ? "concert" : "meeting"; }
function kindLabel(kind: EventKind, lang: Lang) { return kind === "concert" ? (lang === "pl" ? "Koncert" : "Concert") : kind === "theatre" ? (lang === "pl" ? "Jazzowa sztuka teatralna" : "Jazz theatre") : (lang === "pl" ? "Spotkanie" : "Meeting"); }
// Keep spelling and letter case exactly as supplied by the website.
function cleanTitle(value: string) { return value; }
function seriesTitle(value: string) { return value.replace(/(?:\s*[·|–-]\s*)?\d{1,2}[./-]\d{1,2}(?:[./-]\d{2,4})?\s*$/u, "").trim().toLocaleLowerCase("pl"); }
function eventDate(event: ArtEvent, now: Date) {
  const month = MONTHS[normalizedToken(event.month)] ?? now.getMonth();
  const day = Number.parseInt(event.day, 10) || 1;
  let year = now.getFullYear();
  const candidate = new Date(year, month, day, 12);
  const yesterday = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1);
  if (candidate < yesterday) year += 1;
  return new Date(year, month, day, 12);
}
function keyOf(date: Date) { return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`; }
function monthKey(date: Date) { return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`; }
function sameDay(a: Date, b: Date) { return keyOf(a) === keyOf(b); }
function kindArt(event: ArtEvent) { return KIND_ART[kindOf(event.kind)]; }

function DateDisc({ event, size = "medium" }: { event: ArtEvent; size?: "small" | "medium" | "large" }) {
  return <span className={`art-event-disc is-${size}`} style={{ backgroundImage: `url(${kindArt(event)})` }}><span>{Number.parseInt(event.day, 10)}</span></span>;
}

function Arrow({ back = false }: { back?: boolean }) {
  return <svg aria-hidden="true" width="22" height="22" viewBox="0 0 22 22" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d={back ? "M17 5 5 17M14 17H5V8" : "M5 17 17 5M8 5h9v9"}/></svg>;
}

export default function ArtEventsPage({ lang, events, loading, unavailable, stale }: { lang: Lang; events: ArtEvent[]; loading: boolean; unavailable: boolean; stale: boolean }) {
  const L = (pl: string, en: string) => lang === "pl" ? pl : en;
  const now = useMemo(() => new Date(), []);
  const dated = useMemo(() => events.map((event) => ({ event, date: eventDate(event, now) })).sort((a, b) => a.date.getTime() - b.date.getTime() || a.event.time.localeCompare(b.event.time)), [events, now]);
  const [view, setView] = useState<ViewMode>("list");
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [visibleMonth, setVisibleMonth] = useState<Date | null>(null);
  const [detailsOpen, setDetailsOpen] = useState(false);
  const [detailCache, setDetailCache] = useState<Record<string, EventDetail>>({});
  const [detailFailures, setDetailFailures] = useState<Record<string, true>>({});
  const selected = dated.find(({ event }) => event.id === selectedId) ?? dated[0] ?? null;
  const detail = selected ? detailCache[selected.event.id] : undefined;
  const calendarMonth = visibleMonth ?? (dated[0] ? new Date(dated[0].date.getFullYear(), dated[0].date.getMonth(), 1) : new Date(now.getFullYear(), now.getMonth(), 1));

  useEffect(() => {
    if (!selected || detailCache[selected.event.id] || detailFailures[selected.event.id]) return;
    const controller = new AbortController();
    fetch(`/api/events/${encodeURIComponent(selected.event.id)}?menu-refresh=${Date.now()}`, { signal: controller.signal, cache: "no-store", headers: { "cache-control": "no-cache" } })
      .then(async (response) => { if (!response.ok) throw new Error("detail unavailable"); return response.json() as Promise<EventDetail>; })
      .then((body) => setDetailCache((current) => ({ ...current, [selected.event.id]: body })))
      .catch(() => { if (!controller.signal.aborted) setDetailFailures((current) => ({ ...current, [selected.event.id]: true })); });
    return () => controller.abort();
  }, [selected, detailCache, detailFailures]);

  const eventsByDay = useMemo(() => { const map = new Map<string, typeof dated>(); dated.forEach((item) => map.set(keyOf(item.date), [...(map.get(keyOf(item.date)) ?? []), item])); return map; }, [dated]);
  const eventMonths = useMemo(() => Array.from(new Map(dated.map((item) => [monthKey(item.date), { date: new Date(item.date.getFullYear(), item.date.getMonth(), 1), count: 0 }])).values()).map((item) => ({ ...item, count: dated.filter((entry) => monthKey(entry.date) === monthKey(item.date)).length })), [dated]);
  const selectedMonthEvents = dated.filter((item) => monthKey(item.date) === monthKey(calendarMonth));
  const calendarDays = useMemo(() => {
    const year = calendarMonth.getFullYear(); const month = calendarMonth.getMonth(); const count = new Date(year, month + 1, 0).getDate(); const offset = (new Date(year, month, 1).getDay() + 6) % 7;
    return [...Array.from({ length: offset }, () => null), ...Array.from({ length: count }, (_, index) => new Date(year, month, index + 1, 12))];
  }, [calendarMonth]);
  const groups = useMemo(() => { const map = new Map<string, typeof dated>(); dated.forEach((item) => map.set(monthKey(item.date), [...(map.get(monthKey(item.date)) ?? []), item])); return Array.from(map.values()); }, [dated]);
  const formatter = (options: Intl.DateTimeFormatOptions) => new Intl.DateTimeFormat(lang === "pl" ? "pl-PL" : "en-GB", options);
  const select = (item: typeof dated[number], open = false) => { setSelectedId(item.event.id); setVisibleMonth(new Date(item.date.getFullYear(), item.date.getMonth(), 1)); if (open) setDetailsOpen(true); };
  const detailLoading = Boolean(selected && !detail && !detailFailures[selected.event.id]);
  const detailUnavailable = Boolean(selected && detailFailures[selected.event.id]);
  const description = detailLoading ? L("Pobieramy opis wydarzenia…", "Loading event details…") : detailUnavailable ? L("Opis jest chwilowo niedostępny. Zapytaj obsługę o szczegóły wydarzenia.", "The description is temporarily unavailable. Ask our staff for details.") : detail ? (lang === "pl" ? detail.descriptionPl : detail.descriptionEn || detail.descriptionPl) : "";

  return <>
    <section className="art-events-page" aria-labelledby="art-events-title">
      <header className="art-events-hero"><div className="art-events-hero-copy"><small>ATELIER CAFÉ · {L("KALENDARZ", "CALENDAR")}</small><h1 id="art-events-title">{L("Nadchodzące wydarzenia", "Upcoming events")}</h1><p>{L("Koncerty, spektakle i spotkania. Dotknij wydarzenia, żeby poznać szczegóły.", "Concerts, performances and meetings. Tap an event to discover the details.")}</p></div><a href="/voucher" className="art-events-record art-concert-circle art-gift-circle" aria-label={L("Voucher na okazjonalny prezent — otwórz kreator", "Gift voucher — open the designer")}><i className="art-concert-wave"/><i className="art-concert-wave"/><img className="art-concert-record" src="/menu-art/kolo-koncerty.webp" alt=""/><span className="art-gift-circle-label"><small>VOUCHER</small><b>{L("na okazjonalny prezent", "for a special occasion")}</b><em>{L("Zaprojektuj prezent", "Design a gift")} ↗</em></span></a></header>
      <div className="art-events-toolbar"><div className="art-events-switch" role="group" aria-label={L("Widok wydarzeń", "Events view")}><button type="button" className={view === "calendar" ? "is-active" : ""} aria-pressed={view === "calendar"} onClick={() => setView("calendar")}><span>{L("Kalendarz", "Calendar")}</span><small className="art-calendar-coming-soon">* {L("w przygotowaniu", "in preparation")}</small></button><button type="button" className={view === "list" ? "is-active" : ""} aria-pressed={view === "list"} onClick={() => setView("list")}>{L("Lista", "List")}</button></div></div>
      {loading && !dated.length ? <div className="art-events-status" role="status">{L("Pobieramy aktualny kalendarz…", "Loading the current calendar…")}</div> : !dated.length ? <div className="art-events-status"><b>{L("Nie udało się teraz pobrać kalendarza.", "The calendar is temporarily unavailable.")}</b><span>{L("Zapytaj obsługę o aktualne wydarzenia.", "Ask our staff about current events.")}</span></div> : view === "calendar" ? <>
        <div className="art-events-monthbar"><div className="art-events-month-title"><button type="button" onClick={() => setVisibleMonth(new Date(calendarMonth.getFullYear(), calendarMonth.getMonth() - 1, 1))} aria-label={L("Poprzedni miesiąc", "Previous month")}><Arrow back/></button><h2>{formatter({ month: "long", year: "numeric" }).format(calendarMonth)}</h2><button type="button" onClick={() => setVisibleMonth(new Date(calendarMonth.getFullYear(), calendarMonth.getMonth() + 1, 1))} aria-label={L("Następny miesiąc", "Next month")}><Arrow/></button></div><nav aria-label={L("Miesiące z wydarzeniami", "Months with events")}>{eventMonths.map(({ date, count }) => <button type="button" key={monthKey(date)} className={monthKey(date) === monthKey(calendarMonth) ? "is-active" : ""} aria-current={monthKey(date) === monthKey(calendarMonth) ? "true" : undefined} onClick={() => setVisibleMonth(date)}><span>{formatter({ month: "long" }).format(date)}</span><b>{count}</b></button>)}</nav></div>
        <div className="art-events-calendar-layout"><div className="art-events-calendar"><div className="art-events-weekdays">{(lang === "pl" ? ["pon", "wt", "śr", "czw", "pt", "sob", "niedz"] : ["mon", "tue", "wed", "thu", "fri", "sat", "sun"]).map((day) => <span key={day}>{day}</span>)}</div><div className="art-events-days">{calendarDays.map((date, index) => {
          if (!date) return <span className="is-empty" key={`empty-${index}`}/>;
          const items = eventsByDay.get(keyOf(date)) ?? []; const today = sameDay(date, now); const past = date < new Date(now.getFullYear(), now.getMonth(), now.getDate()); const isSelected = selected ? sameDay(date, selected.date) : false;
          if (!items.length) return <span className={`art-events-day${past ? " is-past" : ""}${today ? " is-today" : ""}`} key={keyOf(date)}><span>{date.getDate()}</span>{today && <small>{L("dziś", "today")}</small>}</span>;
          const aria = items.map(({ event }) => `${event.time}, ${cleanTitle(lang === "pl" ? event.title : event.titleEn || event.title)}`).join("; ");
          return <button type="button" className={`art-events-day has-events${isSelected ? " is-selected" : ""}`} key={keyOf(date)} onClick={() => select(items[0])} aria-label={`${formatter({ weekday: "long", day: "numeric", month: "long" }).format(date)}, ${aria}`}><DateDisc event={items[0].event} size="small"/><span className="art-events-day-lines">{items.slice(0, 2).map(({ event }) => <span key={event.id}><b>{event.time}</b><em>{cleanTitle(lang === "pl" ? event.title : event.titleEn || event.title)}</em></span>)}{items.length > 2 && <strong>+{items.length - 2}</strong>}</span></button>;
        })}</div></div>
        <aside className="art-event-panel">{selectedMonthEvents.length && selected ? <><div className="art-event-panel-date"><DateDisc event={selected.event} size="large"/><div><small>{kindLabel(kindOf(selected.event.kind), lang)}</small><span>{formatter({ weekday: "long", day: "numeric", month: "long" }).format(selected.date)} · {selected.event.time}</span></div></div><h2>{cleanTitle(lang === "pl" ? selected.event.title : selected.event.titleEn || selected.event.title)}</h2>{description && <p>{description}</p>}<div className="art-event-panel-actions"><EventTicketAction event={selected.event} lang={lang}/><button type="button" onClick={() => setDetailsOpen(true)}>{L("Szczegóły", "Details")}</button></div>{dated.filter((item) => item.event.id !== selected.event.id && seriesTitle(item.event.title) === seriesTitle(selected.event.title)).length > 0 && <div className="art-event-next-dates"><small>{L("Kolejne terminy", "Next dates")}</small><div>{dated.filter((item) => item.event.id !== selected.event.id && seriesTitle(item.event.title) === seriesTitle(selected.event.title)).map((item) => <button type="button" key={item.event.id} onClick={() => select(item)}>{formatter({ day: "numeric", month: "long" }).format(item.date)}</button>)}</div></div>}</> : <div className="art-events-empty-month"><p>{L("W tym miesiącu nie ma jeszcze wydarzeń.", "There are no events in this month yet.")}</p>{dated[0] && <button type="button" onClick={() => select(dated[0])}>{L("Pokaż najbliższy miesiąc", "Show the nearest month")}</button>}</div>}</aside></div>
        <div className="art-events-legend"><span><i style={{ backgroundImage: `url(${KIND_ART.concert})` }}/> {kindLabel("concert", lang)}</span><span><i style={{ backgroundImage: `url(${KIND_ART.theatre})` }}/> {kindLabel("theatre", lang)}</span><span><i style={{ backgroundImage: `url(${KIND_ART.meeting})` }}/> {kindLabel("meeting", lang)}</span></div>
      </> : <div className="art-events-list">{groups.map((group) => <section key={monthKey(group[0].date)}><h2>{formatter({ month: "long", year: group[0].date.getFullYear() === now.getFullYear() ? undefined : "numeric" }).format(group[0].date)}</h2>{group.map((item) => <article key={item.event.id}><button type="button" className="art-event-list-main" onClick={() => select(item, true)} aria-label={`${L("Pokaż szczegóły", "Show details")}: ${cleanTitle(lang === "pl" ? item.event.title : item.event.titleEn || item.event.title)}`}><DateDisc event={item.event}/><span><small>{kindLabel(kindOf(item.event.kind), lang)}</small><b>{formatter({ weekday: "long" }).format(item.date)} · {item.event.time}</b><strong>{cleanTitle(lang === "pl" ? item.event.title : item.event.titleEn || item.event.title)}</strong></span></button><EventTicketAction event={item.event} lang={lang}/></article>)}</section>)}</div>}
      {(stale || unavailable) && dated.length > 0 && <p className="art-events-warning">{L("Pokazujemy ostatnio pobrany repertuar.", "Showing the most recently fetched programme.")}</p>}
    </section>
    <Dialog open={detailsOpen && Boolean(selected)} onOpenChange={setDetailsOpen}><DialogContent className="art-event-detail-dialog" showCloseButton={false}>{selected && <><button type="button" className="art-event-dialog-close" onClick={() => setDetailsOpen(false)} aria-label={L("Zamknij szczegóły", "Close details")}>×</button><div className="art-event-dialog-heading"><DateDisc event={selected.event} size="large"/><div><small>{kindLabel(kindOf(selected.event.kind), lang)}</small><DialogTitle>{cleanTitle(lang === "pl" ? selected.event.title : selected.event.titleEn || selected.event.title)}</DialogTitle><span>{formatter({ weekday: "long", day: "numeric", month: "long", year: "numeric" }).format(selected.date)} · {selected.event.time}</span></div></div><DialogDescription>{description}</DialogDescription><div className="art-event-dialog-actions"><EventTicketAction event={selected.event} lang={lang}/><button type="button" onClick={() => setDetailsOpen(false)}>{L("Wróć do wydarzeń", "Back to events")}</button></div></>}</DialogContent></Dialog>
  </>;
}
