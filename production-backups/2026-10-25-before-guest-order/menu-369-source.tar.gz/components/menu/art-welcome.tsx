"use client";

import { PromoLaunchNotice } from "./promo-launch-notice";
import { wineLabelStyle } from "../../lib/wine-framing";
import { bottleLabelStyle } from "../../lib/bottle-framing";
import { useEffect, useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogTitle } from "../ui/dialog";
import ArtLoopVideo from "./art-loop-video";
import { EMPTY_ART_MEDIA, hasGuestPrice, hostPeriod, menuArtAsset, type ArtMediaConfig, type MenuArtSection, type HostPeriod } from "../../lib/menu-art";

type Lang = "pl" | "en";
type Category = { id: string; pl: string; en: string; visualKind?: string };
type WelcomeProduct = { promo?: boolean; featured?: boolean; id?: number; pl: string; en: string; descPl: string; descEn: string; price: string; category: string; visualKind?: string; image?: string };
export const ART_WELCOME_CATEGORIES: Array<{ id: string; kind: MenuArtSection; pl: string; en: string; notePl: string; noteEn: string; small?: boolean }> = [
  { id: "coffee", kind: "coffee", pl: "Kawa", en: "Coffee", notePl: "Mały rytuał. Wielka przyjemność.", noteEn: "A little ritual. A great pleasure." },
  { id: "food", kind: "food", pl: "Na słono", en: "Savoury", notePl: "Coś dobrego na początek dnia.", noteEn: "Something lovely to start the day." },
  { id: "cakes", kind: "cakes", pl: "Na słodko", en: "Sweet", notePl: "Zawsze jest miejsce na deser.", noteEn: "There is always room for dessert." },
  { id: "matcha", kind: "matcha", pl: "Matcha", en: "Matcha", notePl: "Zielona chwila dla siebie.", noteEn: "A green moment just for you." },
  { id: "tea", kind: "tea", pl: "Herbata", en: "Tea", notePl: "Zaparz sobie spokojną chwilę.", noteEn: "Brew yourself a quiet moment." },
  { id: "cold", kind: "cold", pl: "Napoje", en: "Drinks", notePl: "Odrobina orzeźwienia.", noteEn: "A little refreshment." },
  { id: "wine", kind: "wine", pl: "Wino", en: "Wine", notePl: "Spotkajmy się przy kieliszku.", noteEn: "Let’s meet over a glass.", small: true },
  { id: "beer", kind: "beer", pl: "Piwo", en: "Beer", notePl: "Na lekki wieczór.", noteEn: "For an easy evening.", small: true },
  { id: "alco-bar", kind: "cocktails", pl: "Alkohole", en: "Alcoholic drinks", notePl: "Klasyki i nasze kompozycje.", noteEn: "Classics and our creations.", small: true },
  { id: "whisky", kind: "whisky", pl: "Whisky", en: "Whisky", notePl: "Od łagodnych po dymne.", noteEn: "From smooth to smoky.", small: true },
  { id: "zero", kind: "zero", pl: "Strefa 0%", en: "Alcohol-free", notePl: "Pełnia smaku, zero alkoholu.", noteEn: "All the flavour, no alcohol.", small: true },
];
export function artWelcomeCategoryId(categories: Category[], tile: { id: string; kind: string }) { return categories.find((category) => category.id === tile.id)?.id ?? categories.find((category) => category.visualKind === tile.kind)?.id; }
function Arrow() { return <svg width="22" height="22" viewBox="0 0 22 22" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M5 17 17 5M8 5h9v9"/></svg>; }
function ArtProductVisual({ image, kind }: { image?: string; kind: string }) {
  const [failedImage, setFailedImage] = useState<string | null>(null);
  const fallback = !image || image === failedImage;
  const labelStyle = !fallback ? wineLabelStyle(image) ?? bottleLabelStyle(image) : undefined;
  return <span className={`art-product-image${labelStyle ? " is-label-detail" : ""}${fallback ? " is-art-placeholder" : ""}`}><img style={labelStyle} src={fallback ? menuArtAsset(kind) : image} loading={labelStyle ? "eager" : "lazy"} alt="" onError={() => { if (image) setFailedImage(image); }}/></span>;
}
function Gallery({ lang, open, onOpenChange }: { lang: Lang; open: boolean; onOpenChange: (value: boolean) => void }) {
  return <Dialog open={open} onOpenChange={onOpenChange}><DialogContent className="art-gallery-dialog"><DialogTitle>{lang === "pl" ? "Sztuka w Atelier" : "Art at Atelier"}</DialogTitle><DialogDescription>Urszula Clarise, 2025 · {lang === "pl" ? "Obraz w Atelier" : "Art at Atelier"}</DialogDescription><img src="/atelier-watercolor.png" alt={lang === "pl" ? "Kolorowa abstrakcja w Atelier" : "Colourful abstract artwork at Atelier"}/></DialogContent></Dialog>;
}
export function ArtWelcomeHeader({ lang, onHome, onLanguage, onEvents, onLoyalty, onAbout }: { lang: Lang; onHome: () => void; onLanguage: () => void; onEvents: () => void; onLoyalty: () => void; onAbout?: () => void }) {
  const [galleryOpen, setGalleryOpen] = useState(false);
  const L = (pl: string, en: string) => lang === "pl" ? pl : en;
  return <header className="art-welcome-header"><button type="button" className="brand" onClick={onHome} aria-label={L("Wróć na początek", "Back to welcome")}><img src="/menu-art/logo-mb-atelier-cafe-czarne.svg" alt="Marta Banaszek atelier – café" width="216" height="68"/></button><div className="art-welcome-header-links">
    <a href="#art-welcome-host" onClick={onAbout ? (event) => { event.preventDefault(); onAbout(); } : undefined}>{L("O nas", "About us")}</a><button type="button" onClick={onEvents}>{L("Koncerty w Atelier", "Events at Atelier")}</button><button type="button" onClick={onLoyalty}>{L("Karta rabatowa", "MB Card")}</button><button type="button" onClick={() => setGalleryOpen(true)}>{L("Galeria sztuki", "Art gallery")}</button><button type="button" className="art-language" onClick={onLanguage} aria-label={L("Przełącz na angielski", "Switch to Polish")}>{lang === "pl" ? "EN" : "PL"}</button>
  </div><Gallery lang={lang} open={galleryOpen} onOpenChange={setGalleryOpen}/></header>;
}
export function ArtWelcome<T extends WelcomeProduct>({ lang, categories, go, promos, onOpen, onChristmas, reviewUrl, reviewQr, media = EMPTY_ART_MEDIA }: { lang: Lang; categories: Category[]; go: (id: string) => void; promos: T[]; onOpen: (product: T) => void; onChristmas: () => void; reviewUrl?: string; reviewQr?: string; media?: ArtMediaConfig }) {
  const L = (pl: string, en: string) => lang === "pl" ? pl : en;
  const [period, setPeriod] = useState<HostPeriod>("rano");
  const [galleryOpen, setGalleryOpen] = useState(false);
  useEffect(() => { const update = () => setPeriod(hostPeriod(new Date())); update(); const timer = window.setInterval(update, 60000); return () => window.clearInterval(timer); }, []);
  const available = ART_WELCOME_CATEGORIES.flatMap((tile) => { const target = artWelcomeCategoryId(categories, tile); return target ? [{ ...tile, target }] : []; });
  const renderTile = (tile: typeof available[number]) => <button className={`art-category is-${tile.kind}`} type="button" key={tile.id} onClick={() => go(tile.target)}><span className="art-category-circle"><img className="art-category-fragment" src={menuArtAsset(tile.kind)} width="1000" height="1000" alt=""/>{media.categories[tile.kind] && <span className="art-category-media"><ArtLoopVideo media={media.categories[tile.kind]!}/></span>}</span><strong>{tile[lang]}</strong></button>;
  const hostMedia = media.host[period];
  return <section className="art-welcome" aria-label={L("Wybierz dział menu", "Choose a menu section")}><h1 className="art-sr-only">{L("Na co masz dziś ochotę?", "What are you in the mood for?")}</h1>
    <div className="art-categories"><div className="art-category-grid">{available.filter((tile) => !tile.small).map(renderTile)}</div>{available.some((tile) => tile.small) && <div className={`art-category-grid is-evening${available.filter((tile) => tile.small).length === 5 ? " is-five" : ""}`}>{available.filter((tile) => tile.small).map(renderTile)}</div>}</div>
    <section className="art-host" id="art-welcome-host" aria-labelledby="art-host-title"><div className="art-host-main"><div className="art-host-circle"><img className="art-host-fragment" src="/menu-art/ramka-marta.webp" alt="" width="1000" height="1000"/>{hostMedia ? <ArtLoopVideo media={hostMedia} alpha/> : <img className="art-host-photo" src="/marta-banaszek.png" alt={L("Marta Banaszek — gospodyni Atelier Café", "Marta Banaszek — your Atelier Café host")}/>}</div><div className="art-host-copy"><span>{L("Gospodyni miejsca", "Your host")}</span><h2 id="art-host-title">{period === "rano" ? L("Dzień dobry. Kawa już czeka.", "Hello there. Coffee is waiting.") : L("Rozgość się. Jesteś u siebie.", "Make yourself at home.")}</h2><p>{L("Marta Banaszek, projektantka i gospodyni tego miejsca.", "Marta Banaszek, designer and host of this place.")}</p></div></div>
    <div className="art-event-links"><div className="art-event-small"><button type="button" onClick={() => go("events")}><img src="/menu-art/akcent-wydarzenie.webp" width="62" height="62" alt=""/><span><strong>{L("Twoje wydarzenie u nas", "Your event at Atelier")}</strong><Arrow/></span></button><button type="button" onClick={onChristmas}><img src="/menu-art/akcent-swieta.webp" width="44" height="44" alt=""/><span><strong>{L("Oferta świąteczna", "Christmas selection")}</strong><Arrow/></span></button></div><button type="button" className="is-concerts" onClick={() => go("events")} aria-label={L("Koncerty i wydarzenia — przejdź do wydarzeń", "Concerts and events — view events")}><span className="art-concert-circle art-gift-circle"><i className="art-concert-wave"/><i className="art-concert-wave"/><img className="art-concert-record" src="/menu-art/kolo-koncerty.webp" alt="" width="190" height="190"/><span className="art-gift-circle-label"><small>VOUCHER</small><b>{L("na okazjonalny prezent", "for a special occasion")}</b></span></span><span><strong>{L("Koncerty & wydarzenia", "Concerts & events")}</strong><Arrow/></span></button></div></section>
    {promos.length > 0 && <section className="art-recommendations" aria-labelledby="art-recommendations-title"><div className="art-recommendations-heading"><svg width="60" height="52" viewBox="0 0 60 52" fill="none" stroke="#FE0505" strokeWidth="4" strokeLinecap="round" aria-hidden="true"><path d="M56 48 4 34M56 48 16 10M56 48 42 3"/></svg><h2 id="art-recommendations-title">{L("Polecamy dziś", "Today’s selection")}</h2><p>{L("wybraliśmy na dziś", "chosen just for today")}</p></div><div className="art-product-grid">{promos.map((product) => <button type="button" className="art-product" key={product.id ?? `${product.category}-${product.pl}`} onClick={() => onOpen(product)}><ArtProductVisual image={product.image} kind={product.visualKind ?? categories.find((category) => category.id === product.category)?.visualKind ?? product.category}/><small>{categories.find((category) => category.id === product.category)?.[lang] ?? L("Nasz wybór", "Our selection")}</small><h3>{product[lang]}</h3><p>{lang === "pl" ? product.descPl : product.descEn}</p><PromoLaunchNotice product={product} lang={lang}/>{hasGuestPrice(product.price) && <b>{product.price} zł</b>}</button>)}</div></section>}
    <div className="art-colophon"><button type="button" className="art-artwork-credit" onClick={() => setGalleryOpen(true)}><img src={menuArtAsset("cakes")} width="56" height="56" alt=""/><span><small>{L("Obraz w Atelier", "Art at Atelier")}</small><em>Urszula Clarise, 2025 · {L("Galeria sztuki", "Art gallery")}</em></span></button>{reviewUrl && <a className="art-review" href={reviewUrl} target="_blank" rel="noopener noreferrer"><span><strong>{L("Oceń nas na Google", "Review us on Google")}</strong>{reviewQr && <em>{L("Zeskanuj kod telefonem", "Scan with your phone")}</em>}</span>{reviewQr && <img src={reviewQr} width="104" height="104" alt={L("Kod QR do opinii Google", "QR code for a Google review")}/>}</a>}</div><Gallery lang={lang} open={galleryOpen} onOpenChange={setGalleryOpen}/>
  </section>;
}
