import { isUpcomingPromo } from "../../lib/promo-launch";
export function PromoLaunchNotice({ product, lang }: { product: Parameters<typeof isUpcomingPromo>[0]; lang: "pl" | "en" }) {
  return isUpcomingPromo(product) ? <span className="promo-launch-notice">{lang === "pl" ? "Nowość / od piątku w ofercie" : "New / available from Friday"}</span> : null;
}
