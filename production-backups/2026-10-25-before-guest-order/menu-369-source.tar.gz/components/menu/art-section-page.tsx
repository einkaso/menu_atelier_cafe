"use client";

import { PromoLaunchNotice } from "./promo-launch-notice";
import { type CSSProperties, type ReactNode, useEffect, useMemo, useRef, useState } from "react";
import { isGenericFlavorSyrupOption } from "../../lib/flavor-syrups";
import { hasGuestPrice, menuArtAsset, type ArtLoopMedia, type MenuArtSection } from "../../lib/menu-art";
import ArtLoopVideo from "./art-loop-video";

export type ArtSectionProduct = {
  id?: number;
  pl: string;
  en: string;
  descPl: string;
  descEn: string;
  price: string;
  image?: string;
  source?: string;
  featured?: boolean;
  promo?: boolean;
  guestChoice?: boolean;
  groupPl?: string;
  groupEn?: string;
  drinkVessel?: { capacityMl: number };
  temperatures?: Array<"warm" | "cold">;
  espressoShots?: 0 | 1 | 2;
  alcoholMarker?: boolean;
};

export type ArtSectionGroup<T extends ArtSectionProduct> = { id: string; title: string; products: T[] };

type Lang = "pl" | "en";
type SectionKind = Extract<MenuArtSection, "coffee" | "food">;
type BurstStyle = CSSProperties & Record<`--${string}`, string | number>;

const FLOURISHES = ["fala", "kreska", "kropka", "listek", "pierscien", "spirala", "trojkat"];
const BURST_COLORS = ["#FC0AB9", "#FB5925", "#0145BD", "#01AEE8", "#A5E0E1", "#FE0505", "#8E1C86"];

function keyFor(product: ArtSectionProduct, index: number) {
  return String(product.id ?? `${product.pl}-${index}`);
}

function sectionId(value: string) {
  return `art-section-${value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLocaleLowerCase("pl").replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "")}`;
}

function sentenceCase(value: string, lang: Lang) {
  const trimmed = value.trim();
  if (!trimmed || trimmed !== trimmed.toLocaleUpperCase(lang === "pl" ? "pl" : "en")) return trimmed;
  const lower = trimmed.toLocaleLowerCase(lang === "pl" ? "pl" : "en");
  return lower.charAt(0).toLocaleUpperCase(lang === "pl" ? "pl" : "en") + lower.slice(1);
}

function firstSentence(value: string) {
  const trimmed = value.trim();
  const match = trimmed.match(/^.*?[.!?](?=\s|$)/);
  return match?.[0] ?? trimmed;
}

function foodGroup(name: string, lang: Lang) {
  const normalized = name.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLocaleLowerCase("pl").replace(/ł/g, "l");
  if (/kanapk/.test(normalized)) return lang === "pl" ? "Kanapki" : "Sandwiches";
  if (/salat|salad/.test(normalized)) return lang === "pl" ? "Sałaty" : "Salads";
  if (/talerz|plate/.test(normalized)) return lang === "pl" ? "Talerzyki" : "Small plates";
  return lang === "pl" ? "Idealne na śniadanie" : "Perfect for breakfast";
}

export function buildArtSections<T extends ArtSectionProduct>(products: T[], kind: SectionKind, lang: Lang) {
  const ordered = new Map<string, T[]>();
  const foodOrder = lang === "pl" ? ["Kanapki", "Sałaty", "Talerzyki", "Idealne na śniadanie"] : ["Sandwiches", "Salads", "Small plates", "Perfect for breakfast"];
  for (const product of products) {
    const title = kind === "food"
      ? foodGroup(product[lang], lang)
      : ((lang === "pl" ? product.groupPl : product.groupEn || product.groupPl) || (lang === "pl" ? "Kawy" : "Coffee"));
    const group = ordered.get(title) ?? [];
    group.push(product);
    ordered.set(title, group);
  }
  const entries = [...ordered.entries()];
  if (kind === "food") entries.sort((a, b) => foodOrder.indexOf(a[0]) - foodOrder.indexOf(b[0]));
  return entries.map(([title, group]) => ({ id: sectionId(title), title, products: group }));
}

function foodPresentation(name: string, lang: Lang) {
  const note = name.match(/\(([^)]+)\)/)?.[1]?.trim();
  const grams = name.match(/(?:^|\s)(\d+)\s*g\b/i)?.[1];
  const clean = name.replace(/\s*\([^)]+\)\s*/g, " ").replace(/(?:^|\s)\d+\s*g\b/gi, " ").replace(/\s+/g, " ").trim();
  return {
    name: sentenceCase(clean, lang),
    params: [grams ? `${grams} g` : "", note ?? ""].filter(Boolean),
  };
}

function Price({ value }: { value: string }) {
  if (!hasGuestPrice(value)) return null;
  return <span className="art-menu-card-price">{value}{/zł/i.test(value) ? "" : " zł"}</span>;
}

function Arrow({ back = false }: { back?: boolean }) {
  return <svg width="22" height="22" viewBox="0 0 22 22" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{back ? <path d="M17 11H5m5-5-5 5 5 5"/> : <path d="M5 17 17 5M8 5h9v9"/>}</svg>;
}

function InfoBadge({ wave, order }: { wave: number; order: number }) {
  const ref = useRef<HTMLSpanElement>(null);
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const element = ref.current;
    if (!element || typeof IntersectionObserver === "undefined") { setVisible(true); return; }
    const observer = new IntersectionObserver(([entry]) => setVisible(entry.isIntersecting), { threshold: .55 });
    observer.observe(element);
    return () => observer.disconnect();
  }, []);
  const style = visible && wave >= 0 ? { animationName: wave % 2 ? "art-info-pulse-a" : "art-info-pulse-b", animationDelay: `${(order % 10) * 110}ms` } : undefined;
  return <span ref={ref} className="art-menu-info" style={style} aria-hidden="true">i</span>;
}

function Burst({ token }: { token: number }) {
  if (!token) return null;
  return <span className="art-menu-burst" aria-hidden="true">{Array.from({ length: 16 }, (_, index) => {
    const angle = ((index * 137.5 + token * 17) % 360) * Math.PI / 180;
    const distance = 150 + (index % 5) * 19;
    const style: BurstStyle = {
      "--burst-x": `${Math.cos(angle) * distance}px`,
      "--burst-y": `${Math.sin(angle) * distance}px`,
      "--burst-r": `${140 + (index % 6) * 32}deg`,
      "--burst-size": `${20 + (index % 5) * 3}px`,
      "--burst-delay": `${(index % 4) * 18}ms`,
      "--burst-color": BURST_COLORS[index % BURST_COLORS.length],
      "--burst-mask": `url("/menu-art/flourishes/${FLOURISHES[index % FLOURISHES.length]}.svg")`,
    };
    return <i key={`${token}-${index}`} style={style}/>;
  })}</span>;
}

function ProductParams({ product, kind, foodParams, lang }: { product: ArtSectionProduct; kind: SectionKind; foodParams: string[]; lang: Lang }) {
  if (kind === "food") return foodParams.length ? <div className="art-menu-card-params">{foodParams.map(value => <span key={value}>{value}</span>)}</div> : null;
  const shots = product.espressoShots;
  return <div className="art-menu-card-params">
    {product.drinkVessel?.capacityMl ? <span>{product.drinkVessel.capacityMl} ml</span> : null}
    {shots !== undefined ? <span className="art-menu-espresso"><i>{Array.from({ length: Math.max(0, shots) }, (_, index) => <b key={index}/>)}</i>{shots === 0 ? (lang === "pl" ? "bez kawy" : "no coffee") : `${shots} espresso`}</span> : null}
    {(product.temperatures ?? []).map(temperature => <span className={`art-menu-temperature is-${temperature}`} key={temperature}><img src={`/menu-art/icons/${temperature === "warm" ? "na-cieplo" : "na-zimno"}.svg`} alt=""/>{temperature === "warm" ? (lang === "pl" ? "na ciepło" : "warm") : (lang === "pl" ? "na zimno" : "cold")}</span>)}
    {product.alcoholMarker ? <span className="is-alcohol">{lang === "pl" ? "z alkoholem" : "contains alcohol"}</span> : null}
  </div>;
}

function ArtProductCard<T extends ArtSectionProduct>({ product, kind, lang, order, wave, onOpen, onAllergens, featured = false }: { product: T; kind: SectionKind; lang: Lang; order: number; wave: number; onOpen: (product: T) => void; onAllergens?: (product: T) => void; featured?: boolean }) {
  const [failedImage, setFailedImage] = useState<string | null>(null);
  const [burst, setBurst] = useState(0);
  useEffect(() => { if (!burst) return; const timer = window.setTimeout(() => setBurst(0), 760); return () => window.clearTimeout(timer); }, [burst]);
  const fallback = `/menu-art/fallback/${kind}/${order % 5 + 1}.jpg`;
  const image = product.image && product.image !== failedImage ? product.image : fallback;
  const food = kind === "food" ? foodPresentation(product[lang], lang) : { name: product[lang], params: [] as string[] };
  const description = firstSentence(lang === "pl" ? product.descPl : product.descEn || product.descPl);
  const activate = () => { setBurst(value => value + 1); onOpen(product); };
  return <article className={`art-menu-card${featured ? " is-featured" : ""}`} role="button" tabIndex={0} onClick={activate} onKeyDown={event => { if (event.key === "Enter" || event.key === " ") { event.preventDefault(); activate(); } }}>
    <div className="art-menu-card-visual">
      {product.id === 7 && image === product.image ? <span className="art-menu-latte-crop"><img src={image} alt={food.name} onError={() => setFailedImage(image)}/></span> : <img src={image} alt={food.name} onError={() => { if (product.image) setFailedImage(product.image); }}/>}
      <InfoBadge wave={wave} order={order}/><Price value={product.price}/><Burst token={burst}/>
    </div>
    <div className="art-menu-card-copy">
      {product.featured ? <small>{lang === "pl" ? "Polecamy" : "Featured"}</small> : product.guestChoice ? <small>{lang === "pl" ? "Wybór gości" : "Guests’ choice"}</small> : null}
      <h3>{food.name}</h3>
      <PromoLaunchNotice product={product} lang={lang}/>
      <ProductParams product={product} kind={kind} foodParams={food.params} lang={lang}/>
      {description ? <p>{description}</p> : null}
      {kind === "food" && onAllergens && <button type="button" className="art-catalog-allergens" onClick={event=>{event.stopPropagation();onAllergens(product)}} onKeyDown={event=>event.stopPropagation()}>{lang === "pl" ? "Skład i alergeny" : "Ingredients and allergens"}</button>}
    </div>
  </article>;
}

function SectionHeader({ title, id }: { title: string; id: string }) {
  return <h2 className="art-menu-section-title" id={id}>{title}</h2>;
}

export function ArtMentorCard({ lang, onOpen }: { lang: Lang; onOpen: () => void }) {
  const L = (pl: string, en: string) => lang === "pl" ? pl : en;
  return <aside className="art-menu-mentor">
    <span className="art-menu-mentor-portrait"><img src="/menu-art/ramka-mentor.jpg" alt=""/><img src="https://andrzejandrzejczak.pl/images/andrzej-z-miesem.jpg" alt="Andrzej Andrzejczak – Dr Meat"/></span>
    <div><small>{L("Mentor kulinarny Atelier", "Atelier culinary mentor")}</small><h2>{L("Autor receptur i opiekun naszej karty", "Recipe creator and guide to our menu")}</h2><p>{L("Andrzej Andrzejczak, znany jako Dr Meat, stworzył nasze receptury, wspiera zespół i czuwa nad kierunkiem kuchni Atelier.", "Andrzej Andrzejczak, known as Dr Meat, created our recipes, supports the team and guides the culinary direction of Atelier.")}</p><button type="button" onClick={onOpen}>{L("Poznaj mentora kulinarnego Atelier", "Meet Atelier’s culinary mentor")} <Arrow/></button></div>
  </aside>;
}

export type ArtCoffeeAddon = { id: string; pl: string; en: string; price: string };

function addonGroup(value: string) {
  const normalized = value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLocaleLowerCase("pl");
  if (/mlek|owsian|migdal|sojow|kokos|laktoz|oat|almond|soy|coconut|lactose/.test(normalized)) return "milk";
  if (/espresso|bezkof|dcaf|decaf/.test(normalized)) return "strength";
  return "extras";
}

function addonName(value: string) {
  return value.replace(/^(zmiana|zamiana)\s+mleka\s+na\s+/i, "").replace(/^mleko\s+/i, "").trim();
}

export function ArtCoffeeAddons({ options, lang, onSyrups }: { options: ArtCoffeeAddon[]; lang: Lang; onSyrups?: () => void }) {
  const L = (pl: string, en: string) => lang === "pl" ? pl : en;
  const groups = [
    { id: "milk", label: L("Mleko", "Milk") },
    { id: "strength", label: L("Moc", "Strength") },
    { id: "extras", label: L("Dodatki", "Extras") },
  ].map(group => ({ ...group, options: options.filter(option => addonGroup(option.pl) === group.id) })).filter(group => group.options.length);
  return <aside className="art-coffee-addons"><div><small>{L("Dopasuj swoją kawę", "Make it yours")}</small><h2>{L("Mleko, moc, dodatki", "Milk, strength, extras")}</h2></div><div className="art-coffee-addon-groups">{groups.map(group => <section key={group.id}><h3>{group.label}</h3><div>{group.options.map(option => {
    const syrup = isGenericFlavorSyrupOption(option.pl) && onSyrups;
    const content = <><span>{addonName(option[lang])}</span>{syrup ? <em>{L("wybierz smak", "choose a flavour")}</em> : null}<strong>{option.price}{/\d/.test(option.price) && !/zł/i.test(option.price) ? " zł" : ""}</strong></>;
    return syrup ? <button type="button" key={option.id} onClick={onSyrups}>{content}</button> : <span className="art-coffee-addon" key={option.id}>{content}</span>;
  })}</div></section>)}</div></aside>;
}

export function ArtTakeHome<T extends ArtSectionProduct>({ products, lang, onOpen }: { products: T[]; lang: Lang; onOpen: (product: T) => void }) {
  const L = (pl: string, en: string) => lang === "pl" ? pl : en;
  return <section className="art-take-home"><header><small>{L("Z naszej półki", "From our shelf")}</small><h2>{L("Zabierz naszą kawę do domu", "Take our coffee home")}</h2><p>{L("Ziarna, które możesz kupić na miejscu.", "Coffee beans available to buy in the café.")}</p></header><div>{products.map((product, index) => <button type="button" key={keyFor(product, index)} onClick={() => onOpen(product)}>{product.image ? <img src={product.image} alt={product[lang]}/> : <img className="is-fallback" src={`/menu-art/fallback/coffee/${index % 5 + 1}.jpg`} alt=""/>}<span><strong>{product[lang]}</strong><em>{firstSentence(lang === "pl" ? product.descPl : product.descEn || product.descPl)}</em><small>{L("Zobacz kawę i pełny opis", "See the coffee and full description")} <Arrow/></small></span>{hasGuestPrice(product.price) ? <b>{product.price}{/zł/i.test(product.price) ? "" : " zł"}</b> : null}</button>)}</div></section>;
}

export default function ArtSectionPage<T extends ArtSectionProduct>({ kind, lang, title, lead, sections, media, featuredProducts = [], featuredTitle, betweenFeaturedAndSections, afterSections, extraShortcuts = [], onOpen, onAllergens, onHome, onNext, nextLabel }: {
  kind: SectionKind;
  lang: Lang;
  title: string;
  lead: string;
  sections: ArtSectionGroup<T>[];
  media?: ArtLoopMedia;
  featuredProducts?: T[];
  featuredTitle?: string;
  betweenFeaturedAndSections?: ReactNode;
  afterSections?: ReactNode;
  extraShortcuts?: Array<{ id: string; label: string }>;
  onOpen: (product: T) => void;
  onAllergens?: (product: T) => void;
  onHome: () => void;
  onNext: () => void;
  nextLabel: string;
}) {
  const L = (pl: string, en: string) => lang === "pl" ? pl : en;
  const [wave, setWave] = useState(-1);
  useEffect(() => { const first = window.setTimeout(() => setWave(0), 120); const timer = window.setInterval(() => setWave(value => value + 1), 15000); return () => { window.clearTimeout(first); window.clearInterval(timer); }; }, []);
  const offsets = useMemo(() => sections.map((_, index) => sections.slice(0, index).reduce((sum, section) => sum + section.products.length, 0)), [sections]);
  const shortcuts = [...(featuredProducts.length ? [{ id: "art-section-featured", label: featuredTitle ?? L("Wybór Atelier", "Atelier selection") }] : []), ...sections.map(section => ({ id: section.id, label: section.title })), ...extraShortcuts];
  const scrollTo = (id: string) => document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
  return <section className={`art-section-page art-compact-heading is-${kind}`}>
    <header className="art-section-hero"><div className="art-section-hero-copy"><small>Atelier café · {L("karta", "menu")}</small><div className="art-section-heading-row"><h1>{title}</h1><div className="art-section-hero-circle"><img src={menuArtAsset(kind)} alt=""/>{media ? <span><ArtLoopVideo media={media}/></span> : null}</div></div><p>{lead}</p><nav aria-label={L("Skróty do sekcji", "Section shortcuts")}>{shortcuts.map(shortcut => <button type="button" key={shortcut.id} onClick={() => scrollTo(shortcut.id)}>{shortcut.label}</button>)}</nav></div></header>
    {featuredProducts.length ? <section className="art-menu-featured" id="art-section-featured"><SectionHeader id="art-section-featured-title" title={featuredTitle ?? L("Wybór Atelier", "Atelier selection")}/><div>{featuredProducts.map((product, index) => <ArtProductCard key={keyFor(product, index)} product={product} kind={kind} lang={lang} order={index} wave={wave} onOpen={onOpen} onAllergens={onAllergens} featured/>)}</div></section> : null}
    {betweenFeaturedAndSections}
    {sections.map((section, sectionIndex) => <section className="art-menu-product-section" id={section.id} key={section.id} aria-labelledby={`${section.id}-title`}><SectionHeader id={`${section.id}-title`} title={section.title}/><div className="art-menu-product-grid">{section.products.map((product, index) => <ArtProductCard key={keyFor(product, index)} product={product} kind={kind} lang={lang} order={offsets[sectionIndex] + index} wave={wave} onOpen={onOpen} onAllergens={onAllergens}/>)}</div></section>)}
    {afterSections}
    <footer className="art-section-footer"><button type="button" onClick={onHome}><Arrow back/>{L("Start", "Home")}</button><button type="button" onClick={onNext}><span><small>{L("Dalej", "Next")}</small><strong>{nextLabel}</strong></span><img src={menuArtAsset(kind === "coffee" ? "matcha" : "cakes")} alt=""/></button></footer>
  </section>;
}
