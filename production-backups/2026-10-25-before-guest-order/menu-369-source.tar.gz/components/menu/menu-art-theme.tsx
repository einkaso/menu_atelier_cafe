"use client";
import { useEffect } from "react";
import { menuArtAsset } from "../../lib/menu-art";

export default function MenuArtTheme({ enabled, sectionKind = "coffee" }: { enabled: boolean; sectionKind?: string }) {
  useEffect(() => {
    if (!enabled) return;
    const root = document.documentElement;
    const previous = root.getAttribute("data-menu-theme");
    const theme = document.querySelector<HTMLMetaElement>('meta[name="theme-color"]');
    const previousColor = theme?.content;
    root.setAttribute("data-menu-theme", "art"); if (theme) theme.content = "#F1F4F4";
    return () => { if (previous === null) root.removeAttribute("data-menu-theme"); else root.setAttribute("data-menu-theme", previous); if (theme && previousColor) theme.content = previousColor; };
  }, [enabled]);
  useEffect(() => {
    if (!enabled) return;
    const root = document.documentElement;
    const previous = root.style.getPropertyValue("--menu-section-art");
    root.style.setProperty("--menu-section-art", `url("${menuArtAsset(sectionKind)}")`);
    return () => { if (previous) root.style.setProperty("--menu-section-art", previous); else root.style.removeProperty("--menu-section-art"); };
  }, [enabled, sectionKind]);
  return null;
}
