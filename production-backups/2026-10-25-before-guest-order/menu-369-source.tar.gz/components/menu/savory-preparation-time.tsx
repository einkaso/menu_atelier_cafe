"use client";
import {useEffect, useState} from "react";
export default function SavoryPreparationTime({lang, compact = false}: {lang: "pl" | "en"; compact?: boolean}) {
 const pl = lang === "pl";
 const [estimate,setEstimate]=useState({minutes:15,live:false});
 useEffect(()=>{
  let stopped=false; let active:AbortController|null=null;
  const refresh=async()=>{
   if(active || document.hidden)return;
   const controller=new AbortController();active=controller;
   const timeout=window.setTimeout(()=>controller.abort(),8000);
   try{const response=await fetch('/api/menu/preparation-time',{cache:'no-store',signal:controller.signal});if(!response.ok)throw new Error('Unavailable');const data=await response.json();if(!Number.isInteger(data.minutes)||data.minutes<15||data.minutes%5!==0||typeof data.live!=='boolean')throw new Error('Invalid estimate');if(!stopped)setEstimate({minutes:data.live?data.minutes:15,live:data.live});}
   catch{if(!stopped)setEstimate({minutes:15,live:false});}
   finally{window.clearTimeout(timeout);active=null;}
  };
  void refresh();const timer=window.setInterval(()=>void refresh(),30_000);
  const onVisible=()=>{if(!document.hidden)void refresh();};document.addEventListener('visibilitychange',onVisible);
  return()=>{stopped=true;window.clearInterval(timer);active?.abort();document.removeEventListener('visibilitychange',onVisible);};
 },[]);
 const badge = <span className="savory-preparation-badge"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" focusable="false"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg><span>{estimate.live ? (pl ? "Aktualny czas przygotowania:" : "Current preparation time:") : (pl ? "Przygotowanie:" : "Preparation:")}<span className="savory-preparation-duration" style={{display:"block",whiteSpace:"nowrap"}}>{pl ? `około ${estimate.minutes} minut` : `approx. ${estimate.minutes} min`}</span></span></span>;
 if(compact) return badge;
 return <details className="savory-preparation-note"><summary>{badge}<span aria-hidden="true" className="savory-composition-toggle" /></summary><p>{pl ? "Każde danie komponujemy na bieżąco ze świeżych składników wysokiej jakości. Podany czas jest orientacyjny i zależy od bieżącej kolejki zamówień. Przy większym ruchu oczekiwanie może być dłuższe." : "Every dish is assembled to order using fresh, high-quality ingredients. The time shown is an estimate based on the current order queue. Waiting times may be longer during busy periods."}</p></details>;
}
