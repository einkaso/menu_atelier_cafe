"use client";

import { isMulledWine } from "../../lib/wine-serving";
import { useMemo, useState } from "react";
import { alcoFilterTokens, tasteProfileTokens } from "../../lib/taste-profiles";
import { ART_WHISKY_AGES, ART_WHISKY_ORIGINS, EMPTY_ART_WHISKY_FILTERS, matchesArtWhiskyProduct, type ArtWhiskyFilters, type ArtWhiskySection } from "../../lib/art-whisky";
import { Dialog, DialogContent, DialogTitle } from "../ui/dialog";

export type { ArtWhiskyFilters } from "../../lib/art-whisky";

type Lang = "pl" | "en";
type Offer = { kind: "glass" | "serving" | "bottle"; price: string };
export type ArtFinderProduct = {
  id?: number;
  pl: string;
  en: string;
  descPl?: string;
  descEn?: string;
  image?: string;
  country?: string;
  countryEn?: string;
  kind?: string;
  wineColor?: string;
  taste?: string;
  tasteEn?: string;
  sparklingType?: "SPARKLING" | "NATURALLY_SPARKLING";
  vegan?: boolean;
  alcoholFree?: boolean;
  byGlass?: boolean;
  offers?: Offer[];
  attributes?: Record<string, string>;
  attributesEn?: Record<string, string>;
};

export type ArtWineFilters = {
  colors: string[];
  tastes: string[];
  bubbles: string[];
  serving: string[];
  features: string[];
  countries: string[];
};

export type ArtCocktailFilters = {
  moods: string[];
  bases: string[];
  types: string[];
  tastes: string[];
  servings: string[];
};

const EMPTY_WINE_FILTERS: ArtWineFilters = { colors: [], tastes: [], bubbles: [], serving: [], features: [], countries: [] };
const EMPTY_COCKTAIL_FILTERS: ArtCocktailFilters = { moods: [], bases: [], types: [], tastes: [], servings: [] };

function normalized(value: string) {
  return value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/ł/g, "l").toLocaleLowerCase("pl");
}

function toggle(values: string[], value: string) {
  return values.includes(value) ? values.filter(item => item !== value) : [...values, value];
}

function intersects(selected: string[], actual: string[]) {
  return selected.length === 0 || selected.some(value => actual.includes(value));
}

function wineColor(product: ArtFinderProduct) {
  return product.wineColor || product.kind || "";
}

function wineBubble(product: ArtFinderProduct) {
  return product.sparklingType || "STILL";
}

function wineServing(product: ArtFinderProduct) {
  const values = new Set<string>(product.offers?.map(offer => offer.kind) ?? []);
  if (product.byGlass) values.add("glass");
  if (isMulledWine(product)) values.add("mulled");
  if (!values.size || values.has("bottle")) values.add("bottle");
  return [...values];
}

function wineFeatures(product: ArtFinderProduct) {
  return [product.vegan ? "vegan" : "", product.alcoholFree ? "zero" : ""].filter(Boolean);
}

export function matchesArtWineProduct(product: ArtFinderProduct, filters: ArtWineFilters) {
  return intersects(filters.colors, [wineColor(product)])
    && intersects(filters.tastes, [product.taste || ""])
    && intersects(filters.bubbles, [wineBubble(product)])
    && intersects(filters.serving, wineServing(product))
    && intersects(filters.features, wineFeatures(product))
    && intersects(filters.countries, [product.country || ""]);
}

function cocktailTokens(product: ArtFinderProduct, key: string) {
  return alcoFilterTokens(key, product.attributes?.[key]);
}

function moodMatches(product: ArtFinderProduct, mood: string) {
  const types = cocktailTokens(product, "cocktailType").map(normalized);
  const bases = cocktailTokens(product, "cocktailBase").map(normalized);
  const tastes = tasteProfileTokens(product.attributes?.tasteProfile).map(normalized);
  if (mood === "light") return types.some(value => /spritz/.test(value));
  if (mood === "sour") return types.some(value => /sour/.test(value)) || tastes.some(value => /cytrus|kwasn/.test(value));
  if (mood === "sweet") return tastes.some(value => /slod|krem|karmel|wanil/.test(value));
  if (mood === "dry") return tastes.some(value => /wytrawn|ziol|gorz/.test(value)) || bases.some(value => /aperitif|bitter/.test(value));
  if (mood === "fruit") return tastes.some(value => /owoc/.test(value));
  return mood === "zero" && Boolean(product.alcoholFree);
}

function includesAll(selected: string[], actual: string[]) {
  const values = actual.map(normalized);
  return selected.every(value => values.includes(normalized(value)));
}

export function matchesArtCocktailProduct(product: ArtFinderProduct, filters: ArtCocktailFilters) {
  return (filters.moods.length === 0 || filters.moods.every(mood => moodMatches(product, mood)))
    && includesAll(filters.bases, cocktailTokens(product, "cocktailBase"))
    && includesAll(filters.types, cocktailTokens(product, "cocktailType"))
    && includesAll(filters.tastes, tasteProfileTokens(product.attributes?.tasteProfile))
    && includesAll(filters.servings, cocktailTokens(product, "servingStyle"));
}

function ArtFilterCount({ count, lang, onClear, changed, label: customLabel, compact = false }: { count: number; lang: Lang; onClear: () => void; changed: boolean; label?: string; compact?: boolean }) {
  const label = customLabel || (lang === "pl" ? (count === 1 ? "wino pasuje" : count >= 2 && count <= 4 ? "wina pasują" : "win pasuje") : count === 1 ? "wine matches" : "wines match");
  return <div className="art-filter-count"><span aria-label={compact ? `${count} ${label}` : undefined}>{count}</span><div>{!compact ? <b>{label}</b> : null}{changed ? <button type="button" onClick={onClear}>{lang === "pl" ? "Wyczyść" : "Clear"}</button> : null}</div></div>;
}

function ArtFilterPills({ options, selected, onToggle, disabled = new Set(), ariaLabel }: { options: Array<{ value: string; label: string }>; selected: string[]; onToggle: (value: string) => void; disabled?: Set<string>; ariaLabel: string }) {
  return <div className="art-filter-pills" role="group" aria-label={ariaLabel}>{options.map(option => <button type="button" key={option.value} aria-pressed={selected.includes(option.value)} className={selected.includes(option.value) ? "is-selected" : ""} disabled={disabled.has(option.value) && !selected.includes(option.value)} onClick={() => onToggle(option.value)}>{option.label}</button>)}</div>;
}

function ArtFilterScale({ options, selected, onToggle, disabled = new Set(), ariaLabel }: { options: Array<{ value: string; label: string }>; selected: string[]; onToggle: (value: string) => void; disabled?: Set<string>; ariaLabel: string }) {
  return <div className="art-filter-scale" role="group" aria-label={ariaLabel}>{options.map(option => <button type="button" key={option.value} aria-pressed={selected.includes(option.value)} className={selected.includes(option.value) ? "is-selected" : ""} disabled={disabled.has(option.value) && !selected.includes(option.value)} onClick={() => onToggle(option.value)}><i/><span>{option.label}</span></button>)}</div>;
}

function disabledWineOptions(products: ArtFinderProduct[], filters: ArtWineFilters, group: keyof ArtWineFilters, options: string[]) {
  return new Set(options.filter(value => {
    if (filters[group].includes(value)) return false;
    const candidate = { ...filters, [group]: [...filters[group], value] };
    return !products.some(product => matchesArtWineProduct(product, candidate));
  }));
}

export function ArtWineFinder({ lang, products, filters, onChange }: { lang: Lang; products: ArtFinderProduct[]; filters: ArtWineFilters; onChange: (filters: ArtWineFilters) => void }) {
  const L = (pl: string, en: string) => lang === "pl" ? pl : en;
  const [open, setOpen] = useState(false);
  const showResults = () => { setOpen(false); requestAnimationFrame(() => document.querySelector(".art-catalog-page.is-wine .art-catalog-featured, .art-catalog-page.is-wine .art-catalog-group, .art-catalog-page.is-wine .art-finder-empty")?.scrollIntoView({behavior:"smooth",block:"start"})); };
  const colorOrder = ["Białe", "Różowe", "Pomarańczowe", "Czerwone"];
  const colorDots: Record<string, string> = { "Białe": "#EAD98B", "Różowe": "#F2A7B5", "Pomarańczowe": "#F2A14A", "Czerwone": "#7A1730" };
  const tasteOrder = ["Wytrawne", "Półwytrawne", "Półsłodkie", "Słodkie"];
  const colors = colorOrder.filter(value => products.some(product => wineColor(product) === value));
  const tastes = tasteOrder.filter(value => products.some(product => product.taste === value));
  const bubbles = ["STILL", "SPARKLING", "NATURALLY_SPARKLING"];
  const serving = ["glass", "bottle", "mulled"];
  const features = ["vegan", "zero"];
  const countries = useMemo(() => {
    const counts = new Map<string, number>();
    products.forEach(product => { if (product.country) counts.set(product.country, (counts.get(product.country) || 0) + 1); });
    return [...counts].sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0], "pl")).map(([country]) => country);
  }, [products]);
  const count = products.filter(product => matchesArtWineProduct(product, filters)).length;
  const changed = Object.values(filters).some(values => values.length > 0);
  const set = (group: keyof ArtWineFilters, value: string) => onChange({ ...filters, [group]: toggle(filters[group], value) });
  const labels = {
    bubbles: [{ value: "STILL", label: L("Spokojne", "Still") }, { value: "SPARKLING", label: L("Musujące", "Sparkling") }, { value: "NATURALLY_SPARKLING", label: L("Naturalnie musujące", "Naturally sparkling") }],
    serving: [{ value: "glass", label: L("Na kieliszki", "By the glass") }, { value: "bottle", label: L("Na butelki", "By the bottle") }, { value: "mulled", label: L("Grzane", "Mulled") }],
    features: [{ value: "vegan", label: L("Wegańskie", "Vegan") }, { value: "zero", label: "0%" }],
  };
  return <>
    <section className="art-cocktail-finder-launch art-wine-launch" aria-label={L("Wyszukiwanie win", "Wine finder")}>
      <div><small>{L("Dobierz smak i sposób podania", "Choose flavour and serving style")}</small><h2><button type="button" className="art-finder-title-button" onClick={()=>setOpen(true)}>{L("Na jakie wino masz dziś ochotę?", "What kind of wine are you in the mood for?")}</button></h2></div>
      <button type="button" onClick={()=>setOpen(true)}>{L("Wybierz wino", "Choose wine")}<b>{count}</b></button>
      {changed ? <div className="art-active-filters"><button type="button" className="is-clear" onClick={()=>onChange(EMPTY_WINE_FILTERS)}>{L("Wyczyść filtry", "Clear filters")}</button></div> : null}
    </section>
    <Dialog open={open} onOpenChange={setOpen}><DialogContent className="art-cocktail-dialog art-wine-dialog" showCloseButton={false}>
      <header><div><small>{L("Dobierz smak i sposób podania", "Choose flavour and serving style")}</small><DialogTitle>{L("Na jakie wino masz dziś ochotę?", "What kind of wine are you in the mood for?")}</DialogTitle></div><button type="button" className="art-finder-close" aria-label={L("Zamknij wybór wina", "Close wine finder")} onClick={()=>setOpen(false)}>×</button></header>
      <div className="art-cocktail-dialog-body art-wine-dialog-body"><div className="art-catalog-page is-wine art-compact-heading"><section className="art-designed-finder art-wine-finder">
    <div className="art-wine-primary"><div className="art-filter-group"><b>{L("Kolor", "Colour")}</b><div className="art-wine-colors" role="group" aria-label={L("Kolor wina", "Wine colour")}>{colors.map(value => <button type="button" key={value} aria-pressed={filters.colors.includes(value)} className={filters.colors.includes(value) ? "is-selected" : ""} disabled={disabledWineOptions(products, filters, "colors", colors).has(value) && !filters.colors.includes(value)} onClick={() => set("colors", value)}><i style={{ background: colorDots[value] }}/><span>{L(value, value === "Białe" ? "White" : value === "Różowe" ? "Rosé" : value === "Pomarańczowe" ? "Orange" : "Red")}</span></button>)}</div></div>
      <div className="art-filter-group is-scale"><b>{L("Smak, od wytrawnego do słodkiego", "Taste, from dry to sweet")}</b><ArtFilterScale options={tastes.map(value => ({ value, label: L(value, value === "Wytrawne" ? "Dry" : value === "Półwytrawne" ? "Off-dry" : value === "Półsłodkie" ? "Medium-sweet" : "Sweet") }))} selected={filters.tastes} disabled={disabledWineOptions(products, filters, "tastes", tastes)} onToggle={value => set("tastes", value)} ariaLabel={L("Skala smaku", "Taste scale")}/></div>
    </div>
    <div className="art-filter-group"><b>{L("Bąbelki", "Bubbles")}</b><ArtFilterPills options={labels.bubbles} selected={filters.bubbles} disabled={disabledWineOptions(products, filters, "bubbles", bubbles)} onToggle={value => set("bubbles", value)} ariaLabel={L("Bąbelki", "Bubbles")}/></div>
    <div className="art-wine-secondary"><div className="art-filter-group"><b>{L("Podanie", "Serving")}</b><ArtFilterPills options={labels.serving} selected={filters.serving} disabled={disabledWineOptions(products, filters, "serving", serving)} onToggle={value => set("serving", value)} ariaLabel={L("Podanie", "Serving")}/></div><div className="art-filter-group"><b>{L("Cechy", "Features")}</b><ArtFilterPills options={labels.features} selected={filters.features} disabled={disabledWineOptions(products, filters, "features", features)} onToggle={value => set("features", value)} ariaLabel={L("Cechy", "Features")}/></div><div className="art-filter-group is-countries"><b>{L("Kraj", "Country")}</b><ArtFilterPills options={countries.map(value => ({ value, label: lang === "pl" ? value : products.find(product => product.country === value)?.countryEn || value }))} selected={filters.countries} disabled={disabledWineOptions(products, filters, "countries", countries)} onToggle={value => set("countries", value)} ariaLabel={L("Kraj", "Country")}/></div></div>
      </section></div></div>
      <footer><button type="button" className="art-filter-text-button" onClick={()=>onChange(EMPTY_WINE_FILTERS)}>{L("Wyczyść filtry", "Clear filters")}</button><button type="button" className="art-filter-primary" onClick={showResults}>{L(`Pokaż wyniki (${count})`, `Show results (${count})`)}</button></footer>
    </DialogContent></Dialog>
  </>;
}

const MOODS = [
  { id: "light", pl: "Lekkie i musujące", en: "Light and sparkling", examples: "spritze" },
  { id: "sour", pl: "Kwaśne i cytrusowe", en: "Sour and citrus", examples: "sour, margarita, daiquiri" },
  { id: "sweet", pl: "Słodkie i deserowe", en: "Sweet and dessert-like", examples: "espresso martini, tiramisu" },
  { id: "dry", pl: "Wytrawne i gorzkie", en: "Dry and bitter", examples: "negroni, me-groni" },
  { id: "fruit", pl: "Owocowe", en: "Fruity", examples: "raspberry refresh, frambuesa" },
  { id: "zero", pl: "Bez alkoholu", en: "Alcohol-free", examples: "drinki 0%" },
] as const;

export function ArtCocktailFinder({ lang, products, filters, onChange, mode = "cocktails", onShowResults }: { lang: Lang; products: ArtFinderProduct[]; filters: ArtCocktailFilters; onChange: (filters: ArtCocktailFilters) => void; mode?: "cocktails" | "shots"; onShowResults: () => void }) {
  const L = (pl: string, en: string) => lang === "pl" ? pl : en;
  const shots = mode === "shots";
  const title = shots ? L("Jakiego alkoholu dzisiaj szukasz?", "Which spirit are you looking for today?") : L("Na jaki koktajl masz dzisiaj ochotę?", "Which cocktail are you in the mood for today?");
  const count = products.filter(product => matchesArtCocktailProduct(product, filters)).length;
  const [open, setOpen] = useState(false);
  const [expanded, setExpanded] = useState(false);
  const bases = [...new Set(products.flatMap(product => cocktailTokens(product, "cocktailBase")))].sort((a,b)=>a.localeCompare(b,"pl"));
  const types = [...new Set(products.flatMap(product => cocktailTokens(product, "cocktailType")))];
  const tastes = [...new Set(products.flatMap(product => tasteProfileTokens(product.attributes?.tasteProfile)))];
  const servings = [...new Set(products.flatMap(product => cocktailTokens(product, "servingStyle")))];
  const changed = Object.values(filters).some(values => values.length > 0);
  const set = (group: keyof ArtCocktailFilters, value: string) => onChange({ ...filters, [group]: toggle(filters[group], value) });
  const activeLabels = [...filters.moods.map(value => MOODS.find(mood => mood.id === value)?.[lang] || value), ...filters.bases, ...filters.types, ...filters.tastes, ...filters.servings];
  const removeLabel = (label: string) => {
    const mood = MOODS.find(item => item[lang] === label);
    if (mood) return set("moods", mood.id);
    for (const group of ["bases", "types", "tastes", "servings"] as const) if (filters[group].includes(label)) return set(group, label);
  };
  const showResults = () => { setOpen(false); onShowResults(); window.requestAnimationFrame(() => document.querySelector(".art-catalog-group, .art-finder-empty")?.scrollIntoView({ behavior: "smooth", block: "start" })); };
  return <section className="art-cocktail-finder-launch" data-finder={mode}><div><small>{L("Dobierz smak i sposób podania", "Choose flavour and serving style")}</small><h2><button className="art-finder-title-button" type="button" onClick={() => setOpen(true)}>{title}</button></h2></div><button type="button" onClick={() => setOpen(true)}>{shots ? L("Wybierz alkohol", "Choose a spirit") : L("Dobierz koktajl", "Choose a cocktail")}<b>{count}</b></button>{changed ? <div className="art-active-filters" aria-label={L("Aktywne filtry", "Active filters")}>{activeLabels.map(label => <button type="button" key={label} onClick={() => removeLabel(label)}>{label}<span aria-hidden="true">×</span></button>)}<button type="button" className="is-clear" onClick={() => onChange(EMPTY_COCKTAIL_FILTERS)}>{L("Wyczyść wybór", "Clear selection")}</button></div> : null}
    <Dialog open={open} onOpenChange={setOpen}><DialogContent className="art-cocktail-dialog" showCloseButton={false}><header><div><small>{L("Dobierz smak i sposób podania", "Choose flavour and serving style")}</small><DialogTitle>{title}</DialogTitle></div><button type="button" className="art-finder-close" aria-label={L("Zamknij wybór drinka", "Close drink finder")} onClick={() => setOpen(false)}>×</button></header><div className="art-cocktail-dialog-body">{!shots ? <div className="art-mood-grid">{MOODS.map(mood => { const image = products.find(product => moodMatches(product, mood.id) && product.image)?.image || products.find(product => product.image)?.image || "/menu-art/kategoria-alko-bar.webp"; const selected = filters.moods.includes(mood.id); const disabled = !selected && !products.some(product => moodMatches(product, mood.id) && matchesArtCocktailProduct(product, { ...filters, moods: [...filters.moods, mood.id] })); return <button type="button" key={mood.id} aria-pressed={selected} className={selected ? "is-selected" : ""} onClick={() => set("moods", mood.id)}><span><img src={image} alt=""/>{selected ? <em>✓ {L("Wybrane", "Selected")}</em> : null}</span><strong>{mood[lang]}</strong><small>{mood.examples}</small></button>; })}</div> : null}<div className="art-cocktail-filter-row"><b>{shots ? L("Alkohol", "Spirit") : L("Na bazie", "Based on")}</b><ArtFilterPills options={bases.map(value => ({ value, label: value }))} selected={filters.bases} onToggle={value => set("bases", value)} ariaLabel={shots ? L("Alkohol", "Spirit") : L("Baza koktajlu", "Cocktail base")}/><button type="button" className="art-filter-text-button" aria-expanded={expanded} onClick={() => setExpanded(value => !value)}>{expanded ? L("Mniej filtrów", "Fewer filters") : L("Wszystkie filtry", "All filters")}</button></div>{expanded ? <div className="art-cocktail-more"><div className="art-filter-group"><b>{L("Rodzaj", "Type")}</b><ArtFilterPills options={types.map(value => ({ value, label: value }))} selected={filters.types} onToggle={value => set("types", value)} ariaLabel={L("Rodzaj", "Type")}/></div><div className="art-filter-group"><b>{L("Profil smaku", "Taste profile")}</b><ArtFilterPills options={tastes.map(value => ({ value, label: value }))} selected={filters.tastes} onToggle={value => set("tastes", value)} ariaLabel={L("Profil smaku", "Taste profile")}/></div><div className="art-filter-group"><b>{L("Podanie", "Serving")}</b><ArtFilterPills options={servings.map(value => ({ value, label: value }))} selected={filters.servings} onToggle={value => set("servings", value)} ariaLabel={L("Podanie", "Serving")}/></div></div> : null}</div><footer>{changed ? <button type="button" className="art-filter-text-button" onClick={() => onChange(EMPTY_COCKTAIL_FILTERS)}>{L("Wyczyść wybór", "Clear selection")}</button> : <span/>}<button type="button" className="art-filter-primary" onClick={showResults}>{count === products.length ? L("Pokaż wszystkie", "Show all") : L(`Pokaż ${count} pozycji`, `Show ${count} items`)}</button></footer></DialogContent></Dialog>
  </section>;
}

function disabledWhiskyOptions(products: ArtFinderProduct[], filters: ArtWhiskyFilters, group: keyof ArtWhiskyFilters, options: Array<string | number>) {
  return new Set(options.filter(value => {
    if ((filters[group] as Array<string | number>).includes(value)) return false;
    const candidate = { ...filters, [group]: [value] } as ArtWhiskyFilters;
    return !products.some(product => matchesArtWhiskyProduct(product, candidate));
  }));
}

export function ArtWhiskyFinder({ lang, products, filters, onChange }: { lang: Lang; products: ArtFinderProduct[]; filters: ArtWhiskyFilters; onChange: (filters: ArtWhiskyFilters) => void }) {
  const L = (pl: string, en: string) => lang === "pl" ? pl : en;
  const count = products.filter(product => matchesArtWhiskyProduct(product, filters)).length;
  const changed = filters.characters.length > 0 || filters.origins.length > 0 || filters.ages.length > 0;
  const characterOptions: Array<{ value: ArtWhiskySection; label: string }> = [
    { value: "smooth", label: L("Łagodne i miodowe", "Smooth and honeyed") },
    { value: "vanilla", label: L("Waniliowo-karmelowe", "Vanilla and caramel") },
    { value: "smoky", label: L("Dymne i torfowe", "Smoky and peated") },
  ];
  const selectedCognac = filters.characters.includes("cognac");
  const characterDisabled = disabledWhiskyOptions(products, filters, "characters", characterOptions.map(option => option.value));
  const cognacDisabled = disabledWhiskyOptions(products, filters, "characters", ["cognac"]).has("cognac");
  const originDisabled = disabledWhiskyOptions(products, filters, "origins", ART_WHISKY_ORIGINS);
  const ageDisabled = disabledWhiskyOptions(products, filters, "ages", ART_WHISKY_AGES);
  const setCharacter = (value: ArtWhiskySection) => onChange({ ...filters, characters: filters.characters.includes(value) ? [] : [value] });
  const setOrigin = (value: string) => onChange({ ...filters, origins: toggle(filters.origins, value) });
  const setAge = (value: number) => onChange({ ...filters, ages: filters.ages.includes(value) ? [] : [value] });
  const countLabel = L(count === 1 ? "butelka pasuje" : count >= 2 && count <= 4 ? "butelki pasują" : "butelek pasuje", count === 1 ? "bottle matches" : "bottles match");
  const originLabels: Record<string, string> = { Szkocja: "Scotland", Irlandia: "Ireland", USA: "USA", Francja: "France", Grecja: "Greece", Bułgaria: "Bulgaria" };
  return <section className="art-designed-finder art-whisky-finder" aria-label={L("Wyszukiwanie whisky, koniaków i brandy", "Whisky, cognac and brandy finder")}>
    <header><div><small>{L("Znajdź swój charakter", "Find your character")}</small><h2>{L("Na co masz dziś ochotę?", "What are you in the mood for?")}</h2></div><ArtFilterCount compact count={count} lang={lang} label={countLabel} changed={changed} onClear={() => onChange(EMPTY_ART_WHISKY_FILTERS)}/></header>
    <div className="art-whisky-character-row">
      <div className="art-filter-group is-scale"><b>{L("Charakter", "Character")}</b><ArtFilterScale options={characterOptions} selected={filters.characters} disabled={characterDisabled as Set<string>} onToggle={value => setCharacter(value as ArtWhiskySection)} ariaLabel={L("Charakter trunku", "Spirit character")}/></div>
      <span className="art-whisky-or">{L("Albo", "Or")}</span>
      <div className="art-filter-group is-cognac"><b>{L("Winne destylaty", "Wine distillates")}</b><ArtFilterPills options={[{ value: "cognac", label: L("Koniaki i brandy", "Cognac and brandy") }]} selected={selectedCognac ? ["cognac"] : []} disabled={cognacDisabled ? new Set(["cognac"]) : new Set()} onToggle={() => setCharacter("cognac")} ariaLabel={L("Koniaki i brandy", "Cognac and brandy")}/></div>
    </div>
    <div className="art-whisky-secondary">
      <div className="art-filter-group"><b>{L("Pochodzenie", "Origin")}</b><ArtFilterPills options={ART_WHISKY_ORIGINS.map(value => ({ value, label: lang === "pl" ? value : originLabels[value] }))} selected={filters.origins} disabled={originDisabled as Set<string>} onToggle={setOrigin} ariaLabel={L("Pochodzenie", "Origin")}/></div>
      <div className="art-filter-group"><b>{L("Wiek", "Age")}</b><ArtFilterPills options={ART_WHISKY_AGES.map(value => ({ value: String(value), label: L(`${value} lat i więcej`, `${value} years and older`) }))} selected={filters.ages.map(String)} disabled={new Set([...ageDisabled].map(String))} onToggle={value => setAge(Number(value))} ariaLabel={L("Wiek", "Age")}/></div>
    </div>
  </section>;
}

export function ArtSimpleFinder({ lang, eyebrow, title, count, changed, onClear, groups }: { lang: Lang; eyebrow: string; title: string; count: number; changed: boolean; onClear: () => void; groups: Array<{ label: string; ariaLabel: string; options: Array<{ value: string; label: string }>; selected: string[]; onToggle: (value: string) => void }> }) {
  const [open, setOpen] = useState(false);
  const L = (pl: string, en: string) => lang === "pl" ? pl : en;
  const showResults = () => { setOpen(false); requestAnimationFrame(() => document.querySelector(".art-catalog-page.is-beer .art-catalog-featured, .art-catalog-page.is-beer .art-catalog-group, .art-catalog-page.is-beer .art-finder-empty")?.scrollIntoView({behavior:"smooth",block:"start"})); };
  return <>
    <section className="art-cocktail-finder-launch art-beer-launch" aria-label={L("Wyszukiwanie piw", "Beer finder")}>
      <div><small>{eyebrow}</small><h2><button type="button" className="art-finder-title-button" onClick={()=>setOpen(true)}>{title}</button></h2></div>
      <button type="button" onClick={()=>setOpen(true)}>{L("Wybierz piwo", "Choose beer")}<b>{count}</b></button>
      {changed ? <div className="art-active-filters"><button type="button" className="is-clear" onClick={onClear}>{L("Wyczyść filtry", "Clear filters")}</button></div> : null}
    </section>
    <Dialog open={open} onOpenChange={setOpen}><DialogContent className="art-cocktail-dialog art-beer-dialog" showCloseButton={false}>
      <header><div><small>{eyebrow}</small><DialogTitle>{title}</DialogTitle></div><button type="button" className="art-finder-close" aria-label={L("Zamknij wybór piwa", "Close beer finder")} onClick={()=>setOpen(false)}>×</button></header>
      <div className="art-cocktail-dialog-body"><section className="art-designed-finder art-simple-finder"><div className="art-simple-groups">{groups.filter(group => group.options.length).map(group => <div className="art-filter-group" key={group.label}><b>{group.label}</b><ArtFilterPills options={group.options} selected={group.selected} onToggle={group.onToggle} ariaLabel={group.ariaLabel}/></div>)}</div></section></div>
      <footer><button type="button" className="art-filter-text-button" onClick={onClear}>{L("Wyczyść filtry", "Clear filters")}</button><button type="button" className="art-filter-primary" onClick={showResults}>{L(`Pokaż wyniki (${count})`, `Show results (${count})`)}</button></footer>
    </DialogContent></Dialog>
  </>;
}
