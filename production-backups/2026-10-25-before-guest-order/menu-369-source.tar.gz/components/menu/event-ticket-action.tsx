"use client";
import { useEffect, useState } from "react";

type Event = { id: string; ticketUrl?: string };
export function isClosedEvent(event: Event) {
  return event.id === "szkolenie-ai-podcast-macgadka";
}
export default function EventTicketAction({ event, lang }: { event: Event; lang: "pl" | "en" }) {
  const [tablet, setTablet] = useState(false);
  useEffect(() => {
    const ua = navigator.userAgent;
    setTablet(/iPad|Tablet|PlayBook|Silk/i.test(ua) || (/Android/i.test(ua) && !/Mobile/i.test(ua)) || (/Macintosh|MacIntel/i.test(ua + navigator.platform) && navigator.maxTouchPoints > 1));
  }, []);
  if (isClosedEvent(event)) return <span className="event-ticket-action is-closed">{lang === "pl" ? "Wydarzenie zamknięte" : "Private event"}</span>;
  if (!event.ticketUrl) return null;
  if (tablet) return <span className="event-ticket-action is-at-cafe">{lang === "pl" ? "Zakup bilet w kawiarni" : "Buy a ticket at the café"}</span>;
  return <a className="event-ticket-action" href={event.ticketUrl} target="_blank" rel="noopener noreferrer">{lang === "pl" ? "Kup bilet" : "Buy a ticket"}</a>;
}
